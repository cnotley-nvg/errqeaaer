export interface AppEnv {
  graphqlEndpoint: string;
  isLocalhost: boolean;
}

export const getAppEnv = (): AppEnv => {
  const { protocol, hostname } = window.location;
  const isLocalhost = hostname === 'localhost' || hostname === '127.0.0.1';

  // Local development
  if (isLocalhost) {
    // Respect VITE_GRAPHQL_ENDPOINT if provided, otherwise default to 4000
    const endpoint =
      import.meta.env.VITE_GRAPHQL_ENDPOINT?.trim() || 'http://localhost:4000/graphql';
    return { graphqlEndpoint: endpoint, isLocalhost: true };
  }

  // Runtime environment - use /api/* path on same domain
  return { graphqlEndpoint: `${protocol}//${hostname}/api/graphql`, isLocalhost: false };
};
