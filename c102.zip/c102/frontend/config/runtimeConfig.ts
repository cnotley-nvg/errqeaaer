export interface RuntimeConfig {
  unleash?: {
    apiUrl?: string;
    clientKey?: string;
    environment?: string;
  };
}

let runtimeConfig: RuntimeConfig | null = null;
let runtimeConfigPromise: Promise<RuntimeConfig | null> | null = null;

const parseConfig = (data: unknown): RuntimeConfig | null => {
  if (!data || typeof data !== 'object') {
    return null;
  }
  return data as RuntimeConfig;
};

export const loadRuntimeConfig = async (): Promise<RuntimeConfig | null> => {
  if (runtimeConfig) {
    return runtimeConfig;
  }

  if (!runtimeConfigPromise) {
    runtimeConfigPromise = fetch('/config.json', { cache: 'no-store' })
      .then((response) => (response.ok ? response.json() : null))
      .then((data) => {
        runtimeConfig = parseConfig(data);
        return runtimeConfig;
      })
      .catch(() => null);
  }

  return runtimeConfigPromise;
};

export const getRuntimeConfig = (): RuntimeConfig | null => runtimeConfig;
