import { getRuntimeConfig } from './runtimeConfig';

export interface UnleashConfig {
  url: string;
  clientKey: string;
  appName: string;
  environment: string;
  refreshInterval: number;
}

type Stage = 'beta' | 'gamma' | 'production';

const getStageFromHostname = (): Stage => {
  if (typeof window === 'undefined') return 'beta';
  const hostname = window.location.hostname;
  if (hostname.includes('beta')) return 'beta';
  if (hostname.includes('gamma')) return 'gamma';
  if (hostname.includes('prod')) return 'production';
  return 'beta';
};

const stage = getStageFromHostname();

export const getUnleashConfig = (): UnleashConfig => {
  const runtime = getRuntimeConfig()?.unleash;
  return {
    url:
      runtime?.apiUrl ||
      import.meta.env.VITE_UNLEASH_API_URL ||
      'https://prod.feature-flags-manager.realm.wwops.amazon.dev/api/frontend',
    clientKey: runtime?.clientKey || import.meta.env.VITE_UNLEASH_CLIENT_KEY || '',
    appName: 'mosaic',
    environment: runtime?.environment || import.meta.env.VITE_UNLEASH_ENVIRONMENT || stage,
    refreshInterval: 60,
  };
};

export enum FeatureFlag {
  MosaicTestBanner = 'MosaicTestBanner',
}

export const isUnleashConfigured = (): boolean => {
  return Boolean(getUnleashConfig().clientKey);
};
