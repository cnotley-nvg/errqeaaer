import { useState, useMemo, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  SpaceBetween,
  Grid,
  Container,
  Header,
  Button,
  ContentLayout,
  Box,
  Alert,
} from '@amzn/awsui-components-console';
import { LocationMap } from '../components/optimize-design/LocationMap';
import {
  ProjectParametersForm,
  type ProjectParams,
} from '../components/optimize-design/ProjectParametersForm';
import { type AnalysisResult } from '../components/optimize-design/AnalysisResultCard';
import { calculateOptimizeDesign } from '../api/lightningProtection';
import { fetchElectricalLookupTable, calculateElectrical } from '../api/electricalBenchmark';
import { useLatestTemplateVersionsSearch } from '../hooks/useLatestTemplateVersionsSearch';
import { useAnalytics } from '../hooks/useAnalytics';

// Electrical calculation constants
const ELECTRICAL_CONSTANTS = {
  voltage: 480,
  solarPowerDensity: 10,
  roofFactor: 0.7,
};

const INITIAL_PARAMS: ProjectParams = {
  locationType: 'coordinates',
  streetAddress: '',
  country: '',
  city: '',
  zipcode: '',
  latitude: '',
  longitude: '',
  facilityType: '',
  designTemplate: '',
  designTemplateName: '',
  squareFootage: '',
  length: '',
  width: '',
  height: '',
};

type FieldErrors = Partial<Record<keyof ProjectParams, string>>;

export const OptimizeDesign = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const locationState = location.state as { params?: ProjectParams } | null;
  const [params, setParams] = useState<ProjectParams>(locationState?.params || INITIAL_PARAMS);
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});
  const [calculating, setCalculating] = useState(false);
  const { trackDesignOptimization, trackError } = useAnalytics();

  // Fetch template versions to resolve template ID to version ID
  const filter = useMemo(
    () => ({
      pageIdx: 0,
      limit: 1000,
      orderBy: 'name' as const,
      orderDesc: false,
    }),
    []
  );
  const { items: templateVersions } = useLatestTemplateVersionsSearch({ filter });

  const update = useCallback(
    (field: keyof ProjectParams, value: string) => {
      if (field === 'designTemplate') {
        const selectedVersion = templateVersions.find((v) => v.template.id === value);
        const templateName = selectedVersion?.template.name || value;
        setParams((prev) => ({ ...prev, designTemplate: value, designTemplateName: templateName }));
      } else {
        setParams((prev) => ({ ...prev, [field]: value }));
      }
      setFieldErrors((prev) => {
        const updated = { ...prev };
        delete updated[field];
        return updated;
      });
    },
    [templateVersions]
  );

  const handleAddressUpdate = (address: string, city: string, zipcode: string, country: string) => {
    setParams((prev) => ({ ...prev, streetAddress: address, city, zipcode, country }));
    setFieldErrors((prev) => {
      const updated = { ...prev };
      delete updated.streetAddress;
      delete updated.zipcode;
      return updated;
    });
  };

  const handleCoordinatesUpdate = (latitude: number, longitude: number) => {
    setParams((prev) => ({
      ...prev,
      latitude: latitude.toString(),
      longitude: longitude.toString(),
    }));
    setFieldErrors((prev) => {
      const updated = { ...prev };
      delete updated.latitude;
      delete updated.longitude;
      return updated;
    });
  };

  const handleMapClick = (latitude: number, longitude: number) => {
    setParams((prev) => ({
      ...prev,
      latitude: latitude.toFixed(6),
      longitude: longitude.toFixed(6),
      locationType: 'coordinates',
    }));
    setFieldErrors((prev) => {
      const updated = { ...prev };
      delete updated.latitude;
      delete updated.longitude;
      return updated;
    });
  };

  const validateNumericRange = (value: string, min?: number, max?: number): string | undefined => {
    if (!value) return undefined;
    const num = parseFloat(value);
    if (isNaN(num)) return 'Must be a number';
    if (min !== undefined && num < min) return `Must be at least ${min}`;
    if (max !== undefined && num > max) return `Must be at most ${max}`;
    return undefined;
  };

  const validatePositiveNumber = (value: string): string | undefined => {
    if (!value) return undefined;
    const num = parseFloat(value);
    if (isNaN(num)) return 'Must be a positive number';
    if (num <= 0) return 'Must be a positive number';
    return undefined;
  };

  const validateFields = (): FieldErrors => {
    const errors: FieldErrors = {};
    if (params.locationType === 'coordinates') {
      if (!params.latitude) errors.latitude = 'Latitude is required';
      else {
        const latError = validateNumericRange(params.latitude, -90, 90);
        if (latError) errors.latitude = latError;
      }
      if (!params.longitude) errors.longitude = 'Longitude is required';
      else {
        const lonError = validateNumericRange(params.longitude, -180, 180);
        if (lonError) errors.longitude = lonError;
      }
    } else {
      if (!params.streetAddress) errors.streetAddress = 'Street address is required';
      if (!params.zipcode) errors.zipcode = 'Zip/Postal code is required';
    }
    if (!params.designTemplate) errors.designTemplate = 'Design template is required';
    if (!params.squareFootage) errors.squareFootage = 'Total square footage is required';
    else {
      const sqftError = validatePositiveNumber(params.squareFootage);
      if (sqftError) errors.squareFootage = sqftError;
    }
    if (params.length) {
      const lengthError = validatePositiveNumber(params.length);
      if (lengthError) errors.length = lengthError;
    }
    if (params.width) {
      const widthError = validatePositiveNumber(params.width);
      if (widthError) errors.width = widthError;
    }
    if (params.height) {
      const heightError = validatePositiveNumber(params.height);
      if (heightError) errors.height = heightError;
    }
    return errors;
  };

  const handleReset = () => {
    setParams(INITIAL_PARAMS);
    setFieldErrors({});
  };

  const handleOptimize = async () => {
    const errors = validateFields();
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      return;
    }
    setFieldErrors({});
    setCalculating(true);

    try {
      const calculatedAnalyses: AnalysisResult[] = [];

      try {
        const input: any = {
          latitude: parseFloat(params.latitude),
          longitude: parseFloat(params.longitude),
          squareFootage: parseFloat(params.squareFootage),
        };
        if (params.facilityType) input.facilityType = params.facilityType;
        if (params.length) input.length = parseFloat(params.length);
        if (params.width) input.width = parseFloat(params.width);
        if (params.height) input.height = parseFloat(params.height);
        const result = await calculateOptimizeDesign(input);

        // Lightning Protection
        if (result.lightningProtection.recommendation === 'not-provided') {
          calculatedAnalyses.push({
            title: 'Lightning protection',
            description: result.lightningProtection.error || 'Building dimensions required',
            recommendation: 'not-provided',
            error: true,
          });
        } else {
          const lightningDescription =
            result.lightningProtection.recommendation === 'required'
              ? 'A lightning protection system is recommended to be installed based on a risk assessment factoring in lighting strike data in this region and building characteristics.'
              : 'A lightning protection system is optional based on a risk assessment factoring in lighting strike data in this region and building characteristics.';

          calculatedAnalyses.push({
            title: 'Lightning protection',
            description: lightningDescription,
            recommendation: result.lightningProtection.recommendation,
            downloadable: true,
          });
        }

        // Wind Loading - show error if service fails
        if (result.windLoading?.error) {
          calculatedAnalyses.push({
            title: 'Wind loading',
            description: result.windLoading.error,
            recommendation: 'optional',
            error: true,
          });
        } else if (result.windLoading) {
          const windLoadingDescription =
            result.windLoading.recommendation === 'required'
              ? 'Wind loading analysis indicates that ACLW (Above Code Level Wind) design guidelines are required for this location.'
              : 'Wind loading analysis indicates that ACLW (Above Code Level Wind) design guidelines are not required for this location.';

          calculatedAnalyses.push({
            title: 'Wind loading',
            description: windLoadingDescription,
            recommendation: result.windLoading.recommendation || 'optional',
            downloadable: true,
          });
        }

        // Heat Index Calculation
        if (result.heatIndex) {
          if (result.heatIndex.error) {
            calculatedAnalyses.push({
              title: 'Mechanical/Heat index',
              description: result.heatIndex.error,
              recommendation: 'optional',
              error: true,
            });
          } else {
            calculatedAnalyses.push({
              title: 'Mechanical/Heat index',
              description: result.heatIndex.hvacRecommendation,
              recommendation: result.heatIndex.recommendation,
              downloadable: true,
              heatIndexData: result.heatIndex,
            });
          }
        }
      } catch (err) {
        calculatedAnalyses.push({
          title: 'Lightning protection',
          description: err instanceof Error ? err.message : 'Unable to calculate',
          recommendation: 'optional',
          error: true,
        });
      }

      // Electrical Power Demand Calculation
      try {
        // Find the selected template version
        const selectedVersion = templateVersions.find(
          (version) => version.template.id === params.designTemplate
        );

        if (!selectedVersion) {
          throw new Error('Template version not found');
        }

        // Fetch lookup table for the selected template
        const lookupData = await fetchElectricalLookupTable(selectedVersion.id);

        if (!lookupData.electricalLoadLookupsByTemplateVersion?.length) {
          // No lookup table found - show error similar to Wind Loading
          calculatedAnalyses.push({
            title: 'Electrical benchmarking',
            description:
              'Unable to calculate electrical power analysis. Lookup table is not found.',
            recommendation: 'optional',
            error: true,
            templateVersionId: selectedVersion.template.id,
          });
        } else {
          // Calculate electrical with lookup table
          const electricalResult = await calculateElectrical({
            latitude: parseFloat(params.latitude),
            longitude: parseFloat(params.longitude),
            voltage: ELECTRICAL_CONSTANTS.voltage,
            area: parseFloat(params.squareFootage),
            roofFactor: ELECTRICAL_CONSTANTS.roofFactor,
            solarPowerDensity: ELECTRICAL_CONSTANTS.solarPowerDensity,
            lookupTable: lookupData.electricalLoadLookupsByTemplateVersion,
          });

          calculatedAnalyses.push({
            title: 'Electrical benchmarking',
            description:
              'Estimated power demand calculations for the site based on facility type and square footage.',
            recommendation: 'optional',
            downloadable: true,
            electricalData: electricalResult.calculateElectrical,
            state: electricalResult.calculateElectrical.state,
          });
        }
      } catch (err) {
        calculatedAnalyses.push({
          title: 'Electrical benchmarking',
          description:
            err instanceof Error ? err.message : 'Unable to calculate electrical analysis',
          recommendation: 'optional',
          error: true,
        });
      }

      // Track successful optimization
      trackDesignOptimization({
        squareFootage: parseFloat(params.squareFootage),
        designTemplate: params.designTemplateName,
        analysisCount: calculatedAnalyses.length,
        hasLightningProtection: calculatedAnalyses.some((a) => a.title === 'Lightning protection'),
        hasWindLoading: calculatedAnalyses.some((a) => a.title === 'Wind loading'),
        hasElectrical: calculatedAnalyses.some((a) => a.title === 'Electrical benchmarking'),
      });

      navigate('/optimize-design/result', {
        state: {
          params,
          analyses: calculatedAnalyses,
        },
      });
    } catch (err) {
      trackError({
        errorType: 'DESIGN_OPTIMIZATION_FAILED',
        errorMessage: err instanceof Error ? err.message : 'Unknown error',
        context: 'OptimizeDesign.handleOptimize',
      });
    } finally {
      setCalculating(false);
    }
  };

  return (
    <ContentLayout
      header={
        <Header
          variant="h1"
          description="Fine-tune your project parameters to generate the most efficient and cost-effective solution tailored to your specific requirements."
        >
          Optimize your design
        </Header>
      }
    >
      <SpaceBetween size="l">
        <Alert type="info" dismissible={false}>
          Calculations are currently available for <strong>North America</strong> locations only.
          Support for additional regions will be added in future updates.
        </Alert>
        <Container disableContentPaddings>
          <div style={{ display: 'flex', minHeight: '700px' }}>
            <div
              style={{ width: '500px', flexShrink: 0, display: 'flex', flexDirection: 'column' }}
            >
              <ProjectParametersForm params={params} onChange={update} errors={fieldErrors} />
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
              <LocationMap
                address={params.streetAddress}
                zipcode={params.zipcode}
                latitude={params.latitude}
                longitude={params.longitude}
                onAddressUpdate={handleAddressUpdate}
                onCoordinatesUpdate={handleCoordinatesUpdate}
                onMapClick={handleMapClick}
              />
            </div>
          </div>
        </Container>

        <Box float="right">
          <SpaceBetween direction="horizontal" size="xs">
            <Button onClick={handleReset}>Clear all</Button>
            <Button variant="primary" onClick={handleOptimize} loading={calculating}>
              Optimize design
            </Button>
          </SpaceBetween>
        </Box>
      </SpaceBetween>
    </ContentLayout>
  );
};
