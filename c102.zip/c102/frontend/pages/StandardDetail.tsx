import React, { useMemo } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import {
  Alert,
  Box,
  Button,
  Link,
  SpaceBetween,
  StatusIndicator,
  type TabsProps,
} from '@amzn/awsui-components-console';
import { gql } from 'graphql-request';

import { PageLayout } from '../components/PageLayout';
import { useStandardDetail } from '../hooks/useStandardDetail';
import {
  DetailTabs,
  PlaceholderSection,
  StandardOverview,
  StandardVersionHistory,
  StandardKeyItems,
  StandardReferences,
} from '../components/standards';
import {
  useStandardDetailTabs,
  useStandardDocumentLinks,
  useStandardVersionKeyItems,
  useStandardVersionReferences,
} from '../components/standards';
import { graphqlClient } from '../api/graphqlClient';

type TabId = 'overview' | 'versions' | 'key-items' | 'references';

const StandardDetail: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { id } = useParams<{ id: string }>();
  const { standard, loading, error } = useStandardDetail(id);
  const latestVersionId = standard?.latestVersion?.id ?? null;
  const documentState = useStandardDocumentLinks(latestVersionId);
  const [keyItemsSort, setKeyItemsSort] = React.useState<
    { field: 'category' | 'sheet'; desc: boolean }[]
  >([{ field: 'sheet', desc: false }]);
  const [keyItemsPageIdx, setKeyItemsPageIdx] = React.useState(0);
  const [keyItemsPageSize] = React.useState(20);
  const [keyItemsFilter, setKeyItemsFilter] = React.useState('');
  const [isDownloading, setIsDownloading] = React.useState(false);
  const [downloadError, setDownloadError] = React.useState<string | null>(null);
  const {
    items: keyItems,
    loading: keyItemsLoading,
    error: keyItemsError,
  } = useStandardVersionKeyItems(
    latestVersionId,
    keyItemsSort[0]?.field ?? 'sheet',
    keyItemsSort[0]?.desc ?? false
  );

  const [referencesPageIdx, setReferencesPageIdx] = React.useState(0);
  const [referencesPageSize] = React.useState(10);
  const [referencesSort, setReferencesSort] = React.useState<
    { field: 'specification' | 'name' | 'createdAt' | 'ownedBy'; desc: boolean }[]
  >([
    { field: 'specification', desc: false },
    { field: 'name', desc: true },
    { field: 'createdAt', desc: false },
  ]);
  const [referencesFilter, setReferencesFilter] = React.useState('');

  const {
    items: references,
    loading: referencesLoading,
    error: referencesError,
    total: referencesTotal,
    pageIdx: referencesPageIdxResult,
    pageSize: referencesPageSizeResult,
    hasNext: referencesHasNext,
  } = useStandardVersionReferences(latestVersionId, {
    pageIdx: referencesPageIdx,
    pageSize: referencesPageSize,
    sort: referencesSort,
    nameFilter: referencesFilter,
  });
  const [activeTabId, setActiveTabId] = React.useState<TabId>('overview');
  const handleTabChange = React.useCallback((tabId: string) => {
    setActiveTabId(tabId as TabId);
  }, []);

  const breadcrumbs = useMemo(
    () => {
      const search = location.search; // Capture in closure
      return [
        { text: 'Home', href: '/' },
        { text: 'Browse standards', href: `/standards${search}` },
        { text: standard?.name ?? 'Standard detail', href: `/standards/${id ?? ''}` },
      ];
    },
    [location.search, standard?.name, id] // Explicit dependencies
  );

  const headerDescription = standard?.description?.trim() || undefined;

  // Handle download with custom filename - lazy URL generation
  const handleDownload = React.useCallback(async () => {
    if (!latestVersionId || !standard?.latestVersion || isDownloading) {
      return;
    }

    setIsDownloading(true);
    setDownloadError(null);

    try {
      // Step 1: Fetch download URL on-demand (always fresh)
      const response = await graphqlClient.request<{
        standardDocumentLinks: { downloadUrl?: string | null } | null;
      }>(
        gql`
          query StandardDocumentLinks($standardVersionId: ID!) {
            standardDocumentLinks(standardVersionId: $standardVersionId) {
              downloadUrl
            }
          }
        `,
        { standardVersionId: latestVersionId }
      );

      const downloadUrl = response.standardDocumentLinks?.downloadUrl;
      if (!downloadUrl) {
        throw new Error('Download URL not available');
      }

      // Step 2: Construct filename: StandardName_Version.pdf
      const filename = `${standard.name.replace(/\s+/g, '_')}_${standard.latestVersion.version}.pdf`;

      // Step 3: Fetch the file as a blob
      const fileResponse = await fetch(downloadUrl);
      if (!fileResponse.ok) {
        throw new Error('Failed to download file');
      }

      const blob = await fileResponse.blob();

      // Step 4: Create a blob URL and trigger download
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Clean up blob URL after a short delay
      setTimeout(() => URL.revokeObjectURL(blobUrl), 100);
    } catch (error) {
      console.error('Download failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Download failed';
      setDownloadError(errorMessage);
    } finally {
      setIsDownloading(false);
    }
  }, [latestVersionId, standard, isDownloading]);

  const handleRequestChange = React.useCallback(() => {
    window.open(
      'https://einsight.eng-services.a2z.com/#/Laminar/createTicket/85527',
      '_blank',
      'noopener,noreferrer'
    );
  }, []);

  const headerActions = useMemo(() => {
    if (!standard) {
      return undefined;
    }

    return (
      <SpaceBetween direction="horizontal" size="xs">
        <Button iconName="external" onClick={handleRequestChange}>
          Request change
        </Button>
        <Button
          variant="primary"
          onClick={handleDownload}
          disabled={!latestVersionId || isDownloading}
          loading={isDownloading}
        >
          Download
        </Button>
      </SpaceBetween>
    );
  }, [handleDownload, handleRequestChange, isDownloading, latestVersionId, standard]);

  const header = useMemo(() => {
    if (!standard) {
      return null;
    }

    return {
      title: standard.name,
      description: headerDescription,
      actions: headerActions,
    };
  }, [headerActions, headerDescription, standard]);

  const overviewContent = useMemo(() => {
    if (!standard) {
      return null;
    }

    return (
      <StandardOverview
        standard={standard}
        standardName={standard.name}
        documentState={documentState}
      />
    );
  }, [documentState, standard]);

  // Client-side filtering and pagination for key items
  const { filteredKeyItems, paginatedKeyItems, totalKeyItems } = useMemo(() => {
    // Apply filter
    const filtered = keyItemsFilter
      ? keyItems.filter((item) =>
          item.category.toLowerCase().includes(keyItemsFilter.toLowerCase())
        )
      : keyItems;

    // Apply pagination
    const startIdx = keyItemsPageIdx * keyItemsPageSize;
    const endIdx = startIdx + keyItemsPageSize;
    const paginated = filtered.slice(startIdx, endIdx);

    return {
      filteredKeyItems: filtered,
      paginatedKeyItems: paginated,
      totalKeyItems: filtered.length,
    };
  }, [keyItems, keyItemsFilter, keyItemsPageIdx, keyItemsPageSize]);

  const tabs = useMemo<TabsProps.Tab[]>(
    () => [
      {
        id: 'overview',
        label: 'Overview details',
        content: overviewContent ?? (
          <PlaceholderSection title="Overview details" message="No overview available." />
        ),
      },
      {
        id: 'versions',
        label: 'Version history',
        content: standard?.versions?.length ? (
          <StandardVersionHistory versions={standard.versions} />
        ) : (
          <PlaceholderSection title="Version history" message="No version history available." />
        ),
      },
      {
        id: 'key-items',
        label: 'Key items',
        content: (
          <StandardKeyItems
            items={paginatedKeyItems}
            loading={keyItemsLoading}
            error={keyItemsError}
            sort={keyItemsSort}
            onSortingChange={setKeyItemsSort}
            pageIdx={keyItemsPageIdx}
            pageSize={keyItemsPageSize}
            total={totalKeyItems}
            hasNext={(keyItemsPageIdx + 1) * keyItemsPageSize < totalKeyItems}
            onPageChange={setKeyItemsPageIdx}
            filterValue={keyItemsFilter}
            onFilterChange={(value) => {
              setKeyItemsFilter(value);
              setKeyItemsPageIdx(0);
            }}
          />
        ),
      },
      {
        id: 'references',
        label: 'References',
        content: (
          <StandardReferences
            items={references}
            loading={referencesLoading}
            error={referencesError}
            sort={referencesSort}
            pageIdx={referencesPageIdxResult}
            pageSize={referencesPageSizeResult}
            total={referencesTotal}
            hasNext={referencesHasNext}
            onSortingChange={(newSort) => {
              const primary = newSort[0];
              if (!primary) return;

              let composed: {
                field: 'specification' | 'name' | 'createdAt' | 'ownedBy';
                desc: boolean;
              }[] = [primary as any];

              if (primary.field === 'specification') {
                composed = [
                  { field: 'specification', desc: primary.desc },
                  { field: 'name', desc: true },
                  { field: 'createdAt', desc: false },
                ];
              } else if (primary.field === 'name') {
                composed = [
                  { field: 'name', desc: primary.desc },
                  { field: 'specification', desc: false },
                  { field: 'createdAt', desc: false },
                ];
              } else if (primary.field === 'createdAt') {
                composed = [
                  { field: 'createdAt', desc: primary.desc },
                  { field: 'specification', desc: false },
                  { field: 'name', desc: true },
                ];
              }

              setReferencesSort(composed);
              setReferencesPageIdx(0);
            }}
            filterValue={referencesFilter}
            onFilterChange={(value) => {
              setReferencesFilter(value);
              setReferencesPageIdx(0);
            }}
            onPageChange={(page) => {
              setReferencesPageIdx(page);
            }}
          />
        ),
      },
    ],
    [
      overviewContent,
      paginatedKeyItems,
      keyItemsLoading,
      keyItemsError,
      keyItemsSort,
      keyItemsPageIdx,
      keyItemsPageSize,
      keyItemsFilter,
      totalKeyItems,
      references,
      referencesLoading,
      referencesError,
      referencesTotal,
      referencesPageIdxResult,
      referencesPageSizeResult,
      referencesHasNext,
      referencesSort,
      referencesFilter,
      standard?.versions,
    ]
  );

  if (loading) {
    return (
      <PageLayout breadcrumbs={breadcrumbs}>
        <Box textAlign="center" padding="l">
          <StatusIndicator type="loading">Fetching standard</StatusIndicator>
        </Box>
      </PageLayout>
    );
  }

  if (error) {
    return (
      <PageLayout breadcrumbs={breadcrumbs}>
        <Alert type="error" header="Unable to load standard">
          {error}
        </Alert>
      </PageLayout>
    );
  }

  if (!standard) {
    return (
      <PageLayout breadcrumbs={breadcrumbs}>
        <Alert type="warning" header="Standard not found">
          The requested standard could not be located. Return to the{' '}
          <Link href={`/standards${location.search}`}>standards catalog</Link>.
        </Alert>
      </PageLayout>
    );
  }

  return (
    <PageLayout breadcrumbs={breadcrumbs} header={header ?? undefined}>
      <DetailTabs
        ariaLabel="Standard detail sections"
        activeTabId={activeTabId}
        onTabChange={handleTabChange}
        tabs={tabs}
      />
    </PageLayout>
  );
};

export { StandardDetail };
