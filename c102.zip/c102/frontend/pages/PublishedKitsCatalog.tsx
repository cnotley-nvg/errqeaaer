import React, { useCallback, useMemo } from 'react';
import { SpaceBetween, type TableProps } from '@amzn/awsui-components-console';
import { useLocation } from 'react-router-dom';

import { PageLayout } from '../components/PageLayout';
import { CatalogPagination } from '../components/shared/CatalogPagination';
import { CatalogErrorAlert } from '../components/shared/CatalogErrorAlert';
import { PublishedKitsTable, PublishedKitsToolbar } from '../components/kits/catalog';
import {
  CATALOG_PAGE_SIZE_OPTIONS,
  DEFAULT_CATALOG_PAGE_SIZE,
  TABLE_COLUMN_OPTIONS,
  useCatalogPreferences,
} from '../components/kits/catalog/preferences';
import { TablePreferencesButton } from '../components/shared/TablePreferencesButton';
import { usePublishedKitCatalogControls } from '../hooks/usePublishedKitCatalogControls';
import { usePublishedKitsSearch } from '../hooks/usePublishedKitsSearch';
import type { KitCatalogSortableField } from '../hooks/usePublishedKitCatalogPersistence';

export const PublishedKitsCatalog: React.FC = () => {
  const location = useLocation();
  const {
    preferences: catalogPrefs,
    updateTablePreferences,
    updatePageSizeFallback,
    resetToDefaults: resetPreferencesToDefaults,
  } = useCatalogPreferences();
  const {
    propertyFilterQuery,
    sortingField,
    sortingDescending,
    pageIndex,
    pageSize,
    filterInput,
    handlePropertyFilterChange,
    handleSortingChange,
    handlePageChange,
    handlePageSizeChange,
  } = usePublishedKitCatalogControls();

  const { items, total, totalPages, loading, error } = usePublishedKitsSearch({
    filter: filterInput,
  });

  // Toolbar: pagination on right side (if needed)
  const paginationControl =
    totalPages > 1 ? (
      <CatalogPagination
        currentPageIndex={pageIndex}
        pagesCount={totalPages}
        onPageChange={handlePageChange}
      />
    ) : null;

  const resetToDefaults = useCallback(() => {
    resetPreferencesToDefaults();
    updatePageSizeFallback(DEFAULT_CATALOG_PAGE_SIZE);
    handlePageSizeChange(DEFAULT_CATALOG_PAGE_SIZE);
  }, [resetPreferencesToDefaults, updatePageSizeFallback, handlePageSizeChange]);

  // Toolbar: preferences (gear). Published kits is table-only; we only expose page size here.
  const preferencesControl = (
    <TablePreferencesButton
      preferences={{
        pageSize: pageSize,
        contentDisplay: [...catalogPrefs.table.contentDisplay],
        wrapLines: catalogPrefs.table.wrapLines,
        stripedRows: catalogPrefs.table.stripedRows,
      }}
      onConfirm={(newPreferences) => {
        if (newPreferences.contentDisplay) {
          updateTablePreferences({
            contentDisplay: [...newPreferences.contentDisplay],
            wrapLines: newPreferences.wrapLines,
            stripedRows: newPreferences.stripedRows,
          });
        }
        if (newPreferences.pageSize !== undefined) {
          updatePageSizeFallback(newPreferences.pageSize);
          handlePageSizeChange(newPreferences.pageSize);
        }
      }}
      columnOptions={TABLE_COLUMN_OPTIONS}
      pageSizeOptions={CATALOG_PAGE_SIZE_OPTIONS}
      onResetDefaults={resetToDefaults}
      title="Table preferences"
      showTableOptions={false}
    />
  );

  const breadcrumbs = useMemo(
    () => [
      { text: 'Home', href: '/' },
      { text: 'Published kit of parts', href: `/kits${location.search}` },
    ],
    [location.search]
  );

  const header = useMemo(
    () => ({
      title: `Published kit of parts (${total})`,
      description: '',
      info: null,
    }),
    [total]
  );

  const handleTableSortingChange = useCallback<NonNullable<TableProps['onSortingChange']>>(
    (event) => {
      const field =
        (event.detail.sortingColumn?.sortingField as KitCatalogSortableField) ?? 'region';
      handleSortingChange(field, Boolean(event.detail.isDescending));
    },
    [handleSortingChange]
  );

  return (
    <PageLayout breadcrumbs={breadcrumbs} header={header}>
      <div
        style={{
          minWidth: 0,
        }}
      >
        <SpaceBetween size="l">
          <PublishedKitsToolbar
            propertyFilterQuery={propertyFilterQuery}
            onPropertyFilterChange={handlePropertyFilterChange}
            paginationControl={paginationControl}
            preferencesControl={preferencesControl}
          />

          <CatalogErrorAlert error={error} resourceLabel="kits" />

          <PublishedKitsTable
            items={items}
            loading={loading}
            sortingField={sortingField}
            sortingDescending={sortingDescending}
            onSortingChange={handleTableSortingChange}
            preferences={{
              contentDisplay: catalogPrefs.table.contentDisplay,
              wrapLines: catalogPrefs.table.wrapLines,
              stripedRows: catalogPrefs.table.stripedRows,
            }}
          />
        </SpaceBetween>
      </div>
    </PageLayout>
  );
};
