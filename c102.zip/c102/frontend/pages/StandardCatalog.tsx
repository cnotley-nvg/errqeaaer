import React, { useCallback, useMemo, useState } from 'react';
import { SpaceBetween, type PropertyFilterProps } from '@amzn/awsui-components-console';
import { useLocation } from 'react-router-dom';

import { PageLayout } from '../components/PageLayout';
import { useLatestStandardVersionsSearch } from '../hooks/useLatestStandardVersionsSearch';
import type { StandardVersionWithStandard } from '../hooks/useLatestStandardVersionsSearch';
import { useStandardCatalogControls } from '../hooks/useStandardCatalogControls';
import { useStandardFilterOptionsFromBackend } from '../hooks/useStandardFilterOptionsFromBackend';
import {
  StandardCardList,
  StandardTable,
  useStandardSorting,
  StandardCatalogToolbar,
} from '../components/standards';
import {
  useCatalogPreferences,
  CATALOG_PAGE_SIZE_OPTIONS,
  TABLE_COLUMN_OPTIONS,
  CARD_FIELD_OPTIONS,
  BreakpointEditor,
  DEFAULT_CATALOG_PAGE_SIZE,
} from '../components/standards/catalog/preferences';
import { CatalogPagination } from '../components/shared/CatalogPagination';
import { TablePreferencesButton } from '../components/shared/TablePreferencesButton';
import { CatalogErrorAlert } from '../components/shared/CatalogErrorAlert';
import { EmptyState } from '../components/common/EmptyState';

const STANDARD_FILTERING_PROPERTIES: ReadonlyArray<PropertyFilterProps.FilteringProperty> = [
  // Name (text search with multiple operators)
  {
    key: 'name',
    operators: ['=', '!=', ':', '!:'],
    propertyLabel: 'Name',
    groupValuesLabel: 'Name values',
  },

  // Single-value properties (dropdown select - use multiple operators for dropdown UI)
  {
    key: 'region',
    operators: ['=', '!='],
    propertyLabel: 'Region',
    groupValuesLabel: 'Region values',
  },
  {
    key: 'updateCadence',
    operators: ['=', '!='],
    propertyLabel: 'Update Cadence',
    groupValuesLabel: 'Update Cadence values',
  },
  {
    key: 'version',
    operators: ['=', '!=', ':', '!:'],
    propertyLabel: 'Version',
    groupValuesLabel: 'Version values',
  },

  // Multi-value properties (checkbox select - specify tokenType: 'enum' at operator level)
  {
    key: 'program',
    operators: [
      { operator: '=', tokenType: 'enum' } as const,
      { operator: '!=', tokenType: 'enum' } as const,
    ],
    propertyLabel: 'Program',
    groupValuesLabel: 'Program values',
  },
  {
    key: 'projectType',
    operators: [
      { operator: '=', tokenType: 'enum' } as const,
      { operator: '!=', tokenType: 'enum' } as const,
    ],
    propertyLabel: 'Project Type',
    groupValuesLabel: 'Project Type values',
  },
  {
    key: 'roomFeatureZone',
    operators: [
      { operator: '=', tokenType: 'enum' } as const,
      { operator: '!=', tokenType: 'enum' } as const,
    ],
    propertyLabel: 'Room/Feature/Zone',
    groupValuesLabel: 'Room/Feature/Zone values',
  },

  // ACC metadata fields
  {
    key: 'accCreatedBy',
    operators: ['=', '!=', ':', '!:'],
    propertyLabel: 'Created By',
    groupValuesLabel: 'Creator values',
  },
  {
    key: 'accUpdatedBy',
    operators: ['=', '!=', ':', '!:'],
    propertyLabel: 'Last Modified By',
    groupValuesLabel: 'Modifier values',
  },

  // Date properties
  {
    key: 'firstPublishedOn',
    operators: ['=', '!=', '>', '<', '>=', '<='],
    propertyLabel: 'Created Date',
    groupValuesLabel: 'Date values',
    defaultOperator: '>=',
  },
  {
    key: 'publishedOn',
    operators: ['=', '!=', '>', '<', '>=', '<='],
    propertyLabel: 'Last Modified Date',
    groupValuesLabel: 'Date values',
    defaultOperator: '>=',
  },
];

export const StandardCatalog: React.FC = () => {
  const location = useLocation();
  const {
    viewType,
    propertyFilterQuery,
    sortingField,
    sortingDescending,
    pageIndex,
    pageSize,
    filterInput,
    handleViewTypeChange,
    handlePropertyFilterChange,
    handleSortingChange,
    handlePageChange,
    handlePageSizeChange,
  } = useStandardCatalogControls();

  // Unified catalog preferences hook for managing view-specific UI settings
  const {
    preferences: catalogPrefs,
    updateTablePreferences,
    updateCardsPreferences,
    updatePageSizeFallback,
    resetToDefaults: resetPreferencesToDefaults,
  } = useCatalogPreferences();

  // Wrap resetToDefaults to also reset pageSize (which is managed via URL, not preferences)
  const resetToDefaults = useCallback(() => {
    // Reset UI preferences (columns, fields, breakpoints, etc.)
    resetPreferencesToDefaults();

    // Reset pageSize: save to versioned storage AND reset URL to default
    updatePageSizeFallback(DEFAULT_CATALOG_PAGE_SIZE);
    handlePageSizeChange(DEFAULT_CATALOG_PAGE_SIZE);
  }, [resetPreferencesToDefaults, updatePageSizeFallback, handlePageSizeChange]);

  const { items, loading, error, totalCount, totalPages, pageIdx } =
    useLatestStandardVersionsSearch({
      filter: filterInput,
    });

  // Fetch filter options from backend (all values from database, not just current page)
  const { filteringOptions } = useStandardFilterOptionsFromBackend();

  const [searchText, setSearchText] = useState<string>('');

  const handleSearchTextChange = useCallback((value: string) => {
    setSearchText(value);
  }, []);

  const handleSearchTokensChange = useCallback(
    (nextQuery: import('@amzn/awsui-collection-hooks').PropertyFilterQuery) => {
      handlePropertyFilterChange(nextQuery);
    },
    [handlePropertyFilterChange]
  );

  const { handleSortingChange: handleSortingEvent } = useStandardSorting({
    onSortChange: handleSortingChange,
  });

  // Pagination control for toolbar
  const paginationControl =
    totalPages > 1 ? (
      <CatalogPagination
        currentPageIndex={pageIndex}
        pagesCount={totalPages}
        onPageChange={handlePageChange}
      />
    ) : null;

  // Create preferences control (shown for both views but with different settings)
  const preferencesControl =
    viewType === 'table' ? (
      <TablePreferencesButton
        preferences={{
          pageSize: pageSize, // Use URL state
          contentDisplay: [...catalogPrefs.table.contentDisplay],
          wrapLines: catalogPrefs.table.wrapLines,
          stripedRows: catalogPrefs.table.stripedRows,
        }}
        onConfirm={(newPreferences) => {
          // Update localStorage for UI preferences only (NOT pageSize)
          if (newPreferences.contentDisplay) {
            updateTablePreferences({
              contentDisplay: [...newPreferences.contentDisplay],
              wrapLines: newPreferences.wrapLines,
              stripedRows: newPreferences.stripedRows,
            });
          }

          // Update pageSize: save to versioned storage AND update URL
          if (newPreferences.pageSize !== undefined) {
            updatePageSizeFallback(newPreferences.pageSize); // Save to versioned storage
            handlePageSizeChange(newPreferences.pageSize); // Update URL (triggers backend query)
          }
        }}
        columnOptions={TABLE_COLUMN_OPTIONS}
        pageSizeOptions={CATALOG_PAGE_SIZE_OPTIONS}
        onResetDefaults={resetToDefaults}
        title="Table preferences"
      />
    ) : (
      <TablePreferencesButton
        preferences={{
          pageSize: pageSize, // Use URL state
          contentDisplay: [...catalogPrefs.cards.contentDisplay],
          cardsPerRowBreakpoints: catalogPrefs.cards.cardsPerRowBreakpoints,
        }}
        onConfirm={(newPreferences) => {
          // Update localStorage for UI preferences only (NOT pageSize)
          if (newPreferences.contentDisplay) {
            updateCardsPreferences({
              contentDisplay: [...newPreferences.contentDisplay],
              cardsPerRowBreakpoints: (newPreferences as any).cardsPerRowBreakpoints,
            });
          }

          // Update pageSize: save to versioned storage AND update URL
          if (newPreferences.pageSize !== undefined) {
            updatePageSizeFallback(newPreferences.pageSize); // Save to versioned storage
            handlePageSizeChange(newPreferences.pageSize); // Update URL (triggers backend query)
          }
        }}
        columnOptions={CARD_FIELD_OPTIONS}
        pageSizeOptions={CATALOG_PAGE_SIZE_OPTIONS}
        onResetDefaults={resetToDefaults}
        title="Card preferences"
        enableBreakpointEditor={true}
        onBreakpointsChange={(breakpoints) =>
          updateCardsPreferences({ cardsPerRowBreakpoints: breakpoints })
        }
        BreakpointEditorComponent={BreakpointEditor}
        showTableOptions={false}
      />
    );

  // Empty state for when no results
  const emptyState = (
    <EmptyState
      title="No standards"
      subtitle="Try clearing your filters or adjusting the search criteria."
    />
  );

  const breadcrumbs = useMemo(
    () => [
      { text: 'Home', href: '/' },
      { text: 'Browse standards', href: `/standards${location.search}` },
    ],
    [location.search]
  );

  const header = useMemo(
    () => ({
      title: `Browse standards (${totalCount})`,
      description: 'Browse through the standards and narrow them down by searching or filtering',
      info: null,
    }),
    [location.search, totalCount]
  );

  return (
    <PageLayout breadcrumbs={breadcrumbs} header={header}>
      <div
        style={{
          minWidth: 0,
        }}
      >
        <SpaceBetween size="l">
          <StandardCatalogToolbar
            searchValue={searchText}
            onSearchChange={handleSearchTextChange}
            propertyFilterQuery={propertyFilterQuery}
            onPropertyFilterTokensChange={handleSearchTokensChange}
            view={viewType}
            onViewChange={handleViewTypeChange}
            filteringOptions={filteringOptions}
            filteringProperties={STANDARD_FILTERING_PROPERTIES}
            paginationControl={paginationControl}
            preferencesControl={preferencesControl}
          />

          <CatalogErrorAlert error={error} resourceLabel="standards" />

          {viewType === 'card' ? (
            <StandardCardList
              items={items}
              loading={loading}
              empty={emptyState}
              preferences={{
                contentDisplay: catalogPrefs.cards.contentDisplay,
                cardsPerRowBreakpoints: catalogPrefs.cards.cardsPerRowBreakpoints,
              }}
            />
          ) : (
            <StandardTable
              items={items}
              loading={loading}
              sortingField={sortingField}
              sortingDescending={sortingDescending}
              onSortingChange={handleSortingEvent}
              empty={emptyState}
              preferences={{
                contentDisplay: catalogPrefs.table.contentDisplay,
                wrapLines: catalogPrefs.table.wrapLines,
                stripedRows: catalogPrefs.table.stripedRows,
              }}
            />
          )}
        </SpaceBetween>
      </div>
    </PageLayout>
  );
};
