import React, { useCallback, useMemo, useState } from 'react';
import { Link, SpaceBetween } from '@amzn/awsui-components-console';
import { useLocation, useNavigate } from 'react-router-dom';

import {
  useTemplateFilterOptions,
  ALL_TEMPLATE_FILTER_FIELDS,
} from '../hooks/useTemplateFilterOptions';
import { PageLayout } from '../components/PageLayout';
import { EmptyState } from '../components/common/EmptyState';
import { TemplateCardList, TemplateTable, TemplateCatalogToolbar } from '../components/templates';
import {
  useCatalogPreferences,
  CATALOG_PAGE_SIZE_OPTIONS,
  TABLE_COLUMN_OPTIONS,
  CARD_FIELD_OPTIONS,
} from '../components/templates/catalog/preferences';
import { BreakpointEditor } from '../components/templates/catalog/preferences/BreakpointEditor';
import { CatalogPagination } from '../components/shared/CatalogPagination';
import { TablePreferencesButton } from '../components/shared/TablePreferencesButton';
import { CatalogErrorAlert } from '../components/shared/CatalogErrorAlert';
import { useTemplateCatalogControls } from '../hooks/useTemplateCatalogControls';
import { useLatestTemplateVersionsSearch } from '../hooks/useLatestTemplateVersionsSearch';
import type { TemplateSummary } from '../types/template';
import { useTemplateSorting } from '../components/templates/hooks/useTemplateSorting';

export const TemplateCatalog: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const {
    viewType,
    sortingField,
    sortingDescending,
    pageIndex,
    pageSize,
    filterInput,
    propertyFilterQuery,
    handleViewTypeChange,
    handleSortingChange,
    handlePageChange,
    handlePageSizeChange,
    handlePropertyFilterChange,
  } = useTemplateCatalogControls();

  // Local search text state (for display in search input)
  // This is separate from propertyFilterQuery which handles the actual filtering
  const [searchText, setSearchText] = useState<string>('');

  const handleSearchTextChange = useCallback((value: string) => {
    setSearchText(value);
  }, []);

  const handlePropertyFilterTokensChange = useCallback(
    (nextQuery: import('@amzn/awsui-collection-hooks').PropertyFilterQuery) => {
      handlePropertyFilterChange(nextQuery);
    },
    [handlePropertyFilterChange]
  );

  // Unified catalog preferences hook for managing view-specific UI settings
  // NOTE: pageSize is NOT in this hook - it's managed via URL only
  const {
    preferences: catalogPrefs,
    updateTablePreferences,
    updateCardsPreferences,
    updatePageSizeFallback,
    resetToDefaults,
  } = useCatalogPreferences();

  const searchOptions = useMemo(() => {
    return { filter: filterInput };
  }, [filterInput]);
  const {
    items: versionItems,
    loading,
    error,
    totalCount,
    totalPages,
    pageIdx,
  } = useLatestTemplateVersionsSearch(searchOptions);

  // Adapter: Convert TemplateVersionWithTemplate to TemplateSummary format for existing components
  const items = useMemo<TemplateSummary[]>(
    () =>
      versionItems.map((versionItem) => ({
        id: versionItem.template.id,
        name: versionItem.template.name,
        description: versionItem.template.description,
        heroImageUrl: versionItem.template.heroImageUrl,
        accProjectId: versionItem.template.accProjectId,
        createdAt: versionItem.createdAt,
        updatedAt: versionItem.updatedAt,
        latestVersion: {
          id: versionItem.id,
          version: versionItem.version,
          isLatest: versionItem.isLatest,
          accFolderId: versionItem.accFolderId,
          brsId: versionItem.brsId,
          createdAt: versionItem.createdAt,
          updatedAt: versionItem.updatedAt,
          attributes: versionItem.attributes,
          files: versionItem.files,
        },
        versions: [],
      })),
    [versionItems]
  );

  const { handleSortingChange: handleSortingEvent } = useTemplateSorting({
    onSortChange: handleSortingChange,
  });

  const { filteringOptions, loading: filterOptionsLoading } = useTemplateFilterOptions(
    ALL_TEMPLATE_FILTER_FIELDS
  );

  const breadcrumbs = useMemo(
    () => [
      { text: 'Home', href: '/' },
      { text: 'Design templates', href: `/templates${location.search}` },
    ],
    [location.search]
  );

  const header = useMemo(
    () => ({
      title: `Design Templates (${totalCount})`,
      description: 'Browse through a comprehensive catalog of pre-built facility templates',
    }),
    [totalCount]
  );

  const handleOpenTemplate = (templateId: string) => {
    navigate(`/templates/${templateId}${location.search}`);
  };

  const emptyState = (
    <EmptyState
      title="No templates"
      subtitle="Try clearing your filters or adjusting the search criteria."
    />
  );

  // Create pagination control (backend already handles pagination)
  const paginationControl =
    totalPages > 1 ? (
      <CatalogPagination
        currentPageIndex={pageIndex}
        pagesCount={totalPages}
        onPageChange={handlePageChange}
      />
    ) : null;

  // Create preferences control (shown for both views but with different settings)
  const preferencesControl =
    viewType === 'table' ? (
      <TablePreferencesButton
        preferences={{
          pageSize: pageSize, // Use URL state, not localStorage
          contentDisplay: [...catalogPrefs.table.contentDisplay],
          wrapLines: catalogPrefs.table.wrapLines,
          stripedRows: catalogPrefs.table.stripedRows,
        }}
        onConfirm={(newPreferences) => {
          // Update localStorage for UI preferences only (NOT pageSize)
          if (newPreferences.contentDisplay) {
            updateTablePreferences({
              contentDisplay: [...newPreferences.contentDisplay],
              wrapLines: newPreferences.wrapLines,
              stripedRows: newPreferences.stripedRows,
            });
          }

          // Update pageSize: save to versioned storage AND update URL
          if (newPreferences.pageSize !== undefined) {
            updatePageSizeFallback(newPreferences.pageSize); // Save to versioned storage
            handlePageSizeChange(newPreferences.pageSize); // Update URL (triggers backend query)
          }
        }}
        columnOptions={TABLE_COLUMN_OPTIONS}
        pageSizeOptions={CATALOG_PAGE_SIZE_OPTIONS}
        onResetDefaults={resetToDefaults}
        title="Table preferences"
      />
    ) : (
      <TablePreferencesButton
        preferences={{
          pageSize: pageSize, // Use URL state, not localStorage
          contentDisplay: [...catalogPrefs.cards.contentDisplay],
          cardsPerRowBreakpoints: catalogPrefs.cards.cardsPerRowBreakpoints,
        }}
        onConfirm={(newPreferences) => {
          // Update localStorage for UI preferences only (NOT pageSize)
          if (newPreferences.contentDisplay) {
            updateCardsPreferences({
              contentDisplay: [...newPreferences.contentDisplay],
              cardsPerRowBreakpoints: (newPreferences as any).cardsPerRowBreakpoints,
            });
          }

          // Update pageSize: save to versioned storage AND update URL
          if (newPreferences.pageSize !== undefined) {
            updatePageSizeFallback(newPreferences.pageSize); // Save to versioned storage
            handlePageSizeChange(newPreferences.pageSize); // Update URL (triggers backend query)
          }
        }}
        columnOptions={CARD_FIELD_OPTIONS}
        pageSizeOptions={CATALOG_PAGE_SIZE_OPTIONS}
        onResetDefaults={resetToDefaults}
        title="Card preferences"
        enableBreakpointEditor={true}
        onBreakpointsChange={(breakpoints) =>
          updateCardsPreferences({ cardsPerRowBreakpoints: breakpoints })
        }
        BreakpointEditorComponent={BreakpointEditor}
        showTableOptions={false}
      />
    );

  return (
    <PageLayout breadcrumbs={breadcrumbs} header={header}>
      <SpaceBetween size="l">
        <TemplateCatalogToolbar
          searchValue={searchText}
          onSearchChange={handleSearchTextChange}
          propertyFilterQuery={propertyFilterQuery}
          onPropertyFilterTokensChange={handlePropertyFilterTokensChange}
          view={viewType}
          onViewChange={handleViewTypeChange}
          filteringOptions={filteringOptions}
          paginationControl={paginationControl}
          preferencesControl={preferencesControl}
        />

        <CatalogErrorAlert error={error} resourceLabel="templates" />

        {viewType === 'card' ? (
          <TemplateCardList
            items={items}
            loading={loading}
            onOpen={handleOpenTemplate}
            empty={emptyState}
            preferences={{
              contentDisplay: catalogPrefs.cards.contentDisplay,
              cardsPerRowBreakpoints: catalogPrefs.cards.cardsPerRowBreakpoints,
            }}
          />
        ) : (
          <TemplateTable
            items={items}
            loading={loading}
            onOpen={handleOpenTemplate}
            empty={emptyState}
            sortingField={sortingField}
            sortingDescending={sortingDescending}
            onSortingChange={handleSortingEvent}
            preferences={{
              contentDisplay: catalogPrefs.table.contentDisplay,
              wrapLines: catalogPrefs.table.wrapLines,
              stripedRows: catalogPrefs.table.stripedRows,
            }}
          />
        )}
      </SpaceBetween>
    </PageLayout>
  );
};
