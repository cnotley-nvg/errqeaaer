import React, { useMemo, useState, useCallback } from 'react';
import {
  Alert,
  Box,
  Button,
  Link,
  SpaceBetween,
  StatusIndicator,
  Tabs,
  type TabsProps,
} from '@amzn/awsui-components-console';
import { useLocation, useParams } from 'react-router-dom';

import { PageLayout } from '../components/PageLayout';
import { useTemplateDetail } from '../hooks/useTemplateDetail';
import { useTemplateFileDownload } from '../hooks/useTemplateFileDownload';
import { TemplateOverview } from '../components/templates';
import { TemplateRevisionHistory } from '../components/templates';

const LOADING_COPY = 'Fetching template';

export const TemplateDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  const { template, loading, error } = useTemplateDetail(id);

  const [selectedVersionId, setSelectedVersionId] = useState<string | null>(null);
  const [activeTabId, setActiveTabId] = useState<string>('overview');

  const { download: handleDownloadFile, downloadingId } = useTemplateFileDownload();

  const handleDownloadFileVoid = useCallback(
    async (templateFileId: string): Promise<void> => {
      await handleDownloadFile(templateFileId);
    },
    [handleDownloadFile]
  );

  const versions = template?.versions ?? [];

  const effectiveSelectedVersionId = useMemo(() => {
    if (!template) {
      return null;
    }

    if (selectedVersionId && versions.some((version) => version.id === selectedVersionId)) {
      return selectedVersionId;
    }

    return template.latestVersionId ?? versions[0]?.id ?? null;
  }, [selectedVersionId, template, versions]);

  const selectedVersion =
    versions.find((version) => version.id === effectiveSelectedVersionId) ?? null;

  const breadcrumbs = useMemo(
    () => [
      { text: 'Home', href: `/standards${location.search}` },
      { text: 'Design templates', href: `/templates${location.search}` },
      {
        text: template?.name ?? 'Template detail',
        href: `/templates/${id ?? ''}${location.search}`,
      },
    ],
    [id, location.search, template?.name]
  );

  const handleRequestChange = useCallback(() => {
    window.open(
      'https://einsight.eng-services.a2z.com/#/Laminar/createTicket/85527',
      '_blank',
      'noopener,noreferrer'
    );
  }, []);

  const header = useMemo(() => {
    if (!template) {
      return undefined;
    }

    const primaryFileId = selectedVersion?.files[0]?.id ?? null;
    const isDownloadingPrimary = primaryFileId ? downloadingId === primaryFileId : false;

    return {
      title: template.name,
      description: template.description ?? '',
      actions: (
        <SpaceBetween direction="horizontal" size="xs">
          <Button iconName="external" onClick={handleRequestChange}>
            Request change
          </Button>
          {
            //   <Button
            //   iconName="download"
            //   variant="primary"
            //   disabled={!primaryFileId}
            //   loading={isDownloadingPrimary}
            //   onClick={() => {
            //     if (primaryFileId) {
            //       void handleDownloadFileVoid(primaryFileId);
            //     }
            //   }}
            // >
            //   Download
            // </Button>
          }
        </SpaceBetween>
      ),
    };
  }, [downloadingId, handleDownloadFileVoid, handleRequestChange, selectedVersion, template]);

  if (loading) {
    return (
      <PageLayout breadcrumbs={breadcrumbs}>
        <Box textAlign="center" padding="l">
          <StatusIndicator type="loading">{LOADING_COPY}</StatusIndicator>
        </Box>
      </PageLayout>
    );
  }

  if (error) {
    return (
      <PageLayout breadcrumbs={breadcrumbs}>
        <Alert type="error" header="Unable to load template">
          {error}
        </Alert>
      </PageLayout>
    );
  }

  if (!template) {
    return (
      <PageLayout breadcrumbs={breadcrumbs}>
        <Alert type="warning" header="Template not found">
          The requested template could not be located. Return to the{' '}
          <Link href="/templates">template catalog</Link> to continue browsing.
        </Alert>
      </PageLayout>
    );
  }

  const tabs: TabsProps.Tab[] = [
    {
      id: 'overview',
      label: 'Overview details',
      content: (
        <TemplateOverview
          versions={versions}
          selectedVersion={selectedVersion}
          accProjectId={template?.accProjectId ?? null}
          onVersionChange={setSelectedVersionId}
          onDownloadFile={handleDownloadFileVoid}
          downloadingFileId={downloadingId}
        />
      ),
    },
    {
      id: 'history',
      label: 'Revision log',
      content:
        effectiveSelectedVersionId && selectedVersion ? (
          <TemplateRevisionHistory
            templateVersionId={effectiveSelectedVersionId}
            templateName={template.name}
            templateVersion={selectedVersion.version}
            templateDescription={template.description ?? undefined}
          />
        ) : (
          <Box textAlign="center" padding="l">
            <StatusIndicator type="info">No version selected</StatusIndicator>
          </Box>
        ),
    },
  ];

  return (
    <PageLayout breadcrumbs={breadcrumbs} header={header}>
      <SpaceBetween size="l">
        <Tabs
          activeTabId={activeTabId}
          onChange={({ detail }) => setActiveTabId(detail.activeTabId)}
          tabs={tabs}
        />
      </SpaceBetween>
    </PageLayout>
  );
};
