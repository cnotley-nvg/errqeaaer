import { useLocation, useNavigate } from 'react-router-dom';
import { ContentLayout, Header, Popover, Link } from '@amzn/awsui-components-console';
import { OptimizationResults } from '../components/optimize-design/OptimizationResults';
import type { AnalysisResult } from '../components/optimize-design/AnalysisResultCard';
import type { ProjectParams } from '../components/optimize-design/ProjectParametersForm';

type LocationState = {
  params: ProjectParams;
  analyses: AnalysisResult[];
};

export const OptimizeDesignResult = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const state = location.state as LocationState;

  if (!state?.params || !state?.analyses) {
    navigate('/optimize-design');
    return null;
  }

  return (
    <ContentLayout
      header={
        <Header
          variant="h1"
          description="Fine-tune your project parameters to generate the most efficient and cost-effective solution tailored to your specific requirements."
        >
          Optimize your design
        </Header>
      }
    >
      <OptimizationResults
        params={state.params}
        analyses={state.analyses}
        onBack={() => navigate('/optimize-design', { state: { params: state.params } })}
        onDone={() => navigate('/optimize-design')}
      />
    </ContentLayout>
  );
};
