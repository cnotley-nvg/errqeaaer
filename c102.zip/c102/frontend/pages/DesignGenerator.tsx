import React, { useMemo } from 'react';
import { Button, SpaceBetween } from '@amzn/awsui-components-console';
import {
  DesignAlternativesCards,
  DesignGeneratorForm,
  useDesignGeneratorControls,
} from '../components/matchmaker/design-generator';
import { PageLayout } from '../components/PageLayout';

export const DesignGenerator: React.FC = () => {
  const controls = useDesignGeneratorControls();
  const header = useMemo(
    () => ({
      title: 'Design generator',
    }),
    []
  );

  return (
    <PageLayout
      breadcrumbs={[
        { text: 'Home', href: '/' },
        { text: 'Design generator', href: '/design-generator' },
      ]}
      header={header}
    >
      <SpaceBetween size="l">
        <DesignGeneratorForm
          selections={controls.selections}
          handlers={{
            ...controls.handlers,
            onGenerate: controls.handlers.handleGenerate,
            onClearAll: controls.handlers.handleClearAll,
          }}
          derived={{
            areRequirementsFilled: controls.derived.areRequirementsFilled,
            isResultsState: controls.derived.isResultsState,
            baselineThroughput: controls.derived.baselineThroughput,
            baselineThroughputUnits: controls.derived.baselineThroughputUnits,
          }}
        />

        {controls.derived.isResultsState && (
          <SpaceBetween size="l">
            <DesignAlternativesCards items={controls.generatedDesigns} />
            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <SpaceBetween direction="horizontal" size="xs">
                <Button onClick={controls.handlers.handleExitResults}>Back</Button>
                <Button variant="primary" onClick={controls.handlers.handleClearAll}>
                  Done
                </Button>
              </SpaceBetween>
            </div>
          </SpaceBetween>
        )}
      </SpaceBetween>
    </PageLayout>
  );
};
