import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Button } from '@amzn/awsui-components-console';
import { useNavigate } from 'react-router-dom';

import {
  type CreateKitFormInput,
  type KitCompatibleStandard,
  useKitCompatibleStandards,
  useKitOptions,
} from '../hooks/useKitBuilder';
import { useLatestStandardVersionsSearch } from '../hooks/useLatestStandardVersionsSearch';
import type { StandardVersionWithStandard } from '../components/standards/catalog/types';
import { KitBuilderLayout } from '../components/build-kit/KitBuilderLayout';
import { KitAlerts } from '../components/build-kit/KitAlerts';
import { KitFiltersForm } from '../components/build-kit/KitFiltersForm';
import { CompatibleStandardsList } from '../components/build-kit/CompatibleStandardsList';
import { KitActionBar } from '../components/build-kit/KitActionBar';
import { KitFooter } from '../components/build-kit/KitFooter';
import { useKitBuilderControls } from '../components/build-kit/hooks/useKitBuilderControls';
import { useKitFilters } from '../components/build-kit/hooks/useKitFilters';
import { useKitCreation } from '../components/build-kit/hooks/useKitCreation';
import { AdditionalStandardsModal } from '../components/build-kit/AdditionalStandardsModal';

export const BuildKit: React.FC = () => {
  const {
    handleCreateKit: createKitWithFeedback,
    creatingKit,
    feedback: creationFeedback,
    clearFeedback,
  } = useKitCreation();
  const navigate = useNavigate();
  const controls = useKitBuilderControls({ onInteraction: clearFeedback });

  const {
    options: kitOptions,
    loading: loadingOptions,
    error: kitOptionsError,
    isLoaded: kitOptionsLoaded,
  } = useKitOptions();

  const filtersState = useKitFilters({
    selections: controls.selections,
    onInteraction: clearFeedback,
  });
  const {
    filters,
    normalizedSelections,
    selectedStandardIds,
    selectedStandardItems,
    handleSelectionChange,
    resetSelectedStandards,
    registerStandards,
  } = filtersState;

  const canFetchCompatible = useMemo(
    () =>
      Boolean(controls.kitName.trim()) &&
      controls.selections.regions.length > 0 &&
      controls.selections.projectTypes.length > 0,
    [controls.kitName, controls.selections.regions.length, controls.selections.projectTypes.length]
  );

  const effectiveFilters = canFetchCompatible ? filters : null;

  const {
    standards,
    loading: loadingStandards,
    error: compatibleStandardsError,
    hasFetched: hasFetchedStandards,
  } = useKitCompatibleStandards(effectiveFilters);

  const standardsSearchFilter = useMemo(
    () => ({
      pageIdx: 0,
      limit: 500,
      orderBy: 'name',
      orderDesc: false,
    }),
    []
  );

  const { items: allStandardsRaw, loading: loadingAllStandards } = useLatestStandardVersionsSearch({
    filter: standardsSearchFilter,
  });

  const [additionalStandards, setAdditionalStandards] = useState<KitCompatibleStandard[]>([]);
  const [isAddStandardsModalVisible, setAddStandardsModalVisible] = useState(false);

  const toList = useCallback((raw: unknown): string[] => {
    if (raw === null || raw === undefined) return [];
    const values = Array.isArray(raw) ? raw : [raw];
    return values
      .map((value) => {
        if (value === null || value === undefined) return null;
        if (typeof value === 'object') return null;
        const token = String(value).trim();
        return token.length ? token : null;
      })
      .filter((token): token is string => Boolean(token));
  }, []);

  const mapStandardToKitStandard = useCallback(
    (standardVersion: StandardVersionWithStandard): KitCompatibleStandard | null => {
      const attrs = (standardVersion.attributes ?? {}) as Record<string, unknown>;
      const regions = toList(attrs.region);
      if (!regions.length) return null;
      const programs = toList(attrs.program);
      const roomFeatureZones = toList(attrs.roomFeatureZone);
      const dataTypes = toList(attrs.dataType);
      const projectTypes = toList(attrs.projectType);

      return {
        id: standardVersion.id,
        standardId: standardVersion.standard.id,
        standardName: standardVersion.standard.name,
        version: standardVersion.version,
        region: regions[0],
        program: (programs.length ? programs : null) as string[] | null,
        useCase: null,
        roomFeatureZone: (roomFeatureZones.length ? roomFeatureZones : null) as string[] | null,
        dataType: (dataTypes[0] ?? null) as string | null,
        projectType: (projectTypes.length ? projectTypes : null) as string[] | null,
      };
    },
    [toList]
  );

  const allStandards = useMemo(
    () =>
      allStandardsRaw
        .map(mapStandardToKitStandard)
        .filter((standard): standard is KitCompatibleStandard => Boolean(standard)),
    [allStandardsRaw, mapStandardToKitStandard]
  );

  const compatibleIds = useMemo(() => new Set(standards.map((item) => item.id)), [standards]);
  const additionalIds = useMemo(
    () => new Set(additionalStandards.map((item) => item.id)),
    [additionalStandards]
  );

  const displayedStandards = useMemo(() => {
    const merged = new Map<string, KitCompatibleStandard>();
    standards.forEach((standard) => merged.set(standard.id, standard));
    additionalStandards.forEach((standard) => {
      if (!merged.has(standard.id)) {
        merged.set(standard.id, standard);
      }
    });
    return Array.from(merged.values());
  }, [standards, additionalStandards]);

  const availableAdditionalStandards = useMemo(
    () => allStandards.filter((item) => !compatibleIds.has(item.id) && !additionalIds.has(item.id)),
    [allStandards, compatibleIds, additionalIds]
  );

  useEffect(() => {
    // Register all displayed standards so selection can reference them.
    // Compatible standards should be pre-selected, but not locked/read-only.
    registerStandards(displayedStandards);
  }, [registerStandards, displayedStandards, standards]);

  const isCreateDisabled = useMemo(
    () =>
      !controls.kitName.trim() ||
      !controls.selections.regions.length ||
      !controls.selections.projectTypes.length ||
      !selectedStandardIds.length ||
      creatingKit ||
      !kitOptionsLoaded ||
      loadingOptions,
    [
      controls.kitName,
      controls.selections.regions.length,
      controls.selections.projectTypes.length,
      selectedStandardIds.length,
      creatingKit,
      kitOptionsLoaded,
      loadingOptions,
    ]
  );

  const isResetDisabled = useMemo(
    () => controls.isFormPristine && !selectedStandardIds.length,
    [controls.isFormPristine, selectedStandardIds.length]
  );

  const wrapInteraction = useCallback(
    <T extends (...args: any[]) => void>(handler: T) =>
      (...args: Parameters<T>) => {
        clearFeedback();
        handler(...args);
      },
    [clearFeedback]
  );

  const handleCreateKit = useCallback(async () => {
    const payload: CreateKitFormInput = {
      name: controls.kitName.trim(),
      description: controls.kitDescription.trim() ? controls.kitDescription.trim() : undefined,
      region: normalizedSelections.regions[0] ?? '',
      program: normalizedSelections.programs.length ? normalizedSelections.programs : null,
      projectType: normalizedSelections.projectTypes,
      roomFeatureZone: normalizedSelections.roomFeatureZones.length
        ? normalizedSelections.roomFeatureZones
        : null,
      dataType: normalizedSelections.dataTypes[0] ?? null,
      standardVersionIds: selectedStandardIds,
    };

    const created = await createKitWithFeedback(payload);
    if (created) {
      navigate(`/kits/${created.id}`);
    }
  }, [controls, createKitWithFeedback, navigate, normalizedSelections, selectedStandardIds]);

  const handleResetFilters = useCallback(() => {
    clearFeedback();
    controls.resetSelections();
    resetSelectedStandards();
    setAdditionalStandards([]);
  }, [clearFeedback, controls, resetSelectedStandards]);

  // Clear displayed standards when filters are cleared to avoid stale counts.
  useEffect(() => {
    if (!filters) {
      setAdditionalStandards([]);
      registerStandards([], { lockedStandardIds: [] });
    }
  }, [filters, registerStandards]);

  const handleSelectionChangeWrapped = useCallback(
    (items: ReadonlyArray<KitCompatibleStandard>) => {
      clearFeedback();
      handleSelectionChange(items);
    },
    [clearFeedback, handleSelectionChange]
  );

  const handleAddStandards = useCallback(
    (items: ReadonlyArray<KitCompatibleStandard>) => {
      const existingIds = new Set(displayedStandards.map((standard) => standard.id));
      const newItems = items.filter((item) => !existingIds.has(item.id));

      if (newItems.length) {
        setAdditionalStandards((previous) => {
          const merged = new Map(previous.map((standard) => [standard.id, standard]));
          newItems.forEach((standard) => merged.set(standard.id, standard));
          return Array.from(merged.values());
        });
        const updatedSelection = [...selectedStandardItems, ...newItems];
        handleSelectionChangeWrapped(updatedSelection);
      }

      setAddStandardsModalVisible(false);
    },
    [displayedStandards, handleSelectionChangeWrapped, selectedStandardItems]
  );

  const canShowAddStandardsButton = useMemo(
    () =>
      Boolean(controls.kitName.trim()) &&
      normalizedSelections.regions.length > 0 &&
      normalizedSelections.projectTypes.length > 0 &&
      availableAdditionalStandards.length > 0,
    [
      availableAdditionalStandards.length,
      controls.kitName,
      normalizedSelections.regions.length,
      normalizedSelections.projectTypes.length,
    ]
  );

  const alerts = useMemo(
    () => ({
      creationSuccessMessage:
        creationFeedback?.type === 'success' ? creationFeedback.message : null,
      createKitError: creationFeedback?.type === 'error' ? creationFeedback.message : null,
      kitOptionsError,
      compatibleStandardsError,
      onDismissCreationSuccess: creationFeedback?.type === 'success' ? clearFeedback : undefined,
    }),
    [clearFeedback, compatibleStandardsError, creationFeedback, kitOptionsError]
  );

  return (
    <>
      <KitBuilderLayout headerActions={null}>
        <KitAlerts {...alerts} />

        <KitFiltersForm
          kitOptions={kitOptions}
          loadingOptions={loadingOptions}
          kitOptionsLoaded={kitOptionsLoaded}
          kitName={controls.kitName}
          kitDescription={controls.kitDescription}
          selections={controls.selections}
          handlers={{
            onKitNameChange: wrapInteraction(controls.handlers.onKitNameChange),
            onKitDescriptionChange: wrapInteraction(controls.handlers.onKitDescriptionChange),
            onRegionsChange: wrapInteraction(controls.handlers.onRegionsChange),
            onProgramsChange: wrapInteraction(controls.handlers.onProgramsChange),
            onProjectTypesChange: wrapInteraction(controls.handlers.onProjectTypesChange),
            onRoomFeatureZonesChange: wrapInteraction(controls.handlers.onRoomFeatureZonesChange),
            onDataTypesChange: wrapInteraction(controls.handlers.onDataTypesChange),
          }}
        />

        <CompatibleStandardsList
          filters={effectiveFilters}
          standards={displayedStandards}
          selectedStandardItems={selectedStandardItems}
          loadingStandards={loadingStandards}
          hasFetchedStandards={hasFetchedStandards}
          onSelectionChange={handleSelectionChangeWrapped}
          headerActions={
            canShowAddStandardsButton ? (
              <Button
                variant="normal"
                disabled={loadingAllStandards}
                onClick={() => setAddStandardsModalVisible(true)}
              >
                Add standards
              </Button>
            ) : undefined
          }
        />

        <KitFooter>
          <KitActionBar
            onCreate={handleCreateKit}
            onResetFilters={handleResetFilters}
            isResetDisabled={isResetDisabled}
            isCreateDisabled={isCreateDisabled}
            creatingKit={creatingKit}
          />
        </KitFooter>
      </KitBuilderLayout>

      <AdditionalStandardsModal
        visible={isAddStandardsModalVisible}
        onDismiss={() => setAddStandardsModalVisible(false)}
        regionLabel="Region"
        modalStandards={availableAdditionalStandards}
        initialSelected={[]}
        onAdd={handleAddStandards}
        loading={loadingAllStandards}
        error={compatibleStandardsError}
      />
    </>
  );
};
