import React, { useMemo } from 'react';
import FeatureCard from '../components/common/FeatureCard';
import { PageLayout } from '../components/PageLayout';
import { SpaceBetween, ContentLayout } from '@amzn/awsui-components-console';
import { useNavigate } from 'react-router-dom';
import RecentUpdates from '../components/common/RecentUpdates';

const HomePage: React.FC = () => {
  const navigate = useNavigate();

  const header = useMemo(
    () => ({
      title: 'Welcome to Mosaic',
      description:
        "Mosaic is Amazon's real estate platform that transforms how we design, evaluate, and deploy buildings across our global operations network. The platform addresses a fundamental challenge: traditional build-to-suit approaches create rigidity while billions in underutilized assets remain across our network. Mosaic changes this by providing flexible, configurable building solutions that maximize the value of existing investments and unlock new opportunities.",
    }),
    []
  );

  return (
    <PageLayout breadcrumbs={[]} header={header}>
      <ContentLayout>
        <SpaceBetween direction="vertical" size="l">
          <FeatureCard
            title="Design Managers"
            description="Maintain design excellence across Amazon's global portfolio with centralized standards management and powerful design generation tools. Create consistent, compliant designs faster while ensuring every project meets operational requirements."
            buttonText="Explore design templates"
            onButtonClick={() => navigate('/templates')}
            illustration={'/images/design_manager.svg'}
          />

          <FeatureCard
            title="Real Estate Managers"
            description="Streamline project delivery with instant access to proven design templates and design optimization. Reduce iteration cycles, accelerate approvals, and deliver cost-effective solutions that meet site-specific requirements."
            buttonText="Explore design generator"
            onButtonClick={() => navigate('/design-generator')}
            illustrationPosition="left"
            illustration={'/images/transaction_manager.svg'}
          />

          <FeatureCard
            title="Pre-Construction & Construction"
            description="Bridge design to execution with detailed standards, customizable kit-of-parts, and design optimization for construction. Get accurate material lists, installation guides, and compliance documentation that keep projects on schedule and on budget."
            buttonText="Explore build a kit"
            onButtonClick={() => navigate('/build-kit')}
            illustration={'/images/pre_con_and_construction.svg'}
          />

          <FeatureCard
            title="Amazon Stakeholders"
            description="Oversee design consistency and make informed decisions with comprehensive access to standards, approved templates. Track design compliance and ensure operational excellence across all projects."
            buttonText="Explore standards"
            onButtonClick={() => navigate('/standards')}
            illustrationPosition="left"
            illustration={'/images/amazon_stakeholders.svg'}
          />
          <RecentUpdates />
        </SpaceBetween>
      </ContentLayout>
    </PageLayout>
  );
};

export default HomePage;
