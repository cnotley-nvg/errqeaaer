import React, { useMemo } from 'react';
import { useLocation, useParams } from 'react-router-dom';
import { Alert, Box, Link, SpaceBetween, StatusIndicator } from '@amzn/awsui-components-console';

import { PageLayout } from '../components/PageLayout';
import { KitOverviewMetadata, KitStandardsList } from '../components/kits/detail';
import { useKitDetail } from '../hooks/useKitDetail';

export const KitDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  const { kit, loading, error } = useKitDetail(id);

  const noticeText =
    "This kit contains custom components that haven't been approved by Amazon standards. Review all components carefully and consult with your design team before implementation.";

  const breadcrumbs = useMemo(
    () => [
      { text: 'Home', href: '/' },
      { text: 'Published kit of parts', href: `/kits${location.search}` },
      { text: kit?.name ?? 'Kit detail', href: `/kits/${id ?? ''}${location.search}` },
    ],
    [id, kit?.name, location.search]
  );

  const header = useMemo(
    () => ({
      title: kit?.name ?? 'Kit detail',
      description: kit?.description?.trim() ? kit.description : undefined,
      info: null,
    }),
    [kit?.description, kit?.name]
  );

  if (loading) {
    return (
      <PageLayout breadcrumbs={breadcrumbs} header={header}>
        <Box textAlign="center" padding="l">
          <StatusIndicator type="loading">Fetching kit</StatusIndicator>
        </Box>
      </PageLayout>
    );
  }

  if (error) {
    return (
      <PageLayout breadcrumbs={breadcrumbs} header={header}>
        <Alert type="error" header="Unable to load kit">
          {error}
        </Alert>
      </PageLayout>
    );
  }

  if (!kit) {
    return (
      <PageLayout breadcrumbs={breadcrumbs} header={header}>
        <Alert type="warning" header="Kit not found">
          The requested kit could not be located. Return to the{' '}
          <Link href={`/kits${location.search}`}>kits catalog</Link>.
        </Alert>
      </PageLayout>
    );
  }

  return (
    <PageLayout breadcrumbs={breadcrumbs} header={header}>
      <SpaceBetween size="l">
        <Alert type="info">{noticeText}</Alert>

        <KitOverviewMetadata kit={kit} />

        <KitStandardsList kit={kit} />
      </SpaceBetween>
    </PageLayout>
  );
};
