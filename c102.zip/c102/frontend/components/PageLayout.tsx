import React, { useEffect } from 'react';
import type { BreadcrumbGroupProps } from '@amzn/awsui-components-console';

import { useLayout, type LayoutHeader } from './layout/LayoutProvider';

interface PageLayoutProps {
  breadcrumbs: BreadcrumbGroupProps.Item[];
  header?: LayoutHeader;
  children: React.ReactNode;
}

export const PageLayout: React.FC<PageLayoutProps> = ({ breadcrumbs, header, children }) => {
  const { setBreadcrumbs, setHeader } = useLayout();

  useEffect(() => {
    setBreadcrumbs(breadcrumbs);
    // Don't clear breadcrumbs on cleanup - they should persist
  }, [breadcrumbs, setBreadcrumbs]);

  useEffect(() => {
    setHeader(header ?? null);

    // Clear header on cleanup to prevent it from showing on next page
    return () => {
      setHeader(null);
    };
  }, [header, setHeader]);

  return <>{children}</>;
};
