import React from 'react';
import { FlagProvider, useFlag as useUnleashFlag } from '@unleash/proxy-client-react';
import { getUnleashConfig, isUnleashConfigured } from '../config/featureFlags';

export const useFeatureFlag = (flagName: string): boolean => {
  return useUnleashFlag(flagName);
};

interface FlagProviderWrapperProps {
  children: React.ReactNode;
}

export const FlagProviderWrapper: React.FC<FlagProviderWrapperProps> = ({ children }) => {
  const unleashConfig = getUnleashConfig();
  if (!isUnleashConfigured()) {
    return <>{children}</>;
  }

  return (
    <FlagProvider
      config={{
        url: unleashConfig.url,
        clientKey: unleashConfig.clientKey,
        appName: unleashConfig.appName,
        environment: unleashConfig.environment,
        refreshInterval: unleashConfig.refreshInterval,
      }}
    >
      {children}
    </FlagProvider>
  );
};
