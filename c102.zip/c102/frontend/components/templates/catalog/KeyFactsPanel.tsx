import React from 'react';
import { Box, ColumnLayout, Container, Header, SpaceBetween } from '@amzn/awsui-components-console';

import type { TemplateSummary } from '../../../types/template';

interface KeyFactsPanelProps {
  template: TemplateSummary | null;
}

const ATTRIBUTE_KEYS: Array<{ key: string; label: string }> = [
  { key: 'region', label: 'Region' },
  { key: 'program', label: 'Program' },
  { key: 'facilityType', label: 'Facility type' },
  { key: 'businessUnit', label: 'Business unit' },
  { key: 'generation', label: 'Generation' },
  { key: 'capacity', label: 'Capacity' },
  { key: 'stories', label: 'Stories' },
  { key: 'grossSquareFootage', label: 'Gross square footage' },
  { key: 'peakShiftHeadcount', label: 'Peak shift headcount' },
  { key: 'powerKva', label: 'Power (kVA)' },
  { key: 'siteAcreage', label: 'Site acreage' },
  { key: 'releaseDate', label: 'Release date' },
];

const getAttributeDisplay = (template: TemplateSummary | null, key: string): string => {
  if (!template) {
    return '–';
  }

  const attributes = template.latestVersion?.attributes ?? {};
  const raw = attributes[key];
  let value: string | null;

  if (raw === null || raw === undefined) {
    value = null;
  } else if (Array.isArray(raw)) {
    value = raw.length ? String(raw[0]) : null;
  } else if (typeof raw === 'object' && raw !== null && 'value' in raw) {
    const numeric = (raw as { value: unknown }).value;
    value = numeric !== undefined && numeric !== null ? String(numeric) : null;
  } else {
    value = String(raw);
  }

  if (!value || !value.trim().length) {
    return '–';
  }

  if (key.toLowerCase().includes('date')) {
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? value : parsed.toLocaleDateString();
  }

  const numeric = Number.parseFloat(value.replace(/[^0-9.+-]/g, ''));
  if (Number.isFinite(numeric) && !Number.isNaN(numeric)) {
    return numeric.toLocaleString();
  }

  return value;
};

export const KeyFactsPanel: React.FC<KeyFactsPanelProps> = ({ template }) => {
  if (!template) {
    return null;
  }

  return (
    <Container header={<Header variant="h2">Key template facts</Header>}>
      <ColumnLayout columns={3} variant="text-grid">
        {ATTRIBUTE_KEYS.map(({ key, label }) => (
          <SpaceBetween key={key} size="xxs">
            <Box variant="awsui-key-label">{label}</Box>
            <span>{getAttributeDisplay(template, key)}</span>
          </SpaceBetween>
        ))}
      </ColumnLayout>
    </Container>
  );
};
