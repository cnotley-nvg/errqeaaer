import React, { useMemo } from 'react';
import { Link, Table, type TableProps } from '@amzn/awsui-components-console';

import type { TemplateSummary } from '../../../types/template';
import type { TablePreferences } from '../../../hooks/useTablePreferences';
import { useTemplateTablePreferences } from './preferences';

interface TemplateTableProps {
  items: readonly TemplateSummary[];
  loading: boolean;
  onOpen: (templateId: string) => void;
  empty: React.ReactNode;
  sortingField: TableProps.SortingColumn<TemplateSummary>['sortingField'];
  sortingDescending: boolean;
  onSortingChange: TableProps['onSortingChange'];
  preferences?: TablePreferences;
}

const asString = (value?: string | null): string => {
  if (!value) {
    return '–';
  }
  const trimmed = value.trim();
  return trimmed.length ? trimmed : '–';
};

const getAttributeString = (template: TemplateSummary, key: string): string => {
  const attributes = template.latestVersion?.attributes ?? {};
  const raw = attributes[key];
  if (raw === null || raw === undefined) {
    return '–';
  }
  if (Array.isArray(raw)) {
    // Join all array values with comma separator for multi-value attributes
    const filtered = raw.filter((v) => v !== null && v !== undefined && String(v).trim() !== '');
    return filtered.length > 0 ? filtered.map((v) => asString(String(v))).join(', ') : '–';
  }
  if (typeof raw === 'object' && raw !== null && 'value' in raw) {
    return asString(String((raw as { value: unknown }).value ?? ''));
  }
  return asString(String(raw));
};

const parseNumericAttribute = (template: TemplateSummary, key: string): string => {
  const value = getAttributeString(template, key);
  const numeric = Number.parseFloat(value.replace(/[^0-9.+-]/g, ''));
  return Number.isFinite(numeric) ? numeric.toLocaleString() : value;
};

const formatDate = (iso: string | null | undefined): string => {
  if (!iso) {
    return '–';
  }
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) {
    return iso;
  }
  return date.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
};

export const TemplateTable: React.FC<TemplateTableProps> = ({
  items,
  loading,
  onOpen,
  empty,
  sortingField,
  sortingDescending,
  onSortingChange,
  preferences: externalPreferences,
}) => {
  // Use external preferences if provided, otherwise use internal hook for backward compatibility
  const internalPrefs = useTemplateTablePreferences();
  const preferences = externalPreferences || internalPrefs.preferences;

  // Define all possible columns (19 total)
  const allColumnDefinitions = useMemo<TableProps.ColumnDefinition<TemplateSummary>[]>(
    () => [
      {
        id: 'name',
        header: 'Template name',
        cell: (item) => (
          <Link
            href={`/templates/${item.id}`}
            onFollow={(event) => {
              event.preventDefault();
              onOpen(item.id);
            }}
          >
            {item.name}
          </Link>
        ),
        sortingField: 'name',
        minWidth: 240,
        isRowHeader: true,
      },
      {
        id: 'region',
        header: 'Region',
        cell: (item) => getAttributeString(item, 'region'),
        sortingField: 'region',
        minWidth: 120,
      },
      {
        id: 'program',
        header: 'Program',
        cell: (item) => getAttributeString(item, 'program'),
        sortingField: 'program',
        minWidth: 180,
      },
      {
        id: 'facilityType',
        header: 'Facility type',
        cell: (item) => getAttributeString(item, 'facilityType'),
        sortingField: 'facilityType',
        minWidth: 160,
      },
      {
        id: 'capacity',
        header: 'Capacity',
        cell: (item) => parseNumericAttribute(item, 'capacity'),
        sortingField: 'capacity',
        minWidth: 120,
      },
      {
        id: 'stories',
        header: '# of stories',
        cell: (item) => parseNumericAttribute(item, 'stories'),
        sortingField: 'stories',
        minWidth: 120,
      },
      {
        id: 'businessUnit',
        header: 'Business unit',
        cell: (item) => getAttributeString(item, 'businessUnit'),
        sortingField: 'businessUnit',
        minWidth: 200,
      },
      {
        id: 'updatedAt',
        header: 'Last modified date',
        cell: (item) => formatDate(item.updatedAt),
        sortingField: 'updatedAt',
        minWidth: 180,
      },
      {
        id: 'siteAcreage',
        header: 'Site size (acres)',
        cell: (item) => parseNumericAttribute(item, 'siteAcreage'),
        sortingField: 'siteAcreage',
        minWidth: 140,
      },
      {
        id: 'dockDoorCount',
        header: 'Dock door count',
        cell: (item) => parseNumericAttribute(item, 'dockDoorCount'),
        sortingField: 'dockDoorCount',
        minWidth: 140,
      },
      {
        id: 'totalTrailerParking',
        header: 'Total trailer parking',
        cell: (item) => parseNumericAttribute(item, 'totalTrailerParking'),
        sortingField: 'totalTrailerParking',
        minWidth: 160,
      },
      {
        id: 'maxWeeklyHeadcount',
        header: 'Max. weekly head count',
        cell: (item) => parseNumericAttribute(item, 'maxWeeklyHeadcount'),
        sortingField: 'maxWeeklyHeadcount',
        minWidth: 180,
      },
      {
        id: 'powerKva',
        header: 'Power (Amps)',
        cell: (item) => parseNumericAttribute(item, 'powerKva'),
        sortingField: 'powerKva',
        minWidth: 120,
      },
      {
        id: 'createdBy',
        header: 'Created by',
        cell: (item) => getAttributeString(item, 'createdBy'),
        sortingField: 'createdBy',
        minWidth: 140,
      },
      {
        id: 'grossSquareFootage',
        header: 'Building footprint (SF/sq. M)',
        cell: (item) => parseNumericAttribute(item, 'grossSquareFootage'),
        sortingField: 'grossSquareFootage',
        minWidth: 200,
      },
      {
        id: 'peakShiftHeadcount',
        header: 'Peak shift head count',
        cell: (item) => parseNumericAttribute(item, 'peakShiftHeadcount'),
        sortingField: 'peakShiftHeadcount',
        minWidth: 180,
      },
      {
        id: 'clearHeightFtM',
        header: 'Int. clear height (Ft./M)',
        cell: (item) => getAttributeString(item, 'clearHeightFtM'),
        sortingField: 'clearHeightFtM',
        minWidth: 180,
      },
      {
        id: 'dspParking',
        header: 'DSP parking',
        cell: (item) => parseNumericAttribute(item, 'dspParking'),
        sortingField: 'dspParking',
        minWidth: 120,
      },
      {
        id: 'generation',
        header: 'Generation',
        cell: (item) => getAttributeString(item, 'generation'),
        sortingField: 'generation',
        minWidth: 120,
      },
    ],
    [onOpen]
  );

  // Filter and order columns based on preferences
  const visibleColumns = useMemo(() => {
    // If contentDisplay is available, use it for ordering and visibility
    if (preferences.contentDisplay && preferences.contentDisplay.length > 0) {
      const columnMap = new Map(allColumnDefinitions.map((col) => [col.id, col]));

      return preferences.contentDisplay
        .filter((item) => item.visible !== false)
        .map((item) => columnMap.get(item.id))
        .filter((col): col is TableProps.ColumnDefinition<TemplateSummary> => col !== undefined);
    }

    // Fallback to visibleContent (legacy)
    if (preferences.visibleContent && preferences.visibleContent.length > 0) {
      return allColumnDefinitions.filter(
        (col) => col.id === 'name' || preferences.visibleContent?.includes(col.id!)
      );
    }

    // Default: show all columns
    return allColumnDefinitions;
  }, [allColumnDefinitions, preferences.contentDisplay, preferences.visibleContent]);

  return (
    <Table
      trackBy="id"
      loading={loading}
      loadingText="Loading design templates"
      columnDefinitions={visibleColumns}
      items={items as TemplateSummary[]}
      sortingColumn={{ sortingField }}
      sortingDescending={sortingDescending}
      onSortingChange={onSortingChange}
      variant="embedded"
      empty={empty}
    />
  );
};
