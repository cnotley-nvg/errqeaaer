import { useState } from 'react';
import type { CollectionPreferencesProps } from '@amzn/awsui-components-console';

import { useTablePreferences } from '../../../../hooks/useTablePreferences';
import type { CardBreakpoint } from '../../../../hooks/useTablePreferences';
import { DEFAULT_CARD_PREFERENCES, CARD_FIELD_OPTIONS, CARD_PAGE_SIZE_OPTIONS } from './constants';
import type { CardPreferencesHookResult } from './types';

/**
 * Hook for managing template card view preferences (field visibility, page size, breakpoints)
 */
export function useTemplateCardPreferences(): CardPreferencesHookResult {
  const [preferences, setPreferences, resetPreferences] = useTablePreferences(
    'template-catalog-card-preferences',
    DEFAULT_CARD_PREFERENCES
  );

  const [preferencesKey, setPreferencesKey] = useState(0);

  const handlePreferencesChange = (detail: CollectionPreferencesProps.Preferences): void => {
    setPreferences(detail);
  };

  const handleBreakpointsChange = (breakpoints: CardBreakpoint[]): void => {
    const updated = {
      ...preferences,
      cardsPerRowBreakpoints: breakpoints,
    };
    setPreferences(updated as any);
  };

  const handleResetToDefaults = (): void => {
    resetPreferences();
    setPreferencesKey((prev) => prev + 1);
  };

  return {
    preferences,
    setPreferences: handlePreferencesChange,
    setBreakpoints: handleBreakpointsChange,
    resetPreferences: handleResetToDefaults,
    fieldOptions: CARD_FIELD_OPTIONS,
    pageSizeOptions: CARD_PAGE_SIZE_OPTIONS,
    preferencesKey,
  };
}
