// New primary exports - Unified catalog preferences
export { useCatalogPreferences } from './useCatalogPreferences';
export {
  CATALOG_PAGE_SIZE_OPTIONS,
  DEFAULT_CATALOG_PAGE_SIZE,
  DEFAULT_CATALOG_PREFERENCES,
} from './constants';
export type { CatalogPreferences, CatalogPreferencesHookResult } from './types';

// Deprecated exports - Use useCatalogPreferences instead
/** @deprecated Use useCatalogPreferences instead for unified page size across views */
export { useTemplateTablePreferences } from './useTemplateTablePreferences';
/** @deprecated Use useCatalogPreferences instead for unified page size across views */
export { useTemplateCardPreferences } from './useTemplateCardPreferences';

// Keep existing exports
export { BreakpointEditor, normalizeBreakpoints } from './BreakpointEditor';
export {
  TABLE_COLUMN_OPTIONS,
  TABLE_PAGE_SIZE_OPTIONS,
  CARD_FIELD_OPTIONS,
  CARD_PAGE_SIZE_OPTIONS,
  DEFAULT_TABLE_PAGE_SIZE,
  DEFAULT_CARD_PAGE_SIZE,
  CARD_COLUMN_COUNT,
  DEFAULT_CARD_BREAKPOINTS,
  MIN_CARD_WIDTH,
} from './constants';
export { toCollectionPreferences } from './utils';
export type {
  PreferenceOption,
  PageSizeOption,
  PreferencesHookResult,
  CardPreferencesHookResult,
  CardBreakpoint,
} from './types';
