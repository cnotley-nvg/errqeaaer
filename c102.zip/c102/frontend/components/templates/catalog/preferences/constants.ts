import type { TablePreferences, CardBreakpoint } from '../../../../hooks/useTablePreferences';
import type { PreferenceOption, PageSizeOption, CatalogPreferences } from './types';

// Default page sizes (legacy - deprecated)
export const DEFAULT_TABLE_PAGE_SIZE = 10;
export const DEFAULT_CARD_PAGE_SIZE = 10;

// Unified catalog page size
export const DEFAULT_CATALOG_PAGE_SIZE = 20;

// Column/field layout
export const CARD_COLUMN_COUNT = 3;

// Minimum card width for layout calculations (in pixels)
export const MIN_CARD_WIDTH = 385;

// Default breakpoints for card view responsive layout
// NOTE: These thresholds are FIXED and not customizable by users
// Ranges use inclusive lower bounds (>=). Upper bound is exclusive (next breakpoint - 1)
export const DEFAULT_CARD_BREAKPOINTS: readonly CardBreakpoint[] = [
  { minWidth: 768, cards: 2 }, // Tablet: 768px - 1365px
  { minWidth: 1366, cards: 3 }, // Laptop: 1366px - 1919px
  { minWidth: 1920, cards: 4 }, // Desktop: 1920px+
] as const;

// Validation constraints
export const MIN_CARDS_PER_ROW = 1;
export const MAX_CARDS_PER_ROW = 20;
export const MIN_SCREEN_WIDTH = 0;
export const MAX_SCREEN_WIDTH = 10000;
export const MAX_BREAKPOINTS = 3; // Limited to 3 breakpoints for simplicity

// Table column options
export const TABLE_COLUMN_OPTIONS: readonly PreferenceOption[] = [
  { id: 'name', label: 'Template name', alwaysVisible: true },
  { id: 'region', label: 'Region' },
  { id: 'program', label: 'Program' },
  { id: 'facilityType', label: 'Facility type' },
  { id: 'capacity', label: 'Capacity' },
  { id: 'stories', label: '# of stories' },
  { id: 'businessUnit', label: 'Business unit' },
  { id: 'updatedAt', label: 'Last modified date' },
  { id: 'siteAcreage', label: 'Site size (acres)' },
  { id: 'dockDoorCount', label: 'Dock door count' },
  { id: 'totalTrailerParking', label: 'Total trailer parking' },
  { id: 'maxWeeklyHeadcount', label: 'Max. weekly head count' },
  { id: 'powerKva', label: 'Power (Amps)' },
  { id: 'createdBy', label: 'Created by' },
  { id: 'grossSquareFootage', label: 'Building footprint (SF/sq. M)' },
  { id: 'peakShiftHeadcount', label: 'Peak shift head count' },
  { id: 'clearHeightFtM', label: 'Int. clear height (Ft./M)' },
  { id: 'dspParking', label: 'DSP parking' },
  { id: 'generation', label: 'Generation' },
] as const;

export const TABLE_PAGE_SIZE_OPTIONS: readonly PageSizeOption[] = [
  { value: 10, label: '10 templates' },
  { value: 20, label: '20 templates' },
  { value: 50, label: '50 templates' },
] as const;

// Card field options (all table columns EXCEPT 'name' which is the card title)
export const CARD_FIELD_OPTIONS: readonly PreferenceOption[] = [
  { id: 'region', label: 'Region' },
  { id: 'program', label: 'Program' },
  { id: 'facilityType', label: 'Facility type' },
  { id: 'capacity', label: 'Capacity' },
  { id: 'stories', label: '# of stories' },
  { id: 'businessUnit', label: 'Business unit' },
  { id: 'updatedAt', label: 'Last modified date' },
  { id: 'siteAcreage', label: 'Site size (acres)' },
  { id: 'dockDoorCount', label: 'Dock door count' },
  { id: 'totalTrailerParking', label: 'Total trailer parking' },
  { id: 'maxWeeklyHeadcount', label: 'Max. weekly head count' },
  { id: 'powerKva', label: 'Power (Amps)' },
  { id: 'createdBy', label: 'Created by' },
  { id: 'grossSquareFootage', label: 'Building footprint (SF/sq. M)' },
  { id: 'peakShiftHeadcount', label: 'Peak shift head count' },
  { id: 'clearHeightFtM', label: 'Int. clear height (Ft./M)' },
  { id: 'dspParking', label: 'DSP parking' },
  { id: 'generation', label: 'Generation' },
] as const;

export const CARD_PAGE_SIZE_OPTIONS: readonly PageSizeOption[] = [
  { value: 10, label: '10 templates' },
  { value: 20, label: '20 templates' },
  { value: 50, label: '50 templates' },
] as const;

// Default preferences for table view
export const DEFAULT_TABLE_PREFERENCES: TablePreferences = {
  pageSize: DEFAULT_TABLE_PAGE_SIZE,
  contentDisplay: [
    { id: 'name', visible: true },
    { id: 'region', visible: true },
    { id: 'program', visible: true },
    { id: 'facilityType', visible: true },
    { id: 'capacity', visible: true },
    { id: 'stories', visible: true },
    { id: 'businessUnit', visible: true },
    { id: 'updatedAt', visible: true },
    // Hidden columns
    { id: 'siteAcreage', visible: false },
    { id: 'dockDoorCount', visible: false },
    { id: 'totalTrailerParking', visible: false },
    { id: 'maxWeeklyHeadcount', visible: false },
    { id: 'powerKva', visible: false },
    { id: 'createdBy', visible: false },
    { id: 'grossSquareFootage', visible: false },
    { id: 'peakShiftHeadcount', visible: false },
    { id: 'clearHeightFtM', visible: false },
    { id: 'dspParking', visible: false },
    { id: 'generation', visible: false },
  ],
};

// Default preferences for card view
export const DEFAULT_CARD_PREFERENCES: TablePreferences = {
  pageSize: DEFAULT_CARD_PAGE_SIZE,
  cardsPerRowBreakpoints: [...DEFAULT_CARD_BREAKPOINTS],
  contentDisplay: [
    // Default visible fields (6 fields)
    { id: 'region', visible: true },
    { id: 'program', visible: true },
    { id: 'facilityType', visible: true },
    { id: 'capacity', visible: true },
    { id: 'stories', visible: true },
    { id: 'businessUnit', visible: true },
    // Additional fields that can be enabled
    { id: 'updatedAt', visible: false },
    { id: 'siteAcreage', visible: false },
    { id: 'dockDoorCount', visible: false },
    { id: 'totalTrailerParking', visible: false },
    { id: 'maxWeeklyHeadcount', visible: false },
    { id: 'powerKva', visible: false },
    { id: 'createdBy', visible: false },
    { id: 'grossSquareFootage', visible: false },
    { id: 'peakShiftHeadcount', visible: false },
    { id: 'clearHeightFtM', visible: false },
    { id: 'dspParking', visible: false },
    { id: 'generation', visible: false },
  ],
};

// Unified catalog page size options
export const CATALOG_PAGE_SIZE_OPTIONS: readonly PageSizeOption[] = [
  { value: 10, label: '10 templates' },
  { value: 20, label: '20 templates' },
  { value: 30, label: '30 templates' },
  { value: 40, label: '40 templates' },
] as const;

// Default unified catalog preferences (pageSize is NOT stored here - managed via URL only)
export const DEFAULT_CATALOG_PREFERENCES: CatalogPreferences = {
  table: {
    contentDisplay: [
      { id: 'name', visible: true },
      { id: 'region', visible: true },
      { id: 'program', visible: true },
      { id: 'facilityType', visible: true },
      { id: 'capacity', visible: true },
      { id: 'stories', visible: true },
      { id: 'businessUnit', visible: true },
      { id: 'updatedAt', visible: true },
      // Hidden by default
      { id: 'siteAcreage', visible: false },
      { id: 'dockDoorCount', visible: false },
      { id: 'totalTrailerParking', visible: false },
      { id: 'maxWeeklyHeadcount', visible: false },
      { id: 'powerKva', visible: false },
      { id: 'createdBy', visible: false },
      { id: 'grossSquareFootage', visible: false },
      { id: 'peakShiftHeadcount', visible: false },
      { id: 'clearHeightFtM', visible: false },
      { id: 'dspParking', visible: false },
      { id: 'generation', visible: false },
    ],
    wrapLines: false,
    stripedRows: false,
  },
  cards: {
    contentDisplay: [
      // Default visible fields (6 fields)
      { id: 'region', visible: true },
      { id: 'program', visible: true },
      { id: 'facilityType', visible: true },
      { id: 'capacity', visible: true },
      { id: 'stories', visible: true },
      { id: 'businessUnit', visible: true },
      // Hidden by default
      { id: 'updatedAt', visible: false },
      { id: 'siteAcreage', visible: false },
      { id: 'dockDoorCount', visible: false },
      { id: 'totalTrailerParking', visible: false },
      { id: 'maxWeeklyHeadcount', visible: false },
      { id: 'powerKva', visible: false },
      { id: 'createdBy', visible: false },
      { id: 'grossSquareFootage', visible: false },
      { id: 'peakShiftHeadcount', visible: false },
      { id: 'clearHeightFtM', visible: false },
      { id: 'dspParking', visible: false },
      { id: 'generation', visible: false },
    ],
    cardsPerRowBreakpoints: [...DEFAULT_CARD_BREAKPOINTS],
  },
};
