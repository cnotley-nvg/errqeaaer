import { useState } from 'react';
import type { CollectionPreferencesProps } from '@amzn/awsui-components-console';

import { useTablePreferences } from '../../../../hooks/useTablePreferences';
import {
  DEFAULT_TABLE_PREFERENCES,
  TABLE_COLUMN_OPTIONS,
  TABLE_PAGE_SIZE_OPTIONS,
} from './constants';
import type { PreferencesHookResult } from './types';

/**
 * Hook for managing template table preferences (column visibility, page size)
 */
export function useTemplateTablePreferences(): PreferencesHookResult {
  const [preferences, setPreferences, resetPreferences] = useTablePreferences(
    'template-catalog-table-preferences',
    DEFAULT_TABLE_PREFERENCES
  );

  const [preferencesKey, setPreferencesKey] = useState(0);

  const handlePreferencesChange = (detail: CollectionPreferencesProps.Preferences): void => {
    setPreferences(detail);
  };

  const handleResetToDefaults = (): void => {
    resetPreferences();
    setPreferencesKey((prev) => prev + 1);
  };

  return {
    preferences,
    setPreferences: handlePreferencesChange,
    resetPreferences: handleResetToDefaults,
    columnOptions: TABLE_COLUMN_OPTIONS,
    pageSizeOptions: TABLE_PAGE_SIZE_OPTIONS,
    preferencesKey,
  };
}
