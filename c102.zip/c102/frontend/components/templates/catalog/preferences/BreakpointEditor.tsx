import React from 'react';
import { Box, SpaceBetween, Table, Slider } from '@amzn/awsui-components-console';

import type { CardBreakpoint } from '../../../../hooks/useTablePreferences';

interface BreakpointEditorProps {
  breakpoints: CardBreakpoint[];
  onChange: (breakpoints: CardBreakpoint[]) => void;
  currentScreenWidth?: number;
}

const TARGET_BREAKPOINTS = [768, 1366, 1920] as const;
const DEFAULT_CARDS_BY_BREAKPOINT: Record<number, number> = {
  768: 2, // Tablet
  1366: 3, // Laptop
  1920: 4, // Desktop
};
const LEGACY_BREAKPOINT_MAP: Record<number, number> = {
  0: 768,
  1921: 1920,
  2561: 1920,
};

// Fixed min/max cards for each breakpoint
const getCardRangeForBreakpoint = (minWidth: number): { min: number; max: number } => {
  if (minWidth === 768) return { min: 1, max: 2 }; // Tablet: 1-2
  if (minWidth === 1366) return { min: 2, max: 4 }; // Laptop: 2-4
  if (minWidth === 1920) return { min: 3, max: 6 }; // Desktop: 3-6
  return { min: 1, max: 6 }; // Default for custom/legacy breakpoints
};

const clamp = (value: number, min: number, max: number): number =>
  Math.max(min, Math.min(max, value));

// Normalize breakpoints to 3 fixed options and clamp values to valid ranges
export const normalizeBreakpoints = (breakpoints: CardBreakpoint[]): CardBreakpoint[] => {
  const byMinWidth = new Map<number, CardBreakpoint>();
  breakpoints.forEach((bp) => {
    const normalizedMinWidth = LEGACY_BREAKPOINT_MAP[bp.minWidth] ?? bp.minWidth;
    if (!byMinWidth.has(normalizedMinWidth)) {
      byMinWidth.set(normalizedMinWidth, bp);
    }
  });

  return TARGET_BREAKPOINTS.map((minWidth) => {
    const existing = byMinWidth.get(minWidth);
    const { min, max } = getCardRangeForBreakpoint(minWidth);
    const defaultCards = DEFAULT_CARDS_BY_BREAKPOINT[minWidth];
    const cards = clamp(existing?.cards ?? defaultCards, min, max);
    return { minWidth, cards };
  });
};

// Get screen width range label
const getScreenWidthRange = (minWidth: number, breakpoints: CardBreakpoint[]): string => {
  const currentIndex = breakpoints.findIndex((bp) => bp.minWidth === minWidth);
  const nextBreakpoint = breakpoints[currentIndex + 1];

  if (!nextBreakpoint) {
    return `${minWidth}px+`;
  }

  // Range from current to next breakpoint - 1
  return `${minWidth}-${nextBreakpoint.minWidth - 1}px`;
};

// Get screen size label
const getScreenSizeLabel = (minWidth: number): string => {
  if (minWidth === 768) return 'Tablet';
  if (minWidth === 1366) return 'Laptop';
  if (minWidth === 1920) return 'Desktop';
  return 'Custom';
};

export const BreakpointEditor: React.FC<BreakpointEditorProps> = ({
  breakpoints,
  onChange,
  currentScreenWidth,
}) => {
  // Normalize breakpoints on every render to ensure validity
  const normalizedBreakpoints = React.useMemo(
    () => normalizeBreakpoints(breakpoints),
    [breakpoints]
  );

  const handleBreakpointChange = (index: number, field: keyof CardBreakpoint, value: number) => {
    const updated = [...normalizedBreakpoints];
    updated[index] = { ...updated[index], [field]: value };
    onChange(updated);
  };

  // Determine which breakpoint applies to current screen
  const getCurrentBreakpointIndex = (): number | null => {
    if (currentScreenWidth === undefined) return null;
    if (currentScreenWidth < normalizedBreakpoints[0].minWidth) {
      return 0;
    }
    for (let i = normalizedBreakpoints.length - 1; i >= 0; i--) {
      if (currentScreenWidth >= normalizedBreakpoints[i].minWidth) {
        return i;
      }
    }
    return null;
  };

  const currentBreakpointIndex = getCurrentBreakpointIndex();

  return (
    <SpaceBetween size="m">
      <div>
        <Box variant="h5" padding={{ bottom: 'xxxs' }}>
          Card layout by screen size
        </Box>
        <Box variant="small" color="text-body-secondary">
          Adjust the number of cards displayed per row for different screen sizes.
        </Box>
      </div>
      <Table
        columnDefinitions={[
          {
            id: 'label',
            header: 'Screen size',
            cell: (item: CardBreakpoint & { index: number }) => {
              const label = getScreenSizeLabel(item.minWidth);
              const widthRange = getScreenWidthRange(item.minWidth, normalizedBreakpoints);

              return (
                <SpaceBetween size="xxxs">
                  <Box
                    color={currentBreakpointIndex === item.index ? 'text-status-info' : undefined}
                    fontWeight={currentBreakpointIndex === item.index ? 'bold' : undefined}
                  >
                    {label}
                    {currentBreakpointIndex === item.index && <> (current)</>}
                  </Box>
                  <Box variant="small" color="text-body-secondary">
                    {widthRange}
                  </Box>
                </SpaceBetween>
              );
            },
          },
          {
            id: 'cards',
            header: 'Cards per row',
            cell: (item: CardBreakpoint & { index: number }) => {
              const { min: minCards, max: maxCards } = getCardRangeForBreakpoint(item.minWidth);

              // Clamp current value to valid range (handles legacy saved values)
              const clampedValue = Math.max(minCards, Math.min(maxCards, item.cards));

              // If min === max, don't render a Slider - just show static text
              if (minCards === maxCards) {
                return (
                  <Box color="text-body-secondary" fontSize="body-m">
                    {minCards} card (fixed)
                  </Box>
                );
              }

              // When min equals max, step must be 0 or the slider will error
              const step = 1;

              // Show reference values based on min value
              const referenceValues = minCards > 1 ? [minCards, maxCards] : [maxCards];

              return (
                <Slider
                  value={clampedValue}
                  onChange={({ detail }) => {
                    handleBreakpointChange(item.index, 'cards', detail.value);
                  }}
                  min={minCards}
                  max={maxCards}
                  step={step}
                  valueFormatter={(value) => `${value}`}
                  referenceValues={referenceValues}
                />
              );
            },
          },
        ]}
        items={normalizedBreakpoints.map((bp, index) => ({ ...bp, index }))}
        variant="embedded"
        empty={
          <Box textAlign="center" color="inherit">
            No breakpoints defined
          </Box>
        }
      />
    </SpaceBetween>
  );
};
