import type { CollectionPreferencesProps } from '@amzn/awsui-components-console';
import type { TablePreferences } from '../../../../hooks/useTablePreferences';

/**
 * Converts TablePreferences to CollectionPreferencesProps.Preferences
 * Ensures compatibility between our stored preferences and AWSUI component API
 */
export function toCollectionPreferences(
  preferences: TablePreferences
): CollectionPreferencesProps.Preferences {
  return {
    pageSize: preferences.pageSize,
    visibleContent: preferences.visibleContent ? [...preferences.visibleContent] : undefined,
    wrapLines: preferences.wrapLines,
    stripedRows: preferences.stripedRows,
    contentDisplay: preferences.contentDisplay
      ? preferences.contentDisplay.map((item) => ({
          id: item.id,
          visible: item.visible ?? true,
        }))
      : undefined,
  };
}
