import type { CollectionPreferencesProps } from '@amzn/awsui-components-console';
import type { TablePreferences } from '../../../../hooks/useTablePreferences';

export interface PreferenceOption {
  id: string;
  label: string;
  alwaysVisible?: boolean;
}

export interface PageSizeOption {
  value: number;
  label: string;
}

export interface CardBreakpoint {
  minWidth: number; // Minimum screen width in pixels
  cards: number; // Number of cards per row
}

export interface PreferencesHookResult {
  preferences: TablePreferences;
  setPreferences: (preferences: CollectionPreferencesProps.Preferences) => void;
  resetPreferences: () => void;
  columnOptions: readonly PreferenceOption[];
  pageSizeOptions: readonly PageSizeOption[];
  preferencesKey: number;
}

export interface CardPreferencesHookResult {
  preferences: TablePreferences;
  setPreferences: (preferences: CollectionPreferencesProps.Preferences) => void;
  setBreakpoints: (breakpoints: CardBreakpoint[]) => void;
  resetPreferences: () => void;
  fieldOptions: readonly PreferenceOption[];
  pageSizeOptions: readonly PageSizeOption[];
  preferencesKey: number;
}

/**
 * Unified catalog preferences structure for view-specific UI settings
 * NOTE: pageSize is NOT stored here - it's managed via URL parameters only
 */
export interface CatalogPreferences {
  table: {
    contentDisplay: Array<{ id: string; visible: boolean }>;
    wrapLines?: boolean;
    stripedRows?: boolean;
  };
  cards: {
    contentDisplay: Array<{ id: string; visible: boolean }>;
    cardsPerRowBreakpoints: CardBreakpoint[];
  };
}

/**
 * Hook result for useCatalogPreferences
 */
export interface CatalogPreferencesHookResult {
  preferences: CatalogPreferences;
  updateTablePreferences: (updates: Partial<CatalogPreferences['table']>) => void;
  updateCardsPreferences: (updates: Partial<CatalogPreferences['cards']>) => void;
  resetToDefaults: () => void;
}
