import React, { useCallback } from 'react';
import { SegmentedControl, type SegmentedControlProps } from '@amzn/awsui-components-console';

export type TemplateCatalogView = 'card' | 'table';

interface CatalogViewToggleProps {
  value: TemplateCatalogView;
  onChange: (next: TemplateCatalogView) => void;
}

const VIEW_OPTIONS: SegmentedControlProps.Option[] = [
  { id: 'card', text: 'Card view', iconName: 'grid-view' },
  { id: 'table', text: 'Table view', iconName: 'view-full' },
];

export const CatalogViewToggle: React.FC<CatalogViewToggleProps> = ({ value, onChange }) => {
  const handleChange = useCallback(
    ({ detail }: { detail: { selectedId?: string } }) => {
      const nextView = (detail.selectedId as TemplateCatalogView | undefined) ?? 'card';
      onChange(nextView);
    },
    [onChange]
  );

  return <SegmentedControl selectedId={value} onChange={handleChange} options={VIEW_OPTIONS} />;
};
