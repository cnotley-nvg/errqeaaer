import React, { useMemo } from 'react';
import { Box, Cards, Link, SpaceBetween, type CardsProps } from '@amzn/awsui-components-console';
import { useLocation } from 'react-router-dom';

import type { TemplateSummary } from '../../../types/template';
import type { TablePreferences } from '../../../hooks/useTablePreferences';
import { DEFAULT_CARD_BREAKPOINTS } from './preferences/constants';

interface TemplateCardListProps {
  items: readonly TemplateSummary[];
  loading: boolean;
  onOpen: (templateId: string) => void;
  empty: React.ReactNode;
  preferences?: TablePreferences;
}

const renderMetric = (label: string, value: string | number | null | undefined) => (
  <SpaceBetween size="xxs">
    <Box fontWeight="bold">{label}</Box>
    <span>{value ?? '–'}</span>
  </SpaceBetween>
);

const getAttributeValue = (template: TemplateSummary, key: string): string | null => {
  const attributes = template.latestVersion?.attributes ?? {};
  const raw = attributes[key];
  if (raw === null || raw === undefined) {
    return null;
  }
  if (Array.isArray(raw)) {
    // Join all array values with comma separator for multi-value attributes
    const filtered = raw.filter((v) => v !== null && v !== undefined && String(v).trim() !== '');
    return filtered.length > 0 ? filtered.map((v) => String(v)).join(', ') : null;
  }
  if (typeof raw === 'object' && raw !== null && 'value' in raw) {
    return String((raw as { value: unknown }).value ?? '');
  }
  return String(raw);
};

const FALLBACK_HERO = '/thumbnails/Default.svg';

// Default visible fields for card view (6 fields displayed in 2 columns)
const DEFAULT_CARD_FIELDS = [
  'region',
  'program',
  'capacity',
  'stories',
  'facilityType',
  'businessUnit',
];

export const TemplateCardList: React.FC<TemplateCardListProps> = ({
  items,
  loading,
  onOpen,
  empty,
  preferences,
}) => {
  const location = useLocation();

  // Generate cardsPerRow from breakpoints preferences
  const cardsPerRow = useMemo(() => {
    const breakpoints = preferences?.cardsPerRowBreakpoints;
    const resolved = breakpoints && breakpoints.length > 0 ? breakpoints : DEFAULT_CARD_BREAKPOINTS;

    const mapped = resolved.map((bp) => ({
      cards: bp.cards,
      ...(bp.minWidth > 0 && { minWidth: bp.minWidth }),
    }));

    // Ensure a base breakpoint exists for < smallest minWidth
    if (resolved[0]?.minWidth > 0) {
      return [{ cards: resolved[0].cards }, ...mapped];
    }

    return mapped;
  }, [preferences?.cardsPerRowBreakpoints]);

  // Determine which fields to show based on preferences
  const visibleFields = useMemo(() => {
    if (!preferences?.contentDisplay) {
      return DEFAULT_CARD_FIELDS;
    }

    // Filter to only visible fields (no longer restricted to DEFAULT_CARD_FIELDS)
    const visible = preferences.contentDisplay
      .filter((item) => item.visible !== false)
      .map((item) => item.id);

    // If no fields are visible, fall back to defaults
    return visible.length > 0 ? visible : DEFAULT_CARD_FIELDS;
  }, [preferences]);

  // Format date for display
  const formatDate = (iso: string | null | undefined): string => {
    if (!iso) return '–';
    const date = new Date(iso);
    if (Number.isNaN(date.getTime())) return iso;
    return date.toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  // Get field value with special handling for dates
  const getFieldValue = (item: TemplateSummary, fieldId: string): string | number | null => {
    // Handle special date fields
    if (fieldId === 'updatedAt') {
      return formatDate(item.updatedAt);
    }
    if (fieldId === 'createdAt') {
      return formatDate(item.createdAt);
    }
    // Handle regular attribute fields
    return getAttributeValue(item, fieldId);
  };

  // Map field IDs to labels for display (all fields except 'name')
  const fieldLabels: Record<string, string> = {
    region: 'Region',
    program: 'Program',
    facilityType: 'Facility type',
    capacity: 'Capacity',
    stories: 'Number of stories',
    businessUnit: 'Business unit',
    updatedAt: 'Last modified',
    siteAcreage: 'Site size (acres)',
    dockDoorCount: 'Dock door count',
    totalTrailerParking: 'Total trailer parking',
    maxWeeklyHeadcount: 'Max. weekly head count',
    powerKva: 'Power (Amps)',
    createdBy: 'Created by',
    grossSquareFootage: 'Building footprint',
    peakShiftHeadcount: 'Peak shift head count',
    clearHeightFtM: 'Int. clear height',
    dspParking: 'DSP parking',
    generation: 'Generation',
  };

  const cardDefinition = useMemo<CardsProps.CardDefinition<TemplateSummary>>(
    () => ({
      header: (item) => (
        <Box fontSize="heading-m" fontWeight="bold">
          <Link
            href={`/templates/${item.id}${location.search}`}
            onFollow={(event) => {
              event.preventDefault();
              onOpen(item.id);
            }}
          >
            {item.name}
          </Link>
        </Box>
      ),
      sections: [
        {
          id: 'image',
          content: (item) => {
            const imageUrl = item.heroImageUrl || FALLBACK_HERO;

            return (
              <div style={{ marginTop: '1rem', marginBottom: '1rem' }}>
                <img
                  src={imageUrl}
                  alt={`${item.name} thumbnail`}
                  style={{
                    width: '100%',
                    height: 'auto',
                    aspectRatio: '2 / 1',
                    objectFit: 'cover',
                    borderRadius: '8px',
                    backgroundColor: '#f0f0f0',
                    display: 'block',
                  }}
                  onError={(e) => {
                    e.currentTarget.src = FALLBACK_HERO;
                  }}
                  loading="lazy"
                />
              </div>
            );
          },
        },
        {
          id: 'metrics',
          content: (item) => {
            // Dynamically render metrics based on visible fields
            const metricsToShow = visibleFields.map((fieldId) => (
              <React.Fragment key={fieldId}>
                {renderMetric(fieldLabels[fieldId] || fieldId, getFieldValue(item, fieldId))}
              </React.Fragment>
            ));

            // Split metrics into three columns
            const itemsPerColumn = Math.ceil(metricsToShow.length / 3);
            const column1 = metricsToShow.slice(0, itemsPerColumn);
            const column2 = metricsToShow.slice(itemsPerColumn, itemsPerColumn * 2);
            const column3 = metricsToShow.slice(itemsPerColumn * 2);

            return (
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr 1fr',
                  columnGap: '1rem',
                }}
              >
                <SpaceBetween size="s">{column1}</SpaceBetween>
                <SpaceBetween size="s">{column2}</SpaceBetween>
                <SpaceBetween size="s">{column3}</SpaceBetween>
              </div>
            );
          },
        },
      ],
    }),
    [location.search, onOpen, visibleFields]
  );

  return (
    <Cards
      trackBy="id"
      loading={loading}
      loadingText="Loading design templates"
      cardDefinition={cardDefinition}
      cardsPerRow={cardsPerRow}
      items={items as TemplateSummary[]}
      empty={empty}
    />
  );
};
