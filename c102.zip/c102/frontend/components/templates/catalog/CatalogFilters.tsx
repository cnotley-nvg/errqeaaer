import React from 'react';
import {
  Box,
  Button,
  ColumnLayout,
  Container,
  Header,
  Input,
  Select,
  type InputProps,
  type SelectProps,
  SpaceBetween,
} from '@amzn/awsui-components-console';

import type { TemplateFilter } from '../../../types/template';

// Legacy interface for compatibility with old filter UI
interface TemplateFilterSelectOptions {
  regionOptions: SelectProps.Option[];
  programOptions: SelectProps.Option[];
  facilityTypeOptions: SelectProps.Option[];
  businessUnitOptions: SelectProps.Option[];
  generationOptions: SelectProps.Option[];
  versionOptions: SelectProps.Option[];
}

interface CatalogFiltersProps {
  filter: TemplateFilter | undefined;
  filterOptions: TemplateFilterSelectOptions;
  searchValue: string;
  onSearchChange: (value: string) => void;
  onSelectChange: (key: keyof TemplateFilter, value?: string | null) => void;
  onClear: () => void;
}

const SELECT_KEYS: Array<keyof TemplateFilter> = [
  'region',
  'program',
  'facilityType',
  'businessUnit',
  'generation',
  'version',
];

const SELECT_LABELS: Record<keyof TemplateFilter, string> = {
  region: 'Region',
  program: 'Program',
  facilityType: 'Facility type',
  businessUnit: 'Business unit',
  generation: 'Generation',
  version: 'Version',
  searchTerm: 'Search',
};

const optionMap: Record<keyof TemplateFilter, keyof TemplateFilterSelectOptions | undefined> = {
  region: 'regionOptions',
  program: 'programOptions',
  facilityType: 'facilityTypeOptions',
  businessUnit: 'businessUnitOptions',
  generation: 'generationOptions',
  version: 'versionOptions',
  searchTerm: undefined,
};

const selectPlaceholder: Record<keyof TemplateFilter, string> = {
  region: 'All regions',
  program: 'All programs',
  facilityType: 'All facility types',
  businessUnit: 'All business units',
  generation: 'All generations',
  version: 'All versions',
  searchTerm: '',
};

export const CatalogFilters: React.FC<CatalogFiltersProps> = ({
  filter,
  filterOptions,
  searchValue,
  onSearchChange,
  onSelectChange,
  onClear,
}) => {
  const handleSearchChange: InputProps['onChange'] = ({ detail }) => {
    onSearchChange(detail.value);
  };

  const handleSelectChange =
    (key: keyof TemplateFilter): SelectProps['onChange'] =>
    ({ detail }) => {
      onSelectChange(key, detail.selectedOption?.value ?? null);
    };

  const selectedOption = (key: keyof TemplateFilter, options: SelectProps.Option[]) =>
    options.find((option) => option.value === (filter?.[key] ?? null)) ?? null;

  return (
    <Container header={<Header variant="h2">Filter templates</Header>}>
      <SpaceBetween size="l">
        <ColumnLayout columns={3} variant="text-grid">
          <SpaceBetween size="s">
            <Box variant="awsui-key-label">Search templates</Box>
            <Input
              value={searchValue}
              placeholder="Search by name, program, generation, or version"
              onChange={handleSearchChange}
            />
          </SpaceBetween>

          {SELECT_KEYS.map((key) => {
            const optionKey = optionMap[key];
            if (!optionKey) {
              return null;
            }

            const options = filterOptions[optionKey];

            return (
              <SpaceBetween key={key} size="s">
                <Box variant="awsui-key-label">{SELECT_LABELS[key]}</Box>
                <Select
                  placeholder={selectPlaceholder[key]}
                  selectedOption={selectedOption(key, options)}
                  options={options}
                  onChange={handleSelectChange(key)}
                  selectedAriaLabel={SELECT_LABELS[key]}
                />
              </SpaceBetween>
            );
          })}
        </ColumnLayout>

        <Box>
          <Button onClick={onClear}>Clear filters</Button>
        </Box>
      </SpaceBetween>
    </Container>
  );
};
