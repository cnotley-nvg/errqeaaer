import { useCallback, useEffect, useState } from 'react';
import { gql } from 'graphql-request';

import { graphqlClient } from '../../../api/graphqlClient';

export interface LinkField {
  text: string;
  url?: string | null;
}

export interface TemplateVersionChange {
  id: string;
  templateVersionId: string;
  category: string;
  title: string;
  description: string;
  dci?: LinkField | null;
  dcr?: LinkField | null;
  sheet?: string | null;
  changeInCost?: string | null;
}

interface TemplateVersionChangesResponse {
  templateVersionChanges: TemplateVersionChange[];
}

const TEMPLATE_VERSION_CHANGES_QUERY = gql`
  query TemplateVersionChanges($templateVersionId: ID!) {
    templateVersionChanges(templateVersionId: $templateVersionId) {
      id
      templateVersionId
      category
      title
      description
      dci {
        text
        url
      }
      dcr {
        text
        url
      }
      sheet
      changeInCost
    }
  }
`;

export interface TemplateVersionChangesMapResult {
  changesByVersionId: Record<string, TemplateVersionChange[]>;
  loading: boolean;
  error: string | null;
}

export const useTemplateVersionChangesMap = (
  versionIds: readonly string[]
): TemplateVersionChangesMapResult => {
  const [changesByVersionId, setChangesByVersionId] = useState<
    Record<string, TemplateVersionChange[]>
  >({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchChanges = useCallback(async () => {
    const uniqueIds = Array.from(new Set(versionIds.filter(Boolean)));
    if (!uniqueIds.length) {
      setChangesByVersionId({});
      setLoading(false);
      setError(null);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const results = await Promise.all(
        uniqueIds.map((id) =>
          graphqlClient.request<TemplateVersionChangesResponse>(TEMPLATE_VERSION_CHANGES_QUERY, {
            templateVersionId: id,
          })
        )
      );

      const map: Record<string, TemplateVersionChange[]> = {};
      uniqueIds.forEach((id, index) => {
        map[id] = results[index]?.templateVersionChanges ?? [];
      });
      setChangesByVersionId(map);
    } catch (err) {
      setChangesByVersionId({});
      setError(err instanceof Error ? err.message : 'Unable to load template version changes.');
    } finally {
      setLoading(false);
    }
  }, [versionIds.join('|')]);

  useEffect(() => {
    void fetchChanges();
  }, [fetchChanges]);

  return { changesByVersionId, loading, error };
};
