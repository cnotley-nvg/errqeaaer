import { useCallback } from 'react';
import type { TableProps } from '@amzn/awsui-components-console';

import type { TemplateSummary } from '../../../types/template';
import type { SortableTemplateField } from '../../../hooks/useTemplateCatalogControls';

interface UseTemplateSortingProps {
  onSortChange: (field: SortableTemplateField, descending: boolean) => void;
}

type SortingEvent = { detail: TableProps.SortingState<TemplateSummary> };

export const useTemplateSorting = ({ onSortChange }: UseTemplateSortingProps) => {
  const handleSortingChange = useCallback(
    ({ detail }: SortingEvent) => {
      const field = detail.sortingColumn.sortingField as SortableTemplateField | undefined;
      if (!field) {
        return;
      }

      onSortChange(field, detail.isDescending ?? false);
    },
    [onSortChange]
  );

  return { handleSortingChange };
};
