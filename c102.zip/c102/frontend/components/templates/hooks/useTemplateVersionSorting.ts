import { useCallback } from 'react';
import type { TableProps } from '@amzn/awsui-components-console';

import type { SortableTemplateVersionField } from '../../../hooks/useTemplateVersionHistoryControls';

interface UseTemplateVersionSortingProps {
  onSortChange: (field: SortableTemplateVersionField, descending: boolean) => void;
}

export const useTemplateVersionSorting = ({ onSortChange }: UseTemplateVersionSortingProps) => {
  const handleSortingChange = useCallback<NonNullable<TableProps['onSortingChange']>>(
    ({ detail }) => {
      const field = detail.sortingColumn.sortingField as SortableTemplateVersionField | undefined;
      if (!field) {
        return;
      }

      onSortChange(field, detail.isDescending ?? false);
    },
    [onSortChange]
  );

  return { handleSortingChange };
};
