import React from 'react';
import { Link } from '@amzn/awsui-components-console';

import { buildBrsUrl, isValidBrsId } from '../../../utils/accUrlBuilder';

export interface BrsLinkProps {
  /**
   * BRS (Building Requirements Specification) ID
   * Format: Salesforce ID (e.g., "a1q3t00000BmdJHAAZ")
   */
  brsId: string | null | undefined;

  /**
   * Link label text (default: "View BRS")
   */
  label?: string;
}

/**
 * Renders a clickable link to a BRS (Building Requirements Specification) page.
 *
 * If the BRS ID is missing or invalid, renders "–" instead.
 *
 * @example
 * // Basic usage
 * <BrsLink brsId="a1q3t00000BmdJHAAZ" />
 *
 * @example
 * // Custom label
 * <BrsLink brsId="a1q3t00000BmdJHAAZ" label="Open BRS" />
 */
export const BrsLink: React.FC<BrsLinkProps> = ({ brsId, label = 'View BRS' }) => {
  // Validate BRS ID
  if (!brsId || !isValidBrsId(brsId)) {
    return <span>–</span>;
  }

  const url = buildBrsUrl(brsId);

  return (
    <Link href={url} external>
      {label}
    </Link>
  );
};
