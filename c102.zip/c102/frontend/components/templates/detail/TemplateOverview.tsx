import React from 'react';
import { Container, Header, SpaceBetween } from '@amzn/awsui-components-console';

import type { TemplateVersionDetail } from '../../../hooks/useTemplateDetail';
import { TemplateOverviewMetadata } from './TemplateOverviewMetadata';
import { TemplateFilesTable } from './TemplateFilesTable';

interface TemplateOverviewProps {
  versions: TemplateVersionDetail[];
  selectedVersion: TemplateVersionDetail | null;
  accProjectId: string | null;
  onVersionChange: (versionId: string) => void;
  onDownloadFile: (fileId: string) => void | Promise<void>;
  downloadingFileId: string | null;
}

export const TemplateOverview: React.FC<TemplateOverviewProps> = ({
  versions,
  selectedVersion,
  accProjectId,
  onVersionChange,
  onDownloadFile,
  downloadingFileId,
}) => {
  const filesForSelectedVersion = selectedVersion?.files ?? [];

  return (
    <SpaceBetween size="l">
      <TemplateOverviewMetadata selectedVersion={selectedVersion} accProjectId={accProjectId} />

      <Container
        header={
          <Header
            variant="h2"
            // Commented out: bulk download functionality not yet implemented
            // actions={
            //   <Button iconName="download" variant="normal" disabled>
            //     Download
            //   </Button>
            // }
          >
            {`PDF drawings (${filesForSelectedVersion.length})`}
          </Header>
        }
      >
        <TemplateFilesTable
          files={filesForSelectedVersion}
          onDownload={onDownloadFile}
          downloadingId={downloadingFileId}
          versionLabel={selectedVersion?.version ?? null}
        />
      </Container>
    </SpaceBetween>
  );
};
