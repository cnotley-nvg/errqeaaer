import React, { useCallback, useMemo, useState } from 'react';
import {
  Box,
  Button,
  CollectionPreferences,
  type CollectionPreferencesProps,
  Container,
  Header,
  Pagination,
  SpaceBetween,
  Table,
  type PropertyFilterProps,
  type TableProps,
} from '@amzn/awsui-components-console';

import { CatalogSearchBar } from '../../shared/CatalogSearchBar';
import { useTemplateVersionChangesMap, type LinkField } from '../hooks/useTemplateVersionChanges';
import { generateTemplateRevisionHistoryPdf } from '../../../utils/templateRevisionHistoryPdfGenerator';

interface TemplateRevisionHistoryProps {
  templateVersionId: string;
  templateName: string;
  templateVersion: string;
  templateDescription?: string;
}

interface RevisionRow {
  id: string;
  category: string;
  title: string;
  description: string;
  dci?: LinkField | null;
  dcr?: LinkField | null;
  sheet?: string | null;
  changeInCost?: string | null;
}

interface ContentDisplayItem {
  id: string;
  visible: boolean;
}

interface Preferences {
  pageSize: number;
  contentDisplay: readonly ContentDisplayItem[];
  wrapLines?: boolean;
  stripedRows?: boolean;
  contentDensity?: 'compact' | 'comfortable';
}

const DEFAULT_PREFERENCES: Preferences = {
  pageSize: 10,
  contentDisplay: [
    { id: 'category', visible: true },
    { id: 'title', visible: true },
    { id: 'description', visible: true },
    { id: 'dci', visible: true },
    { id: 'dcr', visible: true },
    { id: 'sheet', visible: true },
    { id: 'changeInCost', visible: true },
  ],
  wrapLines: true,
  stripedRows: false,
  contentDensity: 'comfortable',
};

/**
 * Apply a single PropertyFilter token to filter a row
 * Supports operators: ':', '=', '!=', '!:'
 * Handles multi-select enum tokens (value can be string or array)
 */
const applyToken = (row: RevisionRow, token: PropertyFilterProps.Token): boolean => {
  const { propertyKey, operator, value } = token;

  if (!propertyKey || !value) {
    return true; // Invalid token, don't filter
  }

  let rawValue = row[propertyKey as keyof RevisionRow];
  // Extract text from LinkField if needed
  if (rawValue && typeof rawValue === 'object' && 'text' in rawValue) {
    rawValue = rawValue.text;
  }
  const rowValue = (rawValue || '').toString().toLowerCase();

  // Handle multi-select enum tokens (value can be string or array)
  const values = Array.isArray(value) ? value : [value];

  switch (operator) {
    case ':': // Contains
      // Only works with single string value
      if (typeof value === 'string') {
        return rowValue.includes(value.toLowerCase());
      }
      return true;
    case '!:': // Does not contain
      // Only works with single string value
      if (typeof value === 'string') {
        return !rowValue.includes(value.toLowerCase());
      }
      return true;
    case '=': // Equals (OR logic for multiple values)
      return values.some((v) => typeof v === 'string' && rowValue === v.toLowerCase());
    case '!=': // Not equals (AND logic - must not match ANY)
      return values.every((v) => typeof v === 'string' && rowValue !== v.toLowerCase());
    default:
      return true;
  }
};

/**
 * Apply PropertyFilter query to rows array
 * Handles AND/OR operations between tokens
 */
const applyPropertyFilter = (
  rows: RevisionRow[],
  query: PropertyFilterProps.Query
): RevisionRow[] => {
  if (!query.tokens || query.tokens.length === 0) {
    return rows;
  }

  const operation = query.operation || 'and';

  return rows.filter((row) => {
    if (operation === 'and') {
      // ALL tokens must match
      return query.tokens.every((token) => applyToken(row, token));
    } else {
      // ANY token must match
      return query.tokens.some((token) => applyToken(row, token));
    }
  });
};

export const TemplateRevisionHistory: React.FC<TemplateRevisionHistoryProps> = ({
  templateVersionId,
  templateName,
  templateVersion,
  templateDescription,
}) => {
  // User preferences state
  const [preferences, setPreferences] = useState<Preferences>(DEFAULT_PREFERENCES);

  // Local state for client-side filtering/sorting/pagination
  const [propertyFilterQuery, setPropertyFilterQuery] = useState<PropertyFilterProps.Query>({
    tokens: [],
    operation: 'and',
  });
  const [sortingField, setSortingField] = useState<'category' | 'title' | 'description'>(
    'category'
  );
  const [sortingDescending, setSortingDescending] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  // Fetch changes for the single template version
  const { changesByVersionId, loading, error } = useTemplateVersionChangesMap([templateVersionId]);
  const versionChanges = changesByVersionId[templateVersionId] ?? [];

  // 1. Build complete list of changes for this version
  const allRows = useMemo<RevisionRow[]>(() => {
    return versionChanges.map((change) => ({
      id: change.id,
      category: change.category || '—',
      title: change.title || '—',
      description: change.description || '—',
      dci: change.dci || null,
      dcr: change.dcr || null,
      sheet: change.sheet || null,
      changeInCost: change.changeInCost || null,
    }));
  }, [versionChanges]);

  // 2. Apply PropertyFilter tokens (client-side filtering)
  const filteredRows = useMemo<RevisionRow[]>(() => {
    return applyPropertyFilter(allRows, propertyFilterQuery);
  }, [allRows, propertyFilterQuery]);

  // 3. Apply sorting
  const sortedRows = useMemo<RevisionRow[]>(() => {
    const sorted = [...filteredRows];
    sorted.sort((a, b) => {
      const aVal = a[sortingField] || '';
      const bVal = b[sortingField] || '';
      const comparison = aVal.localeCompare(bVal, undefined, { sensitivity: 'base' });
      return sortingDescending ? -comparison : comparison;
    });
    return sorted;
  }, [filteredRows, sortingField, sortingDescending]);

  // 4. Apply pagination (dynamic page size based on preferences)
  const totalPages = Math.ceil(sortedRows.length / preferences.pageSize);
  const paginatedRows = useMemo<RevisionRow[]>(() => {
    const startIdx = (currentPage - 1) * preferences.pageSize;
    return sortedRows.slice(startIdx, startIdx + preferences.pageSize);
  }, [sortedRows, currentPage, preferences.pageSize]);

  // Reset to page 1 when filter changes
  const handleFilterChange = useCallback((query: PropertyFilterProps.Query) => {
    setPropertyFilterQuery(query);
    setCurrentPage(1);
  }, []);

  // Handle sorting changes
  const handleSortingChange = useCallback(
    (event: {
      detail: { sortingColumn: { sortingField?: string | undefined }; isDescending?: boolean };
    }) => {
      const field = event.detail.sortingColumn.sortingField;
      if (field && (field === 'category' || field === 'title' || field === 'description')) {
        setSortingField(field);
        setSortingDescending(event.detail.isDescending ?? false);
      }
    },
    []
  );

  // Handle pagination
  const handlePageChange = useCallback((event: { detail: { currentPageIndex: number } }) => {
    setCurrentPage(event.detail.currentPageIndex);
  }, []);

  // Handle preferences changes
  const handlePreferencesChange = useCallback((event: { detail: Partial<Preferences> }) => {
    setPreferences((prev) => ({ ...prev, ...event.detail }));
    // Reset to page 1 when page size changes
    if (event.detail.pageSize !== undefined) {
      setCurrentPage(1);
    }
  }, []);

  // Handle PDF download
  const handleDownloadPdf = useCallback(() => {
    const now = new Date();
    const generatedDate = now.toLocaleString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });

    generateTemplateRevisionHistoryPdf({
      templateName,
      versionRange: templateVersion,
      description: templateDescription,
      generatedDate,
      totalChanges: sortedRows.length,
      changes: sortedRows.map((row) => ({
        category: row.category,
        title: row.title,
        description: row.description,
        dci: row.dci,
        dcr: row.dcr,
        sheet: row.sheet,
        changeInCost: row.changeInCost,
      })),
    });
  }, [templateName, templateVersion, templateDescription, sortedRows]);

  // Define filterable properties
  const filteringProperties: ReadonlyArray<PropertyFilterProps.FilteringProperty> = useMemo(
    () => [
      {
        key: 'title',
        operators: [':', '!:'], // Contains and does not contain only - no exact match
        propertyLabel: 'Title',
        groupValuesLabel: 'Title values',
      },
      {
        key: 'category',
        operators: [
          { operator: '=', tokenType: 'enum' }, // Multi-select checkboxes for equals
          { operator: '!=', tokenType: 'enum' }, // Multi-select checkboxes for not equals
        ],
        propertyLabel: 'Discipline',
        groupValuesLabel: 'Discipline values',
      },
      {
        key: 'description',
        operators: [':', '!:'], // Contains and does not contain only - no exact match
        propertyLabel: 'Description',
        groupValuesLabel: 'Description values',
      },
      {
        key: 'dci',
        operators: ['=', '!=', ':'],
        propertyLabel: 'DCI #',
        groupValuesLabel: 'DCI values',
      },
      {
        key: 'dcr',
        operators: ['=', '!=', ':'],
        propertyLabel: 'DCR #',
        groupValuesLabel: 'DCR values',
      },
      {
        key: 'sheet',
        operators: ['=', '!=', ':'],
        propertyLabel: 'Sheet',
        groupValuesLabel: 'Sheet values',
      },
      {
        key: 'changeInCost',
        operators: [
          { operator: '=', tokenType: 'enum' }, // Multi-select checkboxes for equals
          { operator: '!=', tokenType: 'enum' }, // Multi-select checkboxes for not equals
        ],
        propertyLabel: 'Change in Cost',
        groupValuesLabel: 'Change in Cost values',
      },
    ],
    []
  );

  // Generate filtering options for discrete value properties (Discipline, Change in Cost, DCI, DCR, Sheet)
  // Do NOT provide options for text fields (Change, Description) to prevent auto-added = operator
  const filteringOptions: ReadonlyArray<PropertyFilterProps.FilteringOption> = useMemo(() => {
    const categories = new Set<string>();
    const dcis = new Set<string>();
    const dcrs = new Set<string>();
    const sheets = new Set<string>();
    const changeInCosts = new Set<string>();

    for (const row of allRows) {
      if (row.category && row.category !== '—') {
        categories.add(row.category);
      }
      if (row.dci?.text) {
        dcis.add(row.dci.text);
      }
      if (row.dcr?.text) {
        dcrs.add(row.dcr.text);
      }
      if (row.sheet) {
        sheets.add(row.sheet);
      }
      if (row.changeInCost) {
        changeInCosts.add(row.changeInCost);
      }
    }

    return [
      // Provide options for discrete-value fields to enable Cloudscape UI enhancements:
      // - Fields with 'enum' tokenType (category, changeInCost) render as multi-select checkboxes
      // - Fields with standard operators (dci, dcr, sheet) render as dropdown suggestions

      // Discipline - enum tokenType enables multi-select checkboxes
      ...Array.from(categories)
        .sort()
        .map((value) => ({
          propertyKey: 'category',
          value,
          label: value,
        })),

      // DCI # - provides dropdown suggestions
      ...Array.from(dcis)
        .sort()
        .map((value) => ({
          propertyKey: 'dci',
          value,
          label: value,
        })),

      // DCR # - provides dropdown suggestions
      ...Array.from(dcrs)
        .sort()
        .map((value) => ({
          propertyKey: 'dcr',
          value,
          label: value,
        })),

      // Sheet - provides dropdown suggestions
      ...Array.from(sheets)
        .sort()
        .map((value) => ({
          propertyKey: 'sheet',
          value,
          label: value,
        })),

      // Change in Cost - enum tokenType enables multi-select checkboxes
      ...Array.from(changeInCosts)
        .sort()
        .map((value) => ({
          propertyKey: 'changeInCost',
          value,
          label: value,
        })),

      // NOTE: No options for 'title' or 'description' (freeform text fields)
      // This limits them to ':' (contains) operator without auto-added '=' (equals)
    ];
  }, [allRows]);

  // All column definitions (including those that may be hidden)
  const allColumnDefinitions = useMemo<TableProps.ColumnDefinition<RevisionRow>[]>(
    () => [
      {
        id: 'category',
        header: 'Discipline',
        cell: (item) => item.category || '—',
        sortingField: 'category',
        minWidth: 160,
      },
      {
        id: 'title',
        header: 'Title',
        cell: (item) => item.title || '—',
        sortingField: 'title',
        minWidth: 240,
      },
      {
        id: 'description',
        header: 'Description',
        cell: (item) => item.description || '—',
        sortingField: 'description',
        minWidth: 320,
        maxWidth: 500,
      },
      {
        id: 'dci',
        header: 'DCI #',
        cell: (item) => {
          if (!item.dci) return '—';
          if (item.dci.url) {
            return (
              <a href={item.dci.url} target="_blank" rel="noopener noreferrer">
                {item.dci.text}
              </a>
            );
          }
          return item.dci.text;
        },
        minWidth: 140,
      },
      {
        id: 'dcr',
        header: 'DCR #',
        cell: (item) => {
          if (!item.dcr) return '—';
          if (item.dcr.url) {
            return (
              <a href={item.dcr.url} target="_blank" rel="noopener noreferrer">
                {item.dcr.text}
              </a>
            );
          }
          return item.dcr.text;
        },
        minWidth: 140,
      },
      {
        id: 'sheet',
        header: 'Sheet',
        cell: (item) => (
          <div style={{ wordBreak: 'break-word', whiteSpace: 'normal' }}>{item.sheet || '—'}</div>
        ),
        minWidth: 120,
        maxWidth: 300,
      },
      {
        id: 'changeInCost',
        header: 'Change in Cost',
        cell: (item) => item.changeInCost || '—',
        minWidth: 140,
      },
    ],
    []
  );

  // Filter and order columns based on contentDisplay preferences
  const visibleColumnDefinitions = useMemo(() => {
    // Map contentDisplay to columns, preserving order and filtering by visibility
    return preferences.contentDisplay
      .filter((item) => item.visible)
      .map((item) => allColumnDefinitions.find((col) => col.id === item.id))
      .filter((col): col is TableProps.ColumnDefinition<RevisionRow> => col !== undefined);
  }, [allColumnDefinitions, preferences.contentDisplay]);

  // Collection preferences configuration
  const collectionPreferencesProps: CollectionPreferencesProps = {
    title: 'Preferences',
    confirmLabel: 'Confirm',
    cancelLabel: 'Cancel',
    preferences: {
      pageSize: preferences.pageSize,
      contentDisplay: preferences.contentDisplay,
      wrapLines: preferences.wrapLines,
      stripedRows: preferences.stripedRows,
      contentDensity: preferences.contentDensity,
    },
    onConfirm: handlePreferencesChange,
    pageSizePreference: {
      title: 'Page size',
      options: [
        { value: 10, label: '10 resources' },
        { value: 20, label: '20 resources' },
        { value: 50, label: '50 resources' },
      ],
    },
    wrapLinesPreference: {
      label: 'Wrap lines',
      description: 'Select to see all the text and wrap the lines',
    },
    stripedRowsPreference: {
      label: 'Striped rows',
      description: 'Select to add alternating shaded rows',
    },
    contentDensityPreference: {
      label: 'Compact mode',
      description: 'Select to display content in a denser, more compact mode',
    },
    contentDisplayPreference: {
      title: 'Column preferences',
      description: 'Customize the visibility and order of the columns.',
      options: [
        { id: 'category', label: 'Discipline', alwaysVisible: true },
        { id: 'title', label: 'Title' },
        { id: 'description', label: 'Description' },
        { id: 'dci', label: 'DCI #' },
        { id: 'dcr', label: 'DCR #' },
        { id: 'sheet', label: 'Sheet' },
        { id: 'changeInCost', label: 'Change in Cost' },
      ],
    },
  };

  if (error) {
    return (
      <Container>
        <Box textAlign="center" padding="m" color="text-status-error">
          {error}
        </Box>
      </Container>
    );
  }

  return (
    <Container
      header={
        <Header
          variant="h2"
          actions={
            <Button
              iconName="download"
              variant="normal"
              onClick={handleDownloadPdf}
              disabled={loading || sortedRows.length === 0}
            >
              Download
            </Button>
          }
        >
          {`Revision log (${sortedRows.length})`}
        </Header>
      }
    >
      <SpaceBetween size="s">
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: '16px',
          }}
        >
          <div style={{ flex: 1, minWidth: 0 }}>
            <CatalogSearchBar
              value=""
              onChange={() => {}}
              placeholder="Find resources"
              ariaLabel="Filter template version changes"
              filteringProperties={filteringProperties}
              filteringOptions={filteringOptions}
              propertyFilterQuery={propertyFilterQuery}
              onPropertyFilterTokensChange={handleFilterChange}
              width="100%"
            />
          </div>
          <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
            {totalPages > 1 && (
              <Pagination
                currentPageIndex={currentPage}
                pagesCount={totalPages}
                onChange={handlePageChange}
              />
            )}
            <CollectionPreferences {...collectionPreferencesProps} />
          </div>
        </div>

        <Table
          trackBy="id"
          items={paginatedRows}
          loading={loading}
          loadingText="Loading version history"
          columnDefinitions={visibleColumnDefinitions}
          sortingColumn={{ sortingField }}
          sortingDescending={sortingDescending}
          onSortingChange={handleSortingChange}
          variant="embedded"
          wrapLines={preferences.wrapLines}
          stripedRows={preferences.stripedRows}
          contentDensity={preferences.contentDensity}
          empty={
            <Box textAlign="center" padding="s">
              No history available.
            </Box>
          }
        />
      </SpaceBetween>
    </Container>
  );
};
