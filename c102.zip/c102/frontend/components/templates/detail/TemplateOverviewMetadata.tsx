import React, { useMemo } from 'react';
import { Box, ColumnLayout, Container, Link, SpaceBetween } from '@amzn/awsui-components-console';

import type { TemplateVersionDetail } from '../../../hooks/useTemplateDetail';
import { BimLink } from '../../standards/common';
import { BrsLink } from '../common';
import { buildPhoneToolUrl, isValidPhoneToolUsername } from '../../../utils/accUrlBuilder';

interface TemplateOverviewMetadataProps {
  selectedVersion: TemplateVersionDetail | null;
  accProjectId: string | null;
}

const attributeValue = (version: TemplateVersionDetail | null, key: string): string => {
  if (!version) {
    return '–';
  }

  const raw = version.attributes?.[key];
  if (raw === null || raw === undefined) {
    return '–';
  }
  if (Array.isArray(raw)) {
    return raw.length ? String(raw[0]) : '–';
  }
  if (typeof raw === 'object' && raw !== null && 'value' in raw) {
    const value = (raw as { value: unknown }).value;
    return value !== undefined && value !== null ? String(value) : '–';
  }
  return String(raw);
};

const formatLongDate = (iso: string | null | undefined): string => {
  if (!iso) {
    return '–';
  }
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) {
    return iso;
  }
  return date.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
};

interface MetadataFieldProps {
  label: string;
  children: React.ReactNode;
}

const MetadataField: React.FC<MetadataFieldProps> = ({ label, children }) => (
  <SpaceBetween size="xxs">
    <Box variant="awsui-key-label">{label}</Box>
    <div>{children}</div>
  </SpaceBetween>
);

export const TemplateOverviewMetadata: React.FC<TemplateOverviewMetadataProps> = ({
  selectedVersion,
  accProjectId,
}) => {
  const createdByRaw = attributeValue(selectedVersion, 'createdBy');
  const createdByUrl = isValidPhoneToolUsername(createdByRaw)
    ? buildPhoneToolUrl(createdByRaw)
    : null;

  const clearHeightValue = attributeValue(selectedVersion, 'clearHeightFtM');
  const dspParkingValue = attributeValue(selectedVersion, 'dspParking');

  const accFolderId = selectedVersion?.accFolderId;
  const brsId = selectedVersion?.brsId;

  return (
    <Container>
      <SpaceBetween size="l">
        <ColumnLayout columns={4} variant="text-grid">
          {/* Column 1 */}
          <SpaceBetween size="s">
            <MetadataField label="Region">
              <span>{attributeValue(selectedVersion, 'region')}</span>
            </MetadataField>

            <MetadataField label="Facility type">
              <span>{attributeValue(selectedVersion, 'facilityType')}</span>
            </MetadataField>

            <MetadataField label="Max. Weekly head count">
              <span>{attributeValue(selectedVersion, 'maxWeeklyHeadcount')}</span>
            </MetadataField>

            <MetadataField label="Power req(Amps)">
              <span>{attributeValue(selectedVersion, 'powerKva')}</span>
            </MetadataField>

            <MetadataField label="Last modified date">
              <span>{formatLongDate(selectedVersion?.updatedAt ?? null)}</span>
            </MetadataField>
          </SpaceBetween>

          {/* Column 2 */}
          <SpaceBetween size="s">
            <MetadataField label="Program">
              <span>{attributeValue(selectedVersion, 'program')}</span>
            </MetadataField>

            <MetadataField label="Business unit">
              <span>{attributeValue(selectedVersion, 'businessUnit')}</span>
            </MetadataField>

            <MetadataField label="Site size (acres)">
              <span>{attributeValue(selectedVersion, 'siteAcreage')}</span>
            </MetadataField>

            <MetadataField label="Dock door count">
              <span>{attributeValue(selectedVersion, 'dockDoorCount')}</span>
            </MetadataField>

            <MetadataField label="Created by">
              {createdByUrl ? (
                <Link external href={createdByUrl} variant="primary">
                  {createdByRaw}
                </Link>
              ) : (
                <span>{createdByRaw}</span>
              )}
            </MetadataField>
          </SpaceBetween>

          {/* Column 3 */}
          <SpaceBetween size="s">
            <MetadataField label="Capacity">
              <span>{attributeValue(selectedVersion, 'capacity')}</span>
            </MetadataField>

            <MetadataField label="Generation">
              <span>{attributeValue(selectedVersion, 'generation')}</span>
            </MetadataField>

            <MetadataField label="Building footprint (SF/sq. M)">
              <span>{attributeValue(selectedVersion, 'grossSquareFootage')}</span>
            </MetadataField>

            <MetadataField label="Total trailer parking">
              <span>{attributeValue(selectedVersion, 'totalTrailerParking')}</span>
            </MetadataField>

            <MetadataField label="BIM 360 link">
              <BimLink accProjectId={accProjectId} accFolderId={accFolderId} label="Info" />
            </MetadataField>
          </SpaceBetween>

          {/* Column 4 */}
          <SpaceBetween size="s">
            <MetadataField label="Number of stories">
              <span>{attributeValue(selectedVersion, 'stories')}</span>
            </MetadataField>

            <MetadataField label="Peak shift head count">
              <span>{attributeValue(selectedVersion, 'peakShiftHeadcount')}</span>
            </MetadataField>

            <MetadataField label="Int. Clear height (ft./M)">
              <span>{clearHeightValue}</span>
            </MetadataField>

            <MetadataField label="DSP parking">
              <span>{dspParkingValue}</span>
            </MetadataField>

            <MetadataField label="BRS link">
              <BrsLink brsId={brsId} />
            </MetadataField>
          </SpaceBetween>
        </ColumnLayout>
      </SpaceBetween>
    </Container>
  );
};
