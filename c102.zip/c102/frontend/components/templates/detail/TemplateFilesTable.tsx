import React, { useMemo } from 'react';
import { Box, Button, Table, type TableProps } from '@amzn/awsui-components-console';

import type { TemplateFileDetail } from '../../../hooks/useTemplateDetail';

interface TemplateFilesTableProps {
  files: readonly TemplateFileDetail[];
  onDownload: (fileId: string) => void | Promise<void>;
  downloadingId: string | null;
  versionLabel?: string | null;
}

const formatDate = (value?: string | null): string => {
  if (!value) {
    return '–';
  }

  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? value : parsed.toLocaleDateString();
};

const extractFileName = (accFileId: string) => {
  try {
    const url = new URL(accFileId);
    return url.pathname.split('/').filter(Boolean).pop() ?? accFileId;
  } catch (_error) {
    return accFileId;
  }
};

export const TemplateFilesTable: React.FC<TemplateFilesTableProps> = ({
  files,
  onDownload,
  downloadingId,
  versionLabel,
}) => {
  const columnDefinitions = useMemo<TableProps.ColumnDefinition<TemplateFileDetail>[]>(
    () => [
      {
        id: 'name',
        header: 'Discipline name',
        cell: (item) =>
          item.displayName && item.displayName.trim().length
            ? item.displayName
            : extractFileName(item.accFileId),
        minWidth: 220,
      },
      {
        id: 'version',
        header: 'Version',
        cell: () => (versionLabel && versionLabel.trim().length ? versionLabel : '—'),
        width: 80,
      },
      {
        id: 'createdAt',
        header: 'Created date',
        cell: (item) => formatDate(item.createdAt),
        width: 120,
      },
      {
        id: 'actions',
        header: '',
        cell: (item) => (
          <Button
            iconName="download"
            variant="inline-icon"
            loading={downloadingId === item.id}
            onClick={() => onDownload(item.id)}
          />
        ),
        width: 60,
      },
    ],
    [downloadingId, onDownload, versionLabel]
  );

  return (
    <Table
      trackBy="id"
      variant="embedded"
      columnDefinitions={columnDefinitions}
      items={files as TemplateFileDetail[]}
      empty={
        <Box textAlign="center" padding="s">
          No files available for this version.
        </Box>
      }
    />
  );
};
