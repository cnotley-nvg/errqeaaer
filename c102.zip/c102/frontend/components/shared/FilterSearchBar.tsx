import React, { useCallback, useMemo, useState } from 'react';
import { PropertyFilter, type PropertyFilterProps } from '@amzn/awsui-components-console';

export interface FilterSearchBarProps {
  value: string;
  onChange: (nextValue: string) => void;

  query?: PropertyFilterProps.Query;
  propertyFilterQuery?: PropertyFilterProps.Query;
  onTokensChange?: (nextQuery: PropertyFilterProps.Query) => void;
  onPropertyFilterTokensChange?: (nextQuery: PropertyFilterProps.Query) => void;

  placeholder: string;
  ariaLabel: string;
  rightAdornment?: React.ReactNode;

  filteringProperties: ReadonlyArray<PropertyFilterProps.FilteringProperty>;
  filteringOptions?: ReadonlyArray<PropertyFilterProps.FilteringOption>;

  width?: number | string;
  disableFreeTextFiltering?: boolean;
  enableTokenGroups?: boolean;
}

export const FilterSearchBar: React.FC<FilterSearchBarProps> = ({
  value,
  onChange,
  query,
  propertyFilterQuery,
  onTokensChange,
  onPropertyFilterTokensChange,
  placeholder,
  ariaLabel,
  rightAdornment,
  filteringProperties,
  filteringOptions,
  width = '100%',
  disableFreeTextFiltering = true,
  enableTokenGroups = false,
}) => {
  const [localQuery, setLocalQuery] = useState<PropertyFilterProps.Query>({
    tokens: [],
    operation: 'and',
    tokenGroups: [],
  });

  const resolvedQuery = useMemo<PropertyFilterProps.Query>(() => {
    if (query) {
      return query;
    }

    if (propertyFilterQuery) {
      return propertyFilterQuery;
    }

    const text = typeof value === 'string' ? value.trim() : '';
    if (!text) {
      return localQuery;
    }

    const primary = filteringProperties[0];
    if (!primary) {
      return localQuery;
    }

    return {
      tokens: [
        {
          propertyKey: primary.key,
          operator: ':',
          value: text,
        },
      ],
      operation: 'and',
      tokenGroups: [],
    };
  }, [query, propertyFilterQuery, value, localQuery, filteringProperties]);

  const handleFilterChange = useCallback<PropertyFilterProps['onChange']>(
    (event) => {
      const nextQuery = event.detail;
      setLocalQuery(nextQuery);

      const primary = filteringProperties[0];
      if (primary) {
        const primaryToken = nextQuery.tokens.find(
          (token) => token.propertyKey === primary.key && typeof token.value === 'string'
        );
        const nextValue = (primaryToken?.value as string) ?? '';
        onChange(nextValue);
      } else {
        onChange('');
      }

      if (onTokensChange) {
        onTokensChange(nextQuery);
      }
      if (onPropertyFilterTokensChange) {
        onPropertyFilterTokensChange(nextQuery);
      }
    },
    [filteringProperties, onChange, onTokensChange, onPropertyFilterTokensChange]
  );

  const resolvedFilteringOptions = filteringOptions ?? [];

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '1rem',
        flexWrap: 'nowrap',
      }}
    >
      <div
        style={{
          flex: '1 1 auto',
          minWidth: 0,
        }}
      >
        <PropertyFilter
          query={resolvedQuery}
          onChange={handleFilterChange}
          filteringPlaceholder={placeholder}
          filteringAriaLabel={ariaLabel}
          filteringProperties={filteringProperties}
          filteringOptions={resolvedFilteringOptions}
          countText=""
          disableFreeTextFiltering={disableFreeTextFiltering}
          enableTokenGroups={enableTokenGroups}
          expandToViewport={true}
          i18nStrings={{
            enteredTextLabel: (text) => `Use: "${text}"`,
            dismissAriaLabel: 'Dismiss',
            clearAriaLabel: 'Clear',
            groupValuesText: 'Values',
            groupPropertiesText: 'Properties',
            operatorsText: 'Operators',
            operationAndText: 'and',
            operationOrText: 'or',
            operatorLessText: 'Less than',
            operatorLessOrEqualText: 'Less than or equal',
            operatorGreaterText: 'Greater than',
            operatorGreaterOrEqualText: 'Greater than or equal',
            operatorContainsText: 'Contains',
            operatorDoesNotContainText: 'Does not contain',
            operatorEqualsText: 'Equals',
            operatorDoesNotEqualText: 'Does not equal',
            operatorStartsWithText: 'Starts with',
            operatorDoesNotStartWithText: 'Does not start with',
            editTokenHeader: 'Edit filter',
            propertyText: 'Property',
            operatorText: 'Operator',
            valueText: 'Value',
            cancelActionText: 'Cancel',
            applyActionText: 'Apply',
            allPropertiesLabel: 'All properties',
            clearFiltersText: 'Clear filters',
            tokenLimitShowMore: 'Show more',
            tokenLimitShowFewer: 'Show fewer',
            removeTokenButtonAriaLabel: (token) =>
              `Remove token ${token.propertyLabel} ${token.operator} ${token.value}`,
          }}
        />
      </div>

      {rightAdornment && (
        <div
          style={{
            flex: '0 0 auto',
            display: 'flex',
            alignItems: 'center',
          }}
        >
          {rightAdornment}
        </div>
      )}
    </div>
  );
};
