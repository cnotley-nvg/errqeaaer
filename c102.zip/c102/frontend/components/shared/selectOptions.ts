import type { MultiselectProps } from '@amzn/awsui-components-console';

import { formatProgramLabel } from '../../utils/attributeDisplay';

export const createSelectOptions = (values: readonly string[]): MultiselectProps.Option[] =>
  values.map((value) => ({ value, label: value }));

export const createProgramOptions = (values: readonly string[]): MultiselectProps.Option[] =>
  values.map((value) => ({
    value,
    label: formatProgramLabel(value),
  }));

export const resolveSelectedOptions = (
  selections: readonly string[],
  options: ReadonlyArray<MultiselectProps.Option>
): MultiselectProps.Option[] => {
  if (!selections.length) {
    return [];
  }

  const optionMap = new Map(options.map((option) => [option.value ?? '', option]));
  return selections
    .map((selection) => optionMap.get(selection) ?? { value: selection, label: selection })
    .filter((option): option is MultiselectProps.Option => Boolean(option.value));
};

export const normalizeSelections = (values: readonly string[]): string[] => {
  const unique = new Set<string>();
  values.forEach((value) => {
    const trimmed = value.trim();
    if (trimmed.length) {
      unique.add(trimmed);
    }
  });
  return Array.from(unique);
};
