import React from 'react';
import type { PropertyFilterProps } from '@amzn/awsui-components-console';
import { FilterSearchBar } from './FilterSearchBar';

interface CatalogSearchBarProps {
  value: string;
  onChange: (nextValue: string) => void;
  onTokensChange?: (nextQuery: PropertyFilterProps.Query) => void;
  query?: PropertyFilterProps.Query;
  placeholder: string;
  ariaLabel: string;
  rightAdornment?: React.ReactNode;
  filteringOptions?: ReadonlyArray<PropertyFilterProps.FilteringOption>;
  filteringProperties?: ReadonlyArray<PropertyFilterProps.FilteringProperty>;
  propertyFilterQuery?: PropertyFilterProps.Query;
  onPropertyFilterTokensChange?: (query: PropertyFilterProps.Query) => void;
  width?: number | string;
}

const FILTERING_PROPERTIES: ReadonlyArray<PropertyFilterProps.FilteringProperty> = [
  // Name (text search with autocomplete)
  {
    key: 'name',
    operators: ['=', '!=', ':', '!:'],
    propertyLabel: 'Name',
    groupValuesLabel: 'Name values',
  },

  // Multi-select checkbox properties with enum token type
  {
    key: 'region',
    operators: [
      { operator: '=', tokenType: 'enum' },
      { operator: '!=', tokenType: 'enum' },
    ],
    propertyLabel: 'Region',
    groupValuesLabel: 'Region values',
  },
  {
    key: 'facilityType',
    operators: [
      { operator: '=', tokenType: 'enum' },
      { operator: '!=', tokenType: 'enum' },
    ],
    propertyLabel: 'Facility Type',
    groupValuesLabel: 'Facility Type values',
  },
  {
    key: 'program',
    operators: [
      { operator: '=', tokenType: 'enum' },
      { operator: '!=', tokenType: 'enum' },
    ],
    propertyLabel: 'Program',
    groupValuesLabel: 'Program values',
  },
  {
    key: 'businessUnit',
    operators: [
      { operator: '=', tokenType: 'enum' },
      { operator: '!=', tokenType: 'enum' },
    ],
    propertyLabel: 'Business Unit',
    groupValuesLabel: 'Business Unit values',
  },

  // Autocomplete properties
  {
    key: 'generation',
    operators: ['=', '!=', ':', '!:'],
    propertyLabel: 'Generation',
    groupValuesLabel: 'Generation values',
  },
  {
    key: 'createdBy',
    operators: ['=', '!=', ':', '!:'],
    propertyLabel: 'Created By',
    groupValuesLabel: 'DPM values',
  },
  {
    key: 'version',
    operators: ['=', '!=', ':', '!:'],
    propertyLabel: 'Version',
    groupValuesLabel: 'Version values',
  },

  // Numeric properties
  {
    key: 'capacity',
    operators: ['=', '!=', '>', '<', '>=', '<='],
    propertyLabel: 'Capacity',
    groupValuesLabel: 'Capacity values',
    defaultOperator: '>=',
  },
  {
    key: 'maxWeeklyHeadcount',
    operators: ['=', '!=', '>', '<', '>=', '<='],
    propertyLabel: 'Max Weekly Headcount',
    groupValuesLabel: 'Headcount values',
    defaultOperator: '>=',
  },
  {
    key: 'peakShiftHeadcount',
    operators: ['=', '!=', '>', '<', '>=', '<='],
    propertyLabel: 'Peak Shift Headcount',
    groupValuesLabel: 'Headcount values',
    defaultOperator: '>=',
  },
  {
    key: 'siteAcreage',
    operators: ['=', '!=', '>', '<', '>=', '<='],
    propertyLabel: 'Site Size',
    groupValuesLabel: 'Acreage values',
    defaultOperator: '>=',
  },
  {
    key: 'grossSquareFootage',
    operators: ['=', '!=', '>', '<', '>=', '<='],
    propertyLabel: 'Building Footprint',
    groupValuesLabel: 'Square footage values',
    defaultOperator: '>=',
  },
  {
    key: 'clearHeightFtM',
    operators: ['=', '!=', '>', '<', '>=', '<='],
    propertyLabel: 'Clear Height',
    groupValuesLabel: 'Height values',
    defaultOperator: '>=',
  },
  {
    key: 'dockDoorCount',
    operators: ['=', '!=', '>', '<', '>=', '<='],
    propertyLabel: 'Dock Door Count',
    groupValuesLabel: 'Door count values',
    defaultOperator: '>=',
  },
  {
    key: 'totalTrailerParking',
    operators: ['=', '!=', '>', '<', '>=', '<='],
    propertyLabel: 'Total Trailer Parking',
    groupValuesLabel: 'Parking values',
    defaultOperator: '>=',
  },
  {
    key: 'dspParking',
    operators: ['=', '!=', '>', '<', '>=', '<='],
    propertyLabel: 'DSP Parking',
    groupValuesLabel: 'DSP parking values',
    defaultOperator: '>=',
  },
  {
    key: 'stories',
    operators: ['=', '!=', '>', '<', '>=', '<='],
    propertyLabel: 'Number of Stories',
    groupValuesLabel: 'Story count values',
    defaultOperator: '=',
  },
  {
    key: 'powerKva',
    operators: ['=', '!=', '>', '<', '>=', '<='],
    propertyLabel: 'Power',
    groupValuesLabel: 'Power values',
    defaultOperator: '>=',
  },

  // Date property
  {
    key: 'updatedAt',
    operators: ['=', '!=', '>', '<', '>=', '<='],
    propertyLabel: 'Last Modified',
    groupValuesLabel: 'Date values',
    defaultOperator: '>=',
  },
];

export const CatalogSearchBar: React.FC<CatalogSearchBarProps> = ({
  value,
  onChange,
  onTokensChange,
  query,
  placeholder,
  ariaLabel,
  rightAdornment,
  filteringOptions,
  filteringProperties,
  propertyFilterQuery,
  onPropertyFilterTokensChange,
  width = '100%',
}) => {
  const resolvedFilteringProperties = filteringProperties ?? FILTERING_PROPERTIES;

  return (
    <FilterSearchBar
      value={value}
      onChange={onChange}
      onTokensChange={onTokensChange}
      query={query}
      propertyFilterQuery={propertyFilterQuery}
      onPropertyFilterTokensChange={onPropertyFilterTokensChange}
      placeholder={placeholder}
      ariaLabel={ariaLabel}
      rightAdornment={rightAdornment}
      filteringProperties={resolvedFilteringProperties}
      filteringOptions={filteringOptions}
      width={width}
      enableTokenGroups={false}
    />
  );
};
