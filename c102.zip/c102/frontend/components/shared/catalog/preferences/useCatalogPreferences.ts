import { useState, useCallback, useEffect } from 'react';
import type { CatalogPreferences, CatalogPreferencesHookResult } from './types';

/**
 * Options for creating a catalog preferences hook
 */
export interface UseCatalogPreferencesOptions {
  /** localStorage key for storing preferences */
  storageKey: string;

  /** Default preferences to use when none are stored */
  defaultPreferences: CatalogPreferences;

  /** Optional migration function to migrate old preferences format */
  migrationFn?: () => CatalogPreferences | null;

  /** Enable debug logging (useful during development) */
  enableDebugLogging?: boolean;
}

/**
 * Factory function that creates a catalog preferences hook
 *
 * This allows each catalog (Templates, Standards, Kits) to have their own
 * preferences with custom storage keys, defaults, and migration logic.
 *
 * @example
 * ```typescript
 * const useCatalogPreferences = createCatalogPreferencesHook({
 *   storageKey: 'template-catalog-prefs',
 *   defaultPreferences: DEFAULT_CATALOG_PREFERENCES,
 *   migrationFn: migrateOldPreferences,
 *   enableDebugLogging: true,
 * });
 * ```
 */
export function createCatalogPreferencesHook(
  options: UseCatalogPreferencesOptions
): () => CatalogPreferencesHookResult {
  const { storageKey, defaultPreferences, migrationFn, enableDebugLogging } = options;

  /**
   * Load preferences from localStorage with optional migration support
   */
  function loadPreferences(): CatalogPreferences {
    // Try migration first if provided
    if (migrationFn) {
      const migrated = migrationFn();
      if (migrated) {
        // Save migrated data to new storage key
        try {
          localStorage.setItem(storageKey, JSON.stringify(migrated));
          if (enableDebugLogging) {
          }
        } catch (error) {
          console.warn(`Failed to save migrated catalog preferences (${storageKey}):`, error);
        }
        return migrated;
      }
    }

    // Load existing preferences
    try {
      const stored = localStorage.getItem(storageKey);
      if (stored) {
        const parsed = JSON.parse(stored);
        // Merge with defaults to ensure all required properties exist
        return {
          ...defaultPreferences,
          ...parsed,
          table: { ...defaultPreferences.table, ...parsed.table },
          cards: { ...defaultPreferences.cards, ...parsed.cards },
        };
      }
    } catch (error) {
      console.warn(`Failed to load catalog preferences (${storageKey}):`, error);
    }

    return defaultPreferences;
  }

  /**
   * The actual hook returned by the factory
   */
  return function useCatalogPreferences(): CatalogPreferencesHookResult {
    const [preferences, setPreferences] = useState<CatalogPreferences>(loadPreferences);

    // Debug: Log preferences on mount only (not on every change to avoid excessive logging)
    useEffect(() => {
      if (enableDebugLogging) {
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []); // Only log on mount

    const updateTablePreferences = useCallback(
      (updates: Partial<CatalogPreferences['table']>) => {
        if (enableDebugLogging) {
        }
        setPreferences((prev) => {
          const updated = {
            ...prev,
            table: { ...prev.table, ...updates },
          };
          try {
            localStorage.setItem(storageKey, JSON.stringify(updated));
            if (enableDebugLogging) {
            }
          } catch (error) {
            console.warn(`Failed to save catalog preferences (${storageKey}):`, error);
          }
          return updated;
        });
      },
      [] // storageKey and enableDebugLogging are from closure, don't need in deps
    );

    const updateCardsPreferences = useCallback(
      (updates: Partial<CatalogPreferences['cards']>) => {
        if (enableDebugLogging) {
        }
        setPreferences((prev) => {
          const updated = {
            ...prev,
            cards: { ...prev.cards, ...updates },
          };
          try {
            localStorage.setItem(storageKey, JSON.stringify(updated));
            if (enableDebugLogging) {
            }
          } catch (error) {
            console.warn(`Failed to save catalog preferences (${storageKey}):`, error);
          }
          return updated;
        });
      },
      [] // storageKey and enableDebugLogging are from closure
    );

    const resetToDefaults = useCallback(() => {
      if (enableDebugLogging) {
      }
      setPreferences(defaultPreferences);
      try {
        localStorage.removeItem(storageKey);
      } catch (error) {
        console.warn(`Failed to clear catalog preferences (${storageKey}):`, error);
      }
    }, []); // storageKey, defaultPreferences, and enableDebugLogging are from closure

    return {
      preferences,
      updateTablePreferences,
      updateCardsPreferences,
      resetToDefaults,
    };
  };
}
