/**
 * Shared types for catalog preferences
 * Used by both Template and Standard catalogs
 */

export interface CardBreakpoint {
  minWidth: number; // Minimum screen width in pixels
  cards: number; // Number of cards per row
}

/**
 * Unified catalog preferences structure for view-specific UI settings
 * NOTE: pageSize is NOT stored here - it's managed via URL parameters only
 */
export interface CatalogPreferences {
  table: {
    contentDisplay: Array<{ id: string; visible: boolean }>;
    wrapLines?: boolean;
    stripedRows?: boolean;
  };
  cards: {
    contentDisplay: Array<{ id: string; visible: boolean }>;
    cardsPerRowBreakpoints: CardBreakpoint[];
  };
}

/**
 * Hook result for useCatalogPreferences
 */
export interface CatalogPreferencesHookResult {
  preferences: CatalogPreferences;
  updateTablePreferences: (updates: Partial<CatalogPreferences['table']>) => void;
  updateCardsPreferences: (updates: Partial<CatalogPreferences['cards']>) => void;
  resetToDefaults: () => void;
}
