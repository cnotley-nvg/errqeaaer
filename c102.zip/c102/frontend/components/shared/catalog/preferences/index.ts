/**
 * Shared catalog preferences infrastructure
 * Factory pattern for creating preferences hooks for different catalogs
 */

export * from './types';
export * from './useCatalogPreferences';
