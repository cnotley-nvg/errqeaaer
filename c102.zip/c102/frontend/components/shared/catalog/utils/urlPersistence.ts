import type { PropertyFilterQuery } from '@amzn/awsui-collection-hooks';
import { getScopedLogger } from '../../../../utils/logger';

/**
 * Shared URL persistence utilities for catalog state management
 * Used by both Template and Standard catalogs
 */

// Types
export interface CatalogStateSnapshot<TSort> {
  viewType: 'card' | 'table';
  propertyFilterQuery: PropertyFilterQuery;
  sortingField: TSort;
  sortingDescending: boolean;
  pageIndex: number;
  pageSize: number;
}

export interface QueryKeys {
  view: string;
  sort: string;
  desc: string;
  page: string;
  pageSize: string;
  filter: string;
}

export interface ApplySnapshotOptions<TSort> {
  params: URLSearchParams;
  snapshot: CatalogStateSnapshot<TSort>;
  fallback: CatalogStateSnapshot<TSort>;
  urlComparisonDefaults: CatalogStateSnapshot<TSort>;
  queryKeys: QueryKeys;
}

// Constants
export const DEFAULT_QUERY_KEYS: QueryKeys = {
  view: 'view',
  sort: 'sort',
  desc: 'desc',
  page: 'page',
  pageSize: 'pageSize',
  filter: 'filter',
};

export const VALID_PAGE_SIZES = [10, 20, 30, 40] as const;

// Error handling
export function serializeError(error: unknown): { message: string; name?: string; value?: string } {
  if (error instanceof Error) {
    return { message: error.message, name: error.name };
  }
  return { message: 'Unknown error', value: String(error) };
}

// Type coercion functions
export function coerceViewType(value: unknown, fallback: 'card' | 'table'): 'card' | 'table' {
  return value === 'table' || value === 'card' ? value : fallback;
}

export function coercePageIndex(value: unknown, fallback: number): number {
  if (typeof value === 'number' && Number.isFinite(value) && value >= 1) {
    return Math.floor(value);
  }

  if (typeof value === 'string') {
    const parsed = Number.parseInt(value, 10);
    if (Number.isFinite(parsed) && parsed >= 1) {
      return parsed;
    }
  }

  return fallback;
}

export function coercePageSize(
  value: unknown,
  fallback: number,
  validPageSizes: readonly number[] = VALID_PAGE_SIZES
): number {
  if (typeof value === 'number' && validPageSizes.includes(value)) {
    return value;
  }

  if (typeof value === 'string') {
    const parsed = Number.parseInt(value, 10);
    if (validPageSizes.includes(parsed)) {
      return parsed;
    }
  }

  return fallback;
}

export function normalizeBoolean(value: string | null, fallback: boolean): boolean {
  if (value === null) {
    return fallback;
  }

  const lower = value.toLowerCase();
  if (lower === '1' || lower === 'true') {
    return true;
  }

  if (lower === '0' || lower === 'false') {
    return false;
  }

  return fallback;
}

// PropertyFilter handling
export function clonePropertyFilterQuery(query: PropertyFilterQuery): PropertyFilterQuery {
  return {
    operation: query.operation === 'or' ? 'or' : 'and',
    tokens: [...(query.tokens ?? [])],
    tokenGroups: [...(query.tokenGroups ?? [])],
  };
}

export function coercePropertyFilterQuery(
  value: unknown,
  fallback: PropertyFilterQuery
): PropertyFilterQuery {
  if (!value || typeof value !== 'object') {
    return clonePropertyFilterQuery(fallback);
  }

  const candidate = value as Partial<PropertyFilterQuery>;
  const operation = candidate.operation === 'or' ? 'or' : 'and';
  const tokens = Array.isArray(candidate.tokens) ? [...candidate.tokens] : [];
  const tokenGroups = Array.isArray(candidate.tokenGroups) ? [...candidate.tokenGroups] : [];

  return {
    operation,
    tokens,
    tokenGroups,
  };
}

export function hasFilterTokens(query: PropertyFilterQuery): boolean {
  const tokenCount = query.tokens?.length ?? 0;
  const groupCount = query.tokenGroups?.length ?? 0;
  return tokenCount + groupCount > 0;
}

export function parseFilterFromParams(
  rawValue: string | null,
  fallback: PropertyFilterQuery,
  loggerScope: string
): PropertyFilterQuery {
  if (!rawValue) {
    return clonePropertyFilterQuery(fallback);
  }

  try {
    const parsed = JSON.parse(rawValue) as unknown;
    return coercePropertyFilterQuery(parsed, fallback);
  } catch (error) {
    const logger = getScopedLogger(loggerScope);
    logger.warn('Unable to restore catalog filters from URL', serializeError(error));
    return clonePropertyFilterQuery(fallback);
  }
}

export function encodeFilterQuery(
  query: PropertyFilterQuery,
  fallback: PropertyFilterQuery,
  loggerScope: string
): string | null {
  const sanitized = coercePropertyFilterQuery(query, fallback);

  if (!hasFilterTokens(sanitized)) {
    return null;
  }

  try {
    return JSON.stringify({
      operation: sanitized.operation,
      tokens: sanitized.tokens ?? [],
      tokenGroups: sanitized.tokenGroups ?? [],
    });
  } catch (error) {
    const logger = getScopedLogger(loggerScope);
    logger.warn('Unable to persist catalog filters in URL', serializeError(error));
    return null;
  }
}

// URL parameter building
export function applySnapshotToSearchParams<TSort>(options: ApplySnapshotOptions<TSort>): void {
  const { params, snapshot, fallback, urlComparisonDefaults, queryKeys } = options;

  const setOrDelete = (key: string, shouldSet: boolean, value: string) => {
    if (shouldSet) {
      params.set(key, value);
    } else {
      params.delete(key);
    }
  };

  setOrDelete(queryKeys.view, snapshot.viewType !== fallback.viewType, snapshot.viewType);
  setOrDelete(
    queryKeys.sort,
    snapshot.sortingField !== fallback.sortingField,
    String(snapshot.sortingField)
  );
  setOrDelete(
    queryKeys.desc,
    snapshot.sortingDescending !== fallback.sortingDescending,
    snapshot.sortingDescending ? '1' : '0'
  );

  // Use hard-coded defaults for page/pageSize comparison to ensure URL shareability
  // (localStorage fallback would cause parameters to be stripped for different users)
  setOrDelete(
    queryKeys.page,
    snapshot.pageIndex !== urlComparisonDefaults.pageIndex,
    `${snapshot.pageIndex}`
  );
  setOrDelete(
    queryKeys.pageSize,
    snapshot.pageSize !== urlComparisonDefaults.pageSize,
    `${snapshot.pageSize}`
  );

  // Always encode filter query through helper (handles empty filters)
  const loggerScope = 'catalog-persistence'; // Generic scope for shared utility
  const filterValue = encodeFilterQuery(
    snapshot.propertyFilterQuery,
    fallback.propertyFilterQuery,
    loggerScope
  );
  if (filterValue) {
    params.set(queryKeys.filter, filterValue);
  } else {
    params.delete(queryKeys.filter);
  }
}
