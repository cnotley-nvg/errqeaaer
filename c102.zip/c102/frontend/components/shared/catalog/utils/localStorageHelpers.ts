/**
 * Shared localStorage utilities for catalog state management
 * Provides consistent error handling and type-safe access
 */

/**
 * Generic localStorage getter with error handling
 */
export function getLocalStorageItem<T>(
  key: string,
  parser: (stored: string) => T,
  fallback: T,
  errorContext?: string
): T {
  try {
    const stored = localStorage.getItem(key);
    if (stored) {
      return parser(stored);
    }
  } catch (error) {
    const context = errorContext ? ` (${errorContext})` : '';
    console.warn(`Failed to read from localStorage${context}:`, error);
  }
  return fallback;
}

/**
 * Generic localStorage setter with error handling
 * Returns true if successful, false otherwise
 */
export function setLocalStorageItem<T>(
  key: string,
  value: T,
  serializer: (value: T) => string = (v) => String(v),
  errorContext?: string
): boolean {
  try {
    const serialized = serializer(value);
    localStorage.setItem(key, serialized);
    return true;
  } catch (error) {
    const context = errorContext ? ` (${errorContext})` : '';
    console.warn(`Failed to write to localStorage${context}:`, error);
    return false;
  }
}

/**
 * Generic localStorage remover with error handling
 */
export function removeLocalStorageItem(key: string, errorContext?: string): void {
  try {
    localStorage.removeItem(key);
  } catch (error) {
    const context = errorContext ? ` (${errorContext})` : '';
    console.warn(`Failed to remove from localStorage${context}:`, error);
  }
}

/**
 * Get page size from localStorage fallback
 * @deprecated Use versioned storage system via useCatalogPreferences hook instead
 */
export function getPageSizeFallback(storageKey: string, defaultPageSize: number): number {
  return getLocalStorageItem(
    storageKey,
    (stored) => {
      const parsed = parseInt(stored, 10);
      if (Number.isFinite(parsed) && parsed > 0) {
        return parsed;
      }
      return defaultPageSize;
    },
    defaultPageSize,
    'pageSize fallback'
  );
}

/**
 * Save page size to localStorage fallback
 * @deprecated Use versioned storage system via useCatalogPreferences hook instead
 */
export function savePageSizeFallback(storageKey: string, pageSize: number): void {
  setLocalStorageItem(storageKey, pageSize, String, 'pageSize fallback');
}

/**
 * Get view type preference from localStorage
 * @deprecated Use versioned storage system via useCatalogPreferences hook instead
 */
export function getViewTypePreference(
  storageKey: string,
  defaultViewType: 'card' | 'table'
): 'card' | 'table' {
  return getLocalStorageItem(
    storageKey,
    (stored) => {
      const parsed = JSON.parse(stored);
      if (parsed.viewType === 'card' || parsed.viewType === 'table') {
        return parsed.viewType;
      }
      return defaultViewType;
    },
    defaultViewType,
    'view type preference'
  );
}

/**
 * Save view type preference to localStorage
 * @deprecated Use versioned storage system via useCatalogPreferences hook instead
 */
export function saveViewTypePreference(storageKey: string, viewType: 'card' | 'table'): void {
  setLocalStorageItem(
    storageKey,
    { viewType },
    (value) => JSON.stringify(value),
    'view type preference'
  );
}
