import { useCallback, useState } from 'react';

export type FeedbackType = 'success' | 'error' | 'info' | 'warning';

export interface FeedbackState {
  type: FeedbackType;
  message: string;
}

export const useFeedback = () => {
  const [feedback, setFeedback] = useState<FeedbackState | null>(null);

  const showFeedback = useCallback((type: FeedbackType, message: string) => {
    setFeedback({ type, message });
  }, []);

  const clearFeedback = useCallback(() => {
    setFeedback(null);
  }, []);

  const showSuccess = useCallback(
    (message: string) => {
      showFeedback('success', message);
    },
    [showFeedback]
  );

  const showError = useCallback(
    (message: string) => {
      showFeedback('error', message);
    },
    [showFeedback]
  );

  return {
    feedback,
    showFeedback,
    showSuccess,
    showError,
    clearFeedback,
  } as const;
};
