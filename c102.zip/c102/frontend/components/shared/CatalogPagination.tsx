import React, { useCallback } from 'react';
import { Pagination, type PaginationProps } from '@amzn/awsui-components-console';

interface CatalogPaginationProps {
  currentPageIndex: number;
  pagesCount: number;
  onPageChange: (nextPageIndex: number) => void;
}

export const CatalogPagination: React.FC<CatalogPaginationProps> = ({
  currentPageIndex,
  pagesCount,
  onPageChange,
}) => {
  const handleChange = useCallback<NonNullable<PaginationProps['onChange']>>(
    ({ detail }) => {
      onPageChange(detail.currentPageIndex);
    },
    [onPageChange]
  );

  if (pagesCount <= 1) {
    return null;
  }

  return (
    <Pagination
      currentPageIndex={currentPageIndex}
      pagesCount={pagesCount}
      onChange={handleChange}
      ariaLabels={{
        nextPageLabel: 'Next page',
        previousPageLabel: 'Previous page',
        paginationLabel: 'Catalog pagination',
        pageLabel: (pageNumber: number) => `Page ${pageNumber}`,
      }}
    />
  );
};
