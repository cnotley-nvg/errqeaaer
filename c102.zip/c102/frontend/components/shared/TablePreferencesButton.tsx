import React, { useState, useMemo } from 'react';
import {
  CollectionPreferences,
  SpaceBetween,
  Alert,
  Box,
  Button,
  type CollectionPreferencesProps,
} from '@amzn/awsui-components-console';

import type { TablePreferences, CardBreakpoint } from '../../hooks/useTablePreferences';
import { normalizeBreakpoints } from '../templates/catalog/preferences/BreakpointEditor';

interface TablePreferencesButtonProps<T extends string> {
  preferences: TablePreferences;
  onConfirm: (preferences: CollectionPreferencesProps.Preferences) => void;
  /**
   * Column options for the "Column visibility" section.
   * Optional so table-only catalogs can use the preferences modal just for page size.
   */
  columnOptions?: ReadonlyArray<{
    id: T;
    label: string;
    alwaysVisible?: boolean;
  }>;
  pageSizeOptions?: ReadonlyArray<{ value: number; label: string }>;
  onResetDefaults?: () => void;
  title?: string;
  enableBreakpointEditor?: boolean;
  onBreakpointsChange?: (breakpoints: CardBreakpoint[]) => void;
  BreakpointEditorComponent?: React.ComponentType<{
    breakpoints: CardBreakpoint[];
    onChange: (breakpoints: CardBreakpoint[]) => void;
    currentScreenWidth?: number;
  }>;
  /** Show wrapLines and stripedRows toggles (table view only) */
  showTableOptions?: boolean;
  /** Show column visibility section. Defaults to true. */
  showContentDisplayPreference?: boolean;
}

const DEFAULT_PAGE_SIZE_OPTIONS = [
  { value: 10, label: '10 items' },
  { value: 20, label: '20 items' },
  { value: 50, label: '50 items' },
  { value: 100, label: '100 items' },
];

export function TablePreferencesButton<T extends string>({
  preferences,
  onConfirm,
  columnOptions = [],
  pageSizeOptions = DEFAULT_PAGE_SIZE_OPTIONS,
  onResetDefaults,
  title = 'Table preferences',
  enableBreakpointEditor = false,
  onBreakpointsChange,
  BreakpointEditorComponent,
  showTableOptions = false,
  showContentDisplayPreference = true,
}: TablePreferencesButtonProps<T>): React.ReactElement {
  // Force remount of CollectionPreferences when reset (closes modal)
  const [preferencesKey, setPreferencesKey] = useState(0);

  // Local state for breakpoints - only committed on Confirm
  // Normalize on initialization to fix any out-of-range values
  const [tempBreakpoints, setTempBreakpoints] = useState<CardBreakpoint[] | undefined>(() =>
    preferences.cardsPerRowBreakpoints
      ? normalizeBreakpoints(preferences.cardsPerRowBreakpoints)
      : undefined
  );

  // Sync temp state when preferences change from outside
  React.useEffect(() => {
    setTempBreakpoints(
      preferences.cardsPerRowBreakpoints
        ? normalizeBreakpoints(preferences.cardsPerRowBreakpoints)
        : undefined
    );
  }, [preferences.cardsPerRowBreakpoints]);

  // Convert TablePreferences to CollectionPreferencesProps.Preferences
  const collectionPreferences = useMemo<CollectionPreferencesProps.Preferences>(() => {
    return {
      pageSize: preferences.pageSize,
      visibleContent: preferences.visibleContent,
      wrapLines: preferences.wrapLines,
      stripedRows: preferences.stripedRows,
      contentDisplay: preferences.contentDisplay
        ? preferences.contentDisplay.map((item) => ({
            id: item.id,
            visible: item.visible ?? true,
          }))
        : undefined,
    };
  }, [preferences]);

  const handleConfirm = (detail: CollectionPreferencesProps.Preferences): void => {
    // Merge breakpoints into the detail object before saving
    const detailWithBreakpoints = {
      ...detail,
      cardsPerRowBreakpoints: tempBreakpoints,
    } as any;
    onConfirm(detailWithBreakpoints);
  };

  return (
    <CollectionPreferences
      key={preferencesKey}
      title={title}
      confirmLabel="Confirm"
      cancelLabel="Cancel"
      preferences={collectionPreferences}
      onConfirm={({ detail }) => handleConfirm(detail)}
      onCancel={() => {
        // Reset temp state on cancel
        setTempBreakpoints(preferences.cardsPerRowBreakpoints);
      }}
      pageSizePreference={{
        title: 'Page size',
        options: pageSizeOptions,
      }}
      {...(showContentDisplayPreference && {
        contentDisplayPreference: {
          title: 'Column visibility',
          description: 'Customize the visibility and order of the columns.',
          options: columnOptions.map((col) => ({
            id: col.id,
            label: col.label,
            alwaysVisible: col.alwaysVisible,
          })),
        },
      })}
      {...(showTableOptions && {
        wrapLinesPreference: {
          label: 'Wrap lines',
          description: 'Wrap table cell content',
        },
        stripedRowsPreference: {
          label: 'Striped rows',
          description: 'Add alternating row colors',
        },
      })}
      {...(onResetDefaults && {
        customPreference: (_value: unknown, _setValue: (value: unknown) => void) => (
          <SpaceBetween size="s">
            {/* Breakpoint editor */}
            {enableBreakpointEditor && BreakpointEditorComponent && tempBreakpoints && (
              <BreakpointEditorComponent
                breakpoints={tempBreakpoints}
                onChange={setTempBreakpoints}
                currentScreenWidth={typeof window !== 'undefined' ? window.innerWidth : undefined}
              />
            )}

            {/* Spacer to push button to bottom */}
            <Box padding={{ top: 'xxxl' }}>
              {/* Reset button */}
              <Button
                variant="normal"
                onClick={() => {
                  onResetDefaults();
                  // Reset temp state to defaults
                  setTempBreakpoints(preferences.cardsPerRowBreakpoints);
                  // Force remount to close modal and show default preferences
                  setPreferencesKey((prev) => prev + 1);
                }}
              >
                Reset to defaults
              </Button>
            </Box>
          </SpaceBetween>
        ),
      })}
    />
  );
}
