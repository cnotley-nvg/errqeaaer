import React from 'react';
import { Alert } from '@amzn/awsui-components-console';

interface CatalogErrorAlertProps {
  error: string | null;
  resourceLabel: string;
}

export const CatalogErrorAlert: React.FC<CatalogErrorAlertProps> = ({ error, resourceLabel }) => {
  if (!error) {
    return null;
  }

  return (
    <Alert type="error" header={`Unable to load ${resourceLabel}`}>
      {error}
    </Alert>
  );
};
