import React from 'react';
import { Header, Button, SpaceBetween, Box, Container } from '@amzn/awsui-components-console';

interface FeatureCardProps {
  title: string;
  description: string;
  buttonText: string;
  onButtonClick?: () => void;
  illustration?: string;
  illustrationPosition?: 'left' | 'right';
}

const FeatureCard: React.FC<FeatureCardProps> = ({
  title,
  description,
  buttonText,
  onButtonClick,
  illustration,
  illustrationPosition,
}) => {
  const contentSection = (
    <Box padding="m">
      <SpaceBetween direction="vertical" size="s">
        <Header variant="h2">{title}</Header>
        <div>{description}</div>
        <Button variant="normal" onClick={onButtonClick}>
          {buttonText}
        </Button>
      </SpaceBetween>
    </Box>
  );

  const illustrationSection = illustration && (
    <>
      <style>{`.overflowHidden { overflow: hidden}`}</style>
      <img src={illustration} style={{ width: '172px' }} />
    </>
  );

  return (
    <Container disableContentPaddings={true} className={'overflowHidden'}>
      <div
        style={{
          display: 'flex',
          gap: '20px',
          justifyContent: illustrationPosition === 'left' ? 'flex-start' : 'space-between',
        }}
      >
        {illustrationPosition === 'left' ? (
          <>
            {illustrationSection}
            {contentSection}
          </>
        ) : (
          <>
            {contentSection}
            {illustrationSection}
          </>
        )}
      </div>
    </Container>
  );
};

export default FeatureCard;
