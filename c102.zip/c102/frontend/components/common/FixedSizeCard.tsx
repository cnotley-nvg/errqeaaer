import React from 'react';

export interface FixedSizeCardProps {
  /**
   * Optional fixed width (in px). If omitted, the card will stretch to
   * fill its grid/flex cell (width: 100%).
   */
  widthPx?: number;
  heightPx: number;
  children: React.ReactNode;
  style?: React.CSSProperties;
}

export const FixedSizeCard: React.FC<FixedSizeCardProps> = ({
  widthPx,
  heightPx,
  children,
  style,
}) => {
  return (
    <div
      style={{
        width: widthPx ? `${widthPx}px` : '100%',
        height: `${heightPx}px`,
        maxHeight: `${heightPx}px`,
        boxSizing: 'border-box',
        border: '1px solid #d5dbdb',
        borderRadius: '16px',
        padding: '16px',
        display: 'flex',
        flexDirection: 'column',
        gap: '12px',
        ...style,
      }}
    >
      {children}
    </div>
  );
};
