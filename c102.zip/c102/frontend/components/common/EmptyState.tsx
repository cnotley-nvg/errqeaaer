import React from 'react';
import { Box, Icon, SpaceBetween, type IconProps } from '@amzn/awsui-components-console';

interface EmptyStateProps {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  iconName?: IconProps.Name;
  actions?: React.ReactNode;
}

export const EmptyState: React.FC<EmptyStateProps> = ({ title, subtitle, iconName, actions }) => (
  <Box textAlign="center" color="inherit">
    <SpaceBetween size="s">
      {iconName ? <Icon name={iconName} size="large" /> : null}
      <b>{title}</b>
      {subtitle ? <span>{subtitle}</span> : null}
      {actions ?? null}
    </SpaceBetween>
  </Box>
);
