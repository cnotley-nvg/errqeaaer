import React, { useState } from 'react';
import {
  HelpPanel,
  Form,
  FormField,
  Select,
  Textarea,
  Button,
  SpaceBetween,
  Flashbar,
} from '@amzn/awsui-components-console';
import { gql } from 'graphql-request';
import { graphqlClient } from '../../api/graphqlClient';
import type { SubmitFeedbackInput } from '@amzn/global-realty-mosaic-graphql-schema';

const FEEDBACK_TYPE_ISSUE = 'Report an issue';

const SUBMIT_FEEDBACK_MUTATION = gql`
  mutation SubmitFeedback($input: SubmitFeedbackInput!) {
    submitFeedback(input: $input) {
      success
      message
      ticketUrl
    }
  }
`;

const FEEDBACK_TYPES = [
  { label: 'Report an issue', value: FEEDBACK_TYPE_ISSUE },
  { label: 'General feedback', value: 'General feedback' },
];

const ISSUE_TYPES = [
  { label: 'Functionality is missing', value: 'Functionality is missing' },
  { label: 'Wrong/missing data', value: 'Wrong/missing data' },
  { label: 'Page is too slow', value: 'Page is too slow' },
  { label: 'Page layout is confusing/glitchy', value: 'Page layout is confusing/glitchy' },
  { label: 'Other', value: 'Other' },
];

export const FeedbackPanel: React.FC = () => {
  const [formData, setFormData] = useState<SubmitFeedbackInput>({
    feedbackType: FEEDBACK_TYPE_ISSUE,
    issueType: '',
    description: '',
  });
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [notification, setNotification] = useState<{
    type: 'success' | 'error';
    message: string;
    buttonText?: string;
    onButtonClick?: () => void;
  } | null>(null);

  const flashbarStyles = `
    .feedback-flashbar ul {
      padding-inline-start: 0 !important;
    }
  `;

  const handleSubmit = async () => {
    setIsSubmitting(true);
    setNotification(null);
    try {
      const input: SubmitFeedbackInput = {
        feedbackType: formData.feedbackType,
        description: formData.description,
        ...(formData.feedbackType === FEEDBACK_TYPE_ISSUE && { issueType: formData.issueType }),
      };

      const response = await graphqlClient.request(SUBMIT_FEEDBACK_MUTATION, { input });

      if (response.submitFeedback.success) {
        const message = response.submitFeedback.ticketUrl
          ? `${response.submitFeedback.message} Track your request:`
          : response.submitFeedback.message;

        setNotification({
          type: 'success',
          message,
          ...(response.submitFeedback.ticketUrl && {
            buttonText: 'SIM Ticket',
            onButtonClick: () => window.open(response.submitFeedback.ticketUrl, '_blank'),
          }),
        });
        setFormData((prev) => ({ ...prev, issueType: '', description: '' }));
      } else {
        setNotification({ type: 'error', message: response.submitFeedback.message });
      }
    } catch (error) {
      setNotification({ type: 'error', message: 'Failed to submit feedback. Please try again.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <HelpPanel header="Give feedback">
      <style>{flashbarStyles}</style>
      <SpaceBetween direction="vertical" size="l">
        {notification && (
          <div className="feedback-flashbar">
            <Flashbar
              items={[
                {
                  type: notification.type,
                  content: notification.message,
                  dismissible: true,
                  onDismiss: () => setNotification(null),
                  ...(notification.buttonText && {
                    buttonText: notification.buttonText,
                    onButtonClick: notification.onButtonClick,
                  }),
                },
              ]}
            />
          </div>
        )}

        <div>What would you like to share?</div>

        <Form>
          <SpaceBetween direction="vertical" size="l">
            <FormField label="Feedback type">
              <Select
                selectedOption={
                  FEEDBACK_TYPES.find((type) => type.value === formData.feedbackType) || null
                }
                onChange={({ detail }) =>
                  setFormData((prev) => ({
                    ...prev,
                    feedbackType: detail.selectedOption.value || FEEDBACK_TYPE_ISSUE,
                  }))
                }
                options={FEEDBACK_TYPES}
              />
            </FormField>

            {formData.feedbackType === FEEDBACK_TYPE_ISSUE && (
              <FormField label="Issue type">
                <Select
                  selectedOption={
                    ISSUE_TYPES.find((type) => type.value === formData.issueType) || null
                  }
                  onChange={({ detail }) =>
                    setFormData((prev) => ({
                      ...prev,
                      issueType: detail.selectedOption.value || '',
                    }))
                  }
                  options={ISSUE_TYPES}
                  placeholder="Choose an option"
                />
              </FormField>
            )}

            <FormField label="Describe the issue">
              <Textarea
                value={formData.description}
                onChange={({ detail }) =>
                  setFormData((prev) => ({ ...prev, description: detail.value }))
                }
                placeholder="Provide details to help us understand the issue"
                rows={4}
              />
            </FormField>

            <Button
              variant="primary"
              onClick={handleSubmit}
              disabled={
                (formData.feedbackType === FEEDBACK_TYPE_ISSUE && !formData.issueType) ||
                !formData.description.trim() ||
                isSubmitting
              }
              loading={isSubmitting}
            >
              Submit feedback
            </Button>
          </SpaceBetween>
        </Form>
      </SpaceBetween>
    </HelpPanel>
  );
};
