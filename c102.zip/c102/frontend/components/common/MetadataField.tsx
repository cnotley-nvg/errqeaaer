import React from 'react';
import { Box, SpaceBetween } from '@amzn/awsui-components-console';

interface MetadataFieldProps {
  label: string;
  children: React.ReactNode;
}

/**
 * A simple metadata field component that displays a label and value.
 * Used for consistent metadata display across Standards and Kits.
 *
 * @param label - The field label to display
 * @param children - The field value content (can be text, components, etc.)
 * @returns A formatted metadata field with label and value
 *
 * @example
 * ```tsx
 * <MetadataField label="Region">
 *   <span>{region || '—'}</span>
 * </MetadataField>
 *
 * <MetadataField label="Created by">
 *   <PhoneToolLink username={username} />
 * </MetadataField>
 * ```
 */
export const MetadataField: React.FC<MetadataFieldProps> = ({ label, children }) => (
  <SpaceBetween size="xxs">
    <Box variant="awsui-key-label">{label}</Box>
    <div>{children}</div>
  </SpaceBetween>
);
