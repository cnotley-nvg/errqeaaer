import { useMemo } from 'react';
import { Link } from '@amzn/awsui-components-console';
import type { CardsProps } from '@amzn/awsui-components-console';
import type { ReactNode } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

import { formatProgram, formatProjectType } from '../../utils/attributeDisplay';

interface StandardSummaryCardConfig<T> {
  header: CardsProps.CardDefinition<T>['header'];
  getRegion: (item: T) => ReactNode;
  getProjectType: (item: T) => ReactNode;
  getProgram: (item: T) => ReactNode;
  regionLabel?: string;
  projectTypeLabel?: string;
  programLabel?: string;
}

const defaultRegionLabel = 'Region';
const defaultProjectTypeLabel = 'Project type';
const defaultProgramLabel = 'Program';

export const createStandardSummaryCardDefinition = <T,>({
  header,
  getRegion,
  getProjectType,
  getProgram,
  regionLabel = defaultRegionLabel,
  projectTypeLabel = defaultProjectTypeLabel,
  programLabel = defaultProgramLabel,
}: StandardSummaryCardConfig<T>): CardsProps.CardDefinition<T> => ({
  header,
  sections: [
    {
      id: 'region',
      header: regionLabel,
      content: getRegion,
    },
    {
      id: 'projectType',
      header: projectTypeLabel,
      content: (item: T) =>
        formatProjectType(getProjectType(item) as string[] | string | null) ?? '—',
    },
    {
      id: 'program',
      header: programLabel,
      content: (item: T) => formatProgram(getProgram(item) as string[] | string | null) ?? '—',
    },
  ],
});

interface LinkedStandardCardConfig<T> {
  getStandardId: (item: T) => string;
  getStandardName: (item: T) => ReactNode;
  getRegion: (item: T) => ReactNode;
  getProjectType: (item: T) => ReactNode;
  getProgram: (item: T) => ReactNode;
  regionLabel?: string;
  projectTypeLabel?: string;
  programLabel?: string;
  linkBasePath?: string;
}

export const useLinkedStandardSummaryCardDefinition = <T,>({
  getStandardId,
  getStandardName,
  getRegion,
  getProjectType,
  getProgram,
  regionLabel,
  projectTypeLabel,
  programLabel,
  linkBasePath = '/standards',
}: LinkedStandardCardConfig<T>): CardsProps.CardDefinition<T> => {
  const navigate = useNavigate();
  const location = useLocation();

  return useMemo(
    () =>
      createStandardSummaryCardDefinition<T>({
        header: (item) => {
          const id = getStandardId(item);
          const href = `${linkBasePath}/${id}${location.search}`;
          return (
            <Link
              href={href}
              onFollow={(event) => {
                event.preventDefault();
                event.stopPropagation();
                navigate(href);
              }}
            >
              {getStandardName(item)}
            </Link>
          );
        },
        getRegion,
        getProjectType,
        getProgram,
        regionLabel,
        projectTypeLabel,
        programLabel,
      }),
    [
      projectTypeLabel,
      getProjectType,
      getProgram,
      getRegion,
      getStandardId,
      getStandardName,
      linkBasePath,
      location.search,
      navigate,
      programLabel,
      regionLabel,
    ]
  );
};
