import React, { useState, useEffect } from 'react';
import {
  Table,
  Box,
  SpaceBetween,
  TextFilter,
  Header,
  Link,
  Icon,
  Pagination,
  IconProps,
  CollectionPreferences,
  Button,
} from '@amzn/awsui-components-console';
import { gql } from 'graphql-request';
import moment from 'moment';
import { graphqlClient } from '../../api/graphqlClient';
import type { SystemEvent } from '@amzn/global-realty-mosaic-graphql-schema';
import {
  useVersionedRecentUpdatesPreferences,
  PAGE_SIZE_OPTIONS,
  CONTENT_DISPLAY_OPTIONS,
  STICKY_COLUMNS_PREFERENCE,
} from '../../storage/recent-updates-preferences';

const SEARCH_SYSTEM_EVENTS = gql`
  query SearchSystemEvents($filter: SystemEventFilterInput) {
    searchSystemEvents(filter: $filter) {
      items {
        id
        type
        details
        message
        status
        createdBy
        createdAt
      }
      total
    }
  }
`;

const getItemLink = (item: SystemEvent) => {
  const details = item.details as { id?: string; name?: string } | null;
  if (item.type === 'STANDARD') {
    return <Link href={`/standards/${details?.id}`}>{details?.name}</Link>;
  } else if (item.type === 'KIT') {
    return <Link href={`/kits/${details?.id}`}>{details?.name}</Link>;
  } else if (item.type === 'TEMPLATE') {
    return <Link href={`/templates/${details?.id}`}>{details?.name}</Link>;
  }
  return <span>{details?.name}</span>;
};

const RecentUpdates: React.FC = () => {
  const [filteringText, setFilteringText] = useState('');
  const [sortingColumn, setSortingColumn] = useState<any>({ sortingField: 'createdAt' });
  const [sortingDescending, setSortingDescending] = useState(true);
  const [currentPageIndex, setCurrentPageIndex] = useState(1);
  const [events, setEvents] = useState<SystemEvent[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [preferencesKey, setPreferencesKey] = useState(0);

  const { preferences, updatePreferences, resetPreferences } =
    useVersionedRecentUpdatesPreferences();

  const fetchEvents = async () => {
    if (isInitialLoad) {
      setLoading(true);
    }
    try {
      const response = await graphqlClient.request(SEARCH_SYSTEM_EVENTS, {
        filter: {
          searchTerm: filteringText || undefined,
          pageIdx: currentPageIndex - 1,
          limit: preferences.pageSize || 10,
          orderBy: sortingColumn.sortingField,
          orderDesc: sortingDescending,
        },
      });
      setEvents(response.searchSystemEvents.items);
      setTotal(response.searchSystemEvents.total);
    } catch (error) {
      console.error('Failed to fetch system events:', error);
      setEvents([]);
      setTotal(0);
    } finally {
      if (isInitialLoad) {
        setLoading(false);
        setIsInitialLoad(false);
      }
    }
  };

  useEffect(() => {
    fetchEvents();
  }, [filteringText, currentPageIndex, sortingColumn, sortingDescending, preferences.pageSize]);

  useEffect(() => {
    setCurrentPageIndex(1);
  }, [filteringText]);

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      UPDATED: { color: '#037f0c', icon: 'status-positive', value: 'Updated' },
      PUBLISHED: { color: '#037f0c', icon: 'status-positive', value: 'Published' },
      CHANGE: { color: '#5f6b7a', icon: 'status-pending', value: 'Change' },
      NEW: { color: '#0972d3', icon: 'status-info', value: 'New' },
    };

    const config = statusConfig[status as keyof typeof statusConfig];
    return (
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
        <span style={{ color: config.color, display: 'inline-flex' }}>
          <Icon name={config.icon as IconProps.Name} size="small" />
        </span>
        {config.value}
      </span>
    );
  };

  return (
    <Table
      columnDefinitions={[
        {
          id: 'details',
          header: 'Item',
          cell: (item) => getItemLink(item),
        },
        {
          id: 'message',
          header: 'Action',
          cell: (item) => item.message,
        },
        {
          id: 'createdBy',
          header: 'Updated by',
          cell: (item) => item.createdBy,
        },
        {
          id: 'createdAt',
          header: 'Date',
          cell: (item) => moment(item.createdAt).fromNow(),
        },
        {
          id: 'status',
          header: 'Status',
          cell: (item) => getStatusBadge(item.status),
        },
      ]}
      items={events}
      loading={loading}
      sortingColumn={sortingColumn}
      sortingDescending={sortingDescending}
      onSortingChange={(event) => {
        setSortingColumn(event.detail.sortingColumn);
        setSortingDescending(event.detail.isDescending || false);
      }}
      columnDisplay={preferences.contentDisplay?.map((item) => ({
        id: item.id,
        visible: item.visible ?? true,
      }))}
      wrapLines={preferences.wrapLines}
      stripedRows={preferences.stripedRows}
      stickyColumns={preferences.stickyColumns}
      preferences={
        <CollectionPreferences
          key={preferencesKey}
          onConfirm={({ detail }) => updatePreferences(detail)}
          title="Preferences"
          confirmLabel="Confirm"
          cancelLabel="Cancel"
          preferences={{
            ...preferences,
            contentDisplay: preferences.contentDisplay?.map((item) => ({
              id: item.id,
              visible: item.visible ?? true,
            })),
            stickyColumns: preferences.stickyColumns,
          }}
          pageSizePreference={{
            title: 'Page size',
            options: PAGE_SIZE_OPTIONS,
          }}
          wrapLinesPreference={{
            label: 'Wrap lines',
            description: 'Wrap table cell content',
          }}
          stripedRowsPreference={{
            label: 'Striped rows',
            description: 'Add alternating row colors',
          }}
          stickyColumnsPreference={STICKY_COLUMNS_PREFERENCE}
          contentDisplayPreference={{
            options: CONTENT_DISPLAY_OPTIONS,
          }}
          customPreference={() => (
            <Box padding={{ top: 'xxxl' }}>
              <Button
                variant="normal"
                onClick={() => {
                  resetPreferences();
                  setPreferencesKey((prev) => prev + 1);
                }}
              >
                Reset to defaults
              </Button>
            </Box>
          )}
        />
      }
      header={
        <Header
          counter={`(${total})`}
          description="Latest activities and changes across your design assets."
        >
          Recent updates
        </Header>
      }
      filter={
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            width: '100%',
          }}
        >
          <div style={{ flex: 1, maxWidth: '700px' }}>
            <TextFilter
              filteringText={filteringText}
              filteringPlaceholder="Find updates"
              onChange={({ detail }) => setFilteringText(detail.filteringText)}
            />
          </div>
          <SpaceBetween direction="horizontal" size="xs">
            {total > 0 && (
              <Pagination
                currentPageIndex={currentPageIndex}
                pagesCount={Math.ceil(total / (preferences.pageSize || 10))}
                onChange={({ detail }) => setCurrentPageIndex(detail.currentPageIndex)}
              />
            )}
          </SpaceBetween>
        </div>
      }
      empty={
        <Box textAlign="center" color="inherit">
          <b>No events</b>
          <Box padding={{ bottom: 's' }} variant="p" color="inherit">
            No system events found.
          </Box>
        </Box>
      }
    />
  );
};

export default RecentUpdates;
