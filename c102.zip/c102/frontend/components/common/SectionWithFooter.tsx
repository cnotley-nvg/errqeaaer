import React from 'react';
import { Container, SpaceBetween } from '@amzn/awsui-components-console';

type BaseContainerProps = Omit<React.ComponentProps<typeof Container>, 'children'>;

export interface SectionWithFooterProps extends BaseContainerProps {
  children: React.ReactNode;
  footerActions?: React.ReactNode;
  spacing?: React.ComponentProps<typeof SpaceBetween>['size'];
}

export const SectionWithFooter: React.FC<SectionWithFooterProps> = ({
  children,
  footerActions,
  spacing = 'l',
  ...containerProps
}) => {
  return (
    <Container {...containerProps}>
      {footerActions ? (
        <SpaceBetween size={spacing}>
          {children}
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>{footerActions}</div>
        </SpaceBetween>
      ) : (
        children
      )}
    </Container>
  );
};
