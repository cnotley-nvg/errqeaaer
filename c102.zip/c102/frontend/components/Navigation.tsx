import React, { useMemo } from 'react';
import { SideNavigation, SideNavigationProps } from '@amzn/awsui-components-console';
import { useLocation, useNavigate } from 'react-router-dom';

const kitOfPartsChildren: SideNavigationProps.Link[] = [
  { type: 'link', text: 'Browse standards', href: '/standards' },
  { type: 'link', text: 'Build a kit', href: '/build-kit' },
  { type: 'link', text: 'Optimize design', href: '/optimize-design' },
  { type: 'link', text: 'Published kit of parts', href: '/kits' },
];

const matchmakerChildren: SideNavigationProps.Link[] = [
  { type: 'link', text: 'Design generator', href: '/design-generator' },
];

export const Navigation: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const { items, activeHref } = useMemo(() => {
    const normalizePath = (path: string) => {
      if (!path) {
        return '/';
      }
      const normalized = path.endsWith('/') && path !== '/' ? path.replace(/\/+$/, '') : path;
      return normalized || '/';
    };

    const startsWithPath = (baseHref: string | undefined, current: string) => {
      if (!baseHref) {
        return false;
      }
      const normalizedBase = normalizePath(baseHref);
      if (current === normalizedBase) {
        return true;
      }
      return current.startsWith(`${normalizedBase}/`);
    };

    const normalizedPath = normalizePath(location.pathname);

    const activeKitChild = kitOfPartsChildren.find((child) =>
      startsWithPath(child.href, normalizedPath)
    );
    const activeMatchmakerChild = matchmakerChildren.find((child) =>
      startsWithPath(child.href, normalizedPath)
    );

    const navigationItems: SideNavigationProps['items'] = [
      { type: 'link', text: 'Home', href: '/' },
      {
        type: 'expandable-link-group',
        text: 'Kit of parts',
        href: '/kit-of-parts',
        defaultExpanded: true,
        items: kitOfPartsChildren,
      },
      { type: 'link', text: 'Design templates', href: '/templates' },
      {
        type: 'expandable-link-group',
        text: 'Matchmaker',
        href: '/matchmaker',
        defaultExpanded: true,
        items: matchmakerChildren,
      },
      { type: 'divider' },
      {
        type: 'link',
        text: 'Training course',
        href: '//atoz.amazon.work/m/learn/transcriptdetail?trainingId=TCRLERN2025121619525856054e96&trainingLms=LEARN',
        external: true,
      },
      {
        type: 'link',
        text: 'Resources',
        href: '//w.amazon.com/bin/view/GRBDE/CoreInitiatives/Mosaic#HFAQ',
        external: true,
      },
    ];

    const allNavigableItems: Array<string> = [];
    const collectHref = (entry: SideNavigationProps.Item) => {
      if ('href' in entry && entry.href) {
        allNavigableItems.push(normalizePath(entry.href));
      }
      if ('items' in entry && entry.items) {
        entry.items.forEach(collectHref);
      }
    };

    navigationItems.forEach(collectHref);

    const resolvedActiveHref = allNavigableItems.reduce<string | null>((best, candidate) => {
      if (!candidate) {
        return best;
      }
      if (!normalizedPath.startsWith(candidate)) {
        return best;
      }
      if (!best) {
        return candidate;
      }
      return candidate.length > best.length ? candidate : best;
    }, null);

    return {
      items: navigationItems,
      activeHref: resolvedActiveHref ?? normalizedPath,
    };
  }, [location.pathname]);

  return (
    <SideNavigation
      activeHref={activeHref}
      header={{ text: 'MOSAIC', href: '/' }}
      items={items}
      onFollow={(event) => {
        const { href, external } = event.detail;
        if (!external && href) {
          event.preventDefault();
          if (event.detail.type === 'expandable-link-group') {
            // For "Kit of parts" and "Matchmaker" we only want to toggle the group open/closed.
            // Do not auto-navigate on group click.
            if (href === '/kit-of-parts' || href === '/matchmaker') {
              return;
            }
          }
          navigate(href);
        }
      }}
    />
  );
};
