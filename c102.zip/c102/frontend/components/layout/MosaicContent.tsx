import React from 'react';

interface MosaicContentProps {
  children: React.ReactNode;
}

export const MosaicContent: React.FC<MosaicContentProps> = ({ children }) => {
  return (
    <div
      style={{
        marginTop: '16px',
        marginBottom: '16px',
      }}
    >
      {children}
    </div>
  );
};
