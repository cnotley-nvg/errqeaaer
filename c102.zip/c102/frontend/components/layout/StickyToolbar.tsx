import { forwardRef } from 'react';
import { BreadcrumbGroup, Icon } from '@amzn/awsui-components-console';
import { useLocation, useNavigate } from 'react-router-dom';

import { useLayout } from './LayoutProvider';

interface StickyToolbarProps {
  onToggleNav: () => void;
}

export const StickyToolbar = forwardRef<HTMLDivElement, StickyToolbarProps>(
  ({ onToggleNav }, ref) => {
    const { breadcrumbs } = useLayout();
    const navigate = useNavigate();
    const location = useLocation();

    if (!breadcrumbs.length) {
      return null;
    }

    return (
      <div
        ref={ref}
        style={{
          backgroundColor: 'var(--awsui-color-background-container-content, #ffffff)',
          borderBottom: '1px solid var(--awsui-color-border-divider-default, #d5dbdb)',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-start',
            padding: '8px 20px',
          }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
            }}
          >
            <div
              onClick={onToggleNav}
              style={{
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
              }}
            >
              <Icon name="menu" />
            </div>

            <BreadcrumbGroup
              items={breadcrumbs}
              ariaLabel="Breadcrumbs"
              onFollow={(event) => {
                const { href, external } = event.detail;
                if (!href || external) {
                  return;
                }
                event.preventDefault();
                if (href === location.pathname) {
                  return;
                }
                navigate(href);
              }}
            />
          </div>
        </div>
      </div>
    );
  }
);
