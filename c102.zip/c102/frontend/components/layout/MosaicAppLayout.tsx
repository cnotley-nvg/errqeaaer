import React, { useState, useEffect } from 'react';
import {
  AppLayoutToolbar,
  TopNavigation,
  Header,
  ContentLayout,
  BreadcrumbGroup,
  Badge,
} from '@amzn/awsui-components-console';
import { gql } from 'graphql-request';
import { Navigation } from '../Navigation';
import { FeedbackPanel } from '../common/FeedbackPanel';
import { useLayout } from './LayoutProvider';
import { useTheme } from '../../hooks/useTheme';
import { useAppShellState } from './useAppShellState';
import { useBreadcrumbs } from '../../hooks/useBreadcrumbs';
import { useLocation, useNavigate } from 'react-router-dom';
import { graphqlClient } from '../../api/graphqlClient';
import { useAnalytics } from '../../hooks/useAnalytics';

const WHOAMI_QUERY = gql`
  query whoami {
    whoami {
      name
      username
      givenName
      familyName
      email
    }
  }
`;

interface MosaicAppLayoutProps {
  children: React.ReactNode;
}

export const MosaicAppLayout: React.FC<MosaicAppLayoutProps> = ({ children }) => {
  const { header, breadcrumbs: layoutBreadcrumbs } = useLayout();
  const location = useLocation();
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();
  const { isNavOpen, toggleNav } = useAppShellState();
  const fallbackBreadcrumbs = useBreadcrumbs();
  const [userName, setUserName] = useState('User');
  const { identifyUser } = useAnalytics();

  const showEnvironmentBadge = () => {
    const hostname = window.location.hostname;
    return !hostname.includes('prod');
  };

  // Use layout breadcrumbs if available (from PageLayout), otherwise use fallback
  const breadcrumbs = layoutBreadcrumbs.length > 0 ? layoutBreadcrumbs : fallbackBreadcrumbs;

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await graphqlClient.request(WHOAMI_QUERY);
        const user = response.whoami;
        const displayName =
          user.username ||
          (user.givenName && user.familyName
            ? `${user.givenName} ${user.familyName}`
            : user.name) ||
          'User';
        setUserName(displayName);

        // Identify user for analytics
        if (user.email) {
          identifyUser({ email: user.email });
        } else {
          console.error('Failed to identify user:', user);
        }
      } catch (error) {
        console.error('Failed to fetch user:', error);
      }
    };
    fetchUser();
  }, [identifyUser]);

  const headerNode = header ? (
    <Header
      variant={header.variant ?? 'h1'}
      description={header.description}
      info={header.info}
      actions={header.actions}
    >
      {header.title}
    </Header>
  ) : undefined;

  return (
    <>
      <div id="h" style={{ position: 'sticky', top: 0, zIndex: 1002 }}>
        <TopNavigation
          identity={{
            href: '#',
            title: (showEnvironmentBadge() ? (
              <div style={{ marginLeft: '16px' }}>
                <Badge color="severity-low">Mosaic test environment</Badge>
              </div>
            ) : undefined) as any,
            logo: {
              src: '/logo/Global_Realty_Light_300px.png',
              alt: 'Global Realty',
            },
            onFollow: (event: any) => {
              event.preventDefault();
              window.open('https://realm.wwops.amazon.dev/', '_blank');
            },
          }}
          utilities={[
            {
              type: 'button',
              text: theme === 'dark' ? 'Dark' : 'Light',
              iconUrl: theme === 'dark' ? '/icons/moon.svg' : '/icons/sun.svg',
              title: `Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`,
              ariaLabel: `Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`,
              onClick: toggleTheme,
            },
            {
              type: 'button',
              text: userName,
              iconName: 'user-profile',
            },
          ]}
        />
      </div>
      <AppLayoutToolbar
        headerSelector="#h"
        navigation={<Navigation />}
        navigationOpen={isNavOpen}
        onNavigationChange={({ detail }) => detail.open !== isNavOpen && toggleNav()}
        breadcrumbs={
          breadcrumbs.length > 0 ? (
            <BreadcrumbGroup
              items={breadcrumbs}
              onFollow={(event) => {
                event.preventDefault();
                if (event.detail.href) {
                  navigate(event.detail.href);
                }
              }}
            />
          ) : undefined
        }
        contentType="cards"
        content={<ContentLayout header={headerNode}>{children}</ContentLayout>}
        drawers={[
          {
            id: 'Mosaic_Feedback_Panel',
            content: <FeedbackPanel />,
            ariaLabels: { drawerName: 'Give feedback' },
            trigger: { iconName: 'support' },
            resizable: false,
          },
        ]}
      />
    </>
  );
};
