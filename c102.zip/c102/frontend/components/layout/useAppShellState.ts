import { useState, useEffect, useCallback } from 'react';

export const useAppShellState = () => {
  const [isNavOpen, setIsNavOpen] = useState(true);
  const [isWideLayout, setIsWideLayout] = useState(false);

  useEffect(() => {
    const mediaQuery = window.matchMedia('(min-width: 1100px)');

    const handleChange = () => {
      setIsWideLayout(mediaQuery.matches);
    };

    handleChange();
    mediaQuery.addEventListener('change', handleChange);

    return () => {
      mediaQuery.removeEventListener('change', handleChange);
    };
  }, []);

  const toggleNav = useCallback(() => {
    setIsNavOpen((previous) => !previous);
  }, []);

  return {
    isNavOpen,
    setIsNavOpen,
    isWideLayout,
    toggleNav,
  };
};
