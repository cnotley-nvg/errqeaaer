import React, {
  createContext,
  useCallback,
  useContext,
  useLayoutEffect,
  useMemo,
  useState,
} from 'react';
import type { BreadcrumbGroupProps, HeaderProps } from '@amzn/awsui-components-console';
import { useLocation } from 'react-router-dom';

export interface LayoutHeader {
  title: React.ReactNode;
  description?: React.ReactNode;
  info?: HeaderProps['info'];
  variant?: HeaderProps['variant'];
  actions?: React.ReactNode;
}

interface LayoutContextValue {
  breadcrumbs: BreadcrumbGroupProps.Item[];
  header: LayoutHeader | null;
  setBreadcrumbs: (items: BreadcrumbGroupProps.Item[]) => void;
  setHeader: (header: LayoutHeader | null) => void;
}

const LayoutContext = createContext<LayoutContextValue | null>(null);

export const LayoutProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const [breadcrumbs, updateBreadcrumbs] = useState<BreadcrumbGroupProps.Item[]>([]);
  const [header, updateHeader] = useState<LayoutHeader | null>(null);

  // Prevent stale PageLayout breadcrumbs from persisting across route changes.
  // Pages that use PageLayout will set their breadcrumbs on mount; pages that don't
  // will fall back to route-derived breadcrumbs in MosaicAppLayout.
  useLayoutEffect(() => {
    updateBreadcrumbs([]);
  }, [location.pathname]);

  const setBreadcrumbs = useCallback((items: BreadcrumbGroupProps.Item[]) => {
    updateBreadcrumbs(items); // Always update - let React handle diffing
  }, []);

  const setHeader = useCallback((next: LayoutHeader | null) => {
    updateHeader((previous) => (previous === next ? previous : next));
  }, []);

  const value = useMemo(
    () => ({ breadcrumbs, header, setBreadcrumbs, setHeader }),
    [breadcrumbs, header, setBreadcrumbs, setHeader]
  );

  return <LayoutContext.Provider value={value}>{children}</LayoutContext.Provider>;
};

export const useLayout = (): LayoutContextValue => {
  const context = useContext(LayoutContext);
  if (!context) {
    throw new Error('useLayout must be used within a LayoutProvider');
  }
  return context;
};
