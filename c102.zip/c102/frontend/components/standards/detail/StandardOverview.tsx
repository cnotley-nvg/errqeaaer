import React from 'react';
import { SpaceBetween } from '@amzn/awsui-components-console';

import type { StandardDetailData } from '../../../hooks/useStandardDetail';
import type { DocumentState } from '../hooks/useStandardDocumentLinks';
import { StandardOverviewMetadata } from './StandardOverviewMetadata';
import { DocumentPreview } from './DocumentPreview';

interface StandardOverviewProps {
  standard: StandardDetailData;
  standardName: string;
  documentState: DocumentState;
}

export const StandardOverview: React.FC<StandardOverviewProps> = ({
  standard,
  standardName,
  documentState,
}) => (
  <SpaceBetween size="l">
    <StandardOverviewMetadata standard={standard} />
    <DocumentPreview standardName={standardName} documentState={documentState} />
  </SpaceBetween>
);
