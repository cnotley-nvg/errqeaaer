import React from 'react';
import { Box, Container, Header } from '@amzn/awsui-components-console';

interface PlaceholderSectionProps {
  title: string;
  message?: string;
}

const DEFAULT_MESSAGE = 'TBD';

export const PlaceholderSection: React.FC<PlaceholderSectionProps> = ({
  title,
  message = DEFAULT_MESSAGE,
}) => (
  <Container header={<Header variant="h2">{title}</Header>}>
    <Box padding="m" textAlign="center" variant="p">
      {message}
    </Box>
  </Container>
);
