import React, { useCallback } from 'react';
import { Tabs, type TabsProps } from '@amzn/awsui-components-console';

interface DetailTabsProps {
  ariaLabel: string;
  activeTabId: string;
  tabs: TabsProps.Tab[];
  onTabChange: (tabId: string) => void;
}

export const DetailTabs: React.FC<DetailTabsProps> = ({
  ariaLabel,
  activeTabId,
  tabs,
  onTabChange,
}) => {
  const handleChange = useCallback<NonNullable<TabsProps['onChange']>>(
    (event) => {
      onTabChange(event.detail.activeTabId);
    },
    [onTabChange]
  );

  return (
    <Tabs ariaLabel={ariaLabel} activeTabId={activeTabId} onChange={handleChange} tabs={tabs} />
  );
};
