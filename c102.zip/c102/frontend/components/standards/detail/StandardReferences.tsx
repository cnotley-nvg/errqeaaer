import React from 'react';
import { Box, Container, Link, Pagination, Table } from '@amzn/awsui-components-console';
import type { PropertyFilterProps, TableProps } from '@amzn/awsui-components-console';
import { FilterSearchBar } from '../../shared/FilterSearchBar';

import type { StandardVersionReference } from '../hooks/useStandardVersionReferences';

interface StandardReferencesProps {
  items: StandardVersionReference[];
  loading: boolean;
  error: string | null;
  pageIdx: number;
  pageSize: number;
  total: number;
  hasNext: boolean;
  sort: { field: string; desc: boolean }[];
  onSortingChange: (sort: { field: string; desc: boolean }[]) => void;
  filterValue: string;
  onFilterChange: (value: string) => void;
  onPageChange: (pageIdx: number) => void;
}

export const StandardReferences: React.FC<StandardReferencesProps> = ({
  items,
  loading,
  error,
  pageIdx,
  pageSize,
  total,
  hasNext,
  sort,
  onSortingChange,
  filterValue,
  onFilterChange,
  onPageChange,
}) => {
  if (loading) {
    return <Box padding="m">Loading references…</Box>;
  }

  if (error) {
    return (
      <Box padding="m" color="text-status-error">
        {error}
      </Box>
    );
  }

  const columnDefinitions: TableProps.ColumnDefinition<StandardVersionReference>[] = [
    {
      id: 'specification',
      header: 'Specification',
      sortingField: 'specification',
      cell: (item) => item.specification,
    },
    {
      id: 'name',
      header: 'Name',
      sortingField: 'name',
      cell: (item) =>
        item.link ? (
          <Link href={item.link} external>
            {item.name}
          </Link>
        ) : (
          item.name
        ),
    },
    {
      id: 'createdAt',
      header: 'Created date',
      sortingField: 'createdAt',
      cell: (item) => item.createdAt ?? '',
    },
    {
      id: 'ownedBy',
      header: 'Owned by',
      sortingField: 'ownedBy',
      cell: (item) => item.ownedBy ?? '',
    },
  ];

  const pagesCount = Math.max(1, Math.ceil(total / pageSize || 1));
  const currentPageIndex = Math.min(pageIdx + 1, pagesCount);

  const primarySort = sort[0] ?? { field: 'specification', desc: false };

  const filteringProperties: ReadonlyArray<PropertyFilterProps.FilteringProperty> = [
    {
      key: 'name',
      operators: [':'],
      propertyLabel: 'Name',
      groupValuesLabel: 'Name values',
    },
  ];

  const filteringOptions: ReadonlyArray<PropertyFilterProps.FilteringOption> = Array.from(
    new Set(items.map((item) => item.name).filter(Boolean))
  ).map((name) => ({
    propertyKey: 'name',
    value: name,
    label: name,
  }));

  const propertyFilterQuery: PropertyFilterProps.Query = {
    operation: 'and',
    tokens: filterValue
      ? [
          {
            propertyKey: 'name',
            operator: ':',
            value: filterValue,
          },
        ]
      : [],
    tokenGroups: [],
  };

  return (
    <Container>
      <FilterSearchBar
        value={filterValue}
        onChange={onFilterChange}
        placeholder="Find resources"
        ariaLabel="Find resources by name"
        filteringProperties={filteringProperties}
        filteringOptions={filteringOptions}
        query={propertyFilterQuery}
        onTokensChange={(nextQuery) => {
          const firstNameToken = nextQuery.tokens.find(
            (token) => token.propertyKey === 'name' && typeof token.value === 'string'
          );
          onFilterChange((firstNameToken?.value as string) ?? '');
        }}
        rightAdornment={
          <div style={{ marginLeft: 'auto' }}>
            <Pagination
              currentPageIndex={currentPageIndex}
              pagesCount={pagesCount}
              onChange={(event) => onPageChange(event.detail.currentPageIndex - 1)}
            />
          </div>
        }
      />

      <Table
        columnDefinitions={columnDefinitions}
        items={items}
        variant="embedded"
        trackBy="id"
        sortingColumn={{ sortingField: primarySort.field }}
        sortingDescending={primarySort.desc}
        onSortingChange={({ detail }) => {
          const field = detail.sortingColumn.sortingField as string;
          const desc = detail.isDescending ?? false;
          onSortingChange([{ field, desc }]);
        }}
        empty={<Box padding="m">No references available.</Box>}
      />
    </Container>
  );
};
