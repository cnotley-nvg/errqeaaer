export interface OverviewFieldLink {
  label: string;
  href: string;
}

export interface OverviewField {
  key: string;
  label: string;
  value?: string | null;
  displayValue?: string;
  href?: string | null;
  links?: OverviewFieldLink[];
}
