import React from 'react';
import { ColumnLayout, Container, SpaceBetween } from '@amzn/awsui-components-console';

import type { StandardDetailData } from '../../../hooks/useStandardDetail';
import { ApprovalLink, BimLink, PhoneToolLink } from '../common';
import { MetadataField } from '../../common';
import { formatAttributeValue } from '../../../utils/standardPresenters';
import { formatDateShort } from '../../../utils/formatDate';

interface StandardOverviewMetadataProps {
  standard: StandardDetailData;
}

export const StandardOverviewMetadata: React.FC<StandardOverviewMetadataProps> = ({ standard }) => {
  const attributes = standard.latestVersion?.attributes;

  // Extract attribute values - use exact attribute names from seeds
  const region = formatAttributeValue(attributes, 'region') || '—';
  const projectType = formatAttributeValue(attributes, 'projectType') || '—';
  const program = formatAttributeValue(attributes, 'program') || 'Cross-program';
  const roomFeatureZone = formatAttributeValue(attributes, 'roomFeatureZone') || '—';
  const updateCadence = formatAttributeValue(attributes, 'updateCadence') || '—';
  const currentVersion = standard.latestVersion?.version || '—';

  // Created by - from ACC fields
  const createdBy = standard.latestVersion?.accCreatedBy || '';

  // Created date - use firstPublishedOn (v1.0 publication date)
  const createdDate = formatDateShort(standard.latestVersion?.firstPublishedOn) || '—';

  // Last modified by - from ACC fields
  const lastModifiedBy = standard.latestVersion?.accUpdatedBy || '';

  // Last modified date - use publishedOn (current version publication date)
  const lastModifiedDate = formatDateShort(standard.latestVersion?.publishedOn) || '—';

  // Approval link - check for URL in approvalLink attribute
  const approvalLink = formatAttributeValue(attributes, 'approvalLink');

  // BIM link - from ACC database fields
  const accProjectId = standard.accProjectId;
  const accFolderId = standard.latestVersion?.accFolderId;

  return (
    <Container>
      <SpaceBetween size="l">
        <ColumnLayout columns={4} variant="text-grid">
          {/* Column 1 */}
          <SpaceBetween size="l">
            <MetadataField label="Region">
              <span>{region}</span>
            </MetadataField>

            <MetadataField label="Update cadence">
              <span>{updateCadence}</span>
            </MetadataField>

            <MetadataField label="Last modified by">
              <PhoneToolLink username={lastModifiedBy} />
            </MetadataField>
          </SpaceBetween>

          {/* Column 2 */}
          <SpaceBetween size="l">
            <MetadataField label="Project type">
              <span>{projectType}</span>
            </MetadataField>

            <MetadataField label="Current version">
              <span>{currentVersion}</span>
            </MetadataField>

            <MetadataField label="Last modified date">
              <span>{lastModifiedDate}</span>
            </MetadataField>
          </SpaceBetween>

          {/* Column 3 */}
          <SpaceBetween size="l">
            <MetadataField label="Program">
              <span>{program}</span>
            </MetadataField>

            <MetadataField label="Created by">
              <PhoneToolLink username={createdBy} />
            </MetadataField>

            <MetadataField label="Approval information">
              <ApprovalLink approvalUrl={approvalLink} />
            </MetadataField>
          </SpaceBetween>

          {/* Column 4 */}
          <SpaceBetween size="l">
            <MetadataField label="Room/Feature/Zone">
              <span>{roomFeatureZone}</span>
            </MetadataField>

            <MetadataField label="Created date">
              <span>{createdDate}</span>
            </MetadataField>

            <MetadataField label="BIM link">
              <BimLink accProjectId={accProjectId} accFolderId={accFolderId} label="Info" />
            </MetadataField>
          </SpaceBetween>
        </ColumnLayout>
      </SpaceBetween>
    </Container>
  );
};
