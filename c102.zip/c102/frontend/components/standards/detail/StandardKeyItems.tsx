import React, { useMemo } from 'react';
import { Box, Container, Pagination, Table } from '@amzn/awsui-components-console';
import type { PropertyFilterProps, TableProps } from '@amzn/awsui-components-console';

import { FilterSearchBar } from '../../shared/FilterSearchBar';
import type { StandardVersionKeyItem } from '../hooks/useStandardVersionKeyItems';

interface StandardKeyItemsProps {
  items: StandardVersionKeyItem[];
  loading: boolean;
  error: string | null;
  sort: { field: 'category' | 'sheet'; desc: boolean }[];
  onSortingChange: (sort: { field: 'category' | 'sheet'; desc: boolean }[]) => void;
  pageIdx: number;
  pageSize: number;
  total: number;
  hasNext: boolean;
  onPageChange: (pageIdx: number) => void;
  filterValue: string;
  onFilterChange: (value: string) => void;
}

export const StandardKeyItems: React.FC<StandardKeyItemsProps> = ({
  items,
  loading,
  error,
  sort,
  onSortingChange,
  pageIdx,
  pageSize,
  total,
  hasNext,
  onPageChange,
  filterValue,
  onFilterChange,
}) => {
  const columnDefinitions = useMemo<TableProps.ColumnDefinition<StandardVersionKeyItem>[]>(
    () => [
      {
        id: 'category',
        header: 'Category name',
        sortingField: 'category',
        cell: (item: StandardVersionKeyItem) => item.category,
      },
      {
        id: 'sheet',
        header: 'Sheet no',
        sortingField: 'sheet',
        cell: (item: StandardVersionKeyItem) => item.sheet,
      },
    ],
    []
  );

  const pagesCount = Math.max(1, Math.ceil(total / pageSize || 1));
  const currentPageIndex = Math.min(pageIdx + 1, pagesCount);
  const primarySort = sort[0] ?? { field: 'sheet', desc: false };

  const filteringProperties: ReadonlyArray<PropertyFilterProps.FilteringProperty> = [
    {
      key: 'category',
      operators: [':'],
      propertyLabel: 'Category',
      groupValuesLabel: 'Category values',
    },
  ];

  const filteringOptions: ReadonlyArray<PropertyFilterProps.FilteringOption> = Array.from(
    new Set(items.map((item) => item.category).filter(Boolean))
  ).map((category) => ({
    propertyKey: 'category',
    value: category,
    label: category,
  }));

  const propertyFilterQuery: PropertyFilterProps.Query = {
    operation: 'and',
    tokens: filterValue
      ? [
          {
            propertyKey: 'category',
            operator: ':',
            value: filterValue,
          },
        ]
      : [],
    tokenGroups: [],
  };

  if (loading) {
    return (
      <Container>
        <Box padding="m">Loading key items…</Box>
      </Container>
    );
  }

  if (error) {
    return (
      <Box padding="m" color="text-status-error">
        {error}
      </Box>
    );
  }

  return (
    <Container>
      <FilterSearchBar
        value={filterValue}
        onChange={onFilterChange}
        placeholder="Find resources"
        ariaLabel="Find key items by category"
        filteringProperties={filteringProperties}
        filteringOptions={filteringOptions}
        query={propertyFilterQuery}
        onTokensChange={(nextQuery) => {
          const categoryToken = nextQuery.tokens.find(
            (token) => token.propertyKey === 'category' && typeof token.value === 'string'
          );
          onFilterChange((categoryToken?.value as string) ?? '');
        }}
        rightAdornment={
          <Pagination
            currentPageIndex={currentPageIndex}
            pagesCount={pagesCount}
            onChange={(event) => onPageChange(event.detail.currentPageIndex - 1)}
            ariaLabels={{ nextPageLabel: 'Next page', previousPageLabel: 'Previous page' }}
          />
        }
      />

      <Table
        columnDefinitions={columnDefinitions}
        items={items}
        variant="embedded"
        trackBy="id"
        sortingColumn={columnDefinitions.find((col) => col.sortingField === primarySort.field)}
        sortingDescending={primarySort.desc}
        onSortingChange={({ detail }) => {
          const field = detail.sortingColumn.sortingField as string;
          const desc = detail.isDescending ?? false;
          if (field === 'category' || field === 'sheet') {
            onSortingChange([{ field, desc }]);
          }
        }}
        empty={<Box padding="m">No key items available.</Box>}
      />
    </Container>
  );
};
