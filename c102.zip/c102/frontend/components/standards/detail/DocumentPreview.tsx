import React from 'react';
import {
  Box,
  Button,
  Container,
  SpaceBetween,
  StatusIndicator,
} from '@amzn/awsui-components-console';

import type { DocumentState } from '../hooks/useStandardDocumentLinks';
import { triggerDownload } from '../../../utils/downloadUtils';

interface DocumentPreviewProps {
  standardName: string;
  documentState: DocumentState;
  height?: string;
  renderUnavailable?: (state: DocumentState) => React.ReactNode;
}

const defaultUnavailable = (state: DocumentState) => (
  <SpaceBetween size="s">
    <StatusIndicator type="stopped">
      {state.error ? 'Unable to load document preview' : 'PDF preview unavailable'}
    </StatusIndicator>
    {state.error ? <span>{state.error}</span> : null}
    {state.downloadUrl ? (
      <div>
        <Button iconName="download" onClick={() => triggerDownload(state.downloadUrl!)}>
          Download
        </Button>
      </div>
    ) : (
      <span>No PDF link is currently available for this document.</span>
    )}
  </SpaceBetween>
);

export const DocumentPreview: React.FC<DocumentPreviewProps> = ({
  standardName,
  documentState,
  height = '80vh',
  renderUnavailable = defaultUnavailable,
}) => {
  return (
    <Container>
      {documentState.loading ? (
        <Box textAlign="center" padding="l">
          <StatusIndicator type="loading">Generating document preview</StatusIndicator>
        </Box>
      ) : documentState.viewerUrl ? (
        <Box padding="xxs">
          <div style={{ width: '100%', height }}>
            <iframe
              title={`${standardName} PDF`}
              src={documentState.viewerUrl}
              style={{ border: 'none', width: '100%', height: '100%' }}
            />
          </div>
        </Box>
      ) : (
        <Box textAlign="center" padding="l">
          {renderUnavailable(documentState)}
        </Box>
      )}
    </Container>
  );
};
