import React from 'react';
import {
  Box,
  Button,
  ExpandableSection,
  SpaceBetween,
  StatusIndicator,
} from '@amzn/awsui-components-console';

import type { StandardVersionDetail } from '../../../hooks/useStandardDetail';
import { useStandardVersionChangesMap } from '../hooks/useStandardVersionChanges';

interface StandardVersionHistoryProps {
  versions: readonly StandardVersionDetail[];
}

const formatReleaseDate = (date: Date): string => {
  if (Number.isNaN(date.getTime())) {
    return date.toISOString();
  }

  return date.toLocaleDateString('en-US', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC',
  });
};

export const StandardVersionHistory: React.FC<StandardVersionHistoryProps> = ({ versions }) => {
  const sorted = [...versions].sort((a, b) => {
    const aTime = new Date(a.publishedOn ?? a.createdAt).getTime();
    const bTime = new Date(b.publishedOn ?? b.createdAt).getTime();
    if (Number.isNaN(aTime) || Number.isNaN(bTime)) {
      return 0;
    }
    return bTime - aTime;
  });

  const versionIds = sorted.map((version) => version.id);
  const { changesByVersionId, loading, error } = useStandardVersionChangesMap(versionIds);

  if (!sorted.length) {
    return (
      <Box textAlign="center" padding="m">
        No versions available.
      </Box>
    );
  }

  if (loading && !Object.keys(changesByVersionId).length) {
    return (
      <Box textAlign="center" padding="m">
        <StatusIndicator type="loading">Loading version history</StatusIndicator>
      </Box>
    );
  }

  if (error) {
    return (
      <Box textAlign="center" padding="m">
        <StatusIndicator type="error">{error}</StatusIndicator>
      </Box>
    );
  }

  return (
    <SpaceBetween size="l">
      {sorted.map((version, index) => {
        const changes = changesByVersionId[version.id] ?? [];
        const firstChange = changes[0];

        const versionLabel = `V${version.version}`;
        const dateLabel = formatReleaseDate(version.publishedOn ?? version.createdAt);
        const headerVersionText = versionLabel;
        const headerDateText = dateLabel;
        const approvalUrl = firstChange?.approveUrl ?? undefined;

        return (
          <ExpandableSection
            key={version.id}
            variant="container"
            defaultExpanded={index === 0}
            headerText={`${headerVersionText} | ${headerDateText}`}
            headerActions={
              approvalUrl ? <Button href={approvalUrl}>Approval link</Button> : undefined
            }
          >
            <SpaceBetween size="s">
              {firstChange ? (
                <>
                  <Box>
                    <strong>Details:</strong> {firstChange.details}
                  </Box>
                  <Box>
                    <strong>Released by:</strong> {firstChange.releasedBy}
                  </Box>
                </>
              ) : (
                <Box>No change history for this version.</Box>
              )}
            </SpaceBetween>
          </ExpandableSection>
        );
      })}
    </SpaceBetween>
  );
};
