import type { CardBreakpoint } from '../../../../hooks/useTablePreferences';
import type { PreferenceOption, PageSizeOption, CatalogPreferences } from './types';

// Unified catalog page size
export const DEFAULT_CATALOG_PAGE_SIZE = 20;

// Card column count for layout
export const CARD_COLUMN_COUNT = 3;

// Minimum card width for layout calculations (in pixels)
export const MIN_CARD_WIDTH = 385;

// Default breakpoints for card view responsive layout
// NOTE: These thresholds are FIXED and not customizable by users
// Ranges use inclusive lower bounds (>=). Upper bound is exclusive (next breakpoint - 1)
export const DEFAULT_CARD_BREAKPOINTS: readonly CardBreakpoint[] = [
  { minWidth: 768, cards: 2 }, // Tablet: 768px - 1365px
  { minWidth: 1366, cards: 3 }, // Laptop: 1366px - 1919px
  { minWidth: 1920, cards: 4 }, // Desktop: 1920px+
] as const;

// Validation constraints
export const MIN_CARDS_PER_ROW = 1;
export const MAX_CARDS_PER_ROW = 20;
export const MIN_SCREEN_WIDTH = 0;
export const MAX_SCREEN_WIDTH = 10000;
export const MAX_BREAKPOINTS = 3; // Limited to 3 breakpoints for simplicity

// Table column options for standards
export const TABLE_COLUMN_OPTIONS: readonly PreferenceOption[] = [
  { id: 'name', label: 'Standard name', alwaysVisible: true },
  { id: 'region', label: 'Region' },
  { id: 'program', label: 'Program' },
  { id: 'projectType', label: 'Project type' },
  { id: 'updateCadence', label: 'Update cadence' },
  { id: 'version', label: 'Version' },
  { id: 'roomFeatureZone', label: 'Room/Feature/Zone' },
  { id: 'approvalInformation', label: 'Approval information' },
  { id: 'bimLink', label: 'BIM link' },
  { id: 'createdBy', label: 'Created by' },
  { id: 'createdDate', label: 'Created date' },
  { id: 'lastModifiedBy', label: 'Last modified by' },
  { id: 'lastModifiedDate', label: 'Last modified date' },
] as const;

// Card field options (all table columns EXCEPT 'name' which is the card title)
export const CARD_FIELD_OPTIONS: readonly PreferenceOption[] = [
  { id: 'region', label: 'Region' },
  { id: 'program', label: 'Program' },
  { id: 'projectType', label: 'Project type' },
  { id: 'updateCadence', label: 'Update cadence' },
  { id: 'version', label: 'Version' },
  { id: 'roomFeatureZone', label: 'Room/Feature/Zone' },
  { id: 'approvalInformation', label: 'Approval information' },
  { id: 'bimLink', label: 'BIM link' },
  { id: 'createdBy', label: 'Created by' },
  { id: 'createdDate', label: 'Created date' },
  { id: 'lastModifiedBy', label: 'Last modified by' },
  { id: 'lastModifiedDate', label: 'Last modified date' },
] as const;

// Unified catalog page size options
export const CATALOG_PAGE_SIZE_OPTIONS: readonly PageSizeOption[] = [
  { value: 10, label: '10 standards' },
  { value: 20, label: '20 standards' },
  { value: 30, label: '30 standards' },
  { value: 40, label: '40 standards' },
] as const;

// Default unified catalog preferences (pageSize is NOT stored here - managed via URL only)
export const DEFAULT_CATALOG_PREFERENCES: CatalogPreferences = {
  table: {
    contentDisplay: [
      { id: 'name', visible: true },
      { id: 'region', visible: true },
      { id: 'program', visible: true },
      { id: 'projectType', visible: true },
      { id: 'updateCadence', visible: true },
      { id: 'version', visible: true },
      // Hidden by default
      { id: 'roomFeatureZone', visible: false },
      { id: 'approvalInformation', visible: false },
      { id: 'bimLink', visible: false },
      { id: 'createdBy', visible: false },
      { id: 'createdDate', visible: false },
      { id: 'lastModifiedBy', visible: false },
      { id: 'lastModifiedDate', visible: false },
    ],
    wrapLines: false,
    stripedRows: false,
  },
  cards: {
    contentDisplay: [
      // Default visible fields (3 fields for standards)
      { id: 'region', visible: true },
      { id: 'projectType', visible: true },
      { id: 'program', visible: true },
      // Hidden by default
      { id: 'updateCadence', visible: false },
      { id: 'version', visible: false },
      { id: 'roomFeatureZone', visible: false },
      { id: 'approvalInformation', visible: false },
      { id: 'bimLink', visible: false },
      { id: 'createdBy', visible: false },
      { id: 'createdDate', visible: false },
      { id: 'lastModifiedBy', visible: false },
      { id: 'lastModifiedDate', visible: false },
    ],
    cardsPerRowBreakpoints: [...DEFAULT_CARD_BREAKPOINTS],
  },
};
