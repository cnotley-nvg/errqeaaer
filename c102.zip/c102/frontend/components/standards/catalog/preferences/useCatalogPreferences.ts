/**
 * Standard catalog preferences hook using versioned storage
 *
 * This replaces the old localStorage implementation with a versioned storage system
 * that automatically handles:
 * - Migration from v0 (separate table/card keys) to v2
 * - Schema validation
 * - Defaults merging
 * - Error recovery
 *
 * The hook maintains the same API as before for backward compatibility.
 */

import { standardCatalogPreferencesStore } from '../../../../storage/catalog-preferences';
import { createVersionedCatalogPreferencesHook } from '../../../../storage/catalog-preferences/useVersionedCatalogPreferences';

/**
 * Hook for managing unified standard catalog preferences
 *
 * Preferences are automatically migrated from old formats:
 * - v0: Separate `standard-catalog-table-preferences` and `standard-catalog-card-preferences` keys
 * - v1: Unified structure with old breakpoint thresholds (1920, 2560)
 * - v2: Current version with updated breakpoints (1921, 2561)
 *
 * Storage key: `standard-catalog-preferences`
 *
 * @example
 * ```typescript
 * const { preferences, updateTablePreferences, updateCardsPreferences, resetToDefaults } = useCatalogPreferences();
 *
 * // Update table preferences
 * updateTablePreferences({ wrapLines: true });
 *
 * // Update card preferences
 * updateCardsPreferences({
 *   contentDisplay: [{ id: 'region', visible: true }]
 * });
 *
 * // Reset to defaults
 * resetToDefaults();
 * ```
 */
export const useCatalogPreferences = createVersionedCatalogPreferencesHook(
  standardCatalogPreferencesStore
);
