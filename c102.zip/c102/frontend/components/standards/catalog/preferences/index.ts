// Primary exports - Unified catalog preferences
export { useCatalogPreferences } from './useCatalogPreferences';
export {
  CATALOG_PAGE_SIZE_OPTIONS,
  DEFAULT_CATALOG_PAGE_SIZE,
  DEFAULT_CATALOG_PREFERENCES,
  TABLE_COLUMN_OPTIONS,
  CARD_FIELD_OPTIONS,
  CARD_COLUMN_COUNT,
  DEFAULT_CARD_BREAKPOINTS,
  MIN_CARD_WIDTH,
} from './constants';
export type { CatalogPreferences, CatalogPreferencesHookResult, CardBreakpoint } from './types';

// Breakpoint editor component
export { BreakpointEditor, normalizeBreakpoints } from './BreakpointEditor';
