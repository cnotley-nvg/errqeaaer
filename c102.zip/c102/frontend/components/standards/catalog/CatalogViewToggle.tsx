import React, { useCallback } from 'react';
import { SegmentedControl, type SegmentedControlProps } from '@amzn/awsui-components-console';

const VIEW_OPTIONS: SegmentedControlProps.Option[] = [
  { id: 'card', text: 'Card view', iconName: 'grid-view' },
  { id: 'table', text: 'Table view', iconName: 'view-full' },
];

export type CatalogViewType = 'card' | 'table';

interface CatalogViewToggleProps {
  viewType: CatalogViewType;
  onViewTypeChange: (nextViewType: CatalogViewType) => void;
}

export const CatalogViewToggle: React.FC<CatalogViewToggleProps> = ({
  viewType,
  onViewTypeChange,
}) => {
  const handleChange = useCallback(
    ({ detail }: { detail: { selectedId?: string } }) => {
      const nextView = (detail.selectedId as CatalogViewType | undefined) ?? 'card';
      onViewTypeChange(nextView);
    },
    [onViewTypeChange]
  );

  return <SegmentedControl selectedId={viewType} onChange={handleChange} options={VIEW_OPTIONS} />;
};
