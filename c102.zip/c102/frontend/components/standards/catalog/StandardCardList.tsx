import React, { useMemo } from 'react';
import { Box, Cards, Link, SpaceBetween, type CardsProps } from '@amzn/awsui-components-console';
import { useLocation, useNavigate } from 'react-router-dom';

import type { StandardVersionWithStandard } from '../../../hooks/useLatestStandardVersionsSearch';
import type { TablePreferences } from '../../../hooks/useTablePreferences';
import { DEFAULT_CARD_BREAKPOINTS } from './preferences';
import { ApprovalLink, BimLink } from '../common';
import { formatDateShort } from '../../../utils/formatDate';

export interface StandardCardListProps {
  items: StandardVersionWithStandard[];
  loading: boolean;
  empty: React.ReactNode;
  preferences?: TablePreferences;
}

// Default visible fields for card view (3 fields for standards)
const DEFAULT_CARD_FIELDS = ['region', 'projectType', 'program'];

const renderCardField = (
  label: string,
  value: string | number | null | undefined,
  item?: StandardVersionWithStandard,
  fieldId?: string
) => {
  // Special handling for BIM link - use BimLink component
  if (fieldId === 'bimLink' && item) {
    return (
      <SpaceBetween size="xxs">
        <Box fontWeight="bold">{label}</Box>
        <BimLink accProjectId={item.standard.accProjectId} accFolderId={item.accFolderId} />
      </SpaceBetween>
    );
  }

  // Special handling for approval information - use ApprovalLink component
  if (fieldId === 'approvalInformation' && item) {
    const approvalLink = getAttributeValue(item, 'approvalLink');
    return (
      <SpaceBetween size="xxs">
        <Box fontWeight="bold">{label}</Box>
        <ApprovalLink approvalUrl={approvalLink} />
      </SpaceBetween>
    );
  }

  // Regular fields - just display the value
  return (
    <SpaceBetween size="xxs">
      <Box fontWeight="bold">{label}</Box>
      <span>{value ?? '–'}</span>
    </SpaceBetween>
  );
};

const getAttributeValue = (version: StandardVersionWithStandard, key: string): string | null => {
  const attributes = version.attributes ?? {};
  const raw = attributes[key];
  if (raw === null || raw === undefined) {
    return null;
  }
  if (Array.isArray(raw)) {
    const filtered = raw.filter((v) => v !== null && v !== undefined && String(v).trim() !== '');
    return filtered.length > 0 ? filtered.map((v) => String(v)).join(', ') : null;
  }
  if (typeof raw === 'object' && raw !== null && 'value' in raw) {
    return String((raw as { value: unknown }).value ?? '');
  }
  return String(raw);
};
// Map field IDs to labels for display
const fieldLabels: Record<string, string> = {
  region: 'Region',
  program: 'Program',
  projectType: 'Project type',
  updateCadence: 'Update cadence',
  version: 'Version',
  roomFeatureZone: 'Room/Feature/Zone',
  approvalInformation: 'Approval information',
  bimLink: 'BIM link',
  createdBy: 'Created by',
  createdDate: 'Created date',
  lastModifiedBy: 'Last modified by',
  lastModifiedDate: 'Last modified date',
};

export const StandardCardList: React.FC<StandardCardListProps> = ({
  items,
  loading,
  empty,
  preferences,
}) => {
  const navigate = useNavigate();
  const location = useLocation();

  // Generate cardsPerRow from breakpoints preferences
  const cardsPerRow = useMemo(() => {
    const breakpoints = preferences?.cardsPerRowBreakpoints;
    const resolved = breakpoints && breakpoints.length > 0 ? breakpoints : DEFAULT_CARD_BREAKPOINTS;

    const mapped = resolved.map((bp) => ({
      cards: bp.cards,
      ...(bp.minWidth > 0 && { minWidth: bp.minWidth }),
    }));

    // Ensure a base breakpoint exists for < smallest minWidth
    if (resolved[0]?.minWidth > 0) {
      return [{ cards: resolved[0].cards }, ...mapped];
    }

    return mapped;
  }, [preferences?.cardsPerRowBreakpoints]);

  // Determine which fields to show based on preferences
  const visibleFields = useMemo(() => {
    if (!preferences?.contentDisplay) {
      return DEFAULT_CARD_FIELDS;
    }

    const visible = preferences.contentDisplay
      .filter((item) => item.visible !== false)
      .map((item) => item.id);

    return visible.length > 0 ? visible : DEFAULT_CARD_FIELDS;
  }, [preferences]);

  // Get field value - returns string/number for simple fields, null for BIM link (rendered separately)
  const getFieldValue = (
    item: StandardVersionWithStandard,
    fieldId: string
  ): string | number | null => {
    // Handle special fields
    if (fieldId === 'program') {
      return 'Cross-program';
    }
    if (fieldId === 'version') {
      return item.version ? `v${item.version}` : null;
    }
    if (fieldId === 'createdBy') {
      return item.accCreatedBy ?? null;
    }
    if (fieldId === 'lastModifiedBy') {
      return item.accUpdatedBy ?? null;
    }
    // BIM link is handled separately by renderCardField (returns component, not string)
    if (fieldId === 'bimLink') {
      return null; // Placeholder - will be replaced by BimLink component
    }
    // Approval information is handled separately by renderCardField (returns component, not string)
    if (fieldId === 'approvalInformation') {
      return null; // Placeholder - will be replaced by ApprovalLink component
    }
    // Handle date fields - format as: DD Mon YYYY (e.g., "15 Jan 2026")
    if (fieldId === 'createdDate') {
      return formatDateShort(item.firstPublishedOn) || null;
    }
    if (fieldId === 'lastModifiedDate') {
      return formatDateShort(item.publishedOn) || null;
    }
    // Handle regular attribute fields
    return getAttributeValue(item, fieldId);
  };

  const cardDefinition = useMemo<CardsProps.CardDefinition<StandardVersionWithStandard>>(
    () => ({
      header: (item) => (
        <Box fontSize="heading-m" fontWeight="bold">
          <Link
            href={`/standards/${item.standard.id}${location.search}`}
            onFollow={(event) => {
              event.preventDefault();
              navigate(`/standards/${item.standard.id}${location.search}`);
            }}
          >
            {item.standard.name}
          </Link>
        </Box>
      ),
      sections: [
        {
          id: 'metrics',
          content: (item) => {
            // Dynamically render fields based on visible fields
            const fieldsToShow = visibleFields.map((fieldId) => (
              <React.Fragment key={fieldId}>
                {renderCardField(
                  fieldLabels[fieldId] || fieldId,
                  getFieldValue(item, fieldId),
                  item,
                  fieldId
                )}
              </React.Fragment>
            ));

            return <SpaceBetween size="s">{fieldsToShow}</SpaceBetween>;
          },
        },
      ],
    }),
    [location.search, navigate, visibleFields]
  );

  return (
    <Cards
      // trackBy="id" uses StandardVersionWithStandard.id (version ID) for React key stability
      // Navigation uses item.standard.id (standard ID) to show all versions
      trackBy="id"
      loading={loading}
      loadingText="Loading standards"
      cardDefinition={cardDefinition}
      cardsPerRow={cardsPerRow}
      items={items}
      empty={empty}
    />
  );
};
