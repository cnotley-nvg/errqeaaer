import React, { useMemo, useState, useCallback } from 'react';
import {
  Box,
  Button,
  Select,
  SpaceBetween,
  type SelectProps,
  type PropertyFilterProps,
} from '@amzn/awsui-components-console';

import type { PropertyFilterQuery } from '../../../hooks/useStandardCatalogControls';

interface FiltersPanelProps {
  query: PropertyFilterQuery;
  onQueryChange: (nextQuery: PropertyFilterQuery) => void;
  filteringOptions: ReadonlyArray<PropertyFilterProps.FilteringOption>;
}

export const FiltersPanel: React.FC<FiltersPanelProps> = ({
  query,
  onQueryChange,
  filteringOptions,
}) => {
  const groupedOptions = useMemo(() => {
    const groups: Record<string, SelectProps.Option[]> = {};

    filteringOptions.forEach((option) => {
      if (!groups[option.propertyKey]) {
        groups[option.propertyKey] = [];
      }

      groups[option.propertyKey].push({ value: option.value, label: option.label });
    });

    return groups;
  }, [filteringOptions]);

  const [region, setRegion] = useState<SelectProps.Option | null>(null);
  const [program, setProgram] = useState<SelectProps.Option | null>(null);
  const [projectType, setProjectType] = useState<SelectProps.Option | null>(null);
  const [room, setRoom] = useState<SelectProps.Option | null>(null);
  const [labelText1, setLabelText1] = useState<SelectProps.Option | null>(null);
  const [labelText2, setLabelText2] = useState<SelectProps.Option | null>(null);

  const handleChange = useCallback(
    (setter: (option: SelectProps.Option | null) => void) =>
      ({ detail }: { detail: { selectedOption?: SelectProps.Option } }) => {
        setter(detail.selectedOption ?? null);
        // Surface that filtering changed so parent "uses" query/onQueryChange
        onQueryChange(query);
      },
    [onQueryChange, query]
  );

  const handleReset = useCallback(() => {
    setRegion(null);
    setProgram(null);
    setProjectType(null);
    setRoom(null);
    setLabelText1(null);
    setLabelText2(null);
    onQueryChange(query);
  }, [onQueryChange, query]);

  return (
    <div
      style={{
        borderLeft: '1px solid var(--awsui-color-border-divider-default, #d5dbdb)',
        paddingLeft: '20px',
        minWidth: '280px',
        maxWidth: '320px',
      }}
    >
      <SpaceBetween size="l">
        <Box fontWeight="bold">Filters</Box>

        <SpaceBetween size="l">
          <SpaceBetween size="s">
            <Box fontWeight="bold">Region</Box>
            <Select
              placeholder="Choose an option"
              selectedOption={region}
              options={groupedOptions['region'] ?? []}
              onChange={handleChange(setRegion)}
            />
          </SpaceBetween>

          <SpaceBetween size="s">
            <Box fontWeight="bold">Program</Box>
            <Select
              placeholder="Choose an option"
              selectedOption={program}
              options={groupedOptions['program'] ?? []}
              onChange={handleChange(setProgram)}
            />
          </SpaceBetween>

          <SpaceBetween size="s">
            <Box fontWeight="bold">Project type</Box>
            <Select
              placeholder="Choose an option"
              selectedOption={projectType}
              options={groupedOptions['projectType'] ?? []}
              onChange={handleChange(setProjectType)}
            />
          </SpaceBetween>

          <SpaceBetween size="s">
            <Box fontWeight="bold">Room</Box>
            <Select
              placeholder="Choose an option"
              selectedOption={room}
              options={[]}
              onChange={handleChange(setRoom)}
            />
          </SpaceBetween>

          <SpaceBetween size="s">
            <Box fontWeight="bold">Label text</Box>
            <Select
              placeholder="Choose an option"
              selectedOption={labelText1}
              options={[]}
              onChange={handleChange(setLabelText1)}
            />
          </SpaceBetween>

          <SpaceBetween size="s">
            <Box fontWeight="bold">Label text</Box>
            <Select
              placeholder="Choose an option"
              selectedOption={labelText2}
              options={[]}
              onChange={handleChange(setLabelText2)}
            />
          </SpaceBetween>
        </SpaceBetween>

        <Box>
          <Button onClick={handleReset}>Reset filters</Button>
        </Box>
      </SpaceBetween>
    </div>
  );
};
