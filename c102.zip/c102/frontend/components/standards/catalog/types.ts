/**
 * Shared type definitions for Standards catalog
 *
 * These types represent the data structure used throughout the catalog:
 * - StandardVersionWithStandard: Flat structure from API (version with nested standard info)
 * - Used by: StandardTable, StandardCardList, and StandardCatalog
 * - Standard: Legacy format with latestVersion nested (used by presenters and some utilities)
 */

import type { AttributeMap } from '@amzn/global-realty-mosaic-graphql-schema';

export interface StandardInfo {
  id: string;
  name: string;
  description?: string | null;
  accProjectId: string;
}

export interface StandardVersionWithStandard {
  id: string;
  standardId: string;
  version: string;
  isLatest: boolean;
  attributes: Record<string, unknown>;
  accCreatedAt: string | null;
  accCreatedBy: string | null;
  accUpdatedAt: string | null;
  accUpdatedBy: string | null;
  createdAt: string;
  updatedAt: string;
  standard: StandardInfo;
}

/**
 * Legacy Standard type with nested latestVersion
 * Used by utilities like standardPresenters that expect this structure
 */
export interface Standard {
  id: string;
  name: string;
  description?: string | null;
  accProjectId: string;
  createdAt: string;
  updatedAt: string;
  latestVersion?: {
    id: string;
    version: string;
    isLatest: boolean;
    attributes: AttributeMap;
    createdAt: string;
    updatedAt: string;
    kits?: unknown[];
  } | null;
}
