import React, { useMemo } from 'react';
import { Link, Table, type TableProps } from '@amzn/awsui-components-console';
import { useLocation, useNavigate } from 'react-router-dom';

import type { StandardVersionWithStandard } from '../../../hooks/useLatestStandardVersionsSearch';
import type { TablePreferences } from '../../../hooks/useTablePreferences';
import { ApprovalLink, BimLink } from '../common';
import { formatDateShort } from '../../../utils/formatDate';

export interface StandardTableProps {
  items: StandardVersionWithStandard[];
  loading: boolean;
  sortingField: TableProps.SortingColumn<StandardVersionWithStandard>['sortingField'];
  sortingDescending: boolean;
  onSortingChange: TableProps['onSortingChange'];
  empty: React.ReactNode;
  preferences?: TablePreferences;
}

const asString = (value?: string | null): string => {
  if (!value) {
    return '–';
  }
  const trimmed = value.trim();
  return trimmed.length ? trimmed : '–';
};

const getAttributeString = (version: StandardVersionWithStandard, key: string): string => {
  const attributes = version.attributes ?? {};
  const raw = attributes[key];
  if (raw === null || raw === undefined) {
    return '–';
  }
  if (Array.isArray(raw)) {
    // Join all array values with comma separator for multi-value attributes
    const filtered = raw.filter((v) => v !== null && v !== undefined && String(v).trim() !== '');
    return filtered.length > 0 ? filtered.map((v) => asString(String(v))).join(', ') : '–';
  }
  if (typeof raw === 'object' && raw !== null && 'value' in raw) {
    return asString(String((raw as { value: unknown }).value ?? ''));
  }
  return asString(String(raw));
};

const formatVersion = (version: StandardVersionWithStandard): string => {
  return version.version ? `v${version.version}` : '–';
};

const formatDate = (iso: string | null | undefined): string => {
  const formatted = formatDateShort(iso);
  return formatted || '–';
};

export const StandardTable: React.FC<StandardTableProps> = ({
  items,
  loading,
  sortingField,
  sortingDescending,
  onSortingChange,
  empty,
  preferences,
}) => {
  const navigate = useNavigate();
  const location = useLocation();

  // Define all possible columns (matching fields from standard detail page)
  const allColumnDefinitions = useMemo<TableProps.ColumnDefinition<StandardVersionWithStandard>[]>(
    () => [
      {
        id: 'name',
        header: 'Standard name',
        cell: (item) => (
          <Link
            href={`/standards/${item.standard.id}${location.search}`}
            onFollow={(event) => {
              event.preventDefault();
              navigate(`/standards/${item.standard.id}${location.search}`);
            }}
          >
            {item.standard.name}
          </Link>
        ),
        sortingField: 'name',
        minWidth: 240,
        isRowHeader: true,
      },
      {
        id: 'region',
        header: 'Region',
        cell: (item) => getAttributeString(item, 'region'),
        sortingField: 'region',
        minWidth: 120,
      },
      {
        id: 'program',
        header: 'Program',
        cell: () => 'Cross-program',
        minWidth: 150,
      },
      {
        id: 'projectType',
        header: 'Project type',
        cell: (item) => getAttributeString(item, 'projectType'),
        sortingField: 'projectType',
        minWidth: 180,
      },
      {
        id: 'updateCadence',
        header: 'Update cadence',
        cell: (item) => getAttributeString(item, 'updateCadence'),
        sortingField: 'updateCadence',
        minWidth: 150,
      },
      {
        id: 'version',
        header: 'Version',
        cell: (item) => formatVersion(item),
        sortingField: 'version',
        minWidth: 120,
      },
      {
        id: 'roomFeatureZone',
        header: 'Room/Feature/Zone',
        cell: (item) => getAttributeString(item, 'roomFeatureZone'),
        sortingField: 'roomFeatureZone',
        minWidth: 180,
      },
      {
        id: 'approvalInformation',
        header: 'Approval information',
        cell: (item) => {
          const approvalLink = getAttributeString(item, 'approvalLink');
          return <ApprovalLink approvalUrl={approvalLink === '–' ? null : approvalLink} />;
        },
        minWidth: 180,
      },
      {
        id: 'bimLink',
        header: 'BIM link',
        cell: (item) => (
          <BimLink accProjectId={item.standard.accProjectId} accFolderId={item.accFolderId} />
        ),
        minWidth: 150,
      },
      {
        id: 'createdBy',
        header: 'Created by',
        cell: (item) => asString(item.accCreatedBy),
        sortingField: 'accCreatedBy',
        minWidth: 160,
      },
      {
        id: 'createdDate',
        header: 'Created date',
        cell: (item) => formatDate(item.firstPublishedOn),
        sortingField: 'firstPublishedOn',
        minWidth: 160,
      },
      {
        id: 'lastModifiedBy',
        header: 'Last modified by',
        cell: (item) => asString(item.accUpdatedBy),
        sortingField: 'accUpdatedBy',
        minWidth: 160,
      },
      {
        id: 'lastModifiedDate',
        header: 'Last modified date',
        cell: (item) => formatDate(item.publishedOn),
        sortingField: 'publishedOn',
        minWidth: 180,
      },
    ],
    [location.search, navigate]
  );

  // Filter columns based on preferences
  const visibleColumns = useMemo(() => {
    if (!preferences?.contentDisplay) {
      return allColumnDefinitions;
    }

    const visibilityMap = new Map(
      preferences.contentDisplay.map((item) => [item.id, item.visible !== false])
    );

    return allColumnDefinitions.filter((col) => {
      if (!col.id) return true; // Keep columns without IDs
      return visibilityMap.get(col.id) !== false;
    });
  }, [allColumnDefinitions, preferences]);

  return (
    <Table
      trackBy="id" // Track by version ID (each row is a StandardVersionWithStandard)
      loading={loading}
      loadingText="Loading standards"
      columnDefinitions={visibleColumns}
      items={items}
      sortingColumn={{ sortingField }}
      sortingDescending={sortingDescending}
      onSortingChange={onSortingChange}
      variant="embedded"
      empty={empty}
      wrapLines={preferences?.wrapLines}
      stripedRows={preferences?.stripedRows}
    />
  );
};
