import type { ReactNode } from 'react';
import type { CardsProps } from '@amzn/awsui-components-console';

interface StandardSummaryCardConfig<T> {
  header: CardsProps.CardDefinition<T>['header'];
  getRegion: (item: T) => ReactNode;
  getProjectType: (item: T) => ReactNode;
  getProgram: (item: T) => ReactNode;
  regionLabel?: string;
  projectTypeLabel?: string;
  programLabel?: string;
}

const defaultRegionLabel = 'Region';
const defaultProjectTypeLabel = 'Project type';
const defaultProgramLabel = 'Program';

export const createStandardSummaryCardDefinition = <T,>({
  header,
  getRegion,
  getProjectType,
  getProgram,
  regionLabel = defaultRegionLabel,
  projectTypeLabel = defaultProjectTypeLabel,
  programLabel = defaultProgramLabel,
}: StandardSummaryCardConfig<T>): CardsProps.CardDefinition<T> => ({
  header,
  sections: [
    {
      id: 'region',
      header: regionLabel,
      content: getRegion,
    },
    {
      id: 'projectType',
      header: projectTypeLabel,
      content: getProjectType,
    },
    {
      id: 'program',
      header: programLabel,
      content: getProgram,
    },
  ],
});
