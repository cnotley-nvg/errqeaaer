import React from 'react';
import { SpaceBetween, Grid, type PropertyFilterProps } from '@amzn/awsui-components-console';

import { CatalogViewToggle, type CatalogViewType } from './CatalogViewToggle';
import { CatalogSearchBar } from '../../shared/CatalogSearchBar';

export interface StandardCatalogToolbarProps {
  searchValue: string;
  onSearchChange: (value: string) => void;
  propertyFilterQuery: PropertyFilterProps.Query;
  onPropertyFilterTokensChange: (query: PropertyFilterProps.Query) => void;

  view: CatalogViewType;
  onViewChange: (view: CatalogViewType) => void;
  filteringOptions?: ReadonlyArray<PropertyFilterProps.FilteringOption>;
  filteringProperties: ReadonlyArray<PropertyFilterProps.FilteringProperty>;

  // Controls for pagination and preferences (rendered on right side)
  paginationControl?: React.ReactNode;
  preferencesControl?: React.ReactNode;
}

export const StandardCatalogToolbar: React.FC<StandardCatalogToolbarProps> = ({
  searchValue,
  onSearchChange,
  view,
  onViewChange,
  filteringOptions,
  filteringProperties,
  propertyFilterQuery,
  onPropertyFilterTokensChange,
  paginationControl,
  preferencesControl,
}) => {
  return (
    <SpaceBetween size="m">
      {/* Row 1: Search bar + Pagination + Gear icon */}
      <Grid gridDefinition={[{ colspan: 8 }, { colspan: 4 }]}>
        <CatalogSearchBar
          value={searchValue}
          onChange={onSearchChange}
          propertyFilterQuery={propertyFilterQuery}
          onPropertyFilterTokensChange={onPropertyFilterTokensChange}
          placeholder="Filter standards by properties (use :empty for null values)"
          ariaLabel="Search standards"
          filteringOptions={filteringOptions}
          filteringProperties={filteringProperties}
          width="100%"
        />

        <div
          style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: '8px' }}
        >
          {paginationControl}
          {preferencesControl}
        </div>
      </Grid>

      {/* Row 2: View toggle (Card | Table) */}
      <CatalogViewToggle viewType={view} onViewTypeChange={onViewChange} />
    </SpaceBetween>
  );
};
