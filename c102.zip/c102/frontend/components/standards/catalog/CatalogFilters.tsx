import React, { useCallback, useMemo } from 'react';
import { PropertyFilter, type PropertyFilterProps } from '@amzn/awsui-components-console';

import { type PropertyFilterQuery } from '../../../hooks/useStandardCatalogControls';

const FILTER_PLACEHOLDER = 'Find resources';

export const FILTERING_PROPERTIES: ReadonlyArray<PropertyFilterProps.FilteringProperty> = [
  {
    key: 'name',
    operators: ['=', '!=', ':'],
    propertyLabel: 'Name',
    groupValuesLabel: 'Name values',
  },
  {
    key: 'region',
    operators: [
      { operator: '=', tokenType: 'enum' },
      { operator: '!=', tokenType: 'enum' },
      ':',
      '!:',
    ],
    propertyLabel: 'Region',
    groupValuesLabel: 'Region values',
  },
  {
    key: 'projectType',
    operators: [
      { operator: '=', tokenType: 'enum' },
      { operator: '!=', tokenType: 'enum' },
      ':',
      '!:',
    ],
    propertyLabel: 'Project Type',
    groupValuesLabel: 'Project Type values',
  },
  {
    key: 'program',
    operators: [
      { operator: '=', tokenType: 'enum' },
      { operator: '!=', tokenType: 'enum' },
      ':',
      '!:',
    ],
    propertyLabel: 'Program',
    groupValuesLabel: 'Program values',
  },
];

const buildPropertyFilterProps = (
  query: PropertyFilterQuery,
  onQueryChange: PropertyFilterProps['onChange'],
  countText: string,
  filteringOptions: ReadonlyArray<PropertyFilterProps.FilteringOption>
): PropertyFilterProps => ({
  query,
  onChange: onQueryChange,
  countText,
  filteringPlaceholder: FILTER_PLACEHOLDER,
  filteringAriaLabel: 'Filter standards',
  enableTokenGroups: true,
  disableFreeTextFiltering: true,
  filteringProperties: FILTERING_PROPERTIES,
  filteringOptions,
  i18nStrings: {
    enteredTextLabel: (text) => `Use: "${text}"`,
    dismissAriaLabel: 'Dismiss',
    clearAriaLabel: 'Clear',
    groupValuesText: 'Values',
    groupPropertiesText: 'Properties',
    operatorsText: 'Operators',
    operationAndText: 'and',
    operationOrText: 'or',
    operatorLessText: 'Less than',
    operatorLessOrEqualText: 'Less than or equal',
    operatorGreaterText: 'Greater than',
    operatorGreaterOrEqualText: 'Greater than or equal',
    operatorContainsText: 'Contains',
    operatorDoesNotContainText: 'Does not contain',
    operatorEqualsText: 'Equals',
    operatorDoesNotEqualText: 'Does not equal',
    operatorStartsWithText: 'Starts with',
    operatorDoesNotStartWithText: 'Does not start with',
    editTokenHeader: 'Edit filter',
    propertyText: 'Property',
    operatorText: 'Operator',
    valueText: 'Value',
    cancelActionText: 'Cancel',
    applyActionText: 'Apply',
    allPropertiesLabel: 'All properties',
    clearFiltersText: 'Clear filters',
    tokenLimitShowMore: 'Show more',
    tokenLimitShowFewer: 'Show fewer',
    removeTokenButtonAriaLabel: (token) =>
      `Remove token ${token.propertyLabel} ${token.operator} ${token.value}`,
  },
});

interface CatalogFiltersProps {
  query: PropertyFilterQuery;
  onQueryChange: (query: PropertyFilterQuery) => void;
  totalCount: number;
  filteringOptions: ReadonlyArray<PropertyFilterProps.FilteringOption>;
}

export const CatalogFilters: React.FC<CatalogFiltersProps> = ({
  query,
  onQueryChange,
  totalCount,
  filteringOptions,
}) => {
  const handleChange = useCallback<PropertyFilterProps['onChange']>(
    (event) => onQueryChange(event.detail),
    [onQueryChange]
  );

  const propertyFilterProps = useMemo(
    () => buildPropertyFilterProps(query, handleChange, `${totalCount} matches`, filteringOptions),
    [filteringOptions, handleChange, query, totalCount]
  );

  return <PropertyFilter {...propertyFilterProps} />;
};
