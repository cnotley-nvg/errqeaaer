import { useCallback } from 'react';
import type { TableProps } from '@amzn/awsui-components-console';

import type { StandardVersionWithStandard } from '../catalog/types';
import type { SortableField } from '../../../hooks/useStandardCatalogControls';

interface UseStandardSortingProps {
  onSortChange: (field: SortableField, descending: boolean) => void;
}

type SortingEvent = { detail: TableProps.SortingState<StandardVersionWithStandard> };

export const useStandardSorting = ({ onSortChange }: UseStandardSortingProps) => {
  const handleSortingChange = useCallback(
    ({ detail }: SortingEvent) => {
      const field = detail.sortingColumn.sortingField as SortableField | undefined;
      if (!field) {
        return;
      }

      onSortChange(field, detail.isDescending ?? false);
    },
    [onSortChange]
  );

  return { handleSortingChange };
};
