import { useCallback, useEffect, useState } from 'react';
import { gql } from 'graphql-request';

import { graphqlClient } from '../../../api/graphqlClient';

export interface StandardVersionReference {
  id: string;
  standardVersionId: string;
  specification: string;
  name: string;
  createdAt?: string | null;
  ownedBy?: string | null;
  link?: string | null;
}

interface StandardVersionReferencesResponse {
  standardVersionReferencesConnection: {
    items: StandardVersionReference[];
    total: number;
    pageIdx: number;
    limit: number;
    hasNext: boolean;
  };
}

const STANDARD_VERSION_REFERENCES_QUERY = gql`
  query StandardVersionReferences(
    $standardVersionId: ID!
    $pageIdx: Int!
    $limit: Int!
    $nameContains: String
    $sort: [StandardVersionReferenceSortInput!]
  ) {
    standardVersionReferencesConnection(
      standardVersionId: $standardVersionId
      pageIdx: $pageIdx
      limit: $limit
      nameContains: $nameContains
      sort: $sort
    ) {
      items {
        id
        standardVersionId
        specification
        name
        createdAt
        ownedBy
        link
      }
      total
      pageIdx
      limit
      hasNext
    }
  }
`;

export interface UseStandardVersionReferencesOptions {
  pageIdx: number;
  pageSize: number;
  sort: { field: 'specification' | 'name' | 'createdAt' | 'ownedBy'; desc: boolean }[];
  nameFilter: string;
}

export const useStandardVersionReferences = (
  standardVersionId: string | null | undefined,
  options: UseStandardVersionReferencesOptions
): {
  items: StandardVersionReference[];
  loading: boolean;
  error: string | null;
  total: number;
  pageIdx: number;
  pageSize: number;
  hasNext: boolean;
} => {
  const [items, setItems] = useState<StandardVersionReference[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [total, setTotal] = useState(0);
  const [pageIdx, setPageIdx] = useState(0);
  const [pageSize, setPageSize] = useState(0);
  const [hasNext, setHasNext] = useState(false);

  const fetchItems = useCallback(async () => {
    if (!standardVersionId) {
      setItems([]);
      setTotal(0);
      setPageIdx(0);
      setPageSize(options.pageSize);
      setHasNext(false);
      setLoading(false);
      setError(null);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await graphqlClient.request<StandardVersionReferencesResponse>(
        STANDARD_VERSION_REFERENCES_QUERY,
        {
          standardVersionId,
          pageIdx: options.pageIdx,
          limit: options.pageSize,
          nameContains: options.nameFilter || null,
          sort: options.sort,
        }
      );
      const connection = response.standardVersionReferencesConnection;
      setItems(connection.items ?? []);
      setTotal(connection.total ?? 0);
      setPageIdx(connection.pageIdx ?? options.pageIdx);
      setPageSize(connection.limit ?? options.pageSize);
      setHasNext(Boolean(connection.hasNext));
    } catch (err) {
      setItems([]);
      setTotal(0);
      setPageIdx(options.pageIdx);
      setPageSize(options.pageSize);
      setHasNext(false);
      setError(err instanceof Error ? err.message : 'Unable to load references.');
    } finally {
      setLoading(false);
    }
  }, [standardVersionId, options.pageIdx, options.pageSize, options.sort, options.nameFilter]);

  useEffect(() => {
    void fetchItems();
  }, [fetchItems]);

  return { items, loading, error, total, pageIdx, pageSize, hasNext };
};
