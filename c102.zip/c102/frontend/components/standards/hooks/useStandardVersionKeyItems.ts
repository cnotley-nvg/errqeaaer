import { useCallback, useEffect, useState } from 'react';
import { gql } from 'graphql-request';

import { graphqlClient } from '../../../api/graphqlClient';

export interface StandardVersionKeyItem {
  id: string;
  standardVersionId: string;
  category: string;
  sheet: string;
  cell: string;
}

interface StandardVersionKeyItemsResponse {
  standardVersionKeyItems: StandardVersionKeyItem[];
}

const STANDARD_VERSION_KEY_ITEMS_QUERY = gql`
  query StandardVersionKeyItems($standardVersionId: ID!, $orderBy: String, $orderDesc: Boolean) {
    standardVersionKeyItems(
      standardVersionId: $standardVersionId
      orderBy: $orderBy
      orderDesc: $orderDesc
    ) {
      id
      standardVersionId
      category
      sheet
      cell
    }
  }
`;

export const useStandardVersionKeyItems = (
  standardVersionId: string | null | undefined,
  sortingField: 'category' | 'sheet',
  sortingDescending: boolean
): { items: StandardVersionKeyItem[]; loading: boolean; error: string | null } => {
  const [items, setItems] = useState<StandardVersionKeyItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchItems = useCallback(async () => {
    if (!standardVersionId) {
      setItems([]);
      setLoading(false);
      setError(null);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await graphqlClient.request<StandardVersionKeyItemsResponse>(
        STANDARD_VERSION_KEY_ITEMS_QUERY,
        { standardVersionId, orderBy: sortingField, orderDesc: sortingDescending }
      );
      setItems(response.standardVersionKeyItems ?? []);
    } catch (err) {
      setItems([]);
      setError(err instanceof Error ? err.message : 'Unable to load key items.');
    } finally {
      setLoading(false);
    }
  }, [standardVersionId, sortingField, sortingDescending]);

  useEffect(() => {
    void fetchItems();
  }, [fetchItems]);

  return { items, loading, error };
};
