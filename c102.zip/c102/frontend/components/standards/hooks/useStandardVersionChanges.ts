import { useCallback, useEffect, useState } from 'react';
import { gql } from 'graphql-request';

import { graphqlClient } from '../../../api/graphqlClient';

export interface StandardVersionChange {
  id: string;
  standardVersionId: string;
  details: string;
  releasedBy: string;
  approveUrl?: string | null;
}

interface StandardVersionChangesResponse {
  standardVersionChanges: StandardVersionChange[];
}

const STANDARD_VERSION_CHANGES_QUERY = gql`
  query StandardVersionChanges($standardVersionId: ID!) {
    standardVersionChanges(standardVersionId: $standardVersionId) {
      id
      standardVersionId
      details
      releasedBy
      approveUrl
    }
  }
`;

export interface StandardVersionChangesMapResult {
  changesByVersionId: Record<string, StandardVersionChange[]>;
  loading: boolean;
  error: string | null;
}

export const useStandardVersionChangesMap = (
  versionIds: readonly string[]
): StandardVersionChangesMapResult => {
  const [changesByVersionId, setChangesByVersionId] = useState<
    Record<string, StandardVersionChange[]>
  >({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchChanges = useCallback(async () => {
    const uniqueIds = Array.from(new Set(versionIds.filter(Boolean)));
    if (!uniqueIds.length) {
      setChangesByVersionId({});
      setLoading(false);
      setError(null);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const results = await Promise.all(
        uniqueIds.map((id) =>
          graphqlClient.request<StandardVersionChangesResponse>(STANDARD_VERSION_CHANGES_QUERY, {
            standardVersionId: id,
          })
        )
      );

      const map: Record<string, StandardVersionChange[]> = {};
      uniqueIds.forEach((id, index) => {
        map[id] = results[index]?.standardVersionChanges ?? [];
      });
      setChangesByVersionId(map);
    } catch (err) {
      setChangesByVersionId({});
      setError(err instanceof Error ? err.message : 'Unable to load version history.');
    } finally {
      setLoading(false);
    }
  }, [versionIds.join('|')]);

  useEffect(() => {
    void fetchChanges();
  }, [fetchChanges]);

  return { changesByVersionId, loading, error };
};
