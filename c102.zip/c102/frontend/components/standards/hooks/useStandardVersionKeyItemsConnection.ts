import { useCallback, useEffect, useState } from 'react';
import { gql } from 'graphql-request';

import { graphqlClient } from '../../../api/graphqlClient';
import type { StandardVersionKeyItem } from './useStandardVersionKeyItems';

export interface StandardVersionKeyItemConnection {
  items: StandardVersionKeyItem[];
  total: number;
  pageIdx: number;
  limit: number;
  hasNext: boolean;
}

interface StandardVersionKeyItemsConnectionResponse {
  standardVersionKeyItemsConnection: StandardVersionKeyItemConnection;
}

const STANDARD_VERSION_KEY_ITEMS_CONNECTION_QUERY = gql`
  query StandardVersionKeyItemsConnection(
    $standardVersionId: ID!
    $pageIdx: Int!
    $limit: Int!
    $sort: [StandardVersionKeyItemSortInput!]
    $categoryContains: String
  ) {
    standardVersionKeyItemsConnection(
      standardVersionId: $standardVersionId
      pageIdx: $pageIdx
      limit: $limit
      categoryContains: $categoryContains
      sort: $sort
    ) {
      items {
        id
        standardVersionId
        category
        sheet
        cell
      }
      total
      pageIdx
      limit
      hasNext
    }
  }
`;

export interface UseStandardVersionKeyItemsConnectionOptions {
  pageIdx: number;
  pageSize: number;
  sort: { field: 'category' | 'sheet'; desc: boolean }[];
  categoryFilter?: string;
}

export const useStandardVersionKeyItemsConnection = (
  standardVersionId: string | null | undefined,
  options: UseStandardVersionKeyItemsConnectionOptions
): {
  items: StandardVersionKeyItem[];
  loading: boolean;
  error: string | null;
  total: number;
  pageIdx: number;
  pageSize: number;
  hasNext: boolean;
} => {
  const [items, setItems] = useState<StandardVersionKeyItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [total, setTotal] = useState(0);
  const [pageIdx, setPageIdx] = useState(0);
  const [pageSize, setPageSize] = useState(options.pageSize);
  const [hasNext, setHasNext] = useState(false);

  // Stabilize the effect dependency: callers may recreate the sort array each render,
  // but identical content should not re-trigger a refetch.
  const sortKey = JSON.stringify(options.sort ?? []);
  const normalizedCategoryFilter = (options.categoryFilter ?? '').trim();
  const categoryFilterKey = normalizedCategoryFilter.toLowerCase();

  const fetchItems = useCallback(async () => {
    if (!standardVersionId) {
      setItems([]);
      setTotal(0);
      setPageIdx(0);
      setPageSize(options.pageSize);
      setHasNext(false);
      setLoading(false);
      setError(null);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await graphqlClient.request<StandardVersionKeyItemsConnectionResponse>(
        STANDARD_VERSION_KEY_ITEMS_CONNECTION_QUERY,
        {
          standardVersionId,
          pageIdx: options.pageIdx,
          limit: options.pageSize,
          sort: options.sort,
          categoryContains: normalizedCategoryFilter || null,
        }
      );

      const connection = response.standardVersionKeyItemsConnection;
      setItems(connection.items ?? []);
      setTotal(connection.total ?? 0);
      setPageIdx(connection.pageIdx ?? options.pageIdx);
      setPageSize(connection.limit ?? options.pageSize);
      setHasNext(Boolean(connection.hasNext));
    } catch (err) {
      setItems([]);
      setTotal(0);
      setPageIdx(options.pageIdx);
      setPageSize(options.pageSize);
      setHasNext(false);
      setError(err instanceof Error ? err.message : 'Unable to load key items.');
    } finally {
      setLoading(false);
    }
  }, [
    standardVersionId,
    options.pageIdx,
    options.pageSize,
    sortKey,
    categoryFilterKey,
    normalizedCategoryFilter,
  ]);

  useEffect(() => {
    void fetchItems();
  }, [fetchItems]);

  return { items, loading, error, total, pageIdx, pageSize, hasNext };
};
