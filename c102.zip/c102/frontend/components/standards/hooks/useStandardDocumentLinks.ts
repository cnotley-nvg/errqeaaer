import { useCallback, useEffect, useState } from 'react';
import { gql } from 'graphql-request';

import { graphqlClient } from '../../../api/graphqlClient';

export interface DocumentState {
  viewerUrl: string | null;
  downloadUrl: string | null;
  loading: boolean;
  error: string | null;
}

const initialState: DocumentState = {
  viewerUrl: null,
  downloadUrl: null,
  loading: false,
  error: null,
};

interface StandardDocumentLinksResponse {
  standardDocumentLinks: {
    viewerUrl?: string | null;
    downloadUrl?: string | null;
  } | null;
}

const STANDARD_DOCUMENT_LINKS_QUERY = gql`
  query StandardDocumentLinks($standardVersionId: ID!) {
    standardDocumentLinks(standardVersionId: $standardVersionId) {
      viewerUrl
      downloadUrl
    }
  }
`;

export const useStandardDocumentLinks = (
  standardVersionId: string | null | undefined
): DocumentState => {
  const [state, setState] = useState<DocumentState>(initialState);

  const fetchLinks = useCallback(async () => {
    if (!standardVersionId) {
      setState(initialState);
      return;
    }

    setState({ viewerUrl: null, downloadUrl: null, loading: true, error: null });

    try {
      const response = await graphqlClient.request<StandardDocumentLinksResponse>(
        STANDARD_DOCUMENT_LINKS_QUERY,
        { standardVersionId }
      );

      const payload = response.standardDocumentLinks ?? null;
      setState({
        viewerUrl: payload?.viewerUrl ?? null,
        downloadUrl: payload?.downloadUrl ?? null,
        loading: false,
        error: null,
      });
    } catch (error) {
      setState({
        viewerUrl: null,
        downloadUrl: null,
        loading: false,
        error: error instanceof Error ? error.message : 'Unable to load document links.',
      });
    }
  }, [standardVersionId]);

  useEffect(() => {
    void fetchLinks();
  }, [fetchLinks]);

  return state;
};
