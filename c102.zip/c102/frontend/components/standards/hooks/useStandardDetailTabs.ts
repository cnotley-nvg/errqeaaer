import { useCallback, useMemo, useState } from 'react';

export type TabId = string;

interface UseStandardDetailTabsOptions {
  storageKey?: string;
  defaultTab: TabId;
}

const defaultStorageKey = 'standard-detail-active-tab';

const getStoredTab = (storageKey: string, fallback: TabId): TabId => {
  if (typeof window === 'undefined') {
    return fallback;
  }

  const stored = window.sessionStorage.getItem(storageKey);
  return stored ? (stored as TabId) : fallback;
};

export const useStandardDetailTabs = ({
  storageKey = defaultStorageKey,
  defaultTab,
}: UseStandardDetailTabsOptions) => {
  const initialTab = useMemo(() => getStoredTab(storageKey, defaultTab), [storageKey, defaultTab]);
  const [activeTabId, setActiveTabId] = useState<TabId>(initialTab);

  const handleTabChange = useCallback(
    (nextTabId: TabId) => {
      setActiveTabId(nextTabId);

      if (typeof window !== 'undefined') {
        window.sessionStorage.setItem(storageKey, nextTabId);
      }
    },
    [storageKey]
  );

  return { activeTabId, handleTabChange };
};
