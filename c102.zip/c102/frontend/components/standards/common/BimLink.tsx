import React from 'react';
import { Link } from '@amzn/awsui-components-console';

import {
  buildAccFolderUrl,
  isValidAccProjectId,
  isValidAccFolderId,
} from '../../../utils/accUrlBuilder';

export interface BimLinkProps {
  /**
   * ACC project ID (e.g., "8e8a9dbb-8c39-4c76-9b81-0d8567ccd32d")
   */
  accProjectId: string | null | undefined;

  /**
   * ACC folder ID (e.g., "urn:adsk.wipprod:fs.folder:co.xxx")
   */
  accFolderId: string | null | undefined;

  /**
   * Link label text (default: "View BIM")
   */
  label?: string;
}

/**
 * Renders a clickable link to an ACC (Autodesk Construction Cloud) folder.
 *
 * Composes the BIM link dynamically from accProjectId and accFolderId.
 * If either ID is missing or invalid, renders "–" instead.
 *
 * @example
 * // Basic usage
 * <BimLink
 *   accProjectId={standard.accProjectId}
 *   accFolderId={version.accFolderId}
 * />
 *
 * @example
 * // Custom label
 * <BimLink
 *   accProjectId={standard.accProjectId}
 *   accFolderId={version.accFolderId}
 *   label="Open in ACC"
 * />
 */
export const BimLink: React.FC<BimLinkProps> = ({
  accProjectId,
  accFolderId,
  label = 'View BIM',
}) => {
  // Validate IDs and compose URL
  if (
    !accProjectId ||
    !accFolderId ||
    !isValidAccProjectId(accProjectId) ||
    !isValidAccFolderId(accFolderId)
  ) {
    return <span>–</span>;
  }

  const url = buildAccFolderUrl(accProjectId, accFolderId);

  return (
    <Link href={url} external>
      {label}
    </Link>
  );
};
