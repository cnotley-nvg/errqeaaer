import React from 'react';
import { Link } from '@amzn/awsui-components-console';

export interface ApprovalLinkProps {
  /**
   * URL to the approval document or page
   */
  approvalUrl: string | null | undefined;

  /**
   * Link label text (default: "View approval")
   */
  label?: string;
}

/**
 * Renders a clickable link to an approval document or page.
 *
 * If the URL is missing or invalid, renders "–" instead.
 *
 * @example
 * // Basic usage
 * <ApprovalLink approvalUrl={attributes.approvalLink} />
 *
 * @example
 * // Custom label
 * <ApprovalLink approvalUrl={attributes.approvalLink} label="View documentation" />
 */
export const ApprovalLink: React.FC<ApprovalLinkProps> = ({
  approvalUrl,
  label = 'View approval',
}) => {
  // Validate URL
  if (!approvalUrl || (!approvalUrl.startsWith('http://') && !approvalUrl.startsWith('https://'))) {
    return <span>–</span>;
  }

  return (
    <Link href={approvalUrl} external>
      {label}
    </Link>
  );
};
