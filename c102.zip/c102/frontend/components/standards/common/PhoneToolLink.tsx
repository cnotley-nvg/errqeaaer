import React from 'react';
import { Link } from '@amzn/awsui-components-console';

import { buildPhoneToolUrl, isValidPhoneToolUsername } from '../../../utils/accUrlBuilder';

export interface PhoneToolLinkProps {
  username?: string | null;
}

/**
 * Renders a PhoneTool link for a valid username, or displays the username/fallback as plain text.
 * Shows "—" if no username is provided.
 */
export const PhoneToolLink: React.FC<PhoneToolLinkProps> = ({ username }) => {
  const trimmedUsername = username?.trim();

  if (!trimmedUsername) {
    return <span>—</span>;
  }

  if (isValidPhoneToolUsername(trimmedUsername)) {
    return (
      <Link href={buildPhoneToolUrl(trimmedUsername)} variant="primary" external>
        {trimmedUsername}
      </Link>
    );
  }

  return <span>{trimmedUsername}</span>;
};
