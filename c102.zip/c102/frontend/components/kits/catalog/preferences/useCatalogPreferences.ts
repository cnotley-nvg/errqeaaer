import { publishedKitCatalogPreferencesStore } from '../../../../storage/catalog-preferences';
import { createVersionedCatalogPreferencesHook } from '../../../../storage/catalog-preferences/useVersionedCatalogPreferences';

export const useCatalogPreferences = createVersionedCatalogPreferencesHook(
  publishedKitCatalogPreferencesStore
);
