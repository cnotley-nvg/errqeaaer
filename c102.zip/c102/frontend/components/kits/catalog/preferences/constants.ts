export const DEFAULT_CATALOG_PAGE_SIZE = 20;

export const CATALOG_PAGE_SIZE_OPTIONS = [
  { value: 10, label: '10 kits' },
  { value: 20, label: '20 kits' },
  { value: 30, label: '30 kits' },
  { value: 40, label: '40 kits' },
] as const;

export const TABLE_COLUMN_OPTIONS = [
  { id: 'name', label: 'Kit name', alwaysVisible: true },
  { id: 'description', label: 'Description' },
  { id: 'region', label: 'Region' },
  { id: 'program', label: 'Program' },
  { id: 'projectType', label: 'Project type' },
  { id: 'roomFeatureZone', label: 'Room/Feature/Zone' },
  { id: 'dataType', label: 'Data type' },
  { id: 'keyLabel', label: 'Key label' },
  { id: 'createdBy', label: 'Created by' },
  { id: 'createdOn', label: 'Created on' },
] as const;
