import React, { useMemo } from 'react';
import { Link, Table, type TableProps } from '@amzn/awsui-components-console';
import { useLocation, useNavigate } from 'react-router-dom';

import type { Kit } from '@amzn/global-realty-mosaic-graphql-schema';

import { formatKitAttribute } from '../../../utils/kitPresenters';
import { formatDateShort } from '../../../utils/formatDate';
import { EmptyState } from '../../common/EmptyState';
import type { TablePreferences } from '../../../hooks/useTablePreferences';

export interface PublishedKitsTableProps {
  items: readonly Kit[];
  loading: boolean;
  sortingField: TableProps.SortingColumn<Kit>['sortingField'];
  sortingDescending: boolean;
  onSortingChange: TableProps['onSortingChange'];
  preferences?: Pick<TablePreferences, 'contentDisplay' | 'wrapLines' | 'stripedRows'>;
}

const emptyState = (
  <EmptyState title="No kits" subtitle="Published kits will appear here once created." />
);

export const PublishedKitsTable: React.FC<PublishedKitsTableProps> = ({
  items,
  loading,
  sortingField,
  sortingDescending,
  onSortingChange,
  preferences,
}) => {
  const navigate = useNavigate();
  const location = useLocation();

  const allColumnDefinitions = useMemo<TableProps.ColumnDefinition<Kit>[]>(
    () => [
      {
        id: 'name',
        header: 'Kit name',
        cell: (item) => (
          <Link
            href={`/kits/${item.id}${location.search}`}
            onFollow={(event) => {
              event.preventDefault();
              navigate(`/kits/${item.id}${location.search}`);
            }}
          >
            {item.name}
          </Link>
        ),
        minWidth: 220,
      },
      {
        id: 'description',
        header: 'Description',
        cell: (item) => item.desc ?? '–',
        minWidth: 240,
      },
      {
        id: 'region',
        header: 'Region',
        sortingField: 'region',
        cell: (item) => formatKitAttribute(item, 'region') || '–',
        minWidth: 180,
      },
      {
        id: 'program',
        header: 'Program',
        sortingField: 'program',
        cell: (item) => formatKitAttribute(item, 'program') || '–',
        minWidth: 180,
      },
      {
        id: 'projectType',
        header: 'Project type',
        cell: (item) => formatKitAttribute(item, 'projectType') || '–',
        minWidth: 200,
      },
      {
        id: 'roomFeatureZone',
        header: 'Room/Feature/Zone',
        cell: (item) => formatKitAttribute(item, 'roomFeatureZone') || '–',
        minWidth: 200,
      },
      {
        id: 'dataType',
        header: 'Data type',
        cell: (item) => formatKitAttribute(item, 'dataType') || '–',
        minWidth: 180,
      },
      {
        id: 'keyLabel',
        header: 'Key label',
        cell: (item) => formatKitAttribute(item, 'keyLabel') || '–',
        minWidth: 180,
      },
      {
        id: 'createdBy',
        header: 'Created by',
        cell: (item) => formatKitAttribute(item, 'createdBy') || '–',
        minWidth: 180,
      },
      {
        id: 'createdOn',
        header: 'Created on',
        cell: (item) => formatDateShort(item.latestVersion?.createdAt ?? item.createdAt) || '–',
        minWidth: 180,
      },
    ],
    [location.search, navigate]
  );

  // Filter columns based on preferences (defaults to all columns visible)
  const visibleColumns = useMemo(() => {
    if (!preferences?.contentDisplay) {
      return allColumnDefinitions;
    }

    const visibilityMap = new Map(
      preferences.contentDisplay.map((item) => [item.id, item.visible !== false])
    );

    return allColumnDefinitions.filter((col) => {
      if (!col.id) return true;
      return visibilityMap.get(col.id) !== false;
    });
  }, [allColumnDefinitions, preferences]);

  return (
    <Table
      trackBy="id"
      loading={loading}
      loadingText="Loading published kits"
      columnDefinitions={visibleColumns}
      items={items as Kit[]}
      stickyColumns={{ first: 1 }}
      sortingColumn={{ sortingField }}
      sortingDescending={sortingDescending}
      onSortingChange={onSortingChange}
      variant="embedded"
      empty={emptyState}
      wrapLines={preferences?.wrapLines}
      stripedRows={preferences?.stripedRows}
    />
  );
};
