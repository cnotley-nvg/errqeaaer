import React from 'react';
import { SpaceBetween, Grid, type PropertyFilterProps } from '@amzn/awsui-components-console';
import type { PropertyFilterQuery } from '@amzn/awsui-collection-hooks';

import { FilterSearchBar } from '../../shared/FilterSearchBar';

const FILTERING_PROPERTIES: ReadonlyArray<PropertyFilterProps.FilteringProperty> = [
  {
    key: 'name',
    operators: [{ operator: '=', tokenType: 'enum' }, { operator: '!=', tokenType: 'enum' }, ':'],
    propertyLabel: 'Name',
    groupValuesLabel: 'Name values',
  },
];

export interface PublishedKitsToolbarProps {
  propertyFilterQuery: PropertyFilterQuery;
  onPropertyFilterChange: (query: PropertyFilterQuery) => void;
  filteringOptions?: ReadonlyArray<PropertyFilterProps.FilteringOption>;
  paginationControl?: React.ReactNode;
  preferencesControl?: React.ReactNode;
}

export const PublishedKitsToolbar: React.FC<PublishedKitsToolbarProps> = ({
  propertyFilterQuery,
  onPropertyFilterChange,
  filteringOptions,
  paginationControl,
  preferencesControl,
}) => {
  const handleSearchChange = (_value: string) => {};

  return (
    <SpaceBetween size="m">
      <Grid gridDefinition={[{ colspan: 8 }, { colspan: 4 }]}>
        <FilterSearchBar
          value=""
          onChange={handleSearchChange}
          propertyFilterQuery={propertyFilterQuery as PropertyFilterProps.Query}
          onPropertyFilterTokensChange={(query) =>
            onPropertyFilterChange(query as PropertyFilterQuery)
          }
          filteringProperties={FILTERING_PROPERTIES}
          filteringOptions={filteringOptions}
          placeholder="Find resources"
          ariaLabel="Filter published kits"
          width="100%"
        />

        <div
          style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: '8px' }}
        >
          {paginationControl}
          {preferencesControl}
        </div>
      </Grid>
    </SpaceBetween>
  );
};
