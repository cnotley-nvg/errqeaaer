import React, { useCallback, useMemo, useState } from 'react';
import {
  Box,
  Button,
  Cards,
  Container,
  Header,
  SpaceBetween,
} from '@amzn/awsui-components-console';
import { gql } from 'graphql-request';

import type { KitCompatibleStandard } from '../../../hooks/useKitBuilder';
import type { KitDetailData, KitDetailStandardLink } from '../../../hooks/useKitDetail';
import { useLinkedStandardSummaryCardDefinition } from '../../common/StandardSummaryCard';
import { EmptyState } from '../../common/EmptyState';
import { STANDARD_CARDS_BREAKPOINTS } from '../../build-kit/constants';
import { graphqlClient } from '../../../api/graphqlClient';
import { formatAttributeValue } from '../../../utils/standardPresenters';

const FALLBACK_VALUE = '—';

const STANDARD_DOCUMENT_LINKS_QUERY = gql`
  query StandardDocumentLinks($standardVersionId: ID!) {
    standardDocumentLinks(standardVersionId: $standardVersionId) {
      downloadUrl
    }
  }
`;

interface DownloadStandardButtonProps {
  standardVersionId: string;
  standardName: string;
  version: string;
}

const DownloadStandardButton: React.FC<DownloadStandardButtonProps> = ({
  standardVersionId,
  standardName,
  version,
}) => {
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownload = useCallback(async () => {
    if (!standardVersionId || isDownloading) return;
    setIsDownloading(true);

    try {
      const response = await graphqlClient.request<{
        standardDocumentLinks: { downloadUrl?: string | null } | null;
      }>(STANDARD_DOCUMENT_LINKS_QUERY, { standardVersionId });

      const downloadUrl = response.standardDocumentLinks?.downloadUrl;
      if (!downloadUrl) {
        throw new Error('Download URL not available');
      }

      const filename = `${standardName.replace(/\s+/g, '_')}_${version}.pdf`;
      const fileResponse = await fetch(downloadUrl);
      if (!fileResponse.ok) {
        throw new Error('Failed to download file');
      }

      const blob = await fileResponse.blob();
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(blobUrl), 100);
    } catch (err) {
      console.error('Download failed:', err);
    } finally {
      setIsDownloading(false);
    }
  }, [standardVersionId, standardName, version, isDownloading]);

  return (
    <Button
      variant="normal"
      onClick={handleDownload}
      disabled={!standardVersionId || isDownloading}
      loading={isDownloading}
    >
      Download
    </Button>
  );
};

const extractAttribute = (attributes: any, key: string): string => {
  const value = formatAttributeValue(attributes, key);
  return value && value.trim().length ? value : '';
};

const mapCompatibleStandards = (kit: KitDetailData | null): KitCompatibleStandard[] => {
  if (!kit?.latestVersion) {
    return [];
  }

  const toCard = (link: KitDetailStandardLink): KitCompatibleStandard => {
    const region = extractAttribute(link.attributes, 'region') || FALLBACK_VALUE;
    const programRaw = link.attributes?.program;
    const projectTypeRaw = link.attributes?.projectType;
    const roomFeatureZoneRaw = link.attributes?.roomFeatureZone;
    const dataType = extractAttribute(link.attributes, 'dataType') || null;

    // Convert to arrays if they are arrays in attributes, otherwise keep as single value
    const program = Array.isArray(programRaw)
      ? programRaw
      : programRaw
        ? [String(programRaw)]
        : null;
    const projectType = Array.isArray(projectTypeRaw)
      ? projectTypeRaw
      : projectTypeRaw
        ? [String(projectTypeRaw)]
        : null;
    const roomFeatureZone = Array.isArray(roomFeatureZoneRaw)
      ? roomFeatureZoneRaw
      : roomFeatureZoneRaw
        ? [String(roomFeatureZoneRaw)]
        : null;

    return {
      id: link.id,
      standardId: link.standardId,
      standardName: link.standardName,
      version: link.version,
      region,
      program,
      roomFeatureZone,
      dataType,
      projectType,
    } as KitCompatibleStandard;
  };

  return kit.latestVersion.standards.map(toCard);
};

interface KitStandardsListProps {
  kit: KitDetailData | null;
}

export const KitStandardsList: React.FC<KitStandardsListProps> = ({ kit }) => {
  const compatibleStandards = useMemo(() => mapCompatibleStandards(kit), [kit]);

  const baseCardDefinition = useLinkedStandardSummaryCardDefinition<KitCompatibleStandard>({
    getStandardId: (item) => item.standardId,
    getStandardName: (item) => item.standardName,
    getRegion: (item) => item.region,
    getProjectType: (item) => item.projectType,
    getProgram: (item) => item.program,
  });

  const renderBaseHeader = (item: KitCompatibleStandard): React.ReactNode => {
    const header = baseCardDefinition.header;
    if (!header) return null;
    return typeof header === 'function' ? header(item) : header;
  };

  const standardCardsDefinition = useMemo(
    () => ({
      ...baseCardDefinition,
      header: (item: KitCompatibleStandard) => (
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            width: '100%',
            gap: '0.5rem',
          }}
        >
          <Box>{renderBaseHeader(item)}</Box>
          <DownloadStandardButton
            standardVersionId={item.id}
            standardName={item.standardName}
            version={item.version}
          />
        </div>
      ),
    }),
    [baseCardDefinition]
  );

  const standardCount = compatibleStandards.length;

  return (
    <Container header={<Header variant="h2">Standards ({standardCount})</Header>}>
      <SpaceBetween size="l">
        {standardCount === 0 ? (
          <EmptyState
            title="No standards"
            subtitle="This kit does not contain any standards yet."
            iconName="search"
          />
        ) : (
          <Cards
            items={compatibleStandards}
            cardDefinition={standardCardsDefinition}
            cardsPerRow={STANDARD_CARDS_BREAKPOINTS}
          />
        )}
      </SpaceBetween>
    </Container>
  );
};
