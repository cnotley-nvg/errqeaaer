import React from 'react';
import { ColumnLayout, Container, SpaceBetween } from '@amzn/awsui-components-console';

import type { KitDetailData } from '../../../hooks/useKitDetail';
import { MetadataField } from '../../common';
import { PhoneToolLink } from '../../standards/common';
import { formatAttributeValue } from '../../../utils/standardPresenters';
import { formatDateShort } from '../../../utils/formatDate';

interface KitOverviewMetadataProps {
  kit: KitDetailData;
}

export const KitOverviewMetadata: React.FC<KitOverviewMetadataProps> = ({ kit }) => {
  const attributes = kit.latestVersion?.attributes;

  // Extract attribute values - use exact attribute names from seeds
  const region = formatAttributeValue(attributes, 'region') || '—';
  const dataType = formatAttributeValue(attributes, 'dataType') || '—';
  const program = formatAttributeValue(attributes, 'program') || '—';
  const projectType = formatAttributeValue(attributes, 'projectType') || '—';
  const roomFeatureZone = formatAttributeValue(attributes, 'roomFeatureZone') || '—';
  const keyLabel = formatAttributeValue(attributes, 'keyLabel') || '—';

  // Created by - from attributes
  const createdBy = formatAttributeValue(attributes, 'createdBy') || '';

  // Created date - use latestVersion.createdAt or fallback to kit.createdAt
  const createdDate = formatDateShort(kit.latestVersion?.createdAt ?? kit.createdAt) || '—';

  return (
    <Container>
      <SpaceBetween size="l">
        <ColumnLayout columns={4} variant="text-grid">
          {/* Column 1 */}
          <SpaceBetween size="l">
            <MetadataField label="Region">
              <span>{region}</span>
            </MetadataField>

            <MetadataField label="Project type">
              <span>{projectType}</span>
            </MetadataField>
          </SpaceBetween>

          {/* Column 2 */}
          <SpaceBetween size="l">
            <MetadataField label="Data type">
              <span>{dataType}</span>
            </MetadataField>

            <MetadataField label="Room/Feature/Zone">
              <span>{roomFeatureZone}</span>
            </MetadataField>
          </SpaceBetween>

          {/* Column 3 */}
          <SpaceBetween size="l">
            <MetadataField label="Program">
              <span>{program}</span>
            </MetadataField>

            <MetadataField label="Key label">
              <span>{keyLabel}</span>
            </MetadataField>
          </SpaceBetween>

          {/* Column 4 */}
          <SpaceBetween size="l">
            <MetadataField label="Created by">
              <PhoneToolLink username={createdBy} />
            </MetadataField>

            <MetadataField label="Created on">
              <span>{createdDate}</span>
            </MetadataField>
          </SpaceBetween>
        </ColumnLayout>
      </SpaceBetween>
    </Container>
  );
};
