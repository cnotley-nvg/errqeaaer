import React, { useCallback, useMemo } from 'react';
import type { MultiselectProps } from '@amzn/awsui-components-console';

import { KitDetailsForm } from './KitDetailsForm';
import type { KitBuilderSelections } from './hooks/useKitBuilderControls';
import type { KitOptionsResult } from './types';
import {
  createProgramOptions,
  createSelectOptions,
  resolveSelectedOptions,
} from '../shared/selectOptions';

const PROJECT_TYPE_LABELS: Record<string, string> = {
  BTS: 'Build-to-suit (BTS)',
  STS: 'Spec-to-suit (STS)',
};

const createProjectTypeOptions = (
  values: readonly string[]
): ReadonlyArray<MultiselectProps.Option> =>
  values.map((value) => ({
    value,
    label: PROJECT_TYPE_LABELS[value] ?? value,
  }));

interface KitFiltersFormProps {
  kitOptions: KitOptionsResult;
  loadingOptions: boolean;
  kitOptionsLoaded: boolean;
  kitName: string;
  kitDescription: string;
  selections: KitBuilderSelections;
  handlers: {
    onKitNameChange: (value: string) => void;
    onKitDescriptionChange: (value: string) => void;
    onRegionsChange: (values: string[]) => void;
    onProgramsChange: (values: string[]) => void;
    onProjectTypesChange: (values: string[]) => void;
    onRoomFeatureZonesChange: (values: string[]) => void;
    onDataTypesChange: (values: string[]) => void;
  };
}

export const KitFiltersForm: React.FC<KitFiltersFormProps> = ({
  kitOptions,
  loadingOptions,
  kitOptionsLoaded,
  kitName,
  kitDescription,
  selections,
  handlers,
}) => {
  const multiselectStatus: NonNullable<MultiselectProps['statusType']> = loadingOptions
    ? 'loading'
    : 'finished';
  const deselectAriaLabel = useCallback(
    (option: MultiselectProps.Option) => `Remove ${option.label ?? option.value ?? 'option'}`,
    []
  );

  const regionOptions = useMemo(
    () => createSelectOptions(kitOptions.regions),
    [kitOptions.regions]
  );
  const programOptions = useMemo(
    () => createProgramOptions(kitOptions.programs),
    [kitOptions.programs]
  );
  const projectTypeOptions = useMemo(
    () => createProjectTypeOptions(kitOptions.projectTypes),
    [kitOptions.projectTypes]
  );
  const roomFeatureZoneOptions = useMemo(
    () => createSelectOptions(kitOptions.roomFeatureZones),
    [kitOptions.roomFeatureZones]
  );
  const dataTypeOptions = useMemo(
    () => createSelectOptions(kitOptions.dataTypes),
    [kitOptions.dataTypes]
  );

  return (
    <KitDetailsForm
      kitName={kitName}
      kitDescription={kitDescription}
      onKitNameChange={handlers.onKitNameChange}
      onKitDescriptionChange={handlers.onKitDescriptionChange}
      regionOptions={regionOptions}
      selectedRegionOptions={resolveSelectedOptions(selections.regions, regionOptions)}
      onRegionsChange={handlers.onRegionsChange}
      programOptions={programOptions}
      selectedProgramOptions={resolveSelectedOptions(selections.programs, programOptions)}
      onProgramsChange={handlers.onProgramsChange}
      projectTypeOptions={projectTypeOptions}
      selectedProjectTypeOptions={resolveSelectedOptions(
        selections.projectTypes,
        projectTypeOptions
      )}
      onProjectTypesChange={handlers.onProjectTypesChange}
      roomFeatureZoneOptions={roomFeatureZoneOptions}
      selectedRoomFeatureZoneOptions={resolveSelectedOptions(
        selections.roomFeatureZones,
        roomFeatureZoneOptions
      )}
      onRoomFeatureZonesChange={handlers.onRoomFeatureZonesChange}
      dataTypeOptions={dataTypeOptions}
      selectedDataTypeOptions={resolveSelectedOptions(selections.dataTypes, dataTypeOptions)}
      onDataTypesChange={handlers.onDataTypesChange}
      multiselectStatus={multiselectStatus}
      loadingOptions={loadingOptions}
      kitOptionsLoaded={kitOptionsLoaded}
      deselectAriaLabel={deselectAriaLabel}
    />
  );
};
