import React from 'react';

import { BuildKitAlerts } from './BuildKitAlerts';

interface KitAlertsProps {
  creationSuccessMessage: string | null;
  createKitError: string | null;
  kitOptionsError: string | null;
  compatibleStandardsError: string | null;
  onDismissCreationSuccess?: () => void;
}

export const KitAlerts: React.FC<KitAlertsProps> = (props) => <BuildKitAlerts {...props} />;
