import React, { useMemo } from 'react';

import type { KitCompatibleStandard, KitCompatibleStandardsInput } from '../../hooks/useKitBuilder';
import { CompatibleStandardsSection } from './CompatibleStandardsSection';
import { EmptyState } from '../common/EmptyState';

interface CompatibleStandardsListProps {
  filters: KitCompatibleStandardsInput | null;
  standards: ReadonlyArray<KitCompatibleStandard>;
  selectedStandardItems: ReadonlyArray<KitCompatibleStandard>;
  loadingStandards: boolean;
  hasFetchedStandards: boolean;
  onSelectionChange: (selectedItems: ReadonlyArray<KitCompatibleStandard>) => void;
  headerActions?: React.ReactNode;
  isItemDisabled?: (item: KitCompatibleStandard) => boolean;
}

const buildEmptyState = (
  filters: KitCompatibleStandardsInput | null,
  hasFetchedStandards: boolean
) => {
  if (!filters) {
    return (
      <EmptyState
        title="Ready to see your standards?"
        subtitle="Complete the required fields above to discover all compatible components for your custom kit."
      />
    );
  }

  if (!hasFetchedStandards) {
    return (
      <EmptyState
        title="Loading compatible standards"
        subtitle="Fetching standards that match your selections…"
      />
    );
  }

  return (
    <EmptyState
      title="No compatible standards"
      subtitle="Adjust your selections to find matching standards for this kit."
    />
  );
};

export const CompatibleStandardsList: React.FC<CompatibleStandardsListProps> = ({
  filters,
  standards,
  selectedStandardItems,
  loadingStandards,
  hasFetchedStandards,
  onSelectionChange,
  headerActions,
  isItemDisabled,
}) => {
  const emptyState = useMemo(
    () => buildEmptyState(filters, hasFetchedStandards),
    [filters, hasFetchedStandards]
  );

  return (
    <CompatibleStandardsSection
      filters={filters}
      standards={standards}
      selectedStandardItems={selectedStandardItems}
      loadingStandards={loadingStandards}
      emptyState={emptyState}
      onSelectionChange={onSelectionChange}
      headerActions={headerActions}
      isItemDisabled={isItemDisabled}
    />
  );
};
