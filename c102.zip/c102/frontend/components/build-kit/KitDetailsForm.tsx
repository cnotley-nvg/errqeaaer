import React, { useMemo } from 'react';
import {
  Container,
  Form,
  FormField,
  Header,
  Input,
  Multiselect,
  type MultiselectProps,
  SpaceBetween,
} from '@amzn/awsui-components-console';

interface KitDetailsFormProps {
  kitName: string;
  kitDescription: string;
  onKitNameChange: (value: string) => void;
  onKitDescriptionChange: (value: string) => void;
  regionOptions: ReadonlyArray<MultiselectProps.Option>;
  selectedRegionOptions: ReadonlyArray<MultiselectProps.Option>;
  onRegionsChange: (values: string[]) => void;
  programOptions: ReadonlyArray<MultiselectProps.Option>;
  selectedProgramOptions: ReadonlyArray<MultiselectProps.Option>;
  onProgramsChange: (values: string[]) => void;
  projectTypeOptions: ReadonlyArray<MultiselectProps.Option>;
  selectedProjectTypeOptions: ReadonlyArray<MultiselectProps.Option>;
  onProjectTypesChange: (values: string[]) => void;
  roomFeatureZoneOptions: ReadonlyArray<MultiselectProps.Option>;
  selectedRoomFeatureZoneOptions: ReadonlyArray<MultiselectProps.Option>;
  onRoomFeatureZonesChange: (values: string[]) => void;
  dataTypeOptions: ReadonlyArray<MultiselectProps.Option>;
  selectedDataTypeOptions: ReadonlyArray<MultiselectProps.Option>;
  onDataTypesChange: (values: string[]) => void;
  multiselectStatus: NonNullable<MultiselectProps['statusType']>;
  loadingOptions: boolean;
  kitOptionsLoaded: boolean;
  deselectAriaLabel: (option: MultiselectProps.Option) => string;
}

interface MultiselectFieldConfig {
  label: string;
  placeholder: string;
  loadingText: string;
  options: ReadonlyArray<MultiselectProps.Option>;
  selectedOptions: ReadonlyArray<MultiselectProps.Option>;
  onChange: (values: string[]) => void;
}

export const KitDetailsForm: React.FC<KitDetailsFormProps> = ({
  kitName,
  kitDescription,
  onKitNameChange,
  onKitDescriptionChange,
  regionOptions,
  selectedRegionOptions,
  onRegionsChange,
  programOptions,
  selectedProgramOptions,
  onProgramsChange,
  projectTypeOptions,
  selectedProjectTypeOptions,
  onProjectTypesChange,
  roomFeatureZoneOptions,
  selectedRoomFeatureZoneOptions,
  onRoomFeatureZonesChange,
  dataTypeOptions,
  selectedDataTypeOptions,
  onDataTypesChange,
  multiselectStatus,
  loadingOptions,
  kitOptionsLoaded,
  deselectAriaLabel,
}) => {
  const FIELD_MAX_WIDTH = 520;
  const fieldContainerStyle: React.CSSProperties = { maxWidth: FIELD_MAX_WIDTH, width: '100%' };

  const createMultiselectHandler =
    (onChange: (values: string[]) => void) =>
    ({ detail }: { detail: MultiselectProps.MultiselectChangeDetail }) => {
      const values = detail.selectedOptions
        .map((option) => (option.value ?? '').trim())
        .filter((value): value is string => Boolean(value));
      onChange(values);
    };

  const isDisabled = !kitOptionsLoaded && loadingOptions;

  const multiselectFields = useMemo<MultiselectFieldConfig[]>(
    () => [
      {
        label: 'Region *',
        placeholder: 'Where will this kit be used?',
        loadingText: 'Loading regions',
        options: regionOptions,
        selectedOptions: selectedRegionOptions,
        onChange: onRegionsChange,
      },
      {
        label: 'Program',
        placeholder: 'Which program does this kit belong to?',
        loadingText: 'Loading programs',
        options: programOptions,
        selectedOptions: selectedProgramOptions,
        onChange: onProgramsChange,
      },
      {
        label: 'Project type *',
        placeholder: 'What project type is this for?',
        loadingText: 'Loading project types',
        options: projectTypeOptions,
        selectedOptions: selectedProjectTypeOptions,
        onChange: onProjectTypesChange,
      },
      {
        label: 'Room / Feature / Zone',
        placeholder: 'Specify the location or feature type',
        loadingText: 'Loading options',
        options: roomFeatureZoneOptions,
        selectedOptions: selectedRoomFeatureZoneOptions,
        onChange: onRoomFeatureZonesChange,
      },
      {
        label: 'Data type',
        placeholder: 'Choose an option',
        loadingText: 'Loading data types',
        options: dataTypeOptions,
        selectedOptions: selectedDataTypeOptions,
        onChange: onDataTypesChange,
      },
    ],
    [
      dataTypeOptions,
      onDataTypesChange,
      onProgramsChange,
      onRegionsChange,
      onRoomFeatureZonesChange,
      onProjectTypesChange,
      programOptions,
      regionOptions,
      roomFeatureZoneOptions,
      selectedDataTypeOptions,
      selectedProgramOptions,
      selectedRegionOptions,
      selectedRoomFeatureZoneOptions,
      selectedProjectTypeOptions,
      projectTypeOptions,
    ]
  );

  return (
    <Container header={<Header variant="h2">Kit details</Header>}>
      <Form>
        <SpaceBetween size="l">
          <div style={fieldContainerStyle}>
            <FormField label="Kit name *" stretch>
              <Input
                value={kitName}
                onChange={(event) => onKitNameChange(event.detail.value)}
                placeholder="Give your kit a memorable name"
              />
            </FormField>
          </div>

          <div style={fieldContainerStyle}>
            <FormField label="Description" stretch>
              <Input
                value={kitDescription}
                onChange={(event) => onKitDescriptionChange(event.detail.value)}
                placeholder="Tell us what this kit is for"
              />
            </FormField>
          </div>

          <SpaceBetween size="l">
            {multiselectFields.map((field) => (
              <div key={field.label} style={fieldContainerStyle}>
                <FormField label={field.label} stretch>
                  <Multiselect
                    disabled={isDisabled}
                    statusType={multiselectStatus}
                    loadingText={field.loadingText}
                    placeholder={field.placeholder}
                    options={field.options}
                    selectedOptions={field.selectedOptions}
                    deselectAriaLabel={deselectAriaLabel}
                    selectedAriaLabel="Selected"
                    onChange={createMultiselectHandler(field.onChange)}
                  />
                </FormField>
              </div>
            ))}
          </SpaceBetween>
        </SpaceBetween>
      </Form>
    </Container>
  );
};
