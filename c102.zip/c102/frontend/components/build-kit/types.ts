import type { KitOptionsData } from '../../hooks/useKitBuilder';

export type KitOptionsResult = KitOptionsData;
