import React from 'react';
import { Cards, Header } from '@amzn/awsui-components-console';

import type { KitCompatibleStandard, KitCompatibleStandardsInput } from '../../hooks/useKitBuilder';
import { STANDARD_CARDS_BREAKPOINTS } from './constants';
import { useLinkedStandardSummaryCardDefinition } from '../common/StandardSummaryCard';
import { SectionWithFooter } from '../common/SectionWithFooter';

interface CompatibleStandardsSectionProps {
  filters: KitCompatibleStandardsInput | null;
  standards: ReadonlyArray<KitCompatibleStandard>;
  selectedStandardItems: ReadonlyArray<KitCompatibleStandard>;
  loadingStandards: boolean;
  emptyState: React.ReactNode;
  onSelectionChange: (selectedItems: ReadonlyArray<KitCompatibleStandard>) => void;
  headerActions?: React.ReactNode;
  footerActions?: React.ReactNode;
  isItemDisabled?: (item: KitCompatibleStandard) => boolean;
}

export const CompatibleStandardsSection: React.FC<CompatibleStandardsSectionProps> = ({
  filters,
  standards,
  selectedStandardItems,
  loadingStandards,
  emptyState,
  onSelectionChange,
  headerActions,
  footerActions,
  isItemDisabled,
}) => {
  const cardDefinition = useLinkedStandardSummaryCardDefinition<KitCompatibleStandard>({
    getStandardId: (item) => item.standardId,
    getStandardName: (item) => item.standardName,
    getRegion: (item) => item.region,
    getProjectType: (item) => item.projectType ?? item.useCase ?? item.dataType ?? '—',
    getProgram: (item) => item.program ?? '—',
  });

  return (
    <SectionWithFooter
      header={
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <div style={{ flex: 1, minWidth: 0, overflow: 'hidden' }}>
            <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              <Header variant="h2">
                {`Compatible standards${standards.length ? ` (${standards.length})` : ''}`}
              </Header>
            </div>
          </div>
          {headerActions ? <div style={{ flex: '0 0 auto' }}>{headerActions}</div> : null}
        </div>
      }
      footerActions={footerActions}
    >
      <Cards
        trackBy="id"
        selectionType="multi"
        items={filters ? standards : []}
        selectedItems={selectedStandardItems}
        onSelectionChange={({ detail }) => onSelectionChange(detail.selectedItems)}
        isItemDisabled={isItemDisabled}
        cardDefinition={cardDefinition}
        loading={loadingStandards && Boolean(filters)}
        loadingText="Loading compatible standards"
        cardsPerRow={STANDARD_CARDS_BREAKPOINTS}
        empty={emptyState}
      />
    </SectionWithFooter>
  );
};
