import React from 'react';
import { Alert } from '@amzn/awsui-components-console';

interface BuildKitAlertsProps {
  creationSuccessMessage?: string | null;
  createKitError?: string | null;
  kitOptionsError?: string | null;
  compatibleStandardsError?: string | null;
  onDismissCreationSuccess?: () => void;
}

export const BuildKitAlerts: React.FC<BuildKitAlertsProps> = ({
  creationSuccessMessage,
  createKitError,
  kitOptionsError,
  compatibleStandardsError,
  onDismissCreationSuccess,
}) => (
  <>
    {creationSuccessMessage && (
      <Alert
        type="success"
        header="Kit created"
        dismissible={Boolean(onDismissCreationSuccess)}
        onDismiss={onDismissCreationSuccess}
      >
        {creationSuccessMessage}
      </Alert>
    )}

    {createKitError && (
      <Alert type="error" header="Unable to create kit">
        {createKitError}
      </Alert>
    )}

    {kitOptionsError && (
      <Alert type="error" header="Unable to load kit options">
        {kitOptionsError}
      </Alert>
    )}

    {compatibleStandardsError && (
      <Alert type="error" header="Unable to load compatible standards">
        {compatibleStandardsError}
      </Alert>
    )}
  </>
);
