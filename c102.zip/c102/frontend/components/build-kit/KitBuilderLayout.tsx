import React, { useMemo } from 'react';
import { Link, SpaceBetween, type BreadcrumbGroupProps } from '@amzn/awsui-components-console';

import { PageLayout } from '../../components/PageLayout';

interface KitBuilderLayoutProps {
  headerActions: React.ReactNode;
  children: React.ReactNode;
}

const BREADCRUMBS: BreadcrumbGroupProps.Item[] = [
  { text: 'Home', href: '/' },
  { text: 'Build a kit', href: '/build-kit' },
];

export const KitBuilderLayout: React.FC<KitBuilderLayoutProps> = ({ headerActions, children }) => {
  const header = useMemo(
    () => ({
      title: 'Build your custom kit',
      description:
        "Let's create your personalized kit! Fill out the details below and we'll show you all compatible parts.",
      actions: headerActions,
    }),
    [headerActions]
  );

  return (
    <PageLayout breadcrumbs={BREADCRUMBS} header={header}>
      <SpaceBetween size="xl">{children}</SpaceBetween>
    </PageLayout>
  );
};
