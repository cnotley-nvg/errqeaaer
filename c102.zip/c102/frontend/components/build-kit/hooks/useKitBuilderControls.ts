import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

interface UseKitBuilderControlsOptions {
  onInteraction?: () => void;
}

export interface KitBuilderSelections {
  regions: string[];
  programs: string[];
  projectTypes: string[];
  roomFeatureZones: string[];
  dataTypes: string[];
}

export const useKitBuilderControls = ({ onInteraction }: UseKitBuilderControlsOptions = {}) => {
  const interactionRef = useRef(onInteraction);

  useEffect(() => {
    interactionRef.current = onInteraction;
  }, [onInteraction]);

  const notifyInteraction = useCallback(() => {
    interactionRef.current?.();
  }, []);

  const [kitName, setKitName] = useState('');
  const [kitDescription, setKitDescription] = useState('');
  const [selectedRegions, setSelectedRegions] = useState<string[]>([]);
  const [selectedPrograms, setSelectedPrograms] = useState<string[]>([]);
  const [selectedProjectTypes, setSelectedProjectTypes] = useState<string[]>([]);
  const [selectedRoomFeatureZones, setSelectedRoomFeatureZones] = useState<string[]>([]);
  const [selectedDataTypes, setSelectedDataTypes] = useState<string[]>([]);

  const handleKitNameChange = useCallback(
    (value: string) => {
      setKitName(value);
      notifyInteraction();
    },
    [notifyInteraction]
  );

  const handleKitDescriptionChange = useCallback(
    (value: string) => {
      setKitDescription(value);
      notifyInteraction();
    },
    [notifyInteraction]
  );

  const handleRegionsChange = useCallback(
    (values: string[]) => {
      setSelectedRegions(values);
      notifyInteraction();
    },
    [notifyInteraction]
  );

  const handleProgramsChange = useCallback(
    (values: string[]) => {
      setSelectedPrograms(values);
      notifyInteraction();
    },
    [notifyInteraction]
  );

  const handleProjectTypesChange = useCallback(
    (values: string[]) => {
      setSelectedProjectTypes(values);
      notifyInteraction();
    },
    [notifyInteraction]
  );

  const handleRoomFeatureZonesChange = useCallback(
    (values: string[]) => {
      setSelectedRoomFeatureZones(values);
      notifyInteraction();
    },
    [notifyInteraction]
  );

  const handleDataTypesChange = useCallback(
    (values: string[]) => {
      setSelectedDataTypes(values);
      notifyInteraction();
    },
    [notifyInteraction]
  );

  const resetSelections = useCallback(() => {
    setSelectedRegions([]);
    setSelectedPrograms([]);
    setSelectedProjectTypes([]);
    setSelectedRoomFeatureZones([]);
    setSelectedDataTypes([]);
  }, []);

  const resetForm = useCallback(
    (options?: { preserveAlerts?: boolean }) => {
      setKitName('');
      setKitDescription('');
      resetSelections();

      if (!options?.preserveAlerts) {
        notifyInteraction();
      }
    },
    [notifyInteraction, resetSelections]
  );

  const selections: KitBuilderSelections = useMemo(
    () => ({
      regions: selectedRegions,
      programs: selectedPrograms,
      projectTypes: selectedProjectTypes,
      roomFeatureZones: selectedRoomFeatureZones,
      dataTypes: selectedDataTypes,
    }),
    [
      selectedDataTypes,
      selectedPrograms,
      selectedRegions,
      selectedRoomFeatureZones,
      selectedProjectTypes,
    ]
  );

  const isFormPristine = useMemo(
    () =>
      !selectedRegions.length &&
      !selectedPrograms.length &&
      !selectedProjectTypes.length &&
      !selectedRoomFeatureZones.length &&
      !selectedDataTypes.length,
    [
      selectedDataTypes.length,
      selectedPrograms.length,
      selectedRegions.length,
      selectedRoomFeatureZones.length,
      selectedProjectTypes.length,
    ]
  );

  return {
    kitName,
    kitDescription,
    selections,
    handlers: {
      onKitNameChange: handleKitNameChange,
      onKitDescriptionChange: handleKitDescriptionChange,
      onRegionsChange: handleRegionsChange,
      onProgramsChange: handleProgramsChange,
      onProjectTypesChange: handleProjectTypesChange,
      onRoomFeatureZonesChange: handleRoomFeatureZonesChange,
      onDataTypesChange: handleDataTypesChange,
    },
    resetSelections,
    resetForm,
    isFormPristine,
  };
};
