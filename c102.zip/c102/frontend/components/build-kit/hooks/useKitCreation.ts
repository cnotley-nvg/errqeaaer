import { useCallback, useEffect } from 'react';

import type { CreateKitFormInput } from '../../../hooks/useKitBuilder';
import { useCreateKit } from '../../../hooks/useKitBuilder';
import { useFeedback } from '../../shared/hooks/useFeedback';
import { useAnalytics } from '../../../hooks/useAnalytics';

export const useKitCreation = () => {
  const { createKit, loading, error, reset } = useCreateKit();
  const { feedback, showError, clearFeedback: clearLocalFeedback } = useFeedback();
  const { trackKitCreated, trackError } = useAnalytics();

  const handleCreateKit = useCallback(
    async (payload: CreateKitFormInput) => {
      try {
        const created = await createKit(payload);

        if (created) {
          trackKitCreated({
            kitId: created.id,
            kitName: created.name,
            standardCount: payload.standardVersionIds.length,
            regions: [payload.region],
          });
        }

        return created;
      } catch (err) {
        trackError({
          errorType: 'KIT_CREATION_FAILED',
          errorMessage: err instanceof Error ? err.message : 'Unknown error',
          context: 'useKitCreation.handleCreateKit',
        });
        throw err;
      }
    },
    [createKit, trackKitCreated, trackError]
  );

  useEffect(() => {
    if (!error) {
      return;
    }

    showError(error);
  }, [error, showError]);

  const clearFeedback = useCallback(() => {
    clearLocalFeedback();
    reset();
  }, [clearLocalFeedback, reset]);

  return {
    handleCreateKit,
    creatingKit: loading,
    feedback,
    clearFeedback,
  } as const;
};
