import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import type {
  KitCompatibleStandard,
  KitCompatibleStandardsInput,
} from '../../../hooks/useKitBuilder';
import { normalizeSelections } from '../../shared/selectOptions';
import type { KitBuilderSelections } from './useKitBuilderControls';

interface UseKitFiltersOptions {
  selections: KitBuilderSelections;
  onInteraction?: () => void;
}

interface UseKitFiltersReturn {
  filters: KitCompatibleStandardsInput | null;
  normalizedSelections: KitBuilderSelections;
  selectedStandardIds: string[];
  selectedStandardItems: ReadonlyArray<KitCompatibleStandard>;
  handleSelectionChange: (selectedItems: ReadonlyArray<KitCompatibleStandard>) => void;
  resetSelectedStandards: (options?: { suppressInteraction?: boolean }) => void;
  registerStandards: (
    standards: ReadonlyArray<KitCompatibleStandard>,
    options?: {
      lockedStandardIds?: ReadonlyArray<string>;
      defaultSelectIds?: ReadonlyArray<string>;
    }
  ) => void;
}

const buildFilters = (
  selections: KitBuilderSelections
): [KitCompatibleStandardsInput | null, KitBuilderSelections] => {
  const normalized: KitBuilderSelections = {
    regions: normalizeSelections(selections.regions),
    programs: normalizeSelections(selections.programs),
    projectTypes: normalizeSelections(selections.projectTypes),
    roomFeatureZones: normalizeSelections(selections.roomFeatureZones),
    dataTypes: normalizeSelections(selections.dataTypes),
  };

  const payload: KitCompatibleStandardsInput = {};

  if (normalized.regions.length) {
    payload.regions = normalized.regions;
  }
  if (normalized.programs.length) {
    payload.programs = normalized.programs;
  }
  if (normalized.projectTypes.length) {
    payload.projectTypes = normalized.projectTypes;
  }
  if (normalized.roomFeatureZones.length) {
    payload.roomFeatureZones = normalized.roomFeatureZones;
  }
  if (normalized.dataTypes.length) {
    payload.dataTypes = normalized.dataTypes;
  }

  const filters = Object.keys(payload).length ? payload : null;

  return [filters, normalized];
};

export const useKitFilters = ({
  selections,
  onInteraction,
}: UseKitFiltersOptions): UseKitFiltersReturn => {
  const interactionRef = useRef(onInteraction);
  const standardsRef = useRef<ReadonlyArray<KitCompatibleStandard>>([]);
  const lockedStandardIdsRef = useRef<ReadonlyArray<string>>([]);
  const knownStandardIdsRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    interactionRef.current = onInteraction;
  }, [onInteraction]);

  const [selectedStandardIds, setSelectedStandardIds] = useState<string[]>([]);

  const [filters, normalizedSelections] = useMemo(() => buildFilters(selections), [selections]);

  const previousFiltersRef = useRef<string | null>(null);
  useEffect(() => {
    const nextHash = filters ? JSON.stringify(filters) : null;
    if (
      previousFiltersRef.current &&
      nextHash !== previousFiltersRef.current &&
      selectedStandardIds.length
    ) {
      setSelectedStandardIds([]);

      knownStandardIdsRef.current = new Set();
      interactionRef.current?.();
    }
    previousFiltersRef.current = nextHash;
  }, [filters, selectedStandardIds.length]);

  const registerStandards = useCallback(
    (
      standards: ReadonlyArray<KitCompatibleStandard>,
      options?: {
        lockedStandardIds?: ReadonlyArray<string>;
        defaultSelectIds?: ReadonlyArray<string>;
      }
    ) => {
      standardsRef.current = standards;
      const lockedIds = options?.lockedStandardIds ?? [];
      lockedStandardIdsRef.current = lockedIds;

      const nextKnown = knownStandardIdsRef.current;
      const nextIdSet = new Set(standards.map((standard) => standard.id));
      for (const id of Array.from(nextKnown)) {
        if (!nextIdSet.has(id)) {
          nextKnown.delete(id);
        }
      }
      const newlySeen: string[] = [];
      for (const id of nextIdSet) {
        if (!nextKnown.has(id)) {
          newlySeen.push(id);
          nextKnown.add(id);
        }
      }

      const defaultSelectIds = options?.defaultSelectIds ?? newlySeen;

      setSelectedStandardIds((previous) => {
        const previousInScope = previous.filter((id) => nextIdSet.has(id));
        const next = new Set<string>([...previousInScope, ...lockedIds, ...defaultSelectIds]);
        return Array.from(next);
      });
    },
    []
  );

  const handleSelectionChange = useCallback(
    (selectedItems: ReadonlyArray<KitCompatibleStandard>) => {
      const selectedIds = new Set<string>(selectedItems.map((item) => item.id));
      lockedStandardIdsRef.current.forEach((id) => selectedIds.add(id));
      setSelectedStandardIds(Array.from(selectedIds));
      interactionRef.current?.();
    },
    []
  );

  const resetSelectedStandards = useCallback((options?: { suppressInteraction?: boolean }) => {
    setSelectedStandardIds([...lockedStandardIdsRef.current]);
    if (!options?.suppressInteraction) {
      interactionRef.current?.();
    }
  }, []);

  const selectedStandardItems = useMemo(
    () =>
      selectedStandardIds
        .map((id) => standardsRef.current.find((standard) => standard.id === id) ?? null)
        .filter((standard): standard is KitCompatibleStandard => Boolean(standard)),
    [selectedStandardIds]
  );

  return {
    filters,
    normalizedSelections,
    selectedStandardIds,
    selectedStandardItems,
    handleSelectionChange,
    resetSelectedStandards,
    registerStandards,
  };
};
