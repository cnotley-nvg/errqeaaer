import React from 'react';
import { Button, SpaceBetween, type SpaceBetweenProps } from '@amzn/awsui-components-console';

interface BuildKitActionButtonsProps {
  onCreate: () => void;
  onResetFilters: () => void;
  isResetDisabled?: boolean;
  isCreateDisabled: boolean;
  creatingKit: boolean;
  size?: SpaceBetweenProps['size'];
  alignItems?: SpaceBetweenProps['alignItems'];
}

export const BuildKitActionButtons: React.FC<BuildKitActionButtonsProps> = ({
  onCreate,
  onResetFilters,
  isResetDisabled = false,
  isCreateDisabled,
  creatingKit,
  size = 's',
  alignItems = 'center',
}) => (
  <SpaceBetween direction="horizontal" size={size} alignItems={alignItems}>
    <Button variant="normal" onClick={onResetFilters} disabled={isResetDisabled}>
      Clear All
    </Button>
    <Button variant="primary" onClick={onCreate} disabled={isCreateDisabled} loading={creatingKit}>
      Create kit
    </Button>
  </SpaceBetween>
);
