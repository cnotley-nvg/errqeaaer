import React from 'react';

import { BuildKitActionButtons } from './BuildKitActionButtons';

interface KitActionBarProps {
  onCreate: () => void;
  onResetFilters: () => void;
  isResetDisabled: boolean;
  isCreateDisabled: boolean;
  creatingKit: boolean;
}

export const KitActionBar: React.FC<KitActionBarProps> = (props) => (
  <BuildKitActionButtons {...props} />
);
