import React from 'react';
import { Box } from '@amzn/awsui-components-console';

interface KitFooterProps {
  children: React.ReactNode;
}

export const KitFooter: React.FC<KitFooterProps> = ({ children }) => (
  <Box textAlign="right">
    <Box display="inline-block">{children}</Box>
  </Box>
);
