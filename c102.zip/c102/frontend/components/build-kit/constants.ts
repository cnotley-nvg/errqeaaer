import type { CardsProps } from '@amzn/awsui-components-console';

import { createStandardSummaryCardDefinition } from '../standards/catalog/StandardSummaryCard';
import type { KitCompatibleStandard } from '../../hooks/useKitBuilder';

export const STANDARD_CARD_DEFINITION = createStandardSummaryCardDefinition<KitCompatibleStandard>({
  header: (item) => item.standardName,
  getRegion: (item) => item.region,
  getProjectType: (item) => item.projectType,
  getProgram: (item) => item.program,
});

export const STANDARD_CARDS_BREAKPOINTS: CardsProps['cardsPerRow'] = [
  { cards: 1 },
  { minWidth: 700, cards: 2 },
  { minWidth: 1100, cards: 3 },
];
