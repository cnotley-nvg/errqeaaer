import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Button, Cards, Modal, SpaceBetween } from '@amzn/awsui-components-console';

import type { KitCompatibleStandard } from '../../hooks/useKitBuilder';
import { useLinkedStandardSummaryCardDefinition } from '../common/StandardSummaryCard';
import { EmptyState } from '../common/EmptyState';
import { STANDARD_CARDS_BREAKPOINTS } from './constants';

export interface AdditionalStandardsModalProps {
  visible: boolean;
  onDismiss: () => void;
  regionLabel: string;

  modalStandards: ReadonlyArray<KitCompatibleStandard>;

  initialSelected: ReadonlyArray<KitCompatibleStandard>;

  onAdd: (newlySelected: ReadonlyArray<KitCompatibleStandard>) => void;

  isItemDisabled?: (item: KitCompatibleStandard) => boolean;

  loading?: boolean;
  error?: string | null;
}

const MODAL_WRAPPER_STYLE: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  height: 720,
  maxHeight: '80vh',
};
const MODAL_BODY_STYLE: React.CSSProperties = {
  padding: 20,
  flex: 1,
  minHeight: 0,
  display: 'flex',
  flexDirection: 'column',
  boxSizing: 'border-box',
};
const MODAL_SCROLL_STYLE: React.CSSProperties = {
  height: '100%',
  overflowY: 'auto',
  paddingBottom: 20,
};
const FOOTER_BAR_STYLE: React.CSSProperties = {
  height: 56,
  borderTop: '1px solid var(--color-border-divider-default)',
  display: 'flex',
  justifyContent: 'flex-end',
  alignItems: 'center',
  padding: '0 20px',
  boxSizing: 'border-box',
};

const ADDITIONAL_CARDS_BREAKPOINTS: typeof STANDARD_CARDS_BREAKPOINTS = [
  { cards: 2 },
  { minWidth: 960, cards: 3 },
];

export const AdditionalStandardsModal: React.FC<AdditionalStandardsModalProps> = ({
  visible,
  onDismiss,
  regionLabel: _regionLabel,
  modalStandards,
  initialSelected,
  onAdd,
  isItemDisabled,
  loading,
  error,
}) => {
  const [selected, setSelected] = useState<ReadonlyArray<KitCompatibleStandard>>([]);

  useEffect(() => {
    if (visible) {
      setSelected(initialSelected);
    }
  }, [visible, initialSelected]);

  const handleConfirm = useCallback(() => {
    onAdd(selected);
  }, [onAdd, selected]);

  const baseCardDefinition = useLinkedStandardSummaryCardDefinition<KitCompatibleStandard>({
    getStandardId: (item) => item.standardId,
    getStandardName: (item) => item.standardName,
    getRegion: (item) => item.region,
    getProjectType: (item) => item.projectType ?? item.useCase ?? item.dataType ?? '—',
    getProgram: (item) => item.program ?? '—',
  });
  const hasSelection = useMemo(() => selected.length > 0, [selected.length]);

  return (
    <Modal
      size="max"
      visible={visible}
      onDismiss={onDismiss}
      disableContentPaddings
      header="Add additional standards"
    >
      <div style={MODAL_WRAPPER_STYLE}>
        <div style={MODAL_BODY_STYLE}>
          <div style={{ flex: 1, minHeight: 0 }}>
            {error ? (
              <div
                style={{
                  marginBottom: 12,
                  color: 'var(--color-text-status-error)',
                  fontWeight: 500,
                }}
              >
                {error}
              </div>
            ) : null}
            <div style={MODAL_SCROLL_STYLE}>
              <Cards
                trackBy="id"
                selectionType="multi"
                items={modalStandards}
                selectedItems={selected}
                isItemDisabled={isItemDisabled}
                onSelectionChange={({ detail }) => setSelected(detail.selectedItems)}
                cardDefinition={baseCardDefinition}
                loading={Boolean(loading)}
                loadingText="Loading additional standards"
                cardsPerRow={ADDITIONAL_CARDS_BREAKPOINTS}
                empty={
                  <EmptyState
                    title="No additional standards"
                    subtitle="All standards for this region are already compatible with your current selections."
                  />
                }
              />
            </div>
          </div>
        </div>

        <div style={FOOTER_BAR_STYLE}>
          <SpaceBetween direction="horizontal" size="xs" alignItems="center">
            <Button variant="normal" onClick={onDismiss}>
              Cancel
            </Button>
            <Button
              variant="primary"
              onClick={handleConfirm}
              disabled={Boolean(loading) || !hasSelection}
            >
              Add standards
            </Button>
          </SpaceBetween>
        </div>
      </div>
    </Modal>
  );
};
