import { useState, useEffect, useRef } from 'react';
import { Map } from '@amzn/global-realty-mosaic-arcgis-client';
import type { MarkerConfig } from '@amzn/global-realty-mosaic-arcgis-client';
import { geocodeAddress, reverseGeocodeCoordinates } from '../../api/locationServices';
import type { GeocodeResult } from '../../api/locationServices';
import '@arcgis/core/assets/esri/themes/light/main.css';

type Props = {
  address: string;
  zipcode: string;
  latitude?: string;
  longitude?: string;
  onAddressUpdate?: (address: string, city: string, zipcode: string, country: string) => void;
  onCoordinatesUpdate?: (latitude: number, longitude: number) => void;
  onMapClick?: (latitude: number, longitude: number) => void;
};

export const LocationMap = ({
  address,
  zipcode,
  latitude,
  longitude,
  onAddressUpdate,
  onCoordinatesUpdate,
  onMapClick,
}: Props) => {
  const [markers, setMarkers] = useState<MarkerConfig[]>([]);
  const lastGeocodedAddress = useRef<string>('');
  const lastGeocodedCoords = useRef<string>('');

  useEffect(() => {
    if (latitude && longitude) {
      const lat = parseFloat(latitude);
      const lng = parseFloat(longitude);
      const coordsKey = `${latitude},${longitude}`;

      if (!isNaN(lat) && !isNaN(lng)) {
        setMarkers([
          {
            longitude: lng,
            latitude: lat,
            color: [226, 119, 40],
            outlineColor: [255, 255, 255],
            outlineWidth: 2,
          },
        ]);

        if (onAddressUpdate && lastGeocodedCoords.current !== coordsKey) {
          lastGeocodedCoords.current = coordsKey;
          reverseGeocodeCoordinates(lat, lng).then((result: GeocodeResult | null) => {
            if (result) {
              onAddressUpdate(
                result.address || '',
                result.city || '',
                result.zipcode || '',
                result.country || ''
              );
            }
          });
        }
      } else {
        setMarkers([]);
      }
    } else if (address && zipcode) {
      const addressKey = `${address},${zipcode}`;

      if (lastGeocodedAddress.current !== addressKey) {
        lastGeocodedAddress.current = addressKey;
        geocodeAddress(address, zipcode).then((result: GeocodeResult | null) => {
          if (result) {
            setMarkers([
              {
                longitude: result.longitude,
                latitude: result.latitude,
                color: [226, 119, 40],
                outlineColor: [255, 255, 255],
                outlineWidth: 2,
              },
            ]);

            if (onCoordinatesUpdate) {
              onCoordinatesUpdate(result.latitude, result.longitude);
            }
          } else {
            setMarkers([]);
          }
        });
      }
    } else {
      setMarkers([]);
    }
  }, [address, zipcode, latitude, longitude, onAddressUpdate, onCoordinatesUpdate]);

  const config =
    markers.length > 0
      ? { center: [markers[0].longitude, markers[0].latitude] as [number, number] }
      : undefined;

  return (
    <div style={{ height: '100%', minHeight: '700px', display: 'flex', flexDirection: 'column' }}>
      <div style={{ flex: 1, borderRadius: '0 15px 15px 0', overflow: 'hidden' }}>
        <Map markers={markers} config={config} onClick={onMapClick} />
      </div>
    </div>
  );
};
