import {
  Container,
  Header,
  Button,
  ColumnLayout,
  Box,
  StatusIndicator,
  Alert,
} from '@amzn/awsui-components-console';
import { downloadLightningProtectionReport } from '../../utils/analysisReportGenerator';
import type { ElectricalCalculatorResult } from '../../api/electricalBenchmark';
import type { HeatIndexResult } from '../../api/lightningProtection';

export type AnalysisResult = {
  title: string;
  description: string;
  riskLevel?: string;
  costImpact?: string;
  timelineImpact?: string;
  project?: string;
  reportId?: string;
  recommendation:
    | 'required'
    | 'not-required'
    | 'not-recommended'
    | 'optional'
    | 'recommended'
    | 'not-provided';
  error?: boolean;
  downloadable?: boolean;
  guidelineUrl?: string;
  electricalData?: ElectricalCalculatorResult;
  state?: string | null;
  heatIndexData?: HeatIndexResult;
  templateVersionId?: string;
};

type AnalysisResultCardProps = {
  analysis: AnalysisResult;
};

export const AnalysisResultCard = ({ analysis }: AnalysisResultCardProps) => {
  const handleDownload = () => {
    if (analysis.title === 'Lightning Protection') {
      downloadLightningProtectionReport({
        recommendation: analysis.recommendation,
        riskLevel: analysis.riskLevel,
        costImpact: analysis.costImpact,
        timelineImpact: analysis.timelineImpact,
        project: analysis.project,
        reportId: analysis.reportId,
      });
    } else if (analysis.title === 'Mechanical/Heat index') {
      if (!analysis.heatIndexData) {
        console.error('ERROR: heatIndexData is missing!');
        return;
      }
      downloadLightningProtectionReport({
        recommendation: analysis.recommendation,
        heatIndexData: analysis.heatIndexData,
      });
    } else {
    }
  };

  const handleGuidelineClick = () => {
    if (analysis.guidelineUrl) {
      window.open(analysis.guidelineUrl, '_blank');
    }
  };

  if (analysis.error) {
    return (
      <Container fitHeight header={<Header variant="h2">{analysis.title}</Header>}>
        <Alert type="info">{analysis.description}</Alert>
      </Container>
    );
  }

  return (
    <Container
      fitHeight
      header={
        <Header
          variant="h2"
          description={analysis.description}
          actions={
            analysis.downloadable ? (
              <Button iconName="download" onClick={handleDownload}>
                Download
              </Button>
            ) : undefined
          }
        >
          {analysis.title}
        </Header>
      }
    >
      <ColumnLayout columns={2} variant="text-grid">
        {analysis.riskLevel !== undefined && (
          <div>
            <Box variant="awsui-key-label">Risk level</Box>
            <div>{analysis.riskLevel}</div>
          </div>
        )}
        {analysis.costImpact !== undefined && (
          <div>
            <Box variant="awsui-key-label">Cost impact</Box>
            <div>{analysis.costImpact}</div>
          </div>
        )}
        {analysis.timelineImpact !== undefined && (
          <div>
            <Box variant="awsui-key-label">Timeline impact</Box>
            <div>{analysis.timelineImpact}</div>
          </div>
        )}
        {analysis.project !== undefined && (
          <div>
            <Box variant="awsui-key-label">Project</Box>
            <div>{analysis.project}</div>
          </div>
        )}
        {analysis.reportId !== undefined && (
          <div>
            <Box variant="awsui-key-label">Report ID</Box>
            <div>{analysis.reportId}</div>
          </div>
        )}
        <div>
          <Box variant="awsui-key-label">Recommendation</Box>
          <div>
            {analysis.recommendation === 'required' && (
              <StatusIndicator type="warning">ACLW Design Guideline Required</StatusIndicator>
            )}
            {analysis.recommendation === 'not-required' && (
              <StatusIndicator type="success">ACLW Design Guideline NOT Required</StatusIndicator>
            )}
            {analysis.recommendation === 'not-recommended' && (
              <StatusIndicator type="error">Not recommended</StatusIndicator>
            )}
            {analysis.recommendation === 'optional' && (
              <StatusIndicator type="info">Optional</StatusIndicator>
            )}
            {analysis.recommendation === 'not-provided' && (
              <StatusIndicator type="info">Not Provided</StatusIndicator>
            )}
          </div>
        </div>
        {analysis.guidelineUrl && (
          <div>
            <Box variant="awsui-key-label">Guideline</Box>
            <div>
              <Button variant="inline-link" onClick={handleGuidelineClick}>
                View ACLW Design Guideline
              </Button>
            </div>
          </div>
        )}
      </ColumnLayout>
    </Container>
  );
};
