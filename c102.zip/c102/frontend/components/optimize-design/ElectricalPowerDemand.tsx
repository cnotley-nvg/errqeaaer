import { useMemo, useState, useEffect, useRef } from 'react';
import {
  Table,
  Box,
  Alert,
  SpaceBetween,
  Container,
  Header,
  Input,
  Icon,
  ColumnLayout,
  Link,
} from '@amzn/awsui-components-console';
import type { ElectricalCalculatorResult } from '../../api/electricalBenchmark';

type ElectricalPowerDemandProps = {
  result: ElectricalCalculatorResult | null;
  error?: string;
  editable?: boolean;
  onEditComplete?: (
    categoryIndex: number,
    field: 'connectedLoadKVA' | 'demandDiversityFactor' | 'utilityDemandFactor',
    newValue: number
  ) => Promise<void>;
  roofFactor?: number;
  solarPowerDensity?: number;
  templateVersionId?: string;
};

// CSS for flash animation and hiding header edit icons
const flashAnimation = `
  @keyframes cellFlash {
    0% { background-color: rgba(0, 123, 255, 0.3); }
    100% { background-color: transparent; }
  }
  .cell-flash {
    animation: cellFlash 1s ease-out;
  }
  /* Hide the pencil edit icons in table headers to keep headers compact */
  [class*="awsui_header-cell_"] [class*="awsui_edit-icon_"] {
    display: none !important;
  }
`;

const formatNumber = (value: number, decimals = 0): string => {
  return value.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
};

const formatPercentage = (value: number): string => {
  return `${Math.round(value * 100)}%`;
};

// Reusable component for table headers with inline edit icon
type EditableTableHeaderProps = {
  line1: string;
  line2?: string;
  showEditIcon?: boolean;
  align?: 'left' | 'right' | 'center';
};

const EditableTableHeader = ({
  line1,
  line2,
  showEditIcon = false,
  align = 'right',
}: EditableTableHeaderProps) => {
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent:
          align === 'right' ? 'flex-end' : align === 'center' ? 'center' : 'flex-start',
        gap: '8px',
      }}
    >
      <div style={{ textAlign: align, textWrap: 'nowrap' }}>
        {line1}
        {line2 && <div>{line2}</div>}
      </div>
      {showEditIcon && <Icon name="edit" size="small" variant="subtle" />}
    </div>
  );
};

export const ElectricalPowerDemand = ({
  result,
  error,
  editable = false,
  onEditComplete,
  roofFactor,
  solarPowerDensity,
  templateVersionId,
}: ElectricalPowerDemandProps) => {
  // Track previous result to detect changes
  const prevResultRef = useRef<ElectricalCalculatorResult | null>(null);
  const [changedCells, setChangedCells] = useState<Set<string>>(new Set());

  // Detect changes when result updates by comparing actual values
  useEffect(() => {
    if (!result || !prevResultRef.current) {
      prevResultRef.current = result;
      return;
    }

    const prev = prevResultRef.current;
    const newChangedCells = new Set<string>();

    // Compare category loads - check each individual cell value
    result.categoryLoads.forEach((load, index) => {
      const prevLoad = prev.categoryLoads[index];
      if (!prevLoad) return;

      // Compare each cell value individually
      if (load.connectedLoad.kVA !== prevLoad.connectedLoad.kVA) {
        newChangedCells.add(`${index}-connectedLoadKVA`);
      }
      if (load.connectedLoad.amps !== prevLoad.connectedLoad.amps) {
        newChangedCells.add(`${index}-connectedLoadAmps`);
      }
      if (load.demandDiversityFactor !== prevLoad.demandDiversityFactor) {
        newChangedCells.add(`${index}-demandDiversityFactor`);
      }
      if (load.diversifiedLoad.kVA !== prevLoad.diversifiedLoad.kVA) {
        newChangedCells.add(`${index}-diversifiedLoadKVA`);
      }
      if (load.diversifiedLoad.amps !== prevLoad.diversifiedLoad.amps) {
        newChangedCells.add(`${index}-diversifiedLoadAmps`);
      }
      if (load.utilityDemandFactor !== prevLoad.utilityDemandFactor) {
        newChangedCells.add(`${index}-utilityDemandFactor`);
      }
      if (load.utilityPowerDemand.kVA !== prevLoad.utilityPowerDemand.kVA) {
        newChangedCells.add(`${index}-utilityPowerDemandKVA`);
      }
      if (load.utilityPowerDemand.amps !== prevLoad.utilityPowerDemand.amps) {
        newChangedCells.add(`${index}-utilityPowerDemandAmps`);
      }
    });

    // Compare totals - check each cell individually
    if (result.total.connectedLoad.kVA !== prev.total.connectedLoad.kVA) {
      newChangedCells.add('total-connectedLoadKVA');
    }
    if (result.total.connectedLoad.amps !== prev.total.connectedLoad.amps) {
      newChangedCells.add('total-connectedLoadAmps');
    }
    if (result.total.diversifiedLoad.kVA !== prev.total.diversifiedLoad.kVA) {
      newChangedCells.add('total-diversifiedLoadKVA');
    }
    if (result.total.diversifiedLoad.amps !== prev.total.diversifiedLoad.amps) {
      newChangedCells.add('total-diversifiedLoadAmps');
    }
    if (result.total.utilityPowerDemand.kVA !== prev.total.utilityPowerDemand.kVA) {
      newChangedCells.add('total-utilityPowerDemandKVA');
    }
    if (result.total.utilityPowerDemand.amps !== prev.total.utilityPowerDemand.amps) {
      newChangedCells.add('total-utilityPowerDemandAmps');
    }

    // Compare O1-O4 summary metrics - check each cell individually
    if (result.o1.kVA !== prev.o1.kVA) {
      newChangedCells.add('o1-value1');
    }
    if (result.o1.amps !== prev.o1.amps) {
      newChangedCells.add('o1-value2');
    }
    if (result.o2.kVA !== prev.o2.kVA) {
      newChangedCells.add('o2-value1');
    }
    if (result.o2.amps !== prev.o2.amps) {
      newChangedCells.add('o2-value2');
    }
    if (result.o3.kVA !== prev.o3.kVA) {
      newChangedCells.add('o3-value1');
    }
    if (result.o3.amps !== prev.o3.amps) {
      newChangedCells.add('o3-value2');
    }
    if (result.o4 !== prev.o4) {
      newChangedCells.add('o4-value2');
    }

    setChangedCells(newChangedCells);
    prevResultRef.current = result;

    // Clear the flash after animation completes (1 second)
    const timer = setTimeout(() => {
      setChangedCells(new Set());
    }, 1000);

    return () => clearTimeout(timer);
  }, [result]);

  // Show custom message when lookup table is not available (error with templateVersionId)
  if ((error || !result) && templateVersionId) {
    return (
      <Alert type="info">
        Electrical utility power demand shell be right-sized by Engineer-of-Record based on
        electrical template details
      </Alert>
    );
  }

  if (error) {
    return (
      <Box padding="s">
        <Alert type="error">{error}</Alert>
      </Box>
    );
  }

  if (!result) {
    return (
      <Box padding="s">
        <Alert type="info">No electrical data available</Alert>
      </Box>
    );
  }

  // Category loads table data - memoized to prevent unnecessary re-renders
  const categoryItems = useMemo(
    () => [
      ...result.categoryLoads.map((load, index) => ({
        rowIndex: index,
        loadDescription: load.category,
        connectedLoadKVA: formatNumber(load.connectedLoad.kVA, 1),
        connectedLoadAmps: formatNumber(load.connectedLoad.amps, 1),
        demandDiversityFactor: formatPercentage(load.demandDiversityFactor),
        diversifiedLoadKVA: formatNumber(load.diversifiedLoad.kVA, 1),
        diversifiedLoadAmps: formatNumber(load.diversifiedLoad.amps, 1),
        utilityDemandFactor: formatPercentage(load.utilityDemandFactor),
        utilityPowerDemandKVA: formatNumber(load.utilityPowerDemand.kVA, 1),
        utilityPowerDemandAmps: formatNumber(load.utilityPowerDemand.amps, 1),
      })),
      {
        rowIndex: -1, // Special index for Total row
        loadDescription: 'Total',
        connectedLoadKVA: formatNumber(result.total.connectedLoad.kVA),
        connectedLoadAmps: formatNumber(result.total.connectedLoad.amps),
        demandDiversityFactor: '',
        diversifiedLoadKVA: formatNumber(result.total.diversifiedLoad.kVA),
        diversifiedLoadAmps: formatNumber(result.total.diversifiedLoad.amps),
        utilityDemandFactor: '',
        utilityPowerDemandKVA: formatNumber(result.total.utilityPowerDemand.kVA),
        utilityPowerDemandAmps: formatNumber(result.total.utilityPowerDemand.amps),
      },
    ],
    [result, changedCells]
  );

  // Combined table data for O1, O2, O3, and O4 - memoized to prevent unnecessary re-renders
  const tableItems = useMemo(
    () => [
      {
        id: 'o1',
        metric: 'Estimate total power demand for the site',
        value1: formatNumber(result.o1.kVA),
        value2: formatNumber(result.o1.amps),
      },
      {
        id: 'o2',
        metric: 'Estimated rooftop solar size (potential)',
        value1: formatNumber(result.o2.kVA),
        value2: formatNumber(result.o2.amps),
      },
      {
        id: 'o3',
        metric: 'Utility power demand request (with rooftop solar)',
        value1: formatNumber(result.o3.kVA),
        value2: formatNumber(result.o3.amps),
      },
      {
        id: 'o4',
        metric: 'Service ratings: number of 480VAC switchboards and their ratings',
        value1: '',
        value2: `${formatNumber(result.o4)} Units`,
      },
    ],
    [result, changedCells]
  );

  // Helper function to get cell class name with flash animation
  const getCellClassName = (rowIndex: number, columnId: string): string => {
    let key: string;
    if (rowIndex === -1) {
      // Total row
      key = `total-${columnId}`;
    } else if (rowIndex === -2) {
      // Summary metrics table (O1-O4) - columnId already includes item id like "o1-value1"
      key = columnId;
    } else {
      // Category rows
      key = `${rowIndex}-${columnId}`;
    }
    return changedCells.has(key) ? 'cell-flash' : '';
  };

  return (
    <SpaceBetween size="m">
      {/* Summary Metrics Section */}
      <Box fontSize="body-m" color="text-body-secondary">
        Electrical utility power demand shown below shall be used for site selection and utility
        engagement. This estimated is based on template BRS and stakeholder inputs, and right-sized
        based on historical electrical consumption benchmarks in legacy sites. Site-specific
        Engineer-of-Record shall validate the requirements based on site conditions and local
        requirements.
      </Box>
      <Table
        columnDefinitions={[
          {
            id: 'metric',
            header: '',
            cell: (item) => item.metric,
            width: 500,
          },
          {
            id: 'value1',
            header: <div style={{ textAlign: 'right' }}>kVA</div>,
            cell: (item: any) => (
              <div className={getCellClassName(-2, `${item.id}-value1`)}>
                <Box textAlign="right">{item.value1}</Box>
              </div>
            ),
            width: 150,
          },
          {
            id: 'value2',
            header: <div style={{ textAlign: 'right' }}>Amps / Units</div>,
            cell: (item: any) => (
              <div className={getCellClassName(-2, `${item.id}-value2`)}>
                <Box textAlign="right">{item.value2}</Box>
              </div>
            ),
            width: 150,
          },
        ]}
        items={tableItems}
        trackBy="id"
        variant="embedded"
        wrapLines={false}
      />
    </SpaceBetween>
  );
};
