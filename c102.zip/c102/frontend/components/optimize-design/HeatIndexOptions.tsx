import { SpaceBetween, Box, Badge, Header, TextContent } from '@amzn/awsui-components-console';
import type { HeatIndexResult } from '../../api/lightningProtection';

interface HeatIndexOptionsProps {
  heatIndexData: HeatIndexResult;
}

export const HeatIndexOptions = ({ heatIndexData }: HeatIndexOptionsProps) => {
  const levels = heatIndexData.levels;
  const level0 = levels.find((l) => l.level === 0);
  const level1 = levels.find((l) => l.level === 1);

  const safePercentage = (level0?.percentage || 0) + (level1?.percentage || 0);

  // Determine which option is recommended based on backend hvacRecommendation text
  let recommendedOptionNumber = 1;
  if (heatIndexData.hvacRecommendation.includes('Option 3')) {
    recommendedOptionNumber = 3;
  } else if (heatIndexData.hvacRecommendation.includes('Option 2')) {
    recommendedOptionNumber = 2;
  } else {
    recommendedOptionNumber = 1;
  }

  const isRecommended = heatIndexData.recommendation === 'recommended';

  return (
    <SpaceBetween size="l">
      <Box>
        <Header
          variant="h3"
          info={
            recommendedOptionNumber === 1 &&
            isRecommended && <Badge color="green">Recommended</Badge>
          }
        >
          Option 1 - Natural Ventilation
        </Header>
        <TextContent>
          <p>Basic ventilation and passive cooling are sufficient.</p>
          <p>Triggers when:</p>
          <ul style={{ marginTop: '8px', marginBottom: 0 }}>
            <li>Internal heat index &lt;80°F for &gt;92.5% of year (Level 0), OR</li>
            <li>Internal heat index &lt;90°F for &gt;99% of year (Levels 0-1)</li>
          </ul>
        </TextContent>
      </Box>

      <Box>
        <Header
          variant="h3"
          info={
            recommendedOptionNumber === 2 &&
            isRecommended && <Badge color="green">Recommended</Badge>
          }
        >
          Option 2 - Partial Mechanical Cooling
        </Header>
        <TextContent>
          <p>Seasonal rental or targeted cooling in high-heat areas.</p>
          <p>Triggers when:</p>
          <ul>
            <li>Internal heat index 90-100°F for 100-500 hrs/year (1.15%-5.7%) — Level 2</li>
          </ul>
          <p>Solution: Seasonal rental portable AC units during peak summer months</p>
        </TextContent>
      </Box>

      <Box>
        <Header
          variant="h3"
          info={
            recommendedOptionNumber === 3 &&
            isRecommended && <Badge color="green">Recommended</Badge>
          }
        >
          Option 3 - Permanent HVAC System
        </Header>
        <TextContent>
          <p>Install mechanical equipment to maintain &lt;85°F during peaks.</p>
          <p>Triggers when any of the following conditions occur:</p>
          <ul>
            <li>Scenario A: Internal heat index 90-100°F for &gt;500 hrs/year (5.7%) — Level 2</li>
            <li>Scenario B: Internal heat index 100-114°F for &gt;300 hrs/year (3.4%) — Level 3</li>
            <li>Scenario C: Internal heat index ≥115°F for ≥1 hr/year — Level 4</li>
          </ul>
        </TextContent>
      </Box>
    </SpaceBetween>
  );
};
