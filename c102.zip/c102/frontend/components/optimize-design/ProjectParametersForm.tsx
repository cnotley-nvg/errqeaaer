import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  SpaceBetween,
  Header,
  FormField,
  Select,
  Input,
  Box,
  Autosuggest,
} from '@amzn/awsui-components-console';
import { useDesignTemplatesOptimized } from '../../hooks/useDesignTemplatesOptimized';
import { useLatestTemplateVersionsSearch } from '../../hooks/useLatestTemplateVersionsSearch';
import { useDebounce } from '../../hooks/useDebounce';
import { getAddressSuggestions } from '../../api/addressAutosuggest';
import type { AddressSuggestion } from '../../api/addressAutosuggest';

export type ProjectParams = {
  locationType: string;
  streetAddress: string;
  country: string;
  city: string;
  zipcode: string;
  latitude: string;
  longitude: string;
  facilityType: string;
  designTemplate: string;
  designTemplateName: string;
  squareFootage: string;
  length: string;
  width: string;
  height: string;
};

type ProjectParametersFormProps = {
  params: ProjectParams;
  onChange: (field: keyof ProjectParams, value: string) => void;
  errors?: Partial<Record<keyof ProjectParams, string>>;
};

export const ProjectParametersForm = ({
  params,
  onChange,
  errors = {},
}: ProjectParametersFormProps) => {
  const { templates, loading } = useDesignTemplatesOptimized();
  const [suggestions, setSuggestions] = useState<
    Array<{ label: string; value: string; data: AddressSuggestion }>
  >([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);

  const fetchSuggestions = useCallback(async (value: string) => {
    if (!value || value.length < 3) {
      setSuggestions([]);
      setLoadingSuggestions(false);
      return;
    }

    setLoadingSuggestions(true);
    const results = await getAddressSuggestions(value);
    const filtered = results
      .filter((r) => r.address && r.address.trim().length > 0)
      .map((r) => ({
        label: `${r.address}${r.city ? ` - ${r.city}, ${r.state}` : ''}`,
        value: r.address,
        data: r,
      }));
    setSuggestions(filtered);
    setLoadingSuggestions(false);
  }, []);

  const debouncedFetchSuggestions = useDebounce(fetchSuggestions, 300);

  const filter = useMemo(
    () => ({
      pageIdx: 0,
      limit: 1000,
      orderBy: 'name' as const,
      orderDesc: false,
    }),
    []
  );

  const { items: templateVersions } = useLatestTemplateVersionsSearch({ filter });

  useEffect(() => {
    if (!params.designTemplate) {
      return;
    }

    if (params.facilityType) {
      return;
    }

    const selectedVersion = templateVersions.find(
      (version) => version.template.id === params.designTemplate
    );

    if (!selectedVersion) {
      return;
    }

    const facilityType = selectedVersion.attributes?.facilityType;

    if (
      typeof facilityType === 'string' &&
      facilityType.trim() !== '' &&
      params.facilityType !== facilityType
    ) {
      onChange('facilityType', facilityType);
    }
  }, [params.designTemplate, params.facilityType, templateVersions, onChange]);

  useEffect(() => {
    if (!params.designTemplate) {
      return;
    }

    const selectedVersion = templateVersions.find(
      (version) => version.template.id === params.designTemplate
    );

    if (!selectedVersion) {
      return;
    }

    const attributes = selectedVersion.attributes;

    const populateField = (fieldName: keyof ProjectParams, attributeName: string) => {
      const value = attributes?.[attributeName];

      if (typeof value === 'number' && value > 0 && params[fieldName] !== value.toString()) {
        onChange(fieldName, value.toString());
      }
    };

    populateField('squareFootage', 'grossSquareFootage');
    populateField('length', 'buildingLength');
    populateField('width', 'buildingWidth');
    populateField('height', 'buildingHeight');
  }, [params.designTemplate, templateVersions, onChange]);

  const handleAddressChange = (value: string) => {
    onChange('streetAddress', value);
    if (value.length >= 3) {
      debouncedFetchSuggestions(value);
    } else {
      setSuggestions([]);
    }
  };

  const handleAddressFocus = () => {
    if (params.streetAddress.length >= 3 && suggestions.length === 0) {
      fetchSuggestions(params.streetAddress);
    }
  };

  const handleAddressSuggestionSelect = (value: string) => {
    const suggestion = suggestions.find((s) => s.value === value);
    if (suggestion) {
      onChange('streetAddress', suggestion.data.address);
      if (suggestion.data.city) onChange('city', suggestion.data.city);
      if (suggestion.data.country) onChange('country', suggestion.data.country);
      if (suggestion.data.zipcode) onChange('zipcode', suggestion.data.zipcode);
      if (suggestion.data.latitude) onChange('latitude', suggestion.data.latitude.toString());
      if (suggestion.data.longitude) onChange('longitude', suggestion.data.longitude.toString());
      setSuggestions([]);
    }
  };

  const handleFacilityTypeChange = useCallback(
    (value?: string) => {
      const newFacilityType = value || '';
      onChange('facilityType', newFacilityType);
      if (!newFacilityType) {
        onChange('designTemplate', '');
      }
    },
    [onChange]
  );

  const filteredTemplates = params.facilityType
    ? templates.filter((t) => t.facilityTypes.includes(params.facilityType))
    : templates;

  const templateOptions = filteredTemplates.map((t) => ({
    label: t.name,
    value: t.id,
    description: t.description || undefined,
  }));

  const selectedTemplate =
    templateOptions.find((opt) => opt.value === params.designTemplate) || null;
  const selectedTemplateData = filteredTemplates.find((t) => t.id === params.designTemplate);

  const allFacilityTypes = params.designTemplate
    ? (selectedTemplateData?.facilityTypes ?? [])
    : Array.from(new Set(templates.flatMap((t) => t.facilityTypes))).sort();

  const facilityTypeOptions = [
    { label: 'Select a facility type', value: undefined },
    ...allFacilityTypes.map((ft) => ({
      label: ft,
      value: ft,
    })),
  ];

  return (
    <Box padding={{ vertical: 'm', horizontal: 'l' }}>
      <SpaceBetween size="m">
        <Header variant="h2">Project parameters</Header>
        <FormField label="Location type *">
          <Select
            selectedOption={
              params.locationType === 'coordinates'
                ? { label: 'Lat Long', value: 'coordinates' }
                : { label: 'Address', value: 'address' }
            }
            onChange={({ detail }) => onChange('locationType', detail.selectedOption.value || '')}
            options={[
              { label: 'Address', value: 'address' },
              { label: 'Lat Long', value: 'coordinates' },
            ]}
          />
        </FormField>
        {params.locationType === 'coordinates' ? (
          <>
            <FormField label="Latitude *" errorText={errors.latitude}>
              <Input
                value={params.latitude}
                onChange={({ detail }) => onChange('latitude', detail.value)}
              />
            </FormField>
            <FormField label="Longitude *" errorText={errors.longitude}>
              <Input
                value={params.longitude}
                onChange={({ detail }) => onChange('longitude', detail.value)}
              />
            </FormField>
          </>
        ) : (
          <>
            <FormField label="Street address *" errorText={errors.streetAddress}>
              <Autosuggest
                value={params.streetAddress}
                onChange={({ detail }) => handleAddressChange(detail.value)}
                onFocus={handleAddressFocus}
                onSelect={({ detail }) => handleAddressSuggestionSelect(detail.value)}
                options={suggestions}
                placeholder="Enter street address"
                loadingText="Loading suggestions..."
                statusType={loadingSuggestions ? 'loading' : 'finished'}
                empty="No addresses found. Try entering more details."
                enteredTextLabel={(value) => `Use: "${value}"`}
                disableBrowserAutocorrect
                expandToViewport
                filteringType="manual"
              />
            </FormField>
            <FormField label="Country">
              <Input value={params.country} readOnly placeholder="-" />
            </FormField>
            <FormField label="City">
              <Input value={params.city} readOnly placeholder="-" />
            </FormField>
            <FormField label="Zip/Postal code *" errorText={errors.zipcode}>
              <Input value={params.zipcode} readOnly placeholder="-" />
            </FormField>
          </>
        )}
        <FormField label="Facility type">
          <Select
            selectedOption={
              facilityTypeOptions.find((opt) => opt.value === params.facilityType) || null
            }
            onChange={({ detail }) => handleFacilityTypeChange(detail.selectedOption.value)}
            options={facilityTypeOptions}
            placeholder="Select a facility type"
            loadingText="Loading facility types..."
            statusType={loading ? 'loading' : 'finished'}
          />
        </FormField>
        <FormField label="Design template *" errorText={errors.designTemplate}>
          <Select
            selectedOption={selectedTemplate}
            onChange={({ detail }) => onChange('designTemplate', detail.selectedOption.value || '')}
            options={templateOptions}
            placeholder="Select a design template"
            loadingText="Loading templates..."
            statusType={loading ? 'loading' : 'finished'}
          />
        </FormField>
        <FormField label="Total square footage *" errorText={errors.squareFootage}>
          <Input
            value={params.squareFootage}
            onChange={({ detail }) => onChange('squareFootage', detail.value)}
            inputMode="decimal"
          />
        </FormField>
        <FormField
          label="Building length (ft)"
          description="Required for Lightning Protection analysis"
          errorText={errors.length}
        >
          <Input
            value={params.length}
            onChange={({ detail }) => onChange('length', detail.value)}
            inputMode="decimal"
            placeholder="-"
          />
        </FormField>
        <FormField
          label="Building width (ft)"
          description="Required for Lightning Protection analysis"
          errorText={errors.width}
        >
          <Input
            value={params.width}
            onChange={({ detail }) => onChange('width', detail.value)}
            inputMode="decimal"
            placeholder="-"
          />
        </FormField>
        <FormField
          label="Building height (ft)"
          description="Required for Lightning Protection analysis"
          errorText={errors.height}
        >
          <Input
            value={params.height}
            onChange={({ detail }) => onChange('height', detail.value)}
            inputMode="decimal"
            placeholder="-"
          />
        </FormField>
      </SpaceBetween>
    </Box>
  );
};
