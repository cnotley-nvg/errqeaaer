import { useState, useCallback } from 'react';
import {
  Container,
  ExpandableSection,
  SpaceBetween,
  Button,
  ColumnLayout,
  Box,
  Badge,
  Alert,
  Link,
} from '@amzn/awsui-components-console';
import type { AnalysisResult } from './AnalysisResultCard';
import { ElectricalPowerDemand } from './ElectricalPowerDemand';
import { HeatIndexOptions } from './HeatIndexOptions';
import { downloadElectricalBenchmarkReport } from '../../utils/electricalBenchmarkPdfGenerator';
import { downloadLightningProtectionReport } from '../../utils/analysisReportGenerator';
import { downloadWindLoadingReport } from '../../utils/windLoadingPdfGenerator';
import { formatNumber } from '../../utils/formatNumber';
import {
  calculateElectrical,
  type ElectricalCalculatorResult,
  type ElectricalLookupRecord,
} from '../../api/electricalBenchmark';

type OptimizationResultsProps = {
  params: {
    streetAddress: string;
    city: string;
    zipcode: string;
    country: string;
    facilityType: string;
    designTemplate: string;
    designTemplateName?: string;
    squareFootage: string;
    length: string;
    width: string;
    height: string;
  };
  analyses: AnalysisResult[];
  onBack: () => void;
  onDone: () => void;
};

export const OptimizationResults = ({
  params,
  analyses,
  onBack,
  onDone,
}: OptimizationResultsProps) => {
  // Separate electrical benchmarking from other analyses
  const electricalAnalysis = analyses.find((a) => a.title === 'Electrical benchmarking');
  const otherAnalyses = analyses.filter((a) => a.title !== 'Electrical benchmarking');

  // State for electrical data (editable)
  const [electricalResult, setElectricalResult] = useState<ElectricalCalculatorResult | null>(
    electricalAnalysis?.electricalData || null
  );

  // Store original for reset functionality
  const [originalElectricalResult] = useState<ElectricalCalculatorResult | null>(
    electricalAnalysis?.electricalData || null
  );

  // Store calculation parameters for recalculation
  const [electricalParams] = useState(() => ({
    latitude: parseFloat((params as any).latitude || '0'),
    longitude: parseFloat((params as any).longitude || '0'),
    voltage: 480,
    area: parseFloat(params.squareFootage),
    roofFactor: 0.7,
    solarPowerDensity: 10,
  }));

  // Track if user has made edits
  const [hasEdits, setHasEdits] = useState(false);

  const getRecommendationBadge = (recommendation: string, title: string) => {
    if (title === 'Electrical benchmarking' || title === 'Mechanical/Heat index') return null;

    if (title === 'Lightning protection') {
      if (recommendation === 'required') return <Badge color="green">Recommended</Badge>;
      if (recommendation === 'not-required') return <Badge color="grey">Not recommended</Badge>;
    }

    if (title === 'Wind loading') {
      if (recommendation === 'required') return <Badge color="green">Required</Badge>;
      if (recommendation === 'not-required') return <Badge color="grey">Not required</Badge>;
    }

    return null;
  };

  // Helper function to extract lookup table from electrical result
  const extractLookupTable = (result: ElectricalCalculatorResult): ElectricalLookupRecord[] => {
    return result.categoryLoads.map((categoryLoad) => ({
      category: categoryLoad.category,
      connectedLoadKVA: categoryLoad.connectedLoad.kVA,
      demandDiversityFactor: categoryLoad.demandDiversityFactor,
      utilityDemandFactor: categoryLoad.utilityDemandFactor,
    }));
  };

  // Handler for editing electrical data
  const handleElectricalEdit = useCallback(
    async (
      categoryIndex: number,
      field: 'connectedLoadKVA' | 'demandDiversityFactor' | 'utilityDemandFactor',
      newValue: number
    ) => {
      if (!electricalResult) return;

      try {
        // Extract current lookup table
        const lookupTable = extractLookupTable(electricalResult);

        // Modify the specific edited field
        lookupTable[categoryIndex][field] = newValue;

        // Call backend API with modified lookup table
        const response = await calculateElectrical({
          latitude: electricalParams.latitude,
          longitude: electricalParams.longitude,
          voltage: electricalParams.voltage,
          area: electricalParams.area,
          roofFactor: electricalParams.roofFactor,
          solarPowerDensity: electricalParams.solarPowerDensity,
          lookupTable: lookupTable,
        });

        // Update state with new calculation - batched together by React 18
        setElectricalResult(response.calculateElectrical);
        setHasEdits(true);
      } catch (error) {
        console.error('Failed to recalculate electrical data:', error);
        // Could show error alert here
      }
    },
    [electricalResult, electricalParams]
  );

  // Handler for resetting to original values
  const handleResetElectrical = () => {
    setElectricalResult(originalElectricalResult);
    setHasEdits(false);
  };

  // Handler for downloading electrical benchmark report
  const handleElectricalDownload = () => {
    if (electricalResult) {
      downloadElectricalBenchmarkReport(
        {
          streetAddress: params.streetAddress,
          city: params.city,
          zipcode: params.zipcode,
          country: params.country,
          state: electricalResult.state || undefined,
          facilityType: params.facilityType,
          designTemplate: params.designTemplateName || params.designTemplate,
          squareFootage: params.squareFootage,
        },
        electricalResult, // Use current (possibly edited) result
        electricalParams.roofFactor,
        electricalParams.solarPowerDensity
      );
    }
  };

  // Handler for downloading other analysis reports
  const handleAnalysisDownload = (analysis: AnalysisResult) => {
    if (analysis.title === 'Mechanical/Heat index' && analysis.heatIndexData) {
      downloadLightningProtectionReport({
        recommendation: analysis.recommendation,
        heatIndexData: analysis.heatIndexData,
        projectParams: {
          streetAddress: params.streetAddress,
          city: params.city,
          state: electricalAnalysis?.state || undefined,
          zipcode: params.zipcode,
          country: params.country,
          facilityType: params.facilityType,
          designTemplate: params.designTemplateName || params.designTemplate,
          squareFootage: params.squareFootage,
        },
      });
    } else if (analysis.title === 'Lightning protection') {
      downloadLightningProtectionReport({
        recommendation: analysis.recommendation,
        riskLevel: analysis.riskLevel,
        costImpact: analysis.costImpact,
        timelineImpact: analysis.timelineImpact,
        project: analysis.project,
        reportId: analysis.reportId,
      });
    } else if (
      analysis.title === 'Wind loading' &&
      (analysis.recommendation === 'required' || analysis.recommendation === 'not-required')
    ) {
      downloadWindLoadingReport({
        recommendation: analysis.recommendation,
        guidelineUrl: analysis.guidelineUrl,
      });
    }
  };

  return (
    <SpaceBetween size="l">
      <Container header={<Box variant="h2">Project parameters</Box>}>
        <ColumnLayout columns={4} variant="text-grid">
          {/* Column 1 */}
          <SpaceBetween size="l">
            <div>
              <Box variant="awsui-key-label">Street address</Box>
              <div>{params.streetAddress}</div>
            </div>
            <div>
              <Box variant="awsui-key-label">Country</Box>
              <div>{params.country}</div>
            </div>
            <div>
              <Box variant="awsui-key-label">Height</Box>
              <div>{formatNumber(params.height)}</div>
            </div>
          </SpaceBetween>

          {/* Column 2 */}
          <SpaceBetween size="l">
            <div>
              <Box variant="awsui-key-label">City</Box>
              <div>{params.city}</div>
            </div>
            <div>
              <Box variant="awsui-key-label">Facility type</Box>
              <div>{params.facilityType}</div>
            </div>
            <div>
              <Box variant="awsui-key-label">Width</Box>
              <div>{formatNumber(params.width)}</div>
            </div>
          </SpaceBetween>

          {/* Column 3 */}
          <SpaceBetween size="l">
            <div>
              <Box variant="awsui-key-label">State</Box>
              <div>{electricalAnalysis?.state || '-'}</div>
            </div>
            <div>
              <Box variant="awsui-key-label">Design template</Box>
              <div>
                <Link href={`/templates/${params.designTemplate}`} external={false}>
                  {params.designTemplateName || params.designTemplate}
                </Link>
              </div>
            </div>
            <div>
              <Box variant="awsui-key-label">Length</Box>
              <div>{formatNumber(params.length)}</div>
            </div>
          </SpaceBetween>

          {/* Column 4 */}
          <SpaceBetween size="l">
            <div>
              <Box variant="awsui-key-label">Zip/Postal code</Box>
              <div>{params.zipcode}</div>
            </div>
            <div>
              <Box variant="awsui-key-label">Total square footage</Box>
              <div>{formatNumber(params.squareFootage)}</div>
            </div>
            <div>
              {/* Empty placeholder to maintain column height */}
              <Box variant="awsui-key-label">&nbsp;</Box>
              <div>&nbsp;</div>
            </div>
          </SpaceBetween>
        </ColumnLayout>
      </Container>

      {/* Render all non-electrical analyses first */}
      {otherAnalyses.map((analysis) => (
        <ExpandableSection
          key={analysis.title}
          variant="container"
          headerText={analysis.title}
          headerInfo={getRecommendationBadge(analysis.recommendation, analysis.title)}
          headerActions={
            analysis.downloadable && (
              <Button iconName="download" onClick={() => handleAnalysisDownload(analysis)}>
                Download report
              </Button>
            )
          }
        >
          <SpaceBetween size="m">
            {analysis.title === 'Mechanical/Heat index' ? (
              <>
                <Alert type="info">
                  Analysis based on <strong>location only</strong>. Project-specific parameters will
                  be incorporated in future updates.
                </Alert>
                {analysis.heatIndexData && (
                  <HeatIndexOptions heatIndexData={analysis.heatIndexData} />
                )}
              </>
            ) : analysis.title === 'Lightning protection' &&
              analysis.recommendation === 'not-provided' ? (
              <Alert type="info">
                Building dimensions required. Please go back and enter height, width, and length in
                Project Parameters, or refer to{' '}
                <Link
                  href="/standards/dd97653e-0d99-47db-9413-7ba6d1100f29?view=table"
                  external={false}
                >
                  Amazon Specifications (3PS)
                </Link>{' '}
                for Lightning Protection requirements.
              </Alert>
            ) : analysis.title !== 'Mechanical/Heat index' &&
              analysis.recommendation === 'not-provided' ? (
              <Alert type="info">{analysis.description}</Alert>
            ) : (
              analysis.description
            )}
          </SpaceBetween>
        </ExpandableSection>
      ))}

      {/* Render electrical benchmarking at the bottom */}
      {electricalAnalysis && (
        <ExpandableSection
          key={electricalAnalysis.title}
          variant="container"
          headerText="Electrical benchmarking"
          headerInfo={
            <div style={{ display: 'inline-flex', gap: '8px' }}>
              {hasEdits && <Badge color="blue">Edited</Badge>}
              {electricalResult && electricalResult.o2.kVA > 0 && (
                <Badge color="green">Solar Recommendation Available</Badge>
              )}
            </div>
          }
          headerActions={
            <SpaceBetween direction="horizontal" size="xs">
              {hasEdits && <Button onClick={handleResetElectrical}>Reset to Original</Button>}
              {electricalResult && (
                <Button iconName="download" onClick={handleElectricalDownload}>
                  Download report
                </Button>
              )}
            </SpaceBetween>
          }
        >
          <ElectricalPowerDemand
            result={electricalResult}
            error={electricalAnalysis.error ? electricalAnalysis.description : undefined}
            editable={true}
            onEditComplete={handleElectricalEdit}
            roofFactor={electricalParams.roofFactor}
            solarPowerDensity={electricalParams.solarPowerDensity}
            templateVersionId={electricalAnalysis.templateVersionId}
          />
        </ExpandableSection>
      )}

      <Box float="right">
        <SpaceBetween direction="horizontal" size="xs">
          <Button onClick={onBack}>Back</Button>
          <Button variant="primary" onClick={onDone}>
            Done
          </Button>
        </SpaceBetween>
      </Box>
    </SpaceBetween>
  );
};
