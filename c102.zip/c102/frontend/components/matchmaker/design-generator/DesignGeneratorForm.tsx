import React from 'react';
import {
  Box,
  Button,
  Container,
  ColumnLayout,
  Form,
  FormField,
  Header,
  Input,
  Select,
  SpaceBetween,
  type SelectProps,
} from '@amzn/awsui-components-console';

import {
  createOptions,
  NUMBER_OF_ALTERNATIVES,
  PROGRAMS,
  REGIONS,
  THROUGHPUT_RANGES,
} from './constants';
import { formatProgramLabel } from '../../../utils/attributeDisplay';

export interface DesignGeneratorFormProps {
  selections: {
    selectedRegion: SelectProps.Option | null;
    selectedProgram: SelectProps.Option | null;
    throughputInput: string;
    selectedThroughputRange: SelectProps.Option | null;
    selectedNumberOfAlternatives: SelectProps.Option | null;
  };
  handlers: {
    setSelectedRegion: (option: SelectProps.Option | null) => void;
    setSelectedProgram: (option: SelectProps.Option | null) => void;
    setThroughputInput: (value: string) => void;
    setSelectedThroughputRange: (option: SelectProps.Option | null) => void;
    setSelectedNumberOfAlternatives: (option: SelectProps.Option | null) => void;
    onGenerate: () => void;
    onClearAll: () => void;
  };
  derived: {
    areRequirementsFilled: boolean;
    isResultsState: boolean;
    baselineThroughput: number | null;
    baselineThroughputUnits:
      | import('@amzn/global-realty-mosaic-graphql-schema').DesignGeneratorThroughputUnits
      | null;
  };
}

const regionOptions = createOptions(REGIONS);
const programOptions = PROGRAMS.map((value) => ({
  value,
  label: formatProgramLabel(value),
}));
const throughputRangeOptions = createOptions(THROUGHPUT_RANGES);
const numberOfAlternativesOptions = createOptions(NUMBER_OF_ALTERNATIVES);

export const DesignGeneratorForm: React.FC<DesignGeneratorFormProps> = ({
  selections,
  handlers,
  derived,
}) => {
  const FIELD_MAX_WIDTH_PX = 520;
  const {
    selectedRegion,
    selectedProgram,
    throughputInput,
    selectedThroughputRange,
    selectedNumberOfAlternatives,
  } = selections;

  const renderSummaryItem = (label: string, value: string) => (
    <SpaceBetween size="xxs">
      <Box variant="awsui-key-label">{label}</Box>
      <div>{value || '—'}</div>
    </SpaceBetween>
  );

  if (derived.isResultsState) {
    return (
      <Container header={<Header variant="h2">Define requirements</Header>}>
        <ColumnLayout columns={4} variant="text-grid">
          {renderSummaryItem('Region', selectedRegion?.label ?? selectedRegion?.value ?? '—')}
          {renderSummaryItem('Program', selectedProgram?.label ?? selectedProgram?.value ?? '—')}
          {renderSummaryItem('Projected throughput', throughputInput || '—')}
          {renderSummaryItem(
            'Throughput range',
            selectedThroughputRange?.label ?? selectedThroughputRange?.value ?? '—'
          )}
        </ColumnLayout>
      </Container>
    );
  }

  return (
    <Form
      actions={
        <SpaceBetween direction="horizontal" size="xs">
          <Button variant="link" onClick={handlers.onClearAll}>
            Clear all
          </Button>
          <Button
            variant="primary"
            disabled={!derived.areRequirementsFilled}
            onClick={handlers.onGenerate}
          >
            Generate design
          </Button>
        </SpaceBetween>
      }
    >
      <Container header={<Header variant="h2">Define requirements</Header>}>
        <SpaceBetween size="l">
          <div style={{ maxWidth: FIELD_MAX_WIDTH_PX }}>
            <FormField label="Region *" stretch>
              <Input
                value={selectedRegion?.label ?? selectedRegion?.value ?? 'North America (NA)'}
                readOnly
              />
            </FormField>
          </div>

          <div style={{ maxWidth: FIELD_MAX_WIDTH_PX }}>
            <FormField label="Program *">
              <Select
                placeholder="Choose an option"
                selectedOption={selectedProgram}
                onChange={(event) => handlers.setSelectedProgram(event.detail.selectedOption)}
                options={programOptions}
              />
            </FormField>
          </div>

          <div style={{ maxWidth: FIELD_MAX_WIDTH_PX }}>
            <FormField label="Projected throughput *">
              <SpaceBetween size="xxs">
                <Input
                  type="text"
                  inputMode="numeric"
                  value={derived.baselineThroughput ? throughputInput : ''}
                  readOnly
                />
                {derived.baselineThroughputUnits ? (
                  <Box fontSize="body-s" color="text-body-secondary">
                    {derived.baselineThroughputUnits === 'DAILY'
                      ? 'Throughput measured daily'
                      : 'Throughput measured weekly'}
                  </Box>
                ) : null}
              </SpaceBetween>
            </FormField>
          </div>

          <div style={{ maxWidth: FIELD_MAX_WIDTH_PX }}>
            <FormField label="Throughput range">
              <Select
                placeholder="Choose a desired range"
                selectedOption={selectedThroughputRange}
                onChange={(event) =>
                  handlers.setSelectedThroughputRange(event.detail.selectedOption)
                }
                options={throughputRangeOptions}
              />
            </FormField>
          </div>

          <div style={{ maxWidth: FIELD_MAX_WIDTH_PX }}>
            <FormField label="# of design alternatives/options *">
              <Select
                placeholder="Choose an option"
                selectedOption={selectedNumberOfAlternatives}
                onChange={(event) =>
                  handlers.setSelectedNumberOfAlternatives(event.detail.selectedOption)
                }
                options={numberOfAlternativesOptions}
              />
            </FormField>
          </div>
        </SpaceBetween>
      </Container>
    </Form>
  );
};
