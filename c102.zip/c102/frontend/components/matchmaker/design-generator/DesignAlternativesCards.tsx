import React, { useMemo } from 'react';
import {
  Box,
  Button,
  Cards,
  Header,
  SpaceBetween,
  type CardsProps,
} from '@amzn/awsui-components-console';

import type { DesignAlternative } from './constants';
import { DEFAULT_CARD_BREAKPOINTS } from '../../templates/catalog/preferences/constants';

export interface DesignAlternativesCardsProps {
  items: DesignAlternative[];
}

const currencyFormatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  maximumFractionDigits: 0,
});

const renderMetric = (label: string, value: React.ReactNode) => (
  <SpaceBetween size="xxs" direction="vertical" alignItems="start">
    <Box variant="awsui-key-label">{label}</Box>
    <Box fontSize="body-m">{value}</Box>
  </SpaceBetween>
);

const formatTrafficValue = (value: number | null) =>
  typeof value === 'number' ? `${value.toLocaleString()} veh/hr` : 'Not Available';

const previewImageStyle: React.CSSProperties = {
  width: '100%',
  maxHeight: 360,
  objectFit: 'contain',
  borderRadius: 4,
  display: 'block',
};

const cardContentStyle: React.CSSProperties = {
  padding: '5px',
  margin: '-16px',
};

const metricsGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(2, minmax(0, 1fr))',
  rowGap: '16px',
  columnGap: '24px',
};

export const DesignAlternativesCards: React.FC<DesignAlternativesCardsProps> = ({ items }) => {
  const cardsPerRow = useMemo(
    () =>
      DEFAULT_CARD_BREAKPOINTS.map((bp) => ({
        cards: bp.cards,
        ...(bp.minWidth > 0 && { minWidth: bp.minWidth }),
      })),
    []
  );
  const cardDefinition = useMemo<CardsProps.CardDefinition<DesignAlternative>>(
    () => ({
      sections: [
        {
          id: 'content',
          content: (item) => {
            const maybeUrl = item.visualizationUrl ?? item.layoutPattern;
            const isUrl =
              typeof maybeUrl === 'string' &&
              (maybeUrl.startsWith('http') || maybeUrl.startsWith('data:'));

            const rows: Array<[React.ReactNode, React.ReactNode | null]> = [
              [
                <Box fontSize="heading-s" fontWeight="bold">
                  {item.title}
                </Box>,
                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                  <Button
                    disabled={!item.reportUrl}
                    onClick={() => {
                      if (item.reportUrl) {
                        window.open(item.reportUrl, '_blank', 'noopener,noreferrer');
                      }
                    }}
                  >
                    Download HTML
                  </Button>
                </div>,
              ],
              [
                renderMetric('Weekly throughput', `${item.throughput.toLocaleString()} units`),
                renderMetric('Min required site area', `${item.minSize.toLocaleString()} sq ft`),
              ],
              [
                renderMetric('Real estate cost', currencyFormatter.format(item.realEstateCost)),
                renderMetric('Warehouse area', `${item.warehouseArea.toLocaleString()} sq ft`),
              ],
              [
                renderMetric('VCPU ($/unit)', `$${item.vcpu}`),
                renderMetric('Utility demand', `${item.utilityDemand.toLocaleString()} Amps`),
              ],
              [
                renderMetric(
                  'Seasonal peak - Morning',
                  formatTrafficValue(item.seasonalPeakMorning)
                ),
                renderMetric(
                  'Seasonal peak - Evening',
                  formatTrafficValue(item.seasonalPeakEvening)
                ),
              ],
              [
                renderMetric('Carbon footprint', `${item.carbonFootprint.toLocaleString()} tCO2`),
                null,
              ],
            ];

            return (
              <div style={cardContentStyle}>
                {isUrl ? (
                  <Box margin={{ bottom: 'xs' }}>
                    <img src={maybeUrl} alt={`${item.title} preview`} style={previewImageStyle} />
                  </Box>
                ) : (
                  <Box variant="p" margin={{ bottom: 'xs' }}>
                    Preview not available
                  </Box>
                )}
                <div style={metricsGridStyle}>
                  {rows.map(([left, right], index) => (
                    <React.Fragment key={index}>
                      <div>{left}</div>
                      <div>{right ?? <span />}</div>
                    </React.Fragment>
                  ))}
                </div>
              </div>
            );
          },
        },
      ],
    }),
    []
  );
  return (
    <SpaceBetween size="l" direction="vertical">
      <Header variant="h2">Design alternatives ({items.length})</Header>
      <Cards items={items} cardDefinition={cardDefinition} cardsPerRow={cardsPerRow} />
    </SpaceBetween>
  );
};
