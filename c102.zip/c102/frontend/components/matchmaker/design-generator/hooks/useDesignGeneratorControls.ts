import { useCallback, useEffect, useMemo, useState } from 'react';
import type { SelectProps } from '@amzn/awsui-components-console';
import { gql } from 'graphql-request';

import { graphqlClient } from '../../../../api/graphqlClient';
import { type DesignAlternative } from '../constants';
import type {
  DesignGeneratorAlternative,
  DesignGeneratorBaselineThroughput,
  DesignGeneratorInput,
  DesignGeneratorProgram,
  DesignGeneratorRegion,
  DesignGeneratorThroughputRange,
  DesignGeneratorThroughputUnits,
} from '@amzn/global-realty-mosaic-graphql-schema';

interface DesignGeneratorAlternativesResponse {
  designGeneratorAlternatives: DesignGeneratorAlternative[];
}

interface DesignGeneratorBaselineThroughputResponse {
  designGeneratorBaselineThroughput: DesignGeneratorBaselineThroughput | null;
}

const DEFAULT_REGION_OPTION: SelectProps.Option = {
  label: 'North America (NA)',
  value: 'North America (NA)',
};

const DESIGN_GENERATOR_ALTERNATIVES_QUERY = gql`
  query DesignGeneratorAlternatives($input: DesignGeneratorInput!) {
    designGeneratorAlternatives(input: $input) {
      templateId
      title
      throughput
      minRequiredSiteAreaSqft
      warehouseAreaSqft
      realEstateCostUsd
      vcpuUsdPerUnit
      utilityDemandAmps
      carbonFootprintTco2
      seasonalPeakMorningVehPerHr
      seasonalPeakEveningVehPerHr
      links {
        reportUrl
        visualizationUrls
      }
    }
  }
`;

const DESIGN_GENERATOR_BASELINE_THROUGHPUT_QUERY = gql`
  query DesignGeneratorBaselineThroughput($program: DesignGeneratorProgram!) {
    designGeneratorBaselineThroughput(program: $program) {
      throughput
      throughputUnits
    }
  }
`;

const toRegionEnum = (option: SelectProps.Option | null): DesignGeneratorRegion | null => {
  if (option?.value === 'North America (NA)') {
    return 'NA';
  }
  return null;
};

const toProgramEnum = (option: SelectProps.Option | null): DesignGeneratorProgram | null => {
  switch (option?.value) {
    case 'IXD Gen 5':
      return 'IXD';
    case 'SSD FC':
      return 'SSD';
    case 'ARS Gen 14':
      return 'ARS';
    default:
      return null;
  }
};

const toRangeEnum = (option: SelectProps.Option | null): DesignGeneratorThroughputRange | null => {
  switch (option?.value) {
    case '+/- 10%':
      return 'PLUS_MINUS_10';
    case '+/- 25%':
      return 'PLUS_MINUS_25';
    case '+/- 50%':
      return 'PLUS_MINUS_50';
    default:
      return null;
  }
};

const mapAlternative = (alt: DesignGeneratorAlternative): DesignAlternative => ({
  title: alt.title,
  throughput: Math.round(alt.throughput),
  minSize: Math.round(alt.minRequiredSiteAreaSqft),
  warehouseArea: Math.round(alt.warehouseAreaSqft ?? 0),
  realEstateCost: Math.round(alt.realEstateCostUsd ?? 0),
  vcpu: Number((alt.vcpuUsdPerUnit ?? 0).toFixed(2)),
  utilityDemand: Math.round(alt.utilityDemandAmps ?? 0),
  carbonFootprint: Math.round(alt.carbonFootprintTco2 ?? 0),
  seasonalPeakMorning:
    typeof alt.seasonalPeakMorningVehPerHr === 'number'
      ? Math.round(alt.seasonalPeakMorningVehPerHr)
      : null,
  seasonalPeakEvening:
    typeof alt.seasonalPeakEveningVehPerHr === 'number'
      ? Math.round(alt.seasonalPeakEveningVehPerHr)
      : null,
  visualizationUrl: alt.links?.visualizationUrls?.[0] ?? null,
  layoutPattern: alt.links?.visualizationUrls?.[0]
    ? `url(${alt.links.visualizationUrls[0]})`
    : 'none',
  reportUrl: alt.links?.reportUrl ?? null,
});

export const useDesignGeneratorControls = () => {
  const [selectedRegion, setSelectedRegion] = useState<SelectProps.Option | null>(
    DEFAULT_REGION_OPTION
  );
  const [selectedProgram, setSelectedProgram] = useState<SelectProps.Option | null>(null);
  const [throughputInput, setThroughputInput] = useState<string>('');
  const [baselineThroughput, setBaselineThroughput] = useState<number | null>(null);
  const [baselineThroughputUnits, setBaselineThroughputUnits] =
    useState<DesignGeneratorThroughputUnits | null>(null);
  const [selectedThroughputRange, setSelectedThroughputRange] = useState<SelectProps.Option | null>(
    null
  );
  const [selectedNumberOfAlternatives, setSelectedNumberOfAlternatives] =
    useState<SelectProps.Option | null>(null);
  const [generatedDesigns, setGeneratedDesigns] = useState<DesignAlternative[]>([]);

  const parsedThroughput = useMemo(() => {
    const normalized = throughputInput.replace(/,/g, '').trim();
    if (!normalized) {
      return 0;
    }
    const value = Number(normalized);
    return Number.isFinite(value) ? value : 0;
  }, [throughputInput]);

  useEffect(() => {
    const program = toProgramEnum(selectedProgram);
    if (!program) {
      setBaselineThroughput(null);
      setBaselineThroughputUnits(null);
      setThroughputInput('');
      return;
    }

    void (async () => {
      try {
        const resp = await graphqlClient.request<DesignGeneratorBaselineThroughputResponse>(
          DESIGN_GENERATOR_BASELINE_THROUGHPUT_QUERY,
          { program }
        );
        const baseline = resp.designGeneratorBaselineThroughput;
        const tp = baseline?.throughput;
        if (typeof tp === 'number' && Number.isFinite(tp)) {
          setBaselineThroughput(tp);
          setBaselineThroughputUnits(baseline?.throughputUnits ?? 'WEEKLY');
          setThroughputInput(tp.toLocaleString('en-US'));
        } else {
          setBaselineThroughput(null);
          setBaselineThroughputUnits(null);
          setThroughputInput('');
        }
      } catch {
        setBaselineThroughput(null);
        setBaselineThroughputUnits(null);
        setThroughputInput('');
      }
    })();
  }, [selectedProgram]);

  const areRequirementsFilled = useMemo(
    () =>
      Boolean(selectedRegion?.value) &&
      Boolean(selectedProgram?.value) &&
      parsedThroughput > 0 &&
      Boolean(selectedNumberOfAlternatives?.value),
    [
      selectedRegion?.value,
      selectedProgram?.value,
      parsedThroughput,
      selectedNumberOfAlternatives?.value,
    ]
  );

  const isResultsState = generatedDesigns.length > 0;

  const handleExitResults = useCallback(() => {
    setGeneratedDesigns([]);
  }, []);

  const handleGenerate = useCallback(() => {
    const region = toRegionEnum(selectedRegion);
    const program = toProgramEnum(selectedProgram);
    const range = toRangeEnum(selectedThroughputRange);
    const num = Number(selectedNumberOfAlternatives?.value ?? 0);

    if (!region || !program || parsedThroughput <= 0 || !Number.isFinite(num) || num <= 0) {
      setGeneratedDesigns([]);
      return;
    }

    const input: DesignGeneratorInput = {
      region,
      program,
      projectedWeeklyThroughput: parsedThroughput,
      throughputRange: range,
      numberOfAlternatives: num,
    };

    void (async () => {
      const response = await graphqlClient.request<DesignGeneratorAlternativesResponse>(
        DESIGN_GENERATOR_ALTERNATIVES_QUERY,
        { input }
      );
      const items = response.designGeneratorAlternatives ?? [];
      setGeneratedDesigns(items.map(mapAlternative));
    })();
  }, [
    parsedThroughput,
    selectedNumberOfAlternatives?.value,
    selectedProgram,
    selectedRegion,
    selectedThroughputRange,
  ]);

  const handleClearAll = useCallback(() => {
    setSelectedRegion(DEFAULT_REGION_OPTION);
    setSelectedProgram(null);
    setThroughputInput('');
    setBaselineThroughput(null);
    setBaselineThroughputUnits(null);
    setSelectedThroughputRange(null);
    setSelectedNumberOfAlternatives(null);
    setGeneratedDesigns([]);
  }, [DEFAULT_REGION_OPTION]);

  return {
    selections: {
      selectedRegion,
      selectedProgram,
      throughputInput,
      selectedThroughputRange,
      selectedNumberOfAlternatives,
    },
    handlers: {
      setSelectedRegion,
      setSelectedProgram,
      setThroughputInput,
      setSelectedThroughputRange,
      setSelectedNumberOfAlternatives,
      handleGenerate,
      handleClearAll,
      handleExitResults,
    },
    derived: {
      parsedThroughput,
      areRequirementsFilled,
      isResultsState,
      baselineThroughput,
      baselineThroughputUnits,
    },
    generatedDesigns,
  } as const;
};
