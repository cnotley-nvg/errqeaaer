import type { SelectProps } from '@amzn/awsui-components-console';

export type DesignAlternative = {
  title: string;
  throughput: number;
  minSize: number;
  warehouseArea: number;
  realEstateCost: number;
  vcpu: number;
  utilityDemand: number;
  carbonFootprint: number;
  seasonalPeakMorning: number | null;
  seasonalPeakEvening: number | null;
  visualizationUrl?: string | null;
  layoutPattern: string;
  reportUrl?: string | null;
};

export const REGIONS = ['North America (NA)'] as const;

export const PROGRAMS = ['IXD Gen 5', 'ARS Gen 14', 'SSD FC'] as const;

export const THROUGHPUT_RANGES = ['+/- 10%', '+/- 25%', '+/- 50%'] as const;

export const NUMBER_OF_ALTERNATIVES = ['2', '4', '6', '8'] as const;

export const createOptions = (values: readonly string[]): SelectProps.Option[] =>
  values.map((value) => ({ label: value, value }));
