import { useCallback, useEffect, useState } from 'react';
import { gql } from 'graphql-request';

import { graphqlClient } from '../api/graphqlClient';

export interface TemplateRevisionEntry {
  id: string;
  category: string;
  title: string;
  description: string;
  changeType?: string | null;
  referenceId?: string | null;
  referenceUrl?: string | null;
}

interface TemplateRevisionLogResponse {
  templateRevisionLog: {
    items: TemplateRevisionEntry[];
  };
}

const TEMPLATE_REVISION_LOG_QUERY = gql`
  query TemplateRevisionLog($templateId: ID!) {
    templateRevisionLog(templateId: $templateId) {
      items {
        id
        category
        title
        description
        changeType
        referenceId
        referenceUrl
      }
    }
  }
`;

interface UseTemplateRevisionLogState {
  items: TemplateRevisionEntry[];
  loading: boolean;
  error: string | null;
}

export const useTemplateRevisionLog = (templateId: string | undefined) => {
  const [state, setState] = useState<UseTemplateRevisionLogState>({
    items: [],
    loading: Boolean(templateId),
    error: null,
  });

  const fetchLog = useCallback(async () => {
    if (!templateId) {
      setState({ items: [], loading: false, error: null });
      return;
    }

    setState((previous) => ({ ...previous, loading: true, error: null }));

    try {
      const response = await graphqlClient.request<TemplateRevisionLogResponse>(
        TEMPLATE_REVISION_LOG_QUERY,
        {
          templateId,
        }
      );

      setState({
        items: response.templateRevisionLog.items ?? [],
        loading: false,
        error: null,
      });
    } catch (error) {
      setState({
        items: [],
        loading: false,
        error: error instanceof Error ? error.message : 'Unable to load revision history.',
      });
    }
  }, [templateId]);

  useEffect(() => {
    void fetchLog();
  }, [fetchLog]);

  return {
    ...state,
    refetch: fetchLog,
  };
};
