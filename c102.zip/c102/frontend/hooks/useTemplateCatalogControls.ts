import { useCallback, useMemo } from 'react';
import type { PropertyFilterQuery } from '@amzn/awsui-collection-hooks';

import {
  useTemplateCatalogPersistence,
  type TemplateCatalogStateSnapshot,
} from './useTemplateCatalogPersistence';
import type { FilterInput } from '@amzn/global-realty-mosaic-graphql-schema';
import { buildFilterInput, type SortableTemplateField } from '../utils/templateFilterUtils';
import { useCatalogPreferences } from '../components/templates/catalog/preferences';
import { useCatalogControls } from './shared/useCatalogControls';

/**
 * @deprecated Use updatePageSizeFallback from useCatalogPreferences hook instead
 */
export const savePageSizeFallback = (pageSize: number): void => {
  console.warn(
    '[useTemplateCatalogControls] savePageSizeFallback is deprecated. Use updatePageSizeFallback from useCatalogPreferences hook instead.'
  );
};

export interface UseTemplateCatalogControlsResult {
  viewType: 'card' | 'table';
  propertyFilterQuery: PropertyFilterQuery;
  sortingField: SortableTemplateField;
  sortingDescending: boolean;
  pageIndex: number;
  pageSize: number;
  filterInput: FilterInput;
  handleViewTypeChange: (nextViewType: 'card' | 'table') => void;
  handlePropertyFilterChange: (nextQuery: PropertyFilterQuery) => void;
  handleSortingChange: (field: SortableTemplateField, descending: boolean) => void;
  handlePageChange: (nextPage: number) => void;
  handlePageSizeChange: (nextPageSize: number) => void;
}

export const useTemplateCatalogControls = (): UseTemplateCatalogControlsResult => {
  // Get preferences and update functions from versioned storage
  const { preferences, updateViewType } = useCatalogPreferences();

  // Get default state with preferences fallback, evaluated at hook call time
  const defaultCatalogState = useMemo(
    (): TemplateCatalogStateSnapshot => ({
      viewType: preferences.viewType, // From versioned storage
      propertyFilterQuery: {
        operation: 'and',
        tokens: [],
      },
      sortingField: 'name',
      sortingDescending: false,
      pageIndex: 1,
      pageSize: preferences.pageSizeFallback, // From versioned storage
    }),
    [preferences.viewType, preferences.pageSizeFallback]
  );

  const { initialState, persistState } = useTemplateCatalogPersistence(defaultCatalogState);

  // Memoize buildFilterInput to maintain stable reference
  const buildFilterInputCallback = useCallback(
    (
      query: PropertyFilterQuery,
      pageIndex: number,
      pageSize: number,
      sortingField: SortableTemplateField,
      sortingDescending: boolean
    ) => buildFilterInput(query, pageIndex, sortingField, sortingDescending, pageSize),
    []
  );

  return useCatalogControls({
    updateViewType, // Use versioned storage update function
    buildFilterInput: buildFilterInputCallback,
    initialState,
    persistState,
  });
};

export type { PropertyFilterQuery } from '@amzn/awsui-collection-hooks';
export type { SortableTemplateField };
