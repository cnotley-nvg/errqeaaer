import { useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import type { BreadcrumbGroupProps } from '@amzn/awsui-components-console';

export const useBreadcrumbs = (): BreadcrumbGroupProps.Item[] => {
  const location = useLocation();

  return useMemo(() => {
    const path = location.pathname;

    // Don't show breadcrumbs on homepage
    if (path === '/') {
      return [];
    }

    const items: BreadcrumbGroupProps.Item[] = [{ text: 'Home', href: '/' }];

    if (path.startsWith('/templates')) {
      items.push({ text: 'Design templates', href: '/templates' });
      if (path !== '/templates') {
        items.push({ text: 'Template details', href: path });
      }
    } else if (path.startsWith('/standards')) {
      items.push({ text: 'Browse standards', href: '/standards' });
      if (path !== '/standards') {
        items.push({ text: 'Standard details', href: path });
      }
    } else if (path.startsWith('/build-kit')) {
      items.push({ text: 'Build a kit', href: '/build-kit' });
    } else if (path.startsWith('/optimize-design')) {
      items.push({ text: 'Optimize design', href: '/optimize-design' });
    } else if (path.startsWith('/kits')) {
      items.push({ text: 'Published kit of parts', href: '/kits' });
    } else if (path.startsWith('/design-generator')) {
      items.push({ text: 'Design generator', href: '/design-generator' });
    } else if (path.startsWith('/designs')) {
      items.push({ text: 'Published designs', href: '/designs' });
    } else if (path.startsWith('/notifications')) {
      items.push({ text: 'Notifications', href: '/notifications' });
    } else if (path.startsWith('/audit')) {
      items.push({ text: 'Audit trail', href: '/audit' });
    }

    return items;
  }, [location.pathname]);
};
