/**
 * Hook for searching latest standard versions with optimized performance.
 *
 * Performance: Optimized for catalog listing use cases (only fetches latest versions).
 *
 * Key features:
 * - Fetches only latest versions (isLatest=true)
 * - Returns StandardVersionWithStandard[] format
 * - Reduced data transfer compared to fetching all versions
 *
 * Use cases:
 * - Standard catalog/listing pages
 * - Standard selection dropdowns
 * - Any UI displaying one version per standard
 *
 * Example:
 * ```tsx
 * const { items, loading, error, totalCount } = useLatestStandardVersionsSearch({
 *   filter: {
 *     pageIdx: 0,
 *     limit: 20,
 *     orderBy: 'name',
 *     orderDesc: false,
 *   }
 * });
 * ```
 *
 * Note: Returns standard version objects with nested standard info.
 * Use adapter pattern if components expect StandardSummary format (with nested latestVersion).
 *
 * @see searchLatestStandardVersions GraphQL query for backend documentation
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { gql } from 'graphql-request';

import { graphqlClient } from '../api/graphqlClient';
import type { AttributeMap, FilterInput } from '@amzn/global-realty-mosaic-graphql-schema';

export interface StandardInfo {
  id: string;
  name: string;
  description?: string | null;
  accProjectId: string;
}

export interface StandardVersionWithStandard {
  id: string;
  standardId: string;
  version: string;
  isLatest: boolean;
  accFolderId: string;
  attributes: AttributeMap;
  accCreatedAt: string | null;
  accCreatedBy: string | null;
  accUpdatedAt: string | null;
  accUpdatedBy: string | null;
  publishedOn: string | null;
  firstPublishedOn: string | null;
  createdAt: string;
  updatedAt: string;
  standard: StandardInfo;
}

interface SearchLatestStandardVersionsResponse {
  searchLatestStandardVersions: {
    items: Array<{
      id: string;
      standardId: string;
      version: string;
      isLatest: boolean;
      accFolderId: string;
      attributes: AttributeMap;
      accCreatedAt: string | null;
      accCreatedBy: string | null;
      accUpdatedAt: string | null;
      accUpdatedBy: string | null;
      publishedOn: string | null;
      firstPublishedOn: string | null;
      createdAt: string;
      updatedAt: string;
      standard: {
        id: string;
        name: string;
        description?: string | null;
        accProjectId: string;
      };
    }>;
    total: number;
    pageIdx: number;
    limit: number;
    hasNext: boolean;
  };
}

const SEARCH_LATEST_STANDARD_VERSIONS_QUERY = gql`
  query SearchLatestStandardVersions($filter: FilterInput!) {
    searchLatestStandardVersions(filter: $filter) {
      items {
        id
        standardId
        version
        isLatest
        accFolderId
        accCreatedAt
        accCreatedBy
        accUpdatedAt
        accUpdatedBy
        publishedOn
        firstPublishedOn
        createdAt
        updatedAt
        attributes
        standard {
          id
          name
          description
          accProjectId
        }
      }
      total
      pageIdx
      limit
      hasNext
    }
  }
`;

const mapVersion = (
  version: SearchLatestStandardVersionsResponse['searchLatestStandardVersions']['items'][number]
): StandardVersionWithStandard => ({
  id: version.id,
  standardId: version.standardId,
  version: version.version,
  isLatest: version.isLatest,
  accFolderId: version.accFolderId,
  attributes: (version.attributes ?? {}) as AttributeMap,
  accCreatedAt: version.accCreatedAt,
  accCreatedBy: version.accCreatedBy,
  accUpdatedAt: version.accUpdatedAt,
  accUpdatedBy: version.accUpdatedBy,
  publishedOn: version.publishedOn,
  firstPublishedOn: version.firstPublishedOn,
  createdAt: version.createdAt,
  updatedAt: version.updatedAt,
  standard: {
    id: version.standard.id,
    name: version.standard.name,
    description: version.standard.description ?? null,
    accProjectId: version.standard.accProjectId,
  },
});

export interface UseLatestStandardVersionsSearchOptions {
  filter: FilterInput;
}

export interface UseLatestStandardVersionsSearchResult {
  items: StandardVersionWithStandard[];
  totalCount: number;
  totalPages: number;
  pageIdx: number;
  limit: number;
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

export const useLatestStandardVersionsSearch = ({
  filter,
}: UseLatestStandardVersionsSearchOptions): UseLatestStandardVersionsSearchResult => {
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [items, setItems] = useState<StandardVersionWithStandard[]>([]);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [pageIdx, setPageIdx] = useState<number>(filter.pageIdx);
  const [limit, setLimit] = useState<number>(filter.limit);

  // Use JSON.stringify for stable comparison to prevent infinite re-renders
  // when filterInput object reference changes but values are the same
  const filterStr = useMemo(() => JSON.stringify(filter), [filter]);

  const memoisedFilter = useMemo(() => JSON.parse(filterStr) as FilterInput, [filterStr]);

  const fetchStandardVersions = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await graphqlClient.request<SearchLatestStandardVersionsResponse>(
        SEARCH_LATEST_STANDARD_VERSIONS_QUERY,
        {
          filter: memoisedFilter,
        }
      );

      const payload = response.searchLatestStandardVersions;
      const mappedItems: StandardVersionWithStandard[] = (payload.items ?? []).map(mapVersion);

      setItems(mappedItems);
      setTotalCount(payload.total ?? 0);
      const calculatedTotalPages =
        payload.limit > 0 ? Math.ceil((payload.total ?? 0) / payload.limit) : 1;
      setTotalPages(calculatedTotalPages || 1);
      setPageIdx(payload.pageIdx ?? memoisedFilter.pageIdx);
      setLimit(payload.limit ?? memoisedFilter.limit);
    } catch (err) {
      setItems([]);
      setTotalCount(0);
      setTotalPages(1);
      setError(err instanceof Error ? err.message : 'Unable to load standard versions.');
    } finally {
      setLoading(false);
    }
  }, [memoisedFilter]);

  useEffect(() => {
    fetchStandardVersions();
  }, [fetchStandardVersions]);

  return {
    items,
    totalCount,
    totalPages,
    pageIdx,
    limit,
    loading,
    error,
    refetch: fetchStandardVersions,
  };
};
