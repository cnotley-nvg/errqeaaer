import { useState, useEffect } from 'react';
import { graphqlClient } from '../api/graphqlClient';
import { STANDARD_FILTER_OPTIONS_QUERY } from '../api/standardFilterOptions';

interface StandardFilterOptionsResponse {
  standardFilterOptions: string[];
}

interface StandardFilterOptionsVariables {
  fieldName: string;
}

/**
 * Hook to fetch filter options for a specific standard field.
 *
 * Fetches distinct values from latest standard versions only.
 * Returns sorted, non-null values suitable for PropertyFilter dropdowns.
 *
 * @param fieldName - Field to get options for (e.g., 'program', 'region', 'projectType')
 * @returns Hook state with options array, loading, and error
 *
 * @example
 * ```tsx
 * const { options: programOptions, loading } = useStandardFilterOptions('program');
 * // options = ['ARS', 'IXD', 'Prime', ...]
 * ```
 */
export const useStandardFilterOptions = (fieldName: string) => {
  const [options, setOptions] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    let isMounted = true;

    const fetchOptions = async () => {
      try {
        setLoading(true);
        setError(null);

        const response = await graphqlClient.request<
          StandardFilterOptionsResponse,
          StandardFilterOptionsVariables
        >(STANDARD_FILTER_OPTIONS_QUERY, { fieldName });

        if (isMounted) {
          setOptions(response.standardFilterOptions);
        }
      } catch (err) {
        if (isMounted) {
          setError(err instanceof Error ? err : new Error('Failed to fetch filter options'));
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    fetchOptions();

    return () => {
      isMounted = false;
    };
  }, [fieldName]);

  return { options, loading, error };
};
