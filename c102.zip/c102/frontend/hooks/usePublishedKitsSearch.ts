import { useCallback, useEffect, useMemo, useState } from 'react';
import { gql } from 'graphql-request';

import type { FilterInput, Kit } from '@amzn/global-realty-mosaic-graphql-schema';

import { graphqlClient } from '../api/graphqlClient';

interface PublishedKitsResponse {
  searchPublishedKits: {
    items: Kit[];
    total: number;
    pageIdx: number;
    limit: number;
    hasNext: boolean;
  };
}

export interface UsePublishedKitsSearchOptions {
  filter: FilterInput;
}

export interface UsePublishedKitsSearchResult {
  items: Kit[];
  total: number;
  pageIdx: number;
  limit: number;
  totalPages: number;
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

const PUBLISHED_KITS_QUERY = gql`
  query SearchPublishedKits($filter: FilterInput!) {
    searchPublishedKits(filter: $filter) {
      items {
        id
        name
        desc
        createdAt
        updatedAt
        latestVersion {
          id
          version
          createdAt
          attributes
        }
      }
      total
      pageIdx
      limit
      hasNext
    }
  }
`;

export const usePublishedKitsSearch = ({
  filter,
}: UsePublishedKitsSearchOptions): UsePublishedKitsSearchResult => {
  const [items, setItems] = useState<Kit[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [pageIdx, setPageIdx] = useState<number>(filter.pageIdx);
  const [limit, setLimit] = useState<number>(filter.limit);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Use JSON.stringify for stable comparison to prevent infinite re-renders
  // when filter object reference changes but values are the same.
  const filterStr = useMemo(() => JSON.stringify(filter), [filter]);
  const memoisedFilter = useMemo(() => JSON.parse(filterStr) as FilterInput, [filterStr]);

  const fetchKits = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await graphqlClient.request<PublishedKitsResponse>(PUBLISHED_KITS_QUERY, {
        filter: memoisedFilter,
      });

      const payload = response.searchPublishedKits;
      setItems(payload.items ?? []);
      setTotal(payload.total ?? 0);
      setPageIdx(payload.pageIdx ?? memoisedFilter.pageIdx);
      setLimit(payload.limit ?? memoisedFilter.limit);
    } catch (err) {
      setItems([]);
      setTotal(0);
      setError(err instanceof Error ? err.message : 'Unable to load published kits.');
    } finally {
      setLoading(false);
    }
  }, [memoisedFilter]);

  useEffect(() => {
    void fetchKits();
  }, [fetchKits]);

  const totalPages = useMemo(() => {
    if (!limit || limit <= 0) {
      return 1;
    }

    return Math.max(1, Math.ceil(total / limit));
  }, [limit, total]);

  return {
    items,
    total,
    pageIdx,
    limit,
    totalPages,
    loading,
    error,
    refetch: fetchKits,
  };
};
