import { useCallback, useEffect, useState } from 'react';
import { gql } from 'graphql-request';

import type { AttributeMap } from '@amzn/global-realty-mosaic-graphql-schema';

import { graphqlClient } from '../api/graphqlClient';

export interface KitDetailStandardLink {
  id: string;
  version: string;
  standardId: string;
  standardName: string;
  standardDescription?: string | null;
  attributes: AttributeMap;
}

export interface KitVersionDetail {
  id: string;
  version: string;
  createdAt: string;
  updatedAt: string;
  attributes: AttributeMap;
  standards: KitDetailStandardLink[];
}

export interface KitDetailData {
  id: string;
  name: string;
  description?: string | null;
  createdAt: string;
  updatedAt: string;
  latestVersion: KitVersionDetail | null;
}

interface KitDetailResponse {
  kit: {
    id: string;
    name: string;
    desc?: string | null;
    createdAt: string;
    updatedAt: string;
    latestVersion: {
      id: string;
      version: string;
      createdAt: string;
      updatedAt: string;
      attributes: AttributeMap;
      standards: Array<{
        id: string;
        version: string;
        attributes: AttributeMap;
        standard: {
          id: string;
          name: string;
          description?: string | null;
        };
      }>;
    } | null;
  } | null;
}

const KIT_DETAIL_QUERY = gql`
  query KitDetail($id: ID!) {
    kit(id: $id) {
      id
      name
      desc
      createdAt
      updatedAt
      latestVersion {
        id
        version
        createdAt
        updatedAt
        attributes
        standards {
          id
          version
          attributes
          standard {
            id
            name
            description
          }
        }
      }
    }
  }
`;

interface UseKitDetailState {
  kit: KitDetailData | null;
  loading: boolean;
  error: string | null;
}

export interface UseKitDetailResult extends UseKitDetailState {
  refetch: () => Promise<void>;
}

const mapStandardLink = (
  record: NonNullable<NonNullable<KitDetailResponse['kit']>['latestVersion']>['standards'][number]
): KitDetailStandardLink => ({
  id: record.id,
  version: record.version,
  standardId: record.standard.id,
  standardName: record.standard.name,
  standardDescription: record.standard.description ?? null,
  attributes: record.attributes ?? {},
});

const mapKit = (record: NonNullable<KitDetailResponse['kit']>): KitDetailData => ({
  id: record.id,
  name: record.name,
  description: record.desc ?? null,
  createdAt: record.createdAt,
  updatedAt: record.updatedAt,
  latestVersion: record.latestVersion
    ? {
        id: record.latestVersion.id,
        version: record.latestVersion.version,
        createdAt: record.latestVersion.createdAt,
        updatedAt: record.latestVersion.updatedAt,
        attributes: record.latestVersion.attributes ?? {},
        standards: record.latestVersion.standards.map(mapStandardLink),
      }
    : null,
});

export const useKitDetail = (id?: string): UseKitDetailResult => {
  const [state, setState] = useState<UseKitDetailState>({
    kit: null,
    loading: Boolean(id),
    error: null,
  });

  const fetchDetail = useCallback(async () => {
    if (!id) {
      setState({ kit: null, loading: false, error: 'Kit id is required.' });
      return;
    }

    setState((previous) => ({ ...previous, loading: true, error: null }));

    try {
      const response = await graphqlClient.request<KitDetailResponse>(KIT_DETAIL_QUERY, { id });
      const record = response.kit;
      setState({
        kit: record ? mapKit(record) : null,
        loading: false,
        error: null,
      });
    } catch (error) {
      setState({
        kit: null,
        loading: false,
        error: error instanceof Error ? error.message : 'Unable to load kit.',
      });
    }
  }, [id]);

  useEffect(() => {
    void fetchDetail();
  }, [fetchDetail]);

  return {
    ...state,
    refetch: fetchDetail,
  };
};
