/**
 * Shared catalog infrastructure hooks
 *
 * Generic hooks for managing catalog state (filters, sorting, pagination) and
 * synchronization with URL parameters.
 *
 * These hooks provide a reusable pattern for catalog views across the application,
 * with built-in safeguards against infinite loops and optimized URL updates.
 *
 * @see docs/frontend/CATALOG_STATE_ARCHITECTURE.md - Detailed architecture documentation
 */

export * from './useCatalogPersistence';
export * from './useCatalogControls';
