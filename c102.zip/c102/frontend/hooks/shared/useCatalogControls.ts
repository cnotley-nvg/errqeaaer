import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { CatalogStateSnapshot } from './useCatalogPersistence';

/**
 * Options for configuring catalog controls
 */
export interface UseCatalogControlsOptions<TSort extends string, TFilterInput> {
  /** Function to update view type in versioned storage */
  updateViewType: (viewType: 'card' | 'table') => void;

  /** Function to build filter input from current state */
  buildFilterInput: (
    propertyFilterQuery: any,
    pageIndex: number,
    pageSize: number,
    sortingField: TSort,
    sortingDescending: boolean
  ) => TFilterInput;

  /** Initial state from persistence hook */
  initialState: CatalogStateSnapshot<TSort>;

  /** Function to persist state to URL */
  persistState: (snapshot: CatalogStateSnapshot<TSort>) => void;
}

/**
 * Result returned by catalog controls hook
 */
export interface CatalogControlsState<TSort extends string, TFilterInput> {
  viewType: 'card' | 'table';
  propertyFilterQuery: any;
  sortingField: TSort;
  sortingDescending: boolean;
  pageIndex: number;
  pageSize: number;
  filterInput: TFilterInput;
}

/**
 * Handlers returned by catalog controls hook
 */
export interface CatalogControlsHandlers<TSort extends string> {
  handleViewTypeChange: (nextViewType: 'card' | 'table') => void;
  handlePropertyFilterChange: (nextQuery: any) => void;
  handleSortingChange: (field: TSort, descending: boolean) => void;
  handlePageChange: (nextPage: number) => void;
  handlePageSizeChange: (nextPageSize: number) => void;
}

/**
 * Complete result from catalog controls hook
 */
export type UseCatalogControlsResult<TSort extends string, TFilterInput> = CatalogControlsState<
  TSort,
  TFilterInput
> &
  CatalogControlsHandlers<TSort>;

/**
 * Shared catalog controls logic
 *
 * Provides consistent state management and handlers for catalog views.
 * Each catalog provides its own filterInput builder logic.
 *
 * @example
 * ```typescript
 * const controls = useCatalogControls({
 *   updateViewType: (viewType) => updateViewType(viewType),
 *   buildFilterInput: (query, pageIndex, pageSize, field, desc) => ({
 *     pageIdx: pageIndex - 1,
 *     limit: pageSize,
 *     orderBy: field,
 *     orderDesc: desc,
 *   }),
 *   initialState,
 *   persistState,
 * });
 * ```
 */
export function useCatalogControls<TSort extends string, TFilterInput>(
  options: UseCatalogControlsOptions<TSort, TFilterInput>
): UseCatalogControlsResult<TSort, TFilterInput> {
  const {
    updateViewType: updateViewTypeCallback,
    buildFilterInput,
    initialState,
    persistState,
  } = options;

  // Initialize state from persistence hook
  const [viewType, setViewType] = useState<'card' | 'table'>(initialState.viewType);
  const [propertyFilterQuery, setPropertyFilterQuery] = useState(initialState.propertyFilterQuery);
  const [sortingField, setSortingField] = useState<TSort>(initialState.sortingField);
  const [sortingDescending, setSortingDescending] = useState<boolean>(
    initialState.sortingDescending
  );
  const [pageIndex, setPageIndex] = useState<number>(initialState.pageIndex);
  const [pageSize, setPageSize] = useState<number>(initialState.pageSize);

  // Build filter input from current state
  const filterInput = useMemo(
    () =>
      buildFilterInput(propertyFilterQuery, pageIndex, pageSize, sortingField, sortingDescending),
    [buildFilterInput, propertyFilterQuery, pageIndex, pageSize, sortingField, sortingDescending]
  );

  // Handler: View type change (also persists to versioned storage)
  const handleViewTypeChange = useCallback(
    (nextViewType: 'card' | 'table') => {
      setViewType(nextViewType);
      updateViewTypeCallback(nextViewType);
    },
    [updateViewTypeCallback]
  );

  // Handler: Property filter change (resets to page 1)
  const handlePropertyFilterChange = useCallback((nextQuery: any) => {
    setPropertyFilterQuery(nextQuery);
    setPageIndex(1);
  }, []);

  // Handler: Sorting change (resets to page 1)
  const handleSortingChange = useCallback((field: TSort, descending: boolean) => {
    setSortingField(field);
    setSortingDescending(descending);
    setPageIndex(1);
  }, []);

  // Handler: Page change
  const handlePageChange = useCallback((nextPage: number) => {
    setPageIndex(nextPage);
  }, []);

  // Handler: Page size change (resets to page 1)
  const handlePageSizeChange = useCallback((nextPageSize: number) => {
    setPageSize(nextPageSize);
    setPageIndex(1);
  }, []);

  // ═══════════════════════════════════════════════════════════════════════════
  // INFINITE LOOP PREVENTION - Layer 1: String Comparison for Deep Equality
  // ═══════════════════════════════════════════════════════════════════════════
  //
  // propertyFilterQuery is an object. Objects are compared by reference in JavaScript,
  // so even if two objects have identical data, they're considered different if they're
  // not the exact same object instance.
  //
  // WHY WE STRINGIFY:
  // - Object references may change between renders (React re-creates objects)
  // - persistState creates NEW objects via coercePropertyFilterQuery (for sanitization)
  // - String comparison detects when the DATA hasn't actually changed
  //
  // EXAMPLE:
  //   const obj1 = { tokens: [], operation: 'and' };
  //   const obj2 = { tokens: [], operation: 'and' };
  //   obj1 !== obj2                                  // true (different refs)
  //   JSON.stringify(obj1) === JSON.stringify(obj2)  // true (same data)
  //
  // This prevents false-positive state changes that would trigger unnecessary
  // URL updates and re-renders.
  //
  const propertyFilterQueryStr = useMemo(
    () => JSON.stringify(propertyFilterQuery),
    [propertyFilterQuery]
  );

  // Stringify initialState's propertyFilterQuery for prevStateRef initialization
  const initialPropertyFilterQueryStr = useMemo(
    () => JSON.stringify(initialState.propertyFilterQuery),
    [initialState.propertyFilterQuery]
  );

  // ═══════════════════════════════════════════════════════════════════════════
  // INFINITE LOOP PREVENTION - Layer 2: Previous State Tracking
  // ═══════════════════════════════════════════════════════════════════════════
  //
  // This ref tracks the state from the PREVIOUS render. By comparing current state
  // to previous state, we can determine if anything actually changed.
  //
  // WHY USE A REF (not state):
  // - Refs don't trigger re-renders when updated
  // - We update this AFTER deciding to persist, inside the useEffect
  // - This creates a comparison point for the NEXT render
  //
  // INITIALIZATION:
  // - Set to initialState so the first render doesn't trigger a persist
  // - The URL already reflects initialState (we read from it on mount)
  // - Persisting the same values would be wasteful
  //
  // HOW IT PREVENTS LOOPS:
  // - Even if persistState's identity changes (it doesn't), this check runs first
  // - If data hasn't changed, we return early before calling persistState
  // - This is the PRIMARY defense against infinite loops
  //
  const prevStateRef = useRef<{
    viewType: 'card' | 'table';
    propertyFilterQueryStr: string;
    sortingField: TSort;
    sortingDescending: boolean;
    pageIndex: number;
    pageSize: number;
  }>({
    viewType: initialState.viewType,
    propertyFilterQueryStr: initialPropertyFilterQueryStr,
    sortingField: initialState.sortingField,
    sortingDescending: initialState.sortingDescending,
    pageIndex: initialState.pageIndex,
    pageSize: initialState.pageSize,
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // URL Persistence Effect - Syncs React State → URL Parameters
  // ═══════════════════════════════════════════════════════════════════════════
  //
  // FLOW:
  // 1. User changes state (e.g., clicks page 2)
  // 2. React re-renders with new state
  // 3. This effect runs (because state values in deps changed)
  // 4. We compare current state to previous state (prevStateRef)
  // 5. If different → persist to URL and update prevStateRef
  // 6. If same → return early (no persist)
  //
  // INFINITE LOOP PREVENTION:
  // This useEffect has multiple safeguards against infinite loops:
  //
  // 1. STRING COMPARISON (Layer 1):
  //    - We compare propertyFilterQueryStr (stringified), not the object itself
  //    - Even if persistState creates a new object, string stays the same
  //    - See comments above propertyFilterQueryStr for details
  //
  // 2. PREVSTATEREF CHECK (Layer 2 - PRIMARY DEFENSE):
  //    - Compare all state to previous render
  //    - If nothing changed, return early BEFORE calling persistState
  //    - This runs even if function identities in deps change
  //
  // 3. URL OPTIMIZATION (Layer 3):
  //    - persistState compares URL strings before updating
  //    - Returns same URLSearchParams reference if unchanged
  //    - See useCatalogPersistence.ts line 206-210
  //
  // 4. REACT ROUTER STABILITY (Layer 4):
  //    - setSearchParams has stable identity (React Router guarantee)
  //    - Coercion functions use stable deps (constants)
  //    - { replace: true } prevents navigation events
  //
  // WHY INCLUDE persistState IN DEPS:
  // - React's exhaustive-deps rule requires it
  // - It has stable identity in practice (setSearchParams is stable)
  // - Even if it changed, prevStateRef check would prevent loops
  // - Including it makes the code more maintainable and explicit
  //
  // See docs/frontend/CATALOG_STATE_ARCHITECTURE.md for detailed flow diagrams
  //
  useEffect(() => {
    // Build snapshot of current state for comparison
    const currentStateForComparison = {
      viewType,
      propertyFilterQueryStr,
      sortingField,
      sortingDescending,
      pageIndex,
      pageSize,
    };

    // ═══════════════════════════════════════════════════════════════════════
    // Early return if state hasn't actually changed
    // ═══════════════════════════════════════════════════════════════════════
    // This is the PRIMARY defense against infinite loops.
    //
    // By comparing to prevStateRef, we ensure persistState is only called
    // when data ACTUALLY changes, not when:
    // - React re-renders with same data
    // - Object references change but data is identical
    // - Function identities in dependency array change
    //
    if (
      prevStateRef.current.viewType === viewType &&
      prevStateRef.current.propertyFilterQueryStr === propertyFilterQueryStr &&
      prevStateRef.current.sortingField === sortingField &&
      prevStateRef.current.sortingDescending === sortingDescending &&
      prevStateRef.current.pageIndex === pageIndex &&
      prevStateRef.current.pageSize === pageSize
    ) {
      return; // State unchanged - skip persist
    }

    // State HAS changed - update ref for next comparison
    prevStateRef.current = currentStateForComparison;

    // Persist to URL
    // Note: persistState may create new object instances via coercePropertyFilterQuery,
    // but that's fine because:
    // 1. The new object goes to the URL, not React state
    // 2. Next render will still have the same propertyFilterQueryStr (stringified)
    // 3. The comparison above will catch that nothing changed
    persistState({
      viewType,
      propertyFilterQuery,
      sortingField,
      sortingDescending,
      pageIndex,
      pageSize,
    });
  }, [
    viewType,
    propertyFilterQueryStr,
    sortingField,
    sortingDescending,
    pageIndex,
    pageSize,
    persistState, // Include persistState in deps - React can track it properly
  ]);

  return {
    viewType,
    propertyFilterQuery,
    sortingField,
    sortingDescending,
    pageIndex,
    pageSize,
    filterInput,
    handleViewTypeChange,
    handlePropertyFilterChange,
    handleSortingChange,
    handlePageChange,
    handlePageSizeChange,
  };
}
