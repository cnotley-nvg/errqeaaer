import { useCallback, useMemo, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import type { PropertyFilterQuery } from '@amzn/awsui-collection-hooks';

import {
  coerceViewType,
  coercePageIndex,
  coercePageSize,
  normalizeBoolean,
  clonePropertyFilterQuery,
  coercePropertyFilterQuery,
  parseFilterFromParams,
  applySnapshotToSearchParams,
  DEFAULT_QUERY_KEYS,
  type QueryKeys,
} from '../../components/shared/catalog/utils';

/**
 * Generic catalog state snapshot
 * TSort: Union type of sortable field names for this catalog
 */
export interface CatalogStateSnapshot<TSort extends string> {
  viewType: 'card' | 'table';
  propertyFilterQuery: PropertyFilterQuery;
  sortingField: TSort;
  sortingDescending: boolean;
  pageIndex: number;
  pageSize: number;
}

/**
 * Options for configuring the catalog persistence hook
 */
export interface UseCatalogPersistenceOptions<TSort extends string> {
  /** Array of valid sortable field names for validation */
  sortableFields: readonly TSort[];

  /** Logger scope for debugging (e.g., 'template-catalog-persistence') */
  loggerScope: string;

  /** Hard-coded defaults for URL comparison (ensures shareability) */
  urlComparisonDefaults: Readonly<CatalogStateSnapshot<TSort>>;

  /** Optional custom query key names (overrides defaults) */
  queryKeys?: Partial<QueryKeys>;

  /** Optional valid page sizes (defaults to [10, 20, 30, 40]) */
  validPageSizes?: readonly number[];
}

/**
 * Result returned by the catalog persistence hook
 */
export interface UseCatalogPersistenceResult<TSort extends string> {
  /** Initial state loaded from URL parameters */
  initialState: CatalogStateSnapshot<TSort>;

  /** Function to persist state changes to URL */
  persistState: (snapshot: CatalogStateSnapshot<TSort>) => void;
}

const DEFAULT_VALID_PAGE_SIZES = [10, 20, 30, 40] as const;

/**
 * Generic hook for managing catalog state persistence via URL parameters
 *
 * This hook provides a consistent pattern for persisting catalog state (view type,
 * sorting, pagination, filters) in URL query parameters, making the state shareable
 * and bookmarkable.
 *
 * @example
 * ```typescript
 * const { initialState, persistState } = useCatalogPersistence(
 *   {
 *     sortableFields: SORTABLE_FIELDS,
 *     loggerScope: 'template-catalog-persistence',
 *     urlComparisonDefaults: URL_COMPARISON_DEFAULTS,
 *   },
 *   fallbackState
 * );
 * ```
 *
 * @param options - Configuration options for the hook
 * @param fallbackState - Default state to use when URL parameters are missing
 * @returns Object with initialState and persistState function
 */
export function useCatalogPersistence<TSort extends string>(
  options: UseCatalogPersistenceOptions<TSort>,
  fallbackState: CatalogStateSnapshot<TSort>
): UseCatalogPersistenceResult<TSort> {
  const {
    sortableFields,
    loggerScope,
    queryKeys: customQueryKeys,
    urlComparisonDefaults,
    validPageSizes = DEFAULT_VALID_PAGE_SIZES,
  } = options;

  // Merge custom query keys with defaults
  const queryKeys = useMemo(
    () => ({ ...DEFAULT_QUERY_KEYS, ...customQueryKeys }),
    [customQueryKeys]
  );

  // Store fallback state in ref to avoid re-renders
  const fallbackRef = useRef<CatalogStateSnapshot<TSort>>(cloneSnapshot(fallbackState));
  const [searchParams, setSearchParams] = useSearchParams();

  /**
   * Coerce sorting field to valid value
   * Returns fallback if value is not in sortableFields array
   */
  const coerceSortingField = useCallback(
    (value: unknown, fallback: TSort): TSort => {
      return sortableFields.includes(value as TSort) ? (value as TSort) : fallback;
    },
    [sortableFields]
  );

  /**
   * Build catalog state snapshot from URL parameters
   * Falls back to fallbackRef values for missing/invalid params
   */
  const buildSnapshotFromSearchParams = useCallback(
    (params: URLSearchParams): CatalogStateSnapshot<TSort> => {
      const viewType = coerceViewType(params.get(queryKeys.view), fallbackRef.current.viewType);
      const sortingField = coerceSortingField(
        params.get(queryKeys.sort),
        fallbackRef.current.sortingField
      );
      const sortingDescending = normalizeBoolean(
        params.get(queryKeys.desc),
        fallbackRef.current.sortingDescending
      );
      const pageIndex = coercePageIndex(params.get(queryKeys.page), fallbackRef.current.pageIndex);
      const pageSize = coercePageSize(
        params.get(queryKeys.pageSize),
        fallbackRef.current.pageSize,
        validPageSizes
      );
      const propertyFilterQuery = parseFilterFromParams(
        params.get(queryKeys.filter),
        fallbackRef.current.propertyFilterQuery,
        loggerScope
      );

      return {
        viewType,
        sortingField,
        sortingDescending,
        pageIndex,
        pageSize,
        propertyFilterQuery,
      };
    },
    [queryKeys, coerceSortingField, loggerScope, validPageSizes]
  );

  // ═══════════════════════════════════════════════════════════════════════════
  // INITIAL STATE - Compute ONCE on mount only
  // ═══════════════════════════════════════════════════════════════════════════
  //
  // CRITICAL: Empty dependency array [] is INTENTIONAL, not a bug!
  //
  // WHY EMPTY DEPS:
  // - We read URL parameters ONCE when the component mounts
  // - After mount, React state drives updates (not URL changes)
  // - This creates unidirectional data flow: URL → React state
  //
  // WHAT IF WE INCLUDED searchParams IN DEPS?
  // - searchParams changes when URL changes
  // - URL changes when we call setSearchParams in persistState
  // - This would create a cycle: State → URL → State → URL → ...
  // - INFINITE LOOP!
  //
  // ARCHITECTURE:
  // Mount:     URL → initialState → React state
  // Updates:   React state → persistState → URL
  //
  // The URL is the source of truth on mount, but React state is the source
  // of truth for updates. This asymmetric flow prevents circular dependencies.
  //
  // See docs/frontend/CATALOG_STATE_ARCHITECTURE.md for flow diagrams
  //
  const initialState = useMemo(() => {
    const snapshot = buildSnapshotFromSearchParams(searchParams);
    return snapshot;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Empty deps = compute once on mount only

  // ═══════════════════════════════════════════════════════════════════════════
  // PERSIST STATE - Write React State to URL Parameters
  // ═══════════════════════════════════════════════════════════════════════════
  //
  // This function is called by useCatalogControls when state changes.
  //
  // SANITIZATION:
  // - All values are coerced to valid types before writing to URL
  // - Invalid values fall back to defaults from fallbackRef
  // - propertyFilterQuery is CLONED via coercePropertyFilterQuery
  //
  // WHY CLONE propertyFilterQuery?
  // - Ensures URL has clean, validated data
  // - Prevents mutations from affecting the original object
  // - Creates NEW object instance (different reference)
  //
  // DOESN'T THIS NEW OBJECT CAUSE INFINITE LOOPS?
  // No! Here's why:
  //
  // 1. NEW OBJECT GOES TO URL, NOT REACT STATE
  //    - This function calls setSearchParams (updates URL)
  //    - It does NOT call setPropertyFilterQuery (doesn't update React state)
  //    - React state remains unchanged with its original object reference
  //
  // 2. STRING COMPARISON CATCHES IT (Layer 1)
  //    - useCatalogControls compares JSON.stringify(propertyFilterQuery)
  //    - The stringified value is the same before and after persist
  //    - Next render: "same string" → early return → no loop
  //
  // 3. URL STRING COMPARISON (Layer 3)
  //    - setSearchParams is called with a function (lines 196-213)
  //    - We compare next.toString() vs currentParams.toString()
  //    - If URLs are identical, we return currentParams (same reference)
  //    - This prevents React Router from triggering a re-render
  //
  // DEPENDENCY ARRAY:
  // - Includes all functions and values used in the callback
  // - setSearchParams has stable identity (React Router guarantee)
  // - Coercion functions have stable deps (sortableFields, validPageSizes are constants)
  // - Even if identities changed, prevStateRef in useCatalogControls would prevent loops
  //
  // INFINITE LOOP PREVENTION:
  // This function participates in Layer 3 of infinite loop prevention.
  // See useCatalogControls.ts and docs/frontend/CATALOG_STATE_ARCHITECTURE.md for full details.
  //
  const persistState = useCallback(
    (snapshot: CatalogStateSnapshot<TSort>) => {
      // Sanitize all values before writing to URL
      // Each coerce function creates NEW objects/values for safety
      const sanitized: CatalogStateSnapshot<TSort> = {
        viewType: coerceViewType(snapshot.viewType, fallbackRef.current.viewType),
        sortingField: coerceSortingField(snapshot.sortingField, fallbackRef.current.sortingField),
        sortingDescending: normalizeBoolean(
          snapshot.sortingDescending ? 'true' : 'false',
          fallbackRef.current.sortingDescending
        ),
        pageIndex: coercePageIndex(snapshot.pageIndex, fallbackRef.current.pageIndex),
        pageSize: coercePageSize(snapshot.pageSize, fallbackRef.current.pageSize, validPageSizes),
        // IMPORTANT: coercePropertyFilterQuery creates a NEW object (cloned)
        // This is intentional for sanitization, and does NOT cause infinite loops
        // because the new object goes to URL, not React state. See comments above.
        propertyFilterQuery: coercePropertyFilterQuery(
          snapshot.propertyFilterQuery,
          fallbackRef.current.propertyFilterQuery
        ),
      };

      // ═══════════════════════════════════════════════════════════════════════
      // Update URL parameters with sanitized values
      // ═══════════════════════════════════════════════════════════════════════
      // Using functional update pattern to access current params
      setSearchParams(
        (currentParams) => {
          const next = new URLSearchParams(currentParams);
          applySnapshotToSearchParams({
            params: next,
            snapshot: sanitized,
            fallback: fallbackRef.current,
            urlComparisonDefaults,
            queryKeys,
          });

          // ═══════════════════════════════════════════════════════════════════
          // INFINITE LOOP PREVENTION - Layer 3: URL String Comparison
          // ═══════════════════════════════════════════════════════════════════
          // Compare URL strings BEFORE updating
          //
          // If the URL hasn't actually changed (same string representation),
          // return the SAME URLSearchParams reference. React Router will see
          // the same object and skip the re-render.
          //
          // This prevents unnecessary updates when:
          // - persistState is called with data that's already in the URL
          // - User navigates with browser back/forward to current state
          //
          if (next.toString() === currentParams.toString()) {
            return currentParams; // Same reference = no re-render
          }

          return next;
        },
        { replace: true } // Use replace to avoid polluting browser history
      );
    },
    [
      setSearchParams,
      coerceSortingField,
      loggerScope,
      queryKeys,
      urlComparisonDefaults,
      validPageSizes,
    ]
  );

  return {
    initialState,
    persistState,
  };
}

/**
 * Helper to clone a catalog state snapshot with deep copy of propertyFilterQuery
 */
function cloneSnapshot<TSort extends string>(
  snapshot: CatalogStateSnapshot<TSort>
): CatalogStateSnapshot<TSort> {
  return {
    viewType: snapshot.viewType,
    propertyFilterQuery: clonePropertyFilterQuery(snapshot.propertyFilterQuery),
    sortingField: snapshot.sortingField,
    sortingDescending: snapshot.sortingDescending,
    pageIndex: snapshot.pageIndex,
    pageSize: snapshot.pageSize,
  };
}
