import type { PropertyFilterProps } from '@amzn/awsui-components-console';
import { useCatalogPersistence, type CatalogStateSnapshot } from './shared/useCatalogPersistence';

/**
 * Template-specific sortable fields
 */
export type SortableTemplateField =
  | 'name'
  | 'accProjectId'
  | 'updatedAt'
  | 'createdAt'
  | 'region'
  | 'program'
  | 'capacity'
  | 'stories'
  | 'facilityType'
  | 'businessUnit'
  | 'siteAcreage'
  | 'dockDoorCount'
  | 'totalTrailerParking'
  | 'maxWeeklyHeadcount'
  | 'powerKva'
  | 'createdBy'
  | 'grossSquareFootage'
  | 'peakShiftHeadcount'
  | 'clearHeightFtM'
  | 'dspParking'
  | 'generation';

/**
 * Template catalog state snapshot
 * Extends generic CatalogStateSnapshot with PropertyFilterProps.Query type
 */
export interface TemplateCatalogStateSnapshot
  extends Omit<CatalogStateSnapshot<SortableTemplateField>, 'propertyFilterQuery'> {
  propertyFilterQuery: PropertyFilterProps.Query;
}

const SORTABLE_FIELDS: ReadonlyArray<SortableTemplateField> = [
  'name',
  'accProjectId',
  'updatedAt',
  'createdAt',
  'region',
  'program',
  'capacity',
  'stories',
  'facilityType',
  'businessUnit',
  'siteAcreage',
  'dockDoorCount',
  'totalTrailerParking',
  'maxWeeklyHeadcount',
  'powerKva',
  'createdBy',
  'grossSquareFootage',
  'peakShiftHeadcount',
  'clearHeightFtM',
  'dspParking',
  'generation',
];

/**
 * Hard-coded defaults for URL comparison
 * These determine which values appear in the URL (non-default values are included)
 * Using hard-coded values ensures URL shareability is not affected by localStorage
 */
const URL_COMPARISON_DEFAULTS: Readonly<CatalogStateSnapshot<SortableTemplateField>> = {
  viewType: 'card',
  sortingField: 'name',
  sortingDescending: false,
  pageIndex: 1,
  pageSize: 20,
  propertyFilterQuery: { operation: 'and', tokens: [] },
};

/**
 * Template catalog persistence hook
 * Uses generic useCatalogPersistence with template-specific configuration
 */
export const useTemplateCatalogPersistence = (
  fallbackState: TemplateCatalogStateSnapshot
): {
  initialState: TemplateCatalogStateSnapshot;
  persistState: (snapshot: TemplateCatalogStateSnapshot) => void;
} => {
  return useCatalogPersistence(
    {
      sortableFields: SORTABLE_FIELDS,
      loggerScope: 'template-catalog-persistence',
      urlComparisonDefaults: URL_COMPARISON_DEFAULTS,
    },
    fallbackState as CatalogStateSnapshot<SortableTemplateField>
  ) as {
    initialState: TemplateCatalogStateSnapshot;
    persistState: (snapshot: TemplateCatalogStateSnapshot) => void;
  };
};
