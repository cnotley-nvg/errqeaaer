import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { gql } from 'graphql-request';

import { graphqlClient } from '../api/graphqlClient';
import type {
  AttributeMap,
  KitOptions,
  KitCompatibleStandard as SchemaKitCompatibleStandard,
  KitCompatibleStandardsInput as SchemaKitCompatibleStandardsInput,
} from '@amzn/global-realty-mosaic-graphql-schema';

export type KitOptionsData = KitOptions;
export type KitCompatibleStandard = SchemaKitCompatibleStandard;
export type KitCompatibleStandardsInput = SchemaKitCompatibleStandardsInput;

export interface CreateKitFormInput {
  name: string;
  description?: string;
  region: string;
  program?: string[] | null;
  projectType: string[];
  roomFeatureZone?: string[] | null;
  dataType?: string | null;
  standardVersionIds: string[];
}

interface KitOptionsQueryResponse {
  kitOptions: KitOptionsData;
}

interface KitCompatibleStandardsResponse {
  kitCompatibleStandards: KitCompatibleStandard[];
}

interface CreateKitMutationResponse {
  createKit: {
    success: boolean;
    message?: string | null;
    kit?: {
      id: string;
      name: string;
    } | null;
  };
}

const EMPTY_OPTIONS: KitOptionsData = Object.freeze({
  regions: [],
  programs: [],
  useCases: [],
  projectTypes: [],
  roomFeatureZones: [],
  dataTypes: [],
});

const KIT_OPTIONS_QUERY = gql`
  query KitOptions {
    kitOptions {
      regions
      programs
      useCases
      projectTypes
      roomFeatureZones
      dataTypes
    }
  }
`;

const KIT_COMPATIBLE_STANDARDS_QUERY = gql`
  query KitCompatibleStandards($input: KitCompatibleStandardsInput!) {
    kitCompatibleStandards(input: $input) {
      id
      standardId
      standardName
      version
      region
      program
      useCase
      roomFeatureZone
      dataType
      projectType
    }
  }
`;

const CREATE_KIT_MUTATION = gql`
  mutation CreateKit($input: CreateKitInput!) {
    createKit(input: $input) {
      success
      message
      kit {
        id
        name
      }
    }
  }
`;

const DEFAULT_INITIAL_VERSION = '1.0.0';

const buildAttributeMap = (input: CreateKitFormInput): AttributeMap => {
  const attributes: AttributeMap = {
    region: input.region,
    projectType: input.projectType,
  };

  if (input.program?.length) {
    attributes.program = input.program;
  }

  if (input.roomFeatureZone?.length) {
    attributes.roomFeatureZone = input.roomFeatureZone;
  }

  if (input.dataType) {
    attributes.dataType = input.dataType;
  }

  return attributes;
};

const normalizeInput = (value: string | null | undefined): string | null => {
  if (!value) {
    return null;
  }
  const trimmed = value.trim();
  return trimmed.length ? trimmed : null;
};

const normalizeList = (values?: readonly string[] | null): string[] => {
  if (!values) {
    return [];
  }

  const unique = new Set<string>();
  values.forEach((value) => {
    const normalized = normalizeInput(value);
    if (normalized) {
      unique.add(normalized);
    }
  });

  return Array.from(unique).sort((a, b) => a.localeCompare(b));
};

const buildFiltersKey = (filters: KitCompatibleStandardsInput | null): string => {
  if (!filters) {
    return 'null';
  }

  const normalized = {
    regions: normalizeList(filters.regions),
    programs: normalizeList(filters.programs),
    projectTypes: normalizeList(filters.projectTypes),
    roomFeatureZones: normalizeList(filters.roomFeatureZones),
    dataTypes: normalizeList(filters.dataTypes),
  };

  return JSON.stringify(normalized);
};

export const useKitOptions = () => {
  const [options, setOptions] = useState<KitOptionsData>(EMPTY_OPTIONS);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState<boolean>(false);

  const fetchOptions = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await graphqlClient.request<KitOptionsQueryResponse>(KIT_OPTIONS_QUERY);
      setOptions(response.kitOptions ?? EMPTY_OPTIONS);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load kit options.');
      setOptions(EMPTY_OPTIONS);
    } finally {
      setLoading(false);
      setIsLoaded(true);
    }
  }, []);

  useEffect(() => {
    void fetchOptions();
  }, [fetchOptions]);

  return {
    options,
    loading,
    error,
    isLoaded,
    refetch: fetchOptions,
  } as const;
};

export const useKitCompatibleStandards = (filters: KitCompatibleStandardsInput | null) => {
  const [standards, setStandards] = useState<KitCompatibleStandard[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [hasFetched, setHasFetched] = useState<boolean>(false);
  const lastFiltersRef = useRef<KitCompatibleStandardsInput | null>(null);

  const execute = useCallback(async (input: KitCompatibleStandardsInput) => {
    setLoading(true);
    setError(null);
    try {
      const response = await graphqlClient.request<KitCompatibleStandardsResponse>(
        KIT_COMPATIBLE_STANDARDS_QUERY,
        { input }
      );
      setStandards(response.kitCompatibleStandards ?? []);
      return response.kitCompatibleStandards ?? [];
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to load compatible standards.';
      setError(message);
      setStandards([]);
      return [];
    } finally {
      setLoading(false);
      setHasFetched(true);
    }
  }, []);

  const filtersKey = useMemo(() => buildFiltersKey(filters), [filters]);

  useEffect(() => {
    if (!filters) {
      lastFiltersRef.current = null;
      setStandards([]);
      setHasFetched(false);
      return;
    }

    const regions = normalizeList(filters.regions);
    const programs = normalizeList(filters.programs);
    const projectTypes = normalizeList(filters.projectTypes);
    const roomFeatureZones = normalizeList(filters.roomFeatureZones);
    const dataTypes = normalizeList(filters.dataTypes);

    const normalizedFilters: KitCompatibleStandardsInput = {};

    if (regions.length) {
      normalizedFilters.regions = regions;
    }

    if (programs.length) {
      normalizedFilters.programs = programs;
    }

    if (projectTypes.length) {
      normalizedFilters.projectTypes = projectTypes;
    }

    if (roomFeatureZones.length) {
      normalizedFilters.roomFeatureZones = roomFeatureZones;
    }

    if (dataTypes.length) {
      normalizedFilters.dataTypes = dataTypes;
    }

    if (!Object.keys(normalizedFilters).length) {
      lastFiltersRef.current = null;
      setStandards([]);
      setHasFetched(false);
      return;
    }

    lastFiltersRef.current = normalizedFilters;
    void execute(normalizedFilters);
  }, [execute, filtersKey, filters]);

  const refetch = useCallback(() => {
    if (!lastFiltersRef.current) {
      setStandards([]);
      return Promise.resolve([] as KitCompatibleStandard[]);
    }

    return execute(lastFiltersRef.current);
  }, [execute]);

  return {
    standards,
    loading,
    error,
    hasFetched,
    refetch,
  } as const;
};

export const useCreateKit = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [createdKitName, setCreatedKitName] = useState<string | null>(null);

  const createKit = useCallback(async (input: CreateKitFormInput) => {
    setLoading(true);
    setError(null);

    const attributes = buildAttributeMap(input);

    try {
      const payload = {
        name: input.name,
        desc: normalizeInput(input.description ?? null) ?? undefined,
        initialVersion: {
          version: DEFAULT_INITIAL_VERSION,
          standardVersionIds: input.standardVersionIds,
          attributes,
        },
      } as const;

      const response = await graphqlClient.request<CreateKitMutationResponse>(CREATE_KIT_MUTATION, {
        input: payload,
      });

      if (!response.createKit.success) {
        const message = response.createKit.message ?? 'Unable to create kit.';
        setCreatedKitName(null);
        setError(message);
        return null;
      }

      setCreatedKitName(response.createKit.kit?.name ?? input.name);
      return response.createKit.kit ?? null;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to create kit.';
      setCreatedKitName(null);
      setError(message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const reset = useCallback(() => {
    setError(null);
    setCreatedKitName(null);
  }, []);

  return {
    createKit,
    loading,
    error,
    createdKitName,
    reset,
  } as const;
};
