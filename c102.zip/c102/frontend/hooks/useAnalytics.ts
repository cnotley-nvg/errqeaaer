import { useCallback } from 'react';

type GrMetrics = {
  track: (eventName: string, eventData?: Record<string, any>) => void;
  identify: (userData: Record<string, any>) => void;
};

/**
 * Hook for tracking analytics events
 * Uses GlobalRealty UI-Metrics (umami) tracker
 */
export const useAnalytics = () => {
  const getAnalytics = useCallback((): GrMetrics | null => {
    if (typeof window !== 'undefined' && (window as any).umami) {
      return (window as any).umami;
    }
    return null;
  }, []);

  const trackEvent = useCallback(
    (eventName: string, eventData?: Record<string, any>) => {
      const analytics = getAnalytics();
      if (analytics) {
        try {
          analytics.track(eventName, eventData);
        } catch (error) {
          console.error('Failed to track analytics event', error);
        }
      }
    },
    [getAnalytics]
  );

  const identifyUser = useCallback(
    (userData: Record<string, any>) => {
      const analytics = getAnalytics();
      if (analytics) {
        try {
          analytics.identify(userData);
        } catch (error) {
          console.error('Failed to identify user', error);
        }
      }
    },
    [getAnalytics]
  );

  // Specific tracking methods
  const trackKitCreated = useCallback(
    (kitData: { kitId: string; kitName: string; standardCount: number; regions?: string[] }) => {
      trackEvent('kit_created', kitData);
    },
    [trackEvent]
  );

  const trackKitUpdated = useCallback(
    (kitData: { kitId: string; kitName: string; changes?: string[] }) => {
      trackEvent('kit_updated', kitData);
    },
    [trackEvent]
  );

  const trackDesignOptimization = useCallback(
    (data: {
      squareFootage?: number;
      designTemplate?: string;
      analysisCount?: number;
      hasLightningProtection?: boolean;
      hasWindLoading?: boolean;
      hasElectrical?: boolean;
    }) => {
      trackEvent('design_optimization', data);
    },
    [trackEvent]
  );

  const trackSearchQuery = useCallback(
    (data: { searchType: string; filterCount?: number; resultCount?: number }) => {
      trackEvent('search_query', data);
    },
    [trackEvent]
  );

  const trackStandardViewed = useCallback(
    (data: { standardId: string; standardName: string; version?: string }) => {
      trackEvent('standard_viewed', data);
    },
    [trackEvent]
  );

  const trackStandardDownloaded = useCallback(
    (data: { standardId: string; standardName: string; format: string }) => {
      trackEvent('standard_downloaded', data);
    },
    [trackEvent]
  );

  const trackError = useCallback(
    (data: { errorType: string; errorMessage?: string; context?: string }) => {
      trackEvent('error_occurred', data);
    },
    [trackEvent]
  );

  return {
    trackEvent,
    identifyUser,
    trackKitCreated,
    trackKitUpdated,
    trackDesignOptimization,
    trackSearchQuery,
    trackStandardViewed,
    trackStandardDownloaded,
    trackError,
    getAnalytics,
  };
};
