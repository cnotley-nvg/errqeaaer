import { useState, useEffect, useMemo } from 'react';
import type { PropertyFilterProps } from '@amzn/awsui-components-console';
import { gql } from 'graphql-request';
import { graphqlClient } from '../api/graphqlClient';
import { formatProgramLabel } from '../utils/attributeDisplay';

/**
 * All available template filter fields.
 * Use this constant when you need all filter options (e.g., in catalog).
 */
export const ALL_TEMPLATE_FILTER_FIELDS = [
  'name',
  'region',
  'facilityType',
  'program',
  'businessUnit',
  'generation',
  'createdBy',
  'version',
];

/**
 * Hook to fetch filter options for one or more template fields in a single batched request.
 *
 * Uses GraphQL field aliases to batch multiple field queries into one HTTP request.
 * Automatically deduplicates field names and formats output for PropertyFilter components.
 *
 * Performance: N fields → 1 HTTP request (vs N separate requests)
 *
 * @param fields - Array of field names to fetch options for (e.g., ['region', 'program'])
 * @returns Filter options in PropertyFilter format, loading state, and error
 *
 * @example
 * ```tsx
 * // Fetch all filter fields (catalog)
 * const { filteringOptions, loading } = useTemplateFilterOptions(ALL_TEMPLATE_FILTER_FIELDS);
 *
 * // Fetch specific fields
 * const { filteringOptions, loading } = useTemplateFilterOptions(['region', 'program']);
 *
 * // Fetch single field
 * const { filteringOptions, loading } = useTemplateFilterOptions(['region']);
 * ```
 */
export const useTemplateFilterOptions = (
  fields: string[]
): {
  filteringOptions: PropertyFilterProps.FilteringOption[];
  loading: boolean;
  error: Error | null;
} => {
  // Deduplicate fields to avoid redundant queries (preserve order)
  const uniqueFields = useMemo(() => Array.from(new Set(fields)), [fields]);

  // Create a stable string key for dependencies (avoids array reference issues)
  const fieldsKey = useMemo(() => uniqueFields.join(','), [uniqueFields]);

  // Build dynamic GraphQL query with field aliases
  const query = useMemo(() => {
    if (uniqueFields.length === 0) {
      // Return empty query for empty input
      return gql`
        query EmptyFilterOptions {
          __typename
        }
      `;
    }

    const aliasedFields = uniqueFields
      .map((field) => `${field}: templateFilterOptions(fieldName: "${field}")`)
      .join('\n    ');

    return gql`
      query DynamicFilterOptions {
        ${aliasedFields}
      }
    `;
    // Use fieldsKey instead of uniqueFields to avoid array reference issues
  }, [fieldsKey, uniqueFields]);

  const [data, setData] = useState<Record<string, string[]> | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    let isMounted = true;

    const fetchOptions = async () => {
      try {
        setLoading(true);
        setError(null);

        // Skip fetch if no fields requested
        if (uniqueFields.length === 0) {
          if (isMounted) {
            setData({});
          }
          return;
        }

        const response = await graphqlClient.request<Record<string, string[]>>(query);

        if (isMounted) {
          setData(response);
        }
      } catch (err) {
        if (isMounted) {
          setError(err instanceof Error ? err : new Error('Failed to fetch filter options'));
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    fetchOptions();

    return () => {
      isMounted = false;
    };
  }, [query, fieldsKey, uniqueFields.length]);

  // Transform data to PropertyFilter format
  const filteringOptions: PropertyFilterProps.FilteringOption[] = useMemo(() => {
    if (!data) return [];

    return uniqueFields.flatMap((field) => {
      const values = data[field] || [];
      return values.map((value) => ({
        propertyKey: field,
        value,
        label: field === 'program' ? formatProgramLabel(value) : value,
      }));
    });
  }, [data, uniqueFields]);

  return {
    filteringOptions,
    loading,
    error,
  };
};
