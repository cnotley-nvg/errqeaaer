import { useCallback, useMemo } from 'react';
import type { PropertyFilterQuery } from '@amzn/awsui-collection-hooks';

import {
  useStandardCatalogPersistence,
  type SortableField,
  type StandardCatalogStateSnapshot,
} from './useStandardCatalogPersistence';
import type { FilterInput } from '@amzn/global-realty-mosaic-graphql-schema';
import { buildFilterInput } from '../utils/standardFilterUtils';
import { useCatalogPreferences } from '../components/standards/catalog/preferences';
import { useCatalogControls } from './shared/useCatalogControls';

/**
 * @deprecated Use updatePageSizeFallback from useCatalogPreferences hook instead
 */
export const savePageSizeFallback = (pageSize: number): void => {
  console.warn(
    '[useStandardCatalogControls] savePageSizeFallback is deprecated. Use updatePageSizeFallback from useCatalogPreferences hook instead.'
  );
};

export interface UseStandardCatalogControlsResult {
  viewType: 'card' | 'table';
  propertyFilterQuery: PropertyFilterQuery;
  sortingField: SortableField;
  sortingDescending: boolean;
  pageIndex: number;
  pageSize: number;
  filterInput: FilterInput;
  handleViewTypeChange: (nextViewType: 'card' | 'table') => void;
  handlePropertyFilterChange: (nextQuery: PropertyFilterQuery) => void;
  handleSortingChange: (field: SortableField, descending: boolean) => void;
  handlePageChange: (nextPage: number) => void;
  handlePageSizeChange: (nextPageSize: number) => void;
}

export const useStandardCatalogControls = (): UseStandardCatalogControlsResult => {
  // Get preferences and update functions from versioned storage
  const { preferences, updateViewType } = useCatalogPreferences();

  // Get default state with preferences fallback, evaluated at hook call time
  const defaultCatalogState = useMemo(
    (): StandardCatalogStateSnapshot => ({
      viewType: preferences.viewType, // From versioned storage
      propertyFilterQuery: {
        operation: 'and',
        tokens: [],
        tokenGroups: [],
      },
      sortingField: 'name',
      sortingDescending: false,
      pageIndex: 1,
      pageSize: preferences.pageSizeFallback, // From versioned storage
    }),
    [preferences.viewType, preferences.pageSizeFallback]
  );

  const { initialState, persistState } = useStandardCatalogPersistence(defaultCatalogState);

  // Memoize buildFilterInput to maintain stable reference
  const buildFilterInputCallback = useCallback(
    (
      query: PropertyFilterQuery,
      pageIndex: number,
      pageSize: number,
      sortingField: SortableField,
      sortingDescending: boolean
    ) => buildFilterInput(query, pageIndex, sortingField, sortingDescending, pageSize),
    []
  );

  return useCatalogControls({
    updateViewType, // Use versioned storage update function
    buildFilterInput: buildFilterInputCallback,
    initialState,
    persistState,
  });
};

export type { PropertyFilterQuery } from '@amzn/awsui-collection-hooks';
export type { SortableField };
