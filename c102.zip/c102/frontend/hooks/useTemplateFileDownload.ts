import { useCallback, useState } from 'react';
import { gql } from 'graphql-request';

import { graphqlClient } from '../api/graphqlClient';
import { triggerDownload } from '../utils/downloadUtils';

interface TemplateFileSignedUrlResponse {
  templateFileSignedUrl: string | null;
}

const TEMPLATE_FILE_SIGNED_URL_QUERY = gql`
  query TemplateFileSignedUrl($templateFileId: ID!, $disposition: SignedUrlDisposition) {
    templateFileSignedUrl(templateFileId: $templateFileId, disposition: $disposition)
  }
`;

export const useTemplateFileDownload = () => {
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const download = useCallback(async (templateFileId: string) => {
    setDownloadingId(templateFileId);
    setError(null);

    try {
      const response = await graphqlClient.request<TemplateFileSignedUrlResponse>(
        TEMPLATE_FILE_SIGNED_URL_QUERY,
        {
          templateFileId,
          disposition: 'ATTACHMENT',
        }
      );

      const url = response.templateFileSignedUrl;
      if (url) {
        triggerDownload(url);
      } else {
        setError('Download link unavailable.');
      }

      return url;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unable to generate download link.';
      setError(message);
      return null;
    } finally {
      setDownloadingId(null);
    }
  }, []);

  return {
    downloadingId,
    error,
    download,
    clearError: () => setError(null),
  };
};
