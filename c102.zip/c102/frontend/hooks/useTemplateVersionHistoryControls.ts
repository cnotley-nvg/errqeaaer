import { useCallback, useMemo, useState } from 'react';
import type {
  FilterInput,
  FilterOperator,
  FilterTokenGroupInput,
} from '@amzn/global-realty-mosaic-graphql-schema';

const DEFAULT_PAGE_SIZE = 20;

export type SortableTemplateVersionField = 'category' | 'title' | 'dci' | 'updatedAt';

export interface UseTemplateVersionHistoryControlsResult {
  sortingField: SortableTemplateVersionField;
  sortingDescending: boolean;
  pageIndex: number;
  filterInput: FilterInput;
  searchValue: string;
  handleSortingChange: (field: SortableTemplateVersionField, descending: boolean) => void;
  handlePageChange: (nextPage: number) => void;
  handleSearchChange: (value: string) => void;
}

interface TemplateVersionFilterState {
  searchTerm?: string;
}

const appendFilterToken = (
  tokens: FilterTokenGroupInput[],
  propertyKey: string,
  operator: FilterOperator,
  rawValue?: string
) => {
  const value = rawValue?.trim();
  if (!value) {
    return;
  }

  tokens.push({ propertyKey, operator, value });
};

const buildFilterInputFromState = (
  filter: TemplateVersionFilterState | undefined,
  pageIndex: number,
  sortingField: SortableTemplateVersionField,
  sortingDescending: boolean
): FilterInput => {
  const tokens: FilterTokenGroupInput[] = [];

  if (filter?.searchTerm) {
    appendFilterToken(tokens, 'title', 'CONTAINS', filter.searchTerm);
  }

  const normalizedPageIdx = Number.isFinite(pageIndex) ? Math.max(0, Math.floor(pageIndex - 1)) : 0;

  return {
    pageIdx: normalizedPageIdx,
    limit: DEFAULT_PAGE_SIZE,
    orderBy: sortingField,
    orderDesc: sortingDescending,
    query: tokens.length
      ? {
          operation: 'AND',
          tokenGroups: tokens,
        }
      : undefined,
  };
};

export const useTemplateVersionHistoryControls = (): UseTemplateVersionHistoryControlsResult => {
  const [sortingField, setSortingField] = useState<SortableTemplateVersionField>('updatedAt');
  const [sortingDescending, setSortingDescending] = useState<boolean>(true);
  const [pageIndex, setPageIndex] = useState<number>(1);

  const [filter, setFilter] = useState<TemplateVersionFilterState | undefined>(undefined);

  const filterInput = useMemo(
    () => buildFilterInputFromState(filter, pageIndex, sortingField, sortingDescending),
    [filter, pageIndex, sortingField, sortingDescending]
  );

  const handleSortingChange = useCallback(
    (field: SortableTemplateVersionField, descending: boolean) => {
      setSortingField(field);
      setSortingDescending(descending);
      setPageIndex(1);
    },
    []
  );

  const handlePageChange = useCallback((nextPage: number) => {
    setPageIndex(nextPage);
  }, []);

  const handleSearchChange = useCallback((value: string) => {
    const normalized = value.trim();
    setFilter((previous) => ({
      ...(previous ?? {}),
      searchTerm: normalized.length ? normalized : undefined,
    }));
    setPageIndex(1);
  }, []);

  return {
    sortingField,
    sortingDescending,
    pageIndex,
    filterInput,
    searchValue: filter?.searchTerm ?? '',
    handleSortingChange,
    handlePageChange,
    handleSearchChange,
  };
};
