import { useCallback, useMemo } from 'react';
import type { PropertyFilterQuery } from '@amzn/awsui-collection-hooks';

import type { FilterInput } from '@amzn/global-realty-mosaic-graphql-schema';

import { toFilterQueryInput } from '../utils/standardFilterUtils';
import {
  type KitCatalogSortableField,
  type PublishedKitCatalogStateSnapshot,
  usePublishedKitCatalogPersistence,
} from './usePublishedKitCatalogPersistence';
import { useCatalogControls } from './shared/useCatalogControls';
import { useCatalogPreferences } from '../components/kits/catalog/preferences';

export interface UsePublishedKitCatalogControlsResult {
  propertyFilterQuery: PropertyFilterQuery;
  sortingField: KitCatalogSortableField;
  sortingDescending: boolean;
  pageIndex: number;
  pageSize: number;
  filterInput: FilterInput;
  handlePropertyFilterChange: (nextQuery: PropertyFilterQuery) => void;
  handleSortingChange: (field: KitCatalogSortableField, descending: boolean) => void;
  handlePageChange: (nextPageIndex: number) => void;
  handlePageSizeChange: (nextPageSize: number) => void;
}

export const usePublishedKitCatalogControls = (): UsePublishedKitCatalogControlsResult => {
  const { preferences } = useCatalogPreferences();

  const defaultCatalogState = useMemo(
    (): PublishedKitCatalogStateSnapshot => ({
      viewType: 'table',
      propertyFilterQuery: { operation: 'and', tokens: [], tokenGroups: [] },
      sortingField: 'region',
      sortingDescending: false,
      pageIndex: 1,
      pageSize: preferences.pageSizeFallback,
    }),
    [preferences.pageSizeFallback]
  );

  const { initialState, persistState } = usePublishedKitCatalogPersistence(defaultCatalogState);

  const buildFilterInput = useCallback(
    (
      query: PropertyFilterQuery,
      pageIndex: number,
      pageSize: number,
      sortingField: KitCatalogSortableField,
      sortingDescending: boolean
    ): FilterInput => {
      const normalizedPageIdx = Number.isFinite(pageIndex)
        ? Math.max(0, Math.floor(pageIndex - 1))
        : 0;

      const base: FilterInput = {
        pageIdx: normalizedPageIdx,
        limit: pageSize,
        orderBy: sortingField,
        orderDesc: sortingDescending,
      };

      const filterQuery = toFilterQueryInput(query);
      return filterQuery ? { ...base, query: filterQuery } : base;
    },
    []
  );

  const controls = useCatalogControls({
    updateViewType: () => undefined, // kits catalog is table-only today
    buildFilterInput,
    initialState,
    persistState,
  });

  return {
    propertyFilterQuery: controls.propertyFilterQuery,
    sortingField: controls.sortingField,
    sortingDescending: controls.sortingDescending,
    pageIndex: controls.pageIndex,
    pageSize: controls.pageSize,
    filterInput: controls.filterInput,
    handlePropertyFilterChange: controls.handlePropertyFilterChange,
    handleSortingChange: controls.handleSortingChange,
    handlePageChange: controls.handlePageChange,
    handlePageSizeChange: controls.handlePageSizeChange,
  };
};
