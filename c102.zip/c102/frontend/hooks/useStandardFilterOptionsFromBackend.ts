import { useMemo } from 'react';
import type { PropertyFilterProps } from '@amzn/awsui-components-console';
import { useStandardFilterOptions } from './useStandardFilterOptions';
import { formatProgramLabel } from '../utils/attributeDisplay';

export interface StandardFilteringOptions {
  filteringOptions: ReadonlyArray<PropertyFilterProps.FilteringOption>;
  loading: boolean;
  error: Error | null;
}

/**
 * Hook to fetch all filter options for standard catalog from backend.
 *
 * Fetches filter options for all filterable fields from latest standard versions.
 * Returns options suitable for PropertyFilter dropdown (checkbox multi-select).
 *
 * This replaces the client-side approach that only showed values from the current page.
 * Now shows ALL available values from the database.
 *
 * @returns Filter options, loading state, and error
 */
export const useStandardFilterOptionsFromBackend = (): StandardFilteringOptions => {
  // Fetch options for each field from backend
  const {
    options: nameOptions,
    loading: nameLoading,
    error: nameError,
  } = useStandardFilterOptions('name');
  const {
    options: versionOptions,
    loading: versionLoading,
    error: versionError,
  } = useStandardFilterOptions('version');
  const {
    options: accProjectIdOptions,
    loading: accProjectIdLoading,
    error: accProjectIdError,
  } = useStandardFilterOptions('accProjectId');
  const {
    options: accCreatedByOptions,
    loading: accCreatedByLoading,
    error: accCreatedByError,
  } = useStandardFilterOptions('accCreatedBy');
  const {
    options: accUpdatedByOptions,
    loading: accUpdatedByLoading,
    error: accUpdatedByError,
  } = useStandardFilterOptions('accUpdatedBy');
  const {
    options: programOptions,
    loading: programLoading,
    error: programError,
  } = useStandardFilterOptions('program');
  const {
    options: regionOptions,
    loading: regionLoading,
    error: regionError,
  } = useStandardFilterOptions('region');
  const {
    options: projectTypeOptions,
    loading: projectTypeLoading,
    error: projectTypeError,
  } = useStandardFilterOptions('projectType');
  const {
    options: roomFeatureZoneOptions,
    loading: roomFeatureZoneLoading,
    error: roomFeatureZoneError,
  } = useStandardFilterOptions('roomFeatureZone');
  const {
    options: updateCadenceOptions,
    loading: updateCadenceLoading,
    error: updateCadenceError,
  } = useStandardFilterOptions('updateCadence');

  const loading =
    nameLoading ||
    versionLoading ||
    accProjectIdLoading ||
    accCreatedByLoading ||
    accUpdatedByLoading ||
    programLoading ||
    regionLoading ||
    projectTypeLoading ||
    roomFeatureZoneLoading ||
    updateCadenceLoading;

  const error =
    nameError ||
    versionError ||
    accProjectIdError ||
    accCreatedByError ||
    accUpdatedByError ||
    programError ||
    regionError ||
    projectTypeError ||
    roomFeatureZoneError ||
    updateCadenceError;

  const filteringOptions: PropertyFilterProps.FilteringOption[] = useMemo(() => {
    return [
      ...nameOptions.map((value) => ({ propertyKey: 'name', value, label: value })),
      ...versionOptions.map((value) => ({ propertyKey: 'version', value, label: value })),
      ...accProjectIdOptions.map((value) => ({ propertyKey: 'accProjectId', value, label: value })),
      ...accCreatedByOptions.map((value) => ({
        propertyKey: 'accCreatedBy',
        value,
        label: value,
      })),
      ...accUpdatedByOptions.map((value) => ({
        propertyKey: 'accUpdatedBy',
        value,
        label: value,
      })),
      ...programOptions.map((value) => ({
        propertyKey: 'program',
        value,
        label: formatProgramLabel(value),
      })),
      ...regionOptions.map((value) => ({ propertyKey: 'region', value, label: value })),
      ...projectTypeOptions.map((value) => ({ propertyKey: 'projectType', value, label: value })),
      ...roomFeatureZoneOptions.map((value) => ({
        propertyKey: 'roomFeatureZone',
        value,
        label: value,
      })),
      ...updateCadenceOptions.map((value) => ({
        propertyKey: 'updateCadence',
        value,
        label: value,
      })),
    ];
  }, [
    nameOptions,
    versionOptions,
    accProjectIdOptions,
    accCreatedByOptions,
    accUpdatedByOptions,
    programOptions,
    regionOptions,
    projectTypeOptions,
    roomFeatureZoneOptions,
    updateCadenceOptions,
  ]);

  return {
    filteringOptions,
    loading,
    error,
  };
};
