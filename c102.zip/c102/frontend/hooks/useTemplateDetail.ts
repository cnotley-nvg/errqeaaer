import { useCallback, useEffect, useState } from 'react';
import { gql } from 'graphql-request';

import { graphqlClient } from '../api/graphqlClient';
import type { AttributeMap } from '@amzn/global-realty-mosaic-graphql-schema';

export interface TemplateFileDetail {
  id: string;
  accFileId: string;
  displayName: string | null;
  createdAt: string;
}

export interface TemplateVersionDetail {
  id: string;
  version: string;
  isLatest: boolean;
  accFolderId: string;
  brsId?: string | null;
  createdAt: string;
  updatedAt: string;
  attributes: AttributeMap;
  files: TemplateFileDetail[];
}

export interface TemplateDetailData {
  id: string;
  name: string;
  description?: string | null;
  accProjectId: string;
  createdAt: string;
  updatedAt: string;
  latestVersionId: string | null;
  versions: TemplateVersionDetail[];
}

interface TemplateDetailResponse {
  template: {
    id: string;
    name: string;
    description?: string | null;
    accProjectId: string;
    createdAt: string;
    updatedAt: string;
    latestVersion: { id: string } | null;
    versions: Array<{
      id: string;
      version: string;
      isLatest: boolean;
      accFolderId: string;
      brsId?: string | null;
      createdAt: string;
      updatedAt: string;
      attributes: AttributeMap;
      files: Array<{
        id: string;
        accFileId: string;
        displayName?: string | null;
        createdAt: string;
      }>;
    }>;
  } | null;
}

const TEMPLATE_DETAIL_QUERY = gql`
  query TemplateDetail($id: ID!) {
    template(id: $id) {
      id
      name
      description
      accProjectId
      createdAt
      updatedAt
      latestVersion {
        id
      }
      versions {
        id
        version
        isLatest
        accFolderId
        brsId
        createdAt
        updatedAt
        attributes
        files {
          id
          accFileId
          displayName
          createdAt
        }
      }
    }
  }
`;

interface UseTemplateDetailState {
  template: TemplateDetailData | null;
  loading: boolean;
  error: string | null;
}

export interface UseTemplateDetailResult extends UseTemplateDetailState {
  refetch: () => Promise<void>;
}

const mapTemplate = (
  record: NonNullable<TemplateDetailResponse['template']>
): TemplateDetailData => ({
  id: record.id,
  name: record.name,
  description: record.description ?? null,
  accProjectId: record.accProjectId,
  createdAt: record.createdAt,
  updatedAt: record.updatedAt,
  latestVersionId: record.latestVersion?.id ?? null,
  versions: record.versions.map((version) => ({
    id: version.id,
    version: version.version,
    isLatest: version.isLatest,
    accFolderId: version.accFolderId,
    brsId: version.brsId ?? null,
    createdAt: version.createdAt,
    updatedAt: version.updatedAt,
    attributes: version.attributes ?? {},
    files: version.files.map((file) => ({
      id: file.id,
      accFileId: file.accFileId,
      displayName: file.displayName ?? null,
      createdAt: file.createdAt,
    })),
  })),
});

export const useTemplateDetail = (id?: string): UseTemplateDetailResult => {
  const [state, setState] = useState<UseTemplateDetailState>({
    template: null,
    loading: Boolean(id),
    error: null,
  });

  const fetchDetail = useCallback(async () => {
    if (!id) {
      setState({ template: null, loading: false, error: 'Template id is required.' });
      return;
    }

    setState((previous) => ({ ...previous, loading: true, error: null }));

    try {
      const response = await graphqlClient.request<TemplateDetailResponse>(TEMPLATE_DETAIL_QUERY, {
        id,
      });
      setState({
        template: response.template ? mapTemplate(response.template) : null,
        loading: false,
        error: null,
      });
    } catch (error) {
      setState({
        template: null,
        loading: false,
        error: error instanceof Error ? error.message : 'Unable to load template.',
      });
    }
  }, [id]);

  useEffect(() => {
    fetchDetail();
  }, [fetchDetail]);

  return {
    ...state,
    refetch: fetchDetail,
  };
};
