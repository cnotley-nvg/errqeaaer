import type { PropertyFilterQuery } from '@amzn/awsui-collection-hooks';
import { useCatalogPersistence, type CatalogStateSnapshot } from './shared/useCatalogPersistence';

/**
 * Standard-specific sortable fields
 */
export type SortableField =
  | 'name'
  | 'region'
  | 'projectType'
  | 'updateCadence'
  | 'version'
  | 'roomFeatureZone'
  | 'accCreatedBy'
  | 'accUpdatedBy'
  | 'accProjectId'
  | 'createdAt'
  | 'updatedAt'
  | 'firstPublishedOn'
  | 'publishedOn';

/**
 * Standard catalog state snapshot
 * Uses the generic CatalogStateSnapshot type
 */
export type StandardCatalogStateSnapshot = CatalogStateSnapshot<SortableField>;

const SORTABLE_FIELDS: ReadonlyArray<SortableField> = [
  'name',
  'region',
  'projectType',
  'updateCadence',
  'version',
  'roomFeatureZone',
  'accCreatedBy',
  'accUpdatedBy',
  'accProjectId',
  'createdAt',
  'updatedAt',
  'firstPublishedOn',
  'publishedOn',
];

/**
 * Hard-coded defaults for URL comparison
 * These determine which values appear in the URL (non-default values are included)
 * Using hard-coded values ensures URL shareability is not affected by localStorage
 */
const URL_COMPARISON_DEFAULTS: Readonly<StandardCatalogStateSnapshot> = {
  viewType: 'card',
  sortingField: 'name',
  sortingDescending: false,
  pageIndex: 1,
  pageSize: 20,
  propertyFilterQuery: { operation: 'and', tokens: [], tokenGroups: [] },
};

/**
 * Standard catalog persistence hook
 * Uses generic useCatalogPersistence with standard-specific configuration
 */
export const useStandardCatalogPersistence = (
  fallbackState: StandardCatalogStateSnapshot
): {
  initialState: StandardCatalogStateSnapshot;
  persistState: (snapshot: StandardCatalogStateSnapshot) => void;
} => {
  return useCatalogPersistence(
    {
      sortableFields: SORTABLE_FIELDS,
      loggerScope: 'standard-catalog-persistence',
      urlComparisonDefaults: URL_COMPARISON_DEFAULTS,
    },
    fallbackState
  );
};
