import { useCallback, useState } from 'react';
import type { CollectionPreferencesProps } from '@amzn/awsui-components-console';

export interface CardBreakpoint {
  minWidth: number;
  cards: number;
}

export interface TablePreferences {
  pageSize?: number;
  visibleContent?: string[];
  wrapLines?: boolean;
  stripedRows?: boolean;
  contentDisplay?: Array<{ id: string; visible?: boolean }>;
  cardsPerRowBreakpoints?: CardBreakpoint[];
}

/**
 * Hook for managing table preferences with localStorage persistence
 * @param key - Unique localStorage key for this table's preferences
 * @param defaultPreferences - Default preferences to use if none are stored
 * @param deprecatedColumns - Optional list of column IDs to remove from stored preferences
 * @returns Tuple of [preferences, updatePreferences, resetPreferences]
 */
export const useTablePreferences = (
  key: string,
  defaultPreferences: TablePreferences,
  deprecatedColumns?: string[]
): [
  TablePreferences,
  (preferences: CollectionPreferencesProps.Preferences) => void,
  () => void,
] => {
  const [preferences, setPreferences] = useState<TablePreferences>(() => {
    try {
      const stored = localStorage.getItem(key);
      if (stored) {
        const parsed = JSON.parse(stored);

        // Filter out deprecated columns from contentDisplay
        if (deprecatedColumns && deprecatedColumns.length > 0 && parsed.contentDisplay) {
          parsed.contentDisplay = parsed.contentDisplay.filter(
            (item: { id: string; visible?: boolean }) => !deprecatedColumns.includes(item.id)
          );
        }

        // Merge with defaults to ensure all required properties exist
        return { ...defaultPreferences, ...parsed };
      }
    } catch (error) {
      console.warn(`Failed to load table preferences from localStorage (key: ${key}):`, error);
    }
    return defaultPreferences;
  });

  const updatePreferences = useCallback(
    (newPreferences: CollectionPreferencesProps.Preferences) => {
      const updated: TablePreferences = {
        pageSize: newPreferences.pageSize,
        visibleContent: newPreferences.visibleContent
          ? [...newPreferences.visibleContent]
          : undefined,
        wrapLines: newPreferences.wrapLines,
        stripedRows: newPreferences.stripedRows,
        contentDisplay: newPreferences.contentDisplay
          ? newPreferences.contentDisplay.map((item) => ({
              id: item.id,
              visible: item.visible,
            }))
          : undefined,
        // Preserve existing cardsPerRowBreakpoints if not provided in new preferences
        cardsPerRowBreakpoints:
          (newPreferences as any).cardsPerRowBreakpoints ?? preferences.cardsPerRowBreakpoints,
      };

      setPreferences(updated);

      try {
        localStorage.setItem(key, JSON.stringify(updated));
      } catch (error) {
        console.warn(`Failed to save table preferences to localStorage (key: ${key}):`, error);
      }
    },
    [key, preferences.cardsPerRowBreakpoints]
  );

  const resetPreferences = useCallback(() => {
    setPreferences(defaultPreferences);
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.warn(`Failed to clear table preferences from localStorage (key: ${key}):`, error);
    }
  }, [key, defaultPreferences]);

  return [preferences, updatePreferences, resetPreferences];
};
