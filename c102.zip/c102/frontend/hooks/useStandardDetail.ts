import { useCallback, useEffect, useState } from 'react';
import { gql } from 'graphql-request';

import { graphqlClient } from '../api/graphqlClient';
import type { AttributeMap } from '@amzn/global-realty-mosaic-graphql-schema';

export interface StandardVersionDetail {
  id: string;
  version: string;
  isLatest: boolean;
  accFolderId: string;
  accFileId?: string | null;
  createdAt: Date;
  updatedAt: Date;
  accCreatedAt?: Date | null;
  accCreatedBy?: string | null;
  accUpdatedAt?: Date | null;
  accUpdatedBy?: string | null;
  publishedOn?: Date | null;
  firstPublishedOn?: Date | null;
  attributes: AttributeMap;
  kits: Array<{
    id: string;
    name: string;
    version: string;
  }>;
}

export interface StandardDetailData {
  id: string;
  name: string;
  description?: string | null;
  accProjectId: string;
  createdAt: Date;
  updatedAt: Date;
  latestVersion: StandardVersionDetail | null;
  versions: StandardVersionDetail[];
}

interface StandardDetailResponse {
  standard: {
    id: string;
    name: string;
    description?: string | null;
    accProjectId: string;
    createdAt: string;
    updatedAt: string;
    latestVersion: {
      id: string;
      version: string;
      isLatest: boolean;
      accFolderId: string;
      accFileId?: string | null;
      createdAt: string;
      updatedAt: string;
      accCreatedAt?: string | null;
      accCreatedBy?: string | null;
      accUpdatedAt?: string | null;
      accUpdatedBy?: string | null;
      publishedOn?: string | null;
      firstPublishedOn?: string | null;
      attributes: AttributeMap;
      kits: Array<{
        id: string;
        version: string;
        kit: {
          id: string;
          name: string;
        };
      }>;
    } | null;
    versions: Array<{
      id: string;
      version: string;
      isLatest: boolean;
      accFolderId: string;
      accFileId?: string | null;
      createdAt: string;
      updatedAt: string;
      accCreatedAt?: string | null;
      accCreatedBy?: string | null;
      accUpdatedAt?: string | null;
      accUpdatedBy?: string | null;
      publishedOn?: string | null;
      firstPublishedOn?: string | null;
      attributes: AttributeMap;
      kits: Array<{
        id: string;
        version: string;
        kit: {
          id: string;
          name: string;
        };
      }>;
    }>;
  } | null;
}

const STANDARD_DETAIL_QUERY = gql`
  query StandardDetail($id: ID!) {
    standard(id: $id) {
      id
      name
      description
      accProjectId
      createdAt
      updatedAt
      latestVersion {
        id
        version
        isLatest
        accFolderId
        accFileId
        createdAt
        updatedAt
        accCreatedAt
        accCreatedBy
        accUpdatedAt
        accUpdatedBy
        publishedOn
        firstPublishedOn
        attributes
        kits {
          id
          version
          kit {
            id
            name
          }
        }
      }
      versions {
        id
        version
        isLatest
        accFolderId
        accFileId
        createdAt
        updatedAt
        accCreatedAt
        accCreatedBy
        accUpdatedAt
        accUpdatedBy
        publishedOn
        firstPublishedOn
        attributes
        kits {
          id
          version
          kit {
            id
            name
          }
        }
      }
    }
  }
`;

interface UseStandardDetailState {
  standard: StandardDetailData | null;
  loading: boolean;
  error: string | null;
}

export interface UseStandardDetailResult extends UseStandardDetailState {
  refetch: () => Promise<void>;
}

const mapVersion = (
  record: NonNullable<StandardDetailResponse['standard']>['versions'][number]
): StandardVersionDetail => ({
  id: record.id,
  version: record.version,
  isLatest: record.isLatest,
  accFolderId: record.accFolderId,
  accFileId: record.accFileId ?? null,
  createdAt: new Date(record.createdAt),
  updatedAt: new Date(record.updatedAt),
  accCreatedAt: record.accCreatedAt ? new Date(record.accCreatedAt) : null,
  accCreatedBy: record.accCreatedBy ?? null,
  accUpdatedAt: record.accUpdatedAt ? new Date(record.accUpdatedAt) : null,
  accUpdatedBy: record.accUpdatedBy ?? null,
  publishedOn: record.publishedOn ? new Date(record.publishedOn) : null,
  firstPublishedOn: record.firstPublishedOn ? new Date(record.firstPublishedOn) : null,
  attributes: record.attributes ?? {},
  kits: record.kits.map((link) => ({
    id: link.kit.id,
    name: link.kit.name,
    version: link.version,
  })),
});

const mapStandard = (
  record: NonNullable<StandardDetailResponse['standard']>
): StandardDetailData => {
  const versions = record.versions.map(mapVersion);
  const latestVersion = record.latestVersion ? mapVersion(record.latestVersion) : null;

  return {
    id: record.id,
    name: record.name,
    description: record.description ?? null,
    accProjectId: record.accProjectId,
    createdAt: new Date(record.createdAt),
    updatedAt: new Date(record.updatedAt),
    latestVersion,
    versions,
  } satisfies StandardDetailData;
};

export const useStandardDetail = (id?: string): UseStandardDetailResult => {
  const [state, setState] = useState<UseStandardDetailState>({
    standard: null,
    loading: Boolean(id),
    error: null,
  });

  const fetchDetail = useCallback(async () => {
    if (!id) {
      setState({ standard: null, loading: false, error: 'Standard id is required.' });
      return;
    }

    setState((previous) => ({ ...previous, loading: true, error: null }));

    try {
      const response = await graphqlClient.request<StandardDetailResponse>(STANDARD_DETAIL_QUERY, {
        id,
      });
      const record = response.standard;
      setState({
        standard: record ? mapStandard(record) : null,
        loading: false,
        error: null,
      });
    } catch (error) {
      setState({
        standard: null,
        loading: false,
        error: error instanceof Error ? error.message : 'Unable to load standard.',
      });
    }
  }, [id]);

  useEffect(() => {
    fetchDetail();
  }, [fetchDetail]);

  return {
    ...state,
    refetch: fetchDetail,
  };
};
