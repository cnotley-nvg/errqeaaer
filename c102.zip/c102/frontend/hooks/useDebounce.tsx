import { useCallback, useEffect, useRef } from 'react';

export const useDebounce = (
  callback: (...args: typeof Function.arguments) => void,
  delay: number
) => {
  const timeout = useRef<ReturnType<typeof setTimeout>>();

  const debouncedCallback = useCallback(
    (...args: typeof Function.arguments) => {
      if (timeout.current) {
        clearTimeout(timeout.current);
      }

      timeout.current = setTimeout(() => callback(...args), delay);
    },
    [callback, delay]
  );

  useEffect(() => {
    return () => {
      clearTimeout(timeout.current);
    };
  }, []);

  return debouncedCallback;
};
