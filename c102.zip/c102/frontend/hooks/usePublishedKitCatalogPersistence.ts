import type { PropertyFilterQuery } from '@amzn/awsui-collection-hooks';
import { useCatalogPersistence, type CatalogStateSnapshot } from './shared/useCatalogPersistence';

export type KitCatalogSortableField = 'region' | 'program';

export type PublishedKitCatalogStateSnapshot = CatalogStateSnapshot<KitCatalogSortableField>;

const SORTABLE_FIELDS: ReadonlyArray<KitCatalogSortableField> = ['region', 'program'];

/**
 * Hard-coded defaults for URL comparison.
 * These determine which values appear in the URL (non-default values are included).
 */
const URL_COMPARISON_DEFAULTS: Readonly<PublishedKitCatalogStateSnapshot> = {
  viewType: 'table',
  sortingField: 'region',
  sortingDescending: false,
  pageIndex: 1,
  pageSize: 20,
  propertyFilterQuery: { operation: 'and', tokens: [], tokenGroups: [] } as PropertyFilterQuery,
};

export const usePublishedKitCatalogPersistence = (
  fallbackState: PublishedKitCatalogStateSnapshot
): {
  initialState: PublishedKitCatalogStateSnapshot;
  persistState: (snapshot: PublishedKitCatalogStateSnapshot) => void;
} => {
  return useCatalogPersistence(
    {
      sortableFields: SORTABLE_FIELDS,
      loggerScope: 'published-kit-catalog-persistence',
      urlComparisonDefaults: URL_COMPARISON_DEFAULTS,
      validPageSizes: [10, 20, 30, 40],
    },
    fallbackState
  );
};
