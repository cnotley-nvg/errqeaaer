import { GraphQLClient } from 'graphql-request';
import { getAppEnv } from '../config/appEnv';

const defaultEndpoint = 'http://localhost:4000/graphql';

const coerceEndpoint = (candidate: string | undefined): string => {
  const trimmed = candidate?.trim();
  return trimmed || defaultEndpoint;
};

const resolveGraphqlEndpoint = (env?: Record<string, string | undefined>): string => {
  return coerceEndpoint(env?.VITE_GRAPHQL_ENDPOINT);
};

const { graphqlEndpoint, isLocalhost } = getAppEnv();

const handleAuthRedirect = () => {
  if (!isLocalhost) {
    window.location.href = `${window.location.origin}/api/login`;
  }
};

export const graphqlClient = new GraphQLClient(graphqlEndpoint, {
  credentials: 'include',
  fetch: async (url, options) => {
    try {
      return await fetch(url, options);
    } catch (error) {
      // CORS errors from OAuth redirects
      handleAuthRedirect();
      throw error;
    }
  },
  responseMiddleware: (response) => {
    if (response instanceof Error) {
      handleAuthRedirect();
      return;
    }

    // Handle auth redirects (401/403)
    if (response.status === 401 || response.status === 403) {
      handleAuthRedirect();
      return;
    }

    // Detect if AJAX followed a redirect to login page (response is HTML instead of JSON)
    const contentType = response.headers?.get('content-type');
    if (contentType?.includes('text/html')) {
      handleAuthRedirect();
    }
  },
});

export const __testables = {
  resolveGraphqlEndpoint,
  coerceEndpoint,
  defaultEndpoint,
};
