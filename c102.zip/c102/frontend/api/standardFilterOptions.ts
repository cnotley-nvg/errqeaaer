import { gql } from 'graphql-request';

/**
 * GraphQL query to fetch distinct filter values for a specific field from latest standard versions.
 *
 * Supported fields:
 * - Direct: version
 * - Parent: name, accProjectId
 * - ACC Metadata: accCreatedBy, accUpdatedBy
 * - Attributes: program, region, projectType, roomFeatureZone, updateCadence
 *
 * Returns sorted array of unique non-null values from latest versions only.
 */
export const STANDARD_FILTER_OPTIONS_QUERY = gql`
  query StandardFilterOptions($fieldName: String!) {
    standardFilterOptions(fieldName: $fieldName)
  }
`;
