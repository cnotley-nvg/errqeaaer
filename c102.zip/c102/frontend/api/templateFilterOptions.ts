import { gql } from 'graphql-request';

/**
 * GraphQL query to fetch filter options for a specific field from latest template versions.
 *
 * Supported fields:
 * - Direct: version
 * - Parent: name, accProjectId
 * - Attributes: program, region, facilityType, businessUnit, generation, createdBy
 *
 * Returns sorted array of unique non-null values from latest versions only.
 */
export const TEMPLATE_FILTER_OPTIONS_QUERY = gql`
  query TemplateFilterOptions($fieldName: String!) {
    templateFilterOptions(fieldName: $fieldName)
  }
`;

export interface TemplateFilterOptionsVariables {
  fieldName: string;
}

export interface TemplateFilterOptionsResponse {
  templateFilterOptions: string[];
}

/**
 * Batched GraphQL query to fetch filter options for ALL filterable fields at once.
 *
 * Uses GraphQL field aliases to call templateFilterOptions multiple times with different
 * arguments in a single request. This reduces 8 separate HTTP requests to 1.
 *
 * Returns all filter options in a structured object with field names as keys.
 */
export const TEMPLATE_FILTER_OPTIONS_BATCH_QUERY = gql`
  query TemplateFilterOptionsBatch {
    name: templateFilterOptions(fieldName: "name")
    region: templateFilterOptions(fieldName: "region")
    facilityType: templateFilterOptions(fieldName: "facilityType")
    program: templateFilterOptions(fieldName: "program")
    businessUnit: templateFilterOptions(fieldName: "businessUnit")
    generation: templateFilterOptions(fieldName: "generation")
    createdBy: templateFilterOptions(fieldName: "createdBy")
    version: templateFilterOptions(fieldName: "version")
  }
`;

export interface TemplateFilterOptionsBatchResponse {
  name: string[];
  region: string[];
  facilityType: string[];
  program: string[];
  businessUnit: string[];
  generation: string[];
  createdBy: string[];
  version: string[];
}
