import { gql } from 'graphql-request';
import { graphqlClient } from './graphqlClient';

// Optimize design calculation API that includes lightning protection and future calculations

const CALCULATE_OPTIMIZE_DESIGN = gql`
  query CalculateOptimizeDesign($input: OptimizeDesignCalculationInput!) {
    calculateOptimizeDesign(input: $input) {
      lightningProtection {
        recommendation
        nd
        nc
        nsg
        ad
        c
        error
      }
      windLoading {
        recommendation
        guidelineUrl
        tornadoSpeed
        windSpeed
        isTornadoRegion
        error
      }
      heatIndex {
        recommendation
        hvacRecommendation
        riskWithoutMitigation
        levels {
          level
          hours
          percentage
        }
        elevation
        operatingHours
        dataAvailable
        error
      }
    }
  }
`;

export interface OptimizeDesignCalculationInput {
  latitude: number;
  longitude: number;
  length: number;
  width: number;
  height: number;
  cd?: number;
  c2?: number;
  squareFootage?: number;
}

export interface LightningProtectionResult {
  recommendation: 'required' | 'not-required' | 'not-provided';
  nd: number;
  nc: number;
  nsg: number;
  ad: number;
  c: number;
  error: string | null;
}

export interface WindLoadingResult {
  recommendation: 'required' | 'not-required' | null;
  guidelineUrl: string | null;
  tornadoSpeed: number | null;
  windSpeed: number | null;
  isTornadoRegion: boolean | null;
  error: string | null;
}

export interface HeatIndexLevel {
  level: number;
  hours: number;
  percentage: number;
}

export interface HeatIndexResult {
  recommendation: 'required' | 'recommended' | 'optional';
  hvacRecommendation: string;
  riskWithoutMitigation: string;
  levels: HeatIndexLevel[];
  elevation: number | null;
  operatingHours: string | null;
  dataAvailable: boolean;
  error: string | null;
}

export interface OptimizeDesignCalculationResult {
  lightningProtection: LightningProtectionResult;
  windLoading: WindLoadingResult | null;
  heatIndex: HeatIndexResult | null;
}

interface CalculateOptimizeDesignResponse {
  calculateOptimizeDesign: OptimizeDesignCalculationResult;
}

export const calculateOptimizeDesign = async (
  input: OptimizeDesignCalculationInput
): Promise<OptimizeDesignCalculationResult> => {
  const response = await graphqlClient.request<CalculateOptimizeDesignResponse>(
    CALCULATE_OPTIMIZE_DESIGN,
    { input }
  );
  return response.calculateOptimizeDesign;
};

export const calculateLightningProtection = async (
  input: OptimizeDesignCalculationInput
): Promise<LightningProtectionResult> => {
  const result = await calculateOptimizeDesign(input);
  return result.lightningProtection;
};
