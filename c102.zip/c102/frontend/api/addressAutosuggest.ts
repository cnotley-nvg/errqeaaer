import { graphqlClient } from './graphqlClient';

export interface AddressSuggestion {
  label: string;
  address: string;
  city?: string;
  state?: string;
  zipcode?: string;
  country?: string;
  latitude?: number;
  longitude?: number;
}

const GET_ADDRESS_SUGGESTIONS_QUERY = `
  query GetAddressSuggestions($text: String!, $country: String, $city: String) {
    getAddressSuggestions(text: $text, country: $country, city: $city) {
      label
      address
      city
      state
      zipcode
      country
      latitude
      longitude
    }
  }
`;

export const getAddressSuggestions = async (
  text?: string,
  country?: string,
  city?: string
): Promise<AddressSuggestion[]> => {
  if (!text || typeof text !== 'string' || text.trim().length < 2) return [];

  try {
    const response = await graphqlClient.request<{ getAddressSuggestions: AddressSuggestion[] }>(
      GET_ADDRESS_SUGGESTIONS_QUERY,
      { text: text.trim(), country, city }
    );
    return response.getAddressSuggestions || [];
  } catch (error) {
    console.error('Autosuggest error:', error);
    return [];
  }
};
