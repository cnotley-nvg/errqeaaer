import { graphqlClient } from './graphqlClient';

export interface GeocodeResult {
  latitude: number;
  longitude: number;
  address: string;
  city?: string;
  state?: string;
  zipcode?: string;
  country?: string;
}

const GEOCODE_ADDRESS_QUERY = `
  query GeocodeAddress($address: String!, $zipcode: String) {
    geocodeAddress(address: $address, zipcode: $zipcode) {
      latitude
      longitude
      address
      city
      state
      zipcode
      country
    }
  }
`;

const REVERSE_GEOCODE_QUERY = `
  query ReverseGeocodeCoordinates($latitude: Float!, $longitude: Float!) {
    reverseGeocodeCoordinates(latitude: $latitude, longitude: $longitude) {
      latitude
      longitude
      address
      city
      state
      zipcode
      country
    }
  }
`;

export const geocodeAddress = async (
  address: string,
  zipcode?: string
): Promise<GeocodeResult | null> => {
  try {
    const response = await graphqlClient.request<{ geocodeAddress: GeocodeResult | null }>(
      GEOCODE_ADDRESS_QUERY,
      { address, zipcode }
    );
    return response.geocodeAddress;
  } catch (error) {
    console.error('Geocoding error:', error);
    return null;
  }
};

export const reverseGeocodeCoordinates = async (
  latitude: number,
  longitude: number
): Promise<GeocodeResult | null> => {
  try {
    const response = await graphqlClient.request<{
      reverseGeocodeCoordinates: GeocodeResult | null;
    }>(REVERSE_GEOCODE_QUERY, { latitude, longitude });
    return response.reverseGeocodeCoordinates;
  } catch (error) {
    console.error('Reverse geocoding error:', error);
    return null;
  }
};
