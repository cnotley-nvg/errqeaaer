import { gql } from 'graphql-request';
import { graphqlClient } from './graphqlClient';

// Electrical benchmark calculation API

const ELECTRICAL_LOAD_LOOKUP_BY_TEMPLATE_VERSION_ID = gql`
  query ElectricalLoadLookupByTemplateId($templateVersionId: ID!) {
    electricalLoadLookupsByTemplateVersion(templateVersionId: $templateVersionId) {
      category
      connectedLoadKVA
      demandDiversityFactor
      utilityDemandFactor
    }
  }
`;

const CALCULATE_ELECTRICAL = gql`
  query CalculateElectrical($input: ElectricalCalculatorInput!) {
    calculateElectrical(input: $input) {
      categoryLoads {
        category
        connectedLoad {
          kVA
          amps
        }
        demandDiversityFactor
        diversifiedLoad {
          kVA
          amps
        }
        utilityDemandFactor
        utilityPowerDemand {
          kVA
          amps
        }
      }
      total {
        connectedLoad {
          kVA
          amps
        }
        diversifiedLoad {
          kVA
          amps
        }
        utilityPowerDemand {
          kVA
          amps
        }
      }
      o1 {
        kVA
        amps
      }
      o2 {
        kVA
        amps
      }
      o3 {
        kVA
        amps
      }
      o4
      state
    }
  }
`;

// TypeScript types
export type ElectricalLoad = {
  kVA: number;
  amps: number;
};

export type ElectricalLookupRecord = {
  category: string;
  connectedLoadKVA: number;
  demandDiversityFactor: number;
  utilityDemandFactor: number;
};

export type ElectricalCategoryLoadDetail = {
  category: string;
  connectedLoad: ElectricalLoad;
  demandDiversityFactor: number;
  diversifiedLoad: ElectricalLoad;
  utilityDemandFactor: number;
  utilityPowerDemand: ElectricalLoad;
};

export type ElectricalTotalLoad = {
  connectedLoad: ElectricalLoad;
  diversifiedLoad: ElectricalLoad;
  utilityPowerDemand: ElectricalLoad;
};

export type ElectricalCalculatorResult = {
  categoryLoads: ElectricalCategoryLoadDetail[];
  total: ElectricalTotalLoad;
  o1: ElectricalLoad;
  o2: ElectricalLoad;
  o3: ElectricalLoad;
  o4: number;
  state: string | null;
};

export type ElectricalCalculatorInput = {
  latitude: number;
  longitude: number;
  voltage: number;
  area: number;
  roofFactor: number;
  solarPowerDensity: number;
  lookupTable: ElectricalLookupRecord[];
};

type ElectricalLookupResponse = {
  electricalLoadLookupsByTemplateVersion: ElectricalLookupRecord[];
};

type ElectricalCalculationResponse = {
  calculateElectrical: ElectricalCalculatorResult;
};

// API Functions
export const fetchElectricalLookupTable = async (
  templateVersionId: string
): Promise<ElectricalLookupResponse> => {
  return graphqlClient.request<ElectricalLookupResponse>(
    ELECTRICAL_LOAD_LOOKUP_BY_TEMPLATE_VERSION_ID,
    { templateVersionId }
  );
};

export const calculateElectrical = async (
  input: ElectricalCalculatorInput
): Promise<ElectricalCalculationResponse> => {
  return graphqlClient.request<ElectricalCalculationResponse>(CALCULATE_ELECTRICAL, { input });
};
