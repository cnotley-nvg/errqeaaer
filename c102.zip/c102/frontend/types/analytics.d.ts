// Type definitions for GlobalRealty UI-Metrics tracker
// Project: https://code.amazon.com/packages/GlobalRealty-UI-Metrics

declare global {
  interface Window {
    umami?: {
      /**
       * Track a custom event
       * @param eventName - Name of the event (use SCREAMING_SNAKE_CASE)
       * @param eventData - Optional event data object
       * @example
       * window.umami.track('KIT_CREATED', {
       *   kitId: 'uuid',
       *   kitName: 'FC 2.0 Kit',
       *   standardCount: 15
       * });
       */
      track: (eventName: string, eventData?: Record<string, any>) => void;

      /**
       * Identify a user with custom data
       * @param userData - User identification data
       * @example
       * window.umami.identify({
       *   email: 'user@amazon.com',
       *   role: 'admin'
       * });
       */
      identify: (userData: Record<string, any>) => void;
    };
  }
}

export {};
