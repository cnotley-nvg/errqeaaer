import type { AttributeMap } from '@amzn/global-realty-mosaic-graphql-schema';

/**
 * Shared template-related type definitions.
 * These types are used across multiple components for template display and filtering.
 */

export interface TemplateFileSummary {
  id: string;
  accFileId: string;
}

export interface TemplateVersionSummary {
  id: string;
  version: string;
  isLatest: boolean;
  accFolderId: string;
  brsId?: string | null;
  createdAt: string;
  updatedAt: string;
  attributes: AttributeMap;
  files?: TemplateFileSummary[];
}

export interface TemplateSummary {
  id: string;
  name: string;
  description?: string | null;
  heroImageUrl?: string | null;
  accProjectId: string;
  createdAt: string;
  updatedAt: string;
  latestVersion: TemplateVersionSummary | null;
  versions: TemplateVersionSummary[];
}

export interface TemplateFilter {
  region?: string;
  program?: string;
  facilityType?: string;
  businessUnit?: string;
  generation?: string;
  version?: string;
  searchTerm?: string;
}
