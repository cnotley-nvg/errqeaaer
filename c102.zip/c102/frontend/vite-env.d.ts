/// <reference types="vite/client" />

declare module '@arcgis/core/*';

declare module '@arcgis/core/*';
