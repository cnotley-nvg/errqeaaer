import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { TemplateCatalog } from './pages/TemplateCatalog';
import { TemplateDetail } from './pages/TemplateDetail';
import { StandardCatalog } from './pages/StandardCatalog';
import { StandardDetail } from './pages/StandardDetail';
import { BuildKit } from './pages/BuildKit';
import { OptimizeDesign } from './pages/OptimizeDesign';
import { OptimizeDesignResult } from './pages/OptimizeDesignResult';
import { PublishedKitsCatalog } from './pages/PublishedKitsCatalog';
import { DesignGenerator } from './pages/DesignGenerator';
import { KitDetail } from './pages/KitDetail';
import { LayoutProvider } from './components/layout/LayoutProvider';
import { MosaicAppLayout } from './components/layout/MosaicAppLayout';
import HomePage from './pages/HomePage';

const App: React.FC = () => {
  return (
    <LayoutProvider>
      <MosaicAppLayout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/templates" element={<TemplateCatalog />} />
          <Route path="/templates/:id" element={<TemplateDetail />} />
          <Route path="/standards" element={<StandardCatalog />} />
          <Route path="/standards/:id" element={<StandardDetail />} />
          <Route path="/kits" element={<PublishedKitsCatalog />} />
          <Route path="/kits/:id" element={<KitDetail />} />
          <Route path="/build-kit" element={<BuildKit />} />
          <Route path="/design-generator" element={<DesignGenerator />} />
          <Route path="/optimize-design" element={<OptimizeDesign />} />
          <Route path="/optimize-design/result" element={<OptimizeDesignResult />} />
        </Routes>
      </MosaicAppLayout>
    </LayoutProvider>
  );
};

export default App;
