import { jsPDF } from 'jspdf';
import {
  generateElectricalBenchmarkPdf,
  downloadElectricalBenchmarkReport,
  type ProjectParameters,
  type ElectricalBenchmarkPdfData,
} from '../../utils/electricalBenchmarkPdfGenerator';
import type { ElectricalCalculatorResult } from '../../api/electricalBenchmark';

// Mock jsPDF
jest.mock('jspdf', () => {
  const mockSave = jest.fn();
  const mockText = jest.fn();
  const mockSetFontSize = jest.fn();
  const mockSetFont = jest.fn();
  const mockLine = jest.fn();
  const mockSetLineWidth = jest.fn();
  const mockAddPage = jest.fn();
  const mockGetNumberOfPages = jest.fn(() => 1);
  const mockGetCurrentPageInfo = jest.fn(() => ({ pageNumber: 1 }));
  const mockGetTextWidth = jest.fn(() => 20);
  const mockSetPage = jest.fn();

  class MockJsPDF {
    internal = {
      pageSize: {
        getWidth: () => 297,
        getHeight: () => 210,
      },
    };
    lastAutoTable = {
      finalY: 100,
    };
    save = mockSave;
    text = mockText;
    setFontSize = mockSetFontSize;
    setFont = mockSetFont;
    line = mockLine;
    setLineWidth = mockSetLineWidth;
    addPage = mockAddPage;
    getNumberOfPages = mockGetNumberOfPages;
    getCurrentPageInfo = mockGetCurrentPageInfo;
    getTextWidth = mockGetTextWidth;
    setPage = mockSetPage;
  }

  return {
    jsPDF: MockJsPDF,
    __esModule: true,
    default: MockJsPDF,
  };
});

// Mock jspdf-autotable
let mockAutoTableCallback: any = null;
jest.mock('jspdf-autotable', () => {
  return jest.fn((doc: any, options: any) => {
    // Store the callback so tests can invoke it
    if (options.didParseCell) {
      mockAutoTableCallback = options.didParseCell;
    }
    doc.lastAutoTable = { finalY: 100 };
  });
});

describe('electricalBenchmarkPdfGenerator', () => {
  const mockProjectParams: ProjectParameters = {
    streetAddress: '123 Main St',
    city: 'Seattle',
    zipcode: '98101',
    country: 'USA',
    state: 'Washington',
    facilityType: 'Data Center',
    designTemplate: 'NA ARS Gen 12.1',
    squareFootage: '50000',
  };

  const mockElectricalData: ElectricalCalculatorResult = {
    categoryLoads: [
      {
        category: 'Lighting',
        connectedLoad: { kVA: 500.0, amps: 1087.5 },
        demandDiversityFactor: 1.0,
        diversifiedLoad: { kVA: 500.0, amps: 1087.5 },
        utilityDemandFactor: 0.5,
        utilityPowerDemand: { kVA: 250.0, amps: 543.75 },
      },
      {
        category: 'HVAC',
        connectedLoad: { kVA: 9496.0, amps: 11421.9 },
        demandDiversityFactor: 0.7,
        diversifiedLoad: { kVA: 6647.2, amps: 7995.3 },
        utilityDemandFactor: 0.5,
        utilityPowerDemand: { kVA: 4748.0, amps: 5711.0 },
      },
    ],
    total: {
      connectedLoad: { kVA: 29131, amps: 35063 },
      diversifiedLoad: { kVA: 19343, amps: 22785 },
      utilityPowerDemand: { kVA: 11219, amps: 13494 },
    },
    o1: { kVA: 11219, amps: 13494 },
    o2: { kVA: 6200, amps: 6179 },
    o3: { kVA: 4419, amps: 5315 },
    o4: 5,
    state: 'Washington',
  };

  const mockPdfData: ElectricalBenchmarkPdfData = {
    projectParams: mockProjectParams,
    electricalData: mockElectricalData,
    generatedDate: '1/1/2024, 12:00:00 PM',
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('generateElectricalBenchmarkPdf', () => {
    it('should create a PDF document and save it', () => {
      generateElectricalBenchmarkPdf(mockPdfData);

      // Verify the document was created and saved
      const mockDoc = new jsPDF();
      expect(mockDoc.save).toHaveBeenCalled();
    });

    it('should save the PDF with correct filename format', () => {
      const mockDate = new Date('2024-01-15T10:30:00Z');
      jest.spyOn(global, 'Date').mockImplementation(() => mockDate as any);

      generateElectricalBenchmarkPdf(mockPdfData);

      const mockDoc = new jsPDF();
      expect(mockDoc.save).toHaveBeenCalledWith('Electrical_Benchmark_Report_2024-01-15.pdf');

      jest.restoreAllMocks();
    });

    it('should include document title', () => {
      generateElectricalBenchmarkPdf(mockPdfData);

      const mockDoc = new jsPDF();
      expect(mockDoc.text).toHaveBeenCalledWith(
        'Electrical Benchmark Report',
        expect.any(Number),
        expect.any(Number)
      );
    });

    it('should include project parameters section header', () => {
      generateElectricalBenchmarkPdf(mockPdfData);

      const mockDoc = new jsPDF();
      expect(mockDoc.text).toHaveBeenCalledWith(
        'Project Parameters',
        expect.any(Number),
        expect.any(Number)
      );
    });

    it('should include all project parameter labels', () => {
      generateElectricalBenchmarkPdf(mockPdfData);

      const mockDoc = new jsPDF();
      const textCalls = (mockDoc.text as jest.Mock).mock.calls;

      const expectedLabels = [
        'Street address:',
        'Country:',
        'State:',
        'City:',
        'Zip/Postal code:',
        'Project type:',
        'Design template:',
        'Total square footage:',
      ];

      expectedLabels.forEach((label) => {
        expect(textCalls.some((call) => call[0] === label)).toBe(true);
      });
    });

    it('should include all project parameter values', () => {
      generateElectricalBenchmarkPdf(mockPdfData);

      const mockDoc = new jsPDF();
      const textCalls = (mockDoc.text as jest.Mock).mock.calls;

      const expectedValues = [
        mockProjectParams.streetAddress,
        mockProjectParams.country,
        mockProjectParams.state,
        mockProjectParams.city,
        mockProjectParams.zipcode,
        mockProjectParams.facilityType,
        mockProjectParams.designTemplate,
        mockProjectParams.squareFootage,
        mockPdfData.generatedDate,
      ];

      expectedValues.forEach((value) => {
        expect(textCalls.some((call) => call[0] === value)).toBe(true);
      });
    });

    it('should include Category Load Analysis section header', () => {
      generateElectricalBenchmarkPdf(mockPdfData);

      const mockDoc = new jsPDF();
      expect(mockDoc.text).toHaveBeenCalledWith(
        'Category Load Analysis',
        expect.any(Number),
        expect.any(Number)
      );
    });

    it('should include Summary Metrics section header', () => {
      generateElectricalBenchmarkPdf(mockPdfData);

      const mockDoc = new jsPDF();
      expect(mockDoc.text).toHaveBeenCalledWith(
        'Summary Metrics',
        expect.any(Number),
        expect.any(Number)
      );
    });

    it('should handle missing optional state field', () => {
      const paramsWithoutState = { ...mockProjectParams, state: undefined };
      const dataWithoutState = {
        ...mockPdfData,
        projectParams: paramsWithoutState,
      };

      generateElectricalBenchmarkPdf(dataWithoutState);

      const mockDoc = new jsPDF();
      const textCalls = (mockDoc.text as jest.Mock).mock.calls;

      // Should show '-' for missing state
      expect(textCalls.some((call) => call[0] === '-')).toBe(true);
    });

    it('should handle missing optional facility type field', () => {
      const paramsWithoutFacility = { ...mockProjectParams, facilityType: '' };
      const dataWithoutFacility = {
        ...mockPdfData,
        projectParams: paramsWithoutFacility,
      };

      generateElectricalBenchmarkPdf(dataWithoutFacility);

      const mockDoc = new jsPDF();
      const textCalls = (mockDoc.text as jest.Mock).mock.calls;

      // Should show '-' for empty facility type
      expect(textCalls.some((call) => call[0] === '-')).toBe(true);
    });

    it('should set font styles appropriately', () => {
      generateElectricalBenchmarkPdf(mockPdfData);

      const mockDoc = new jsPDF();
      expect(mockDoc.setFont).toHaveBeenCalledWith('helvetica', 'bold');
      expect(mockDoc.setFont).toHaveBeenCalledWith('helvetica', 'normal');
    });

    it('should set various font sizes', () => {
      generateElectricalBenchmarkPdf(mockPdfData);

      const mockDoc = new jsPDF();
      expect(mockDoc.setFontSize).toHaveBeenCalledWith(18); // Title
      expect(mockDoc.setFontSize).toHaveBeenCalledWith(12); // Section headers
      expect(mockDoc.setFontSize).toHaveBeenCalledWith(10); // Project params
      expect(mockDoc.setFontSize).toHaveBeenCalledWith(9); // Descriptions
    });

    it('should draw horizontal line under title', () => {
      generateElectricalBenchmarkPdf(mockPdfData);

      const mockDoc = new jsPDF();
      expect(mockDoc.line).toHaveBeenCalled();
      expect(mockDoc.setLineWidth).toHaveBeenCalledWith(0.5);
    });

    it('should apply bold font style to Total row in category loads table', () => {
      // Store callbacks from both table generations
      const callbacks: any[] = [];
      const autoTableMock = require('jspdf-autotable');
      autoTableMock.mockImplementation((doc: any, options: any) => {
        if (options.didParseCell) {
          callbacks.push(options.didParseCell);
        }
        doc.lastAutoTable = { finalY: 100 };
      });

      generateElectricalBenchmarkPdf(mockPdfData);

      // First callback is for category loads table
      const categoryLoadCallback = callbacks[0];
      expect(categoryLoadCallback).toBeDefined();

      // Simulate parsing the Total row (last row in body)
      const mockCell = {
        cell: {
          styles: {
            fontStyle: 'normal',
          },
        },
        section: 'body',
        row: { index: 2 }, // Total row is at index 2 (after 2 category loads)
        column: { index: 0 },
      };

      categoryLoadCallback(mockCell);

      // Verify fontStyle was changed to bold
      expect(mockCell.cell.styles.fontStyle).toBe('bold');
    });

    it('should left align first column header in category loads table', () => {
      generateElectricalBenchmarkPdf(mockPdfData);

      // Verify didParseCell callback was stored
      expect(mockAutoTableCallback).toBeDefined();

      // Simulate parsing the first header column
      const mockCell = {
        cell: {
          styles: {
            halign: 'right',
          },
        },
        section: 'head',
        row: { index: 0 },
        column: { index: 0 },
      };

      mockAutoTableCallback(mockCell);

      // Verify halign was changed to left
      expect(mockCell.cell.styles.halign).toBe('left');
    });

    it('should not modify non-Total rows in category loads table', () => {
      generateElectricalBenchmarkPdf(mockPdfData);

      expect(mockAutoTableCallback).toBeDefined();

      // Simulate parsing a non-Total row
      const mockCell = {
        cell: {
          styles: {
            fontStyle: 'normal',
          },
        },
        section: 'body',
        row: { index: 0 }, // First category load row
        column: { index: 0 },
      };

      const originalFontStyle = mockCell.cell.styles.fontStyle;
      mockAutoTableCallback(mockCell);

      // Verify fontStyle was NOT changed
      expect(mockCell.cell.styles.fontStyle).toBe(originalFontStyle);
    });

    it('should add new page when content exceeds page height', () => {
      // Create a mock with high finalY to trigger pagination
      const autoTableMock = require('jspdf-autotable');
      autoTableMock.mockImplementationOnce((doc: any, options: any) => {
        // Store the callback
        if (options.didParseCell) {
          mockAutoTableCallback = options.didParseCell;
        }
        // Set finalY to exceed page height threshold (210 - 60 = 150)
        doc.lastAutoTable = { finalY: 160 };
      });

      generateElectricalBenchmarkPdf(mockPdfData);

      const mockDoc = new jsPDF();
      // Verify addPage was called
      expect(mockDoc.addPage).toHaveBeenCalled();
    });

    it('should not add new page when content fits on current page', () => {
      // Create a mock with low finalY to NOT trigger pagination
      const autoTableMock = require('jspdf-autotable');
      autoTableMock.mockImplementationOnce((doc: any, options: any) => {
        // Store the callback
        if (options.didParseCell) {
          mockAutoTableCallback = options.didParseCell;
        }
        // Set finalY to be well within page height
        doc.lastAutoTable = { finalY: 100 };
      });

      generateElectricalBenchmarkPdf(mockPdfData);

      const mockDoc = new jsPDF();
      // Verify addPage was NOT called
      expect(mockDoc.addPage).not.toHaveBeenCalled();
    });

    it('should handle multiple pages and add page numbers to all', () => {
      const autoTableMock = require('jspdf-autotable');
      const mockDoc = new jsPDF();

      // Mock multiple pages
      (mockDoc.getNumberOfPages as jest.Mock).mockReturnValue(3);

      generateElectricalBenchmarkPdf(mockPdfData);

      // Verify setPage was called for each page
      expect(mockDoc.setPage).toHaveBeenCalledTimes(3);
      expect(mockDoc.setPage).toHaveBeenCalledWith(1);
      expect(mockDoc.setPage).toHaveBeenCalledWith(2);
      expect(mockDoc.setPage).toHaveBeenCalledWith(3);
    });

    it('should left align first column header in summary metrics table', () => {
      // Store callbacks from both table generations
      const callbacks: any[] = [];
      const autoTableMock = require('jspdf-autotable');
      autoTableMock.mockImplementation((doc: any, options: any) => {
        if (options.didParseCell) {
          callbacks.push(options.didParseCell);
        }
        doc.lastAutoTable = { finalY: 100 };
      });

      generateElectricalBenchmarkPdf(mockPdfData);

      // Second callback is for summary metrics table
      const summaryMetricsCallback = callbacks[1];
      expect(summaryMetricsCallback).toBeDefined();

      // Simulate parsing the first header column
      const mockCell = {
        cell: {
          styles: {
            halign: 'right',
          },
        },
        section: 'head',
        row: { index: 0 },
        column: { index: 0 },
      };

      summaryMetricsCallback(mockCell);

      // Verify halign was changed to left
      expect(mockCell.cell.styles.halign).toBe('left');
    });

    it('should not modify non-first column headers in summary metrics table', () => {
      // Store callbacks from both table generations
      const callbacks: any[] = [];
      const autoTableMock = require('jspdf-autotable');
      autoTableMock.mockImplementation((doc: any, options: any) => {
        if (options.didParseCell) {
          callbacks.push(options.didParseCell);
        }
        doc.lastAutoTable = { finalY: 100 };
      });

      generateElectricalBenchmarkPdf(mockPdfData);

      // Second callback is for summary metrics table
      const summaryMetricsCallback = callbacks[1];
      expect(summaryMetricsCallback).toBeDefined();

      // Simulate parsing a non-first header column
      const mockCell = {
        cell: {
          styles: {
            halign: 'right',
          },
        },
        section: 'head',
        row: { index: 0 },
        column: { index: 1 }, // Second column
      };

      const originalHalign = mockCell.cell.styles.halign;
      summaryMetricsCallback(mockCell);

      // Verify halign was NOT changed
      expect(mockCell.cell.styles.halign).toBe(originalHalign);
    });
  });

  describe('downloadElectricalBenchmarkReport', () => {
    it('should generate and download PDF with provided data', () => {
      downloadElectricalBenchmarkReport(mockProjectParams, mockElectricalData);

      const mockDoc = new jsPDF();
      expect(mockDoc.save).toHaveBeenCalled();
    });

    it('should use current date/time for generatedDate', () => {
      const mockDate = new Date('2024-01-15T10:30:00Z');
      jest.spyOn(global, 'Date').mockImplementation(() => mockDate as any);
      const mockToLocaleString = jest.fn(() => '1/15/2024, 10:30:00 AM');
      mockDate.toLocaleString = mockToLocaleString;

      downloadElectricalBenchmarkReport(mockProjectParams, mockElectricalData);

      expect(mockToLocaleString).toHaveBeenCalled();

      jest.restoreAllMocks();
    });
  });
});
