import {
  generateWindLoadingPDF,
  downloadWindLoadingReport,
} from '../../utils/windLoadingPdfGenerator';

describe('windLoadingPdfGenerator', () => {
  describe('generateWindLoadingPDF', () => {
    it('should generate PDF for required recommendation', () => {
      const doc = generateWindLoadingPDF({
        recommendation: 'required',
        guidelineUrl: 'https://example.com/guideline',
      });
      expect(doc).toBeDefined();
      expect(typeof doc.save).toBe('function');
    });

    it('should generate PDF for not-required recommendation', () => {
      const doc = generateWindLoadingPDF({
        recommendation: 'not-required',
      });
      expect(doc).toBeDefined();
    });

    it('should generate PDF without guideline URL', () => {
      const doc = generateWindLoadingPDF({
        recommendation: 'required',
      });
      expect(doc).toBeDefined();
    });
  });

  describe('downloadWindLoadingReport', () => {
    it('should call save on generated PDF', () => {
      const saveMock = jest.fn();
      jest.spyOn(require('jspdf'), 'jsPDF').mockImplementation(() => ({
        setFontSize: jest.fn(),
        text: jest.fn(),
        setFont: jest.fn(),
        setTextColor: jest.fn(),
        textWithLink: jest.fn(),
        splitTextToSize: jest.fn(() => ['']),
        save: saveMock,
      }));

      downloadWindLoadingReport({
        recommendation: 'required',
        guidelineUrl: 'https://example.com/guideline',
      });

      expect(saveMock).toHaveBeenCalled();
    });
  });
});
