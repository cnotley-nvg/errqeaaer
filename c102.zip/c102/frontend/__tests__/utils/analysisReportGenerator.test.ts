import {
  getRecommendationText,
  getConclusionText,
  generateLightningProtectionPDF,
  downloadLightningProtectionReport,
} from '../../utils/analysisReportGenerator';
import type { LightningProtectionReportData } from '../../utils/analysisReportGenerator';

describe('analysisReportGenerator', () => {
  describe('getRecommendationText', () => {
    it('should return correct text for required recommendation', () => {
      expect(getRecommendationText('required')).toBe('Lightning Protection System RECOMMENDED');
    });

    it('should return correct text for not-recommended recommendation', () => {
      expect(getRecommendationText('not-recommended')).toBe(
        'Lightning Protection System NOT RECOMMENDED'
      );
    });

    it('should return correct text for not-required recommendation', () => {
      expect(getRecommendationText('not-required')).toBe('Lightning Protection System OPTIONAL');
    });

    it('should return correct text for optional recommendation', () => {
      expect(getRecommendationText('optional')).toBe('Lightning Protection System OPTIONAL');
    });
  });

  describe('getConclusionText', () => {
    it('should return correct conclusion for required recommendation', () => {
      const result = getConclusionText('required');
      expect(result).toContain('recommended to be installed');
      expect(result).toContain('risk assessment');
    });

    it('should return correct conclusion for not-recommended recommendation', () => {
      const result = getConclusionText('not-recommended');
      expect(result).toContain('not recommended');
      expect(result).toContain('risk assessment');
    });

    it('should return correct conclusion for not-required recommendation', () => {
      const result = getConclusionText('not-required');
      expect(result).toContain('optional');
      expect(result).toContain('risk assessment');
    });

    it('should return correct conclusion for optional recommendation', () => {
      const result = getConclusionText('optional');
      expect(result).toContain('optional');
      expect(result).toContain('risk assessment');
    });
  });

  describe('generateLightningProtectionPDF', () => {
    const mockData: LightningProtectionReportData = {
      recommendation: 'required',
      riskLevel: 'High',
      costImpact: '$85000 - $120000',
      timelineImpact: '+2-3 Weeks',
      project: 'ARS NA Gen 12.1 G+4 800k O',
      reportId: 'LPA-2024-0320-001',
    };

    it('should generate PDF document', () => {
      const doc = generateLightningProtectionPDF(mockData);
      expect(doc).toBeDefined();
      expect(typeof doc.save).toBe('function');
    });

    it('should handle required recommendation', () => {
      const doc = generateLightningProtectionPDF({ ...mockData, recommendation: 'required' });
      expect(doc).toBeDefined();
    });

    it('should handle not-recommended recommendation', () => {
      const doc = generateLightningProtectionPDF({
        ...mockData,
        recommendation: 'not-recommended',
      });
      expect(doc).toBeDefined();
    });

    it('should handle optional recommendation', () => {
      const doc = generateLightningProtectionPDF({ ...mockData, recommendation: 'optional' });
      expect(doc).toBeDefined();
    });
  });

  describe('downloadLightningProtectionReport', () => {
    const mockData: LightningProtectionReportData = {
      recommendation: 'required',
      riskLevel: 'High',
      costImpact: '$85000 - $120000',
      timelineImpact: '+2-3 Weeks',
      project: 'ARS NA Gen 12.1 G+4 800k O',
      reportId: 'LPA-2024-0320-001',
    };

    it('should call save on generated PDF', () => {
      const saveMock = jest.fn();
      jest.spyOn(require('jspdf'), 'jsPDF').mockImplementation(() => ({
        setFontSize: jest.fn(),
        text: jest.fn(),
        setFont: jest.fn(),
        splitTextToSize: jest.fn(() => ['']),
        save: saveMock,
      }));

      downloadLightningProtectionReport(mockData);
      expect(saveMock).toHaveBeenCalledWith(
        expect.stringMatching(/lightning-protection-report-\d+\.pdf/)
      );
    });

    it('should generate heat index PDF', () => {
      const heatIndexData = {
        recommendation: 'recommended' as const,
        heatIndexData: {
          levels: [
            { level: 0, hours: 7000, percentage: 80 },
            { level: 1, hours: 1500, percentage: 17 },
            { level: 2, hours: 200, percentage: 2 },
            { level: 3, hours: 60, percentage: 0.7 },
            { level: 4, hours: 0, percentage: 0.3 },
          ],
          hvacRecommendation: 'Option 1',
          recommendation: 'recommended',
        },
      };

      const doc = generateLightningProtectionPDF(heatIndexData);
      expect(doc).toBeDefined();
    });
  });
});
