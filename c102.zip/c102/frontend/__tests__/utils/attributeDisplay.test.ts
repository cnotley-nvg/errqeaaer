import { describe, expect, it } from '@jest/globals';
import {
  formatArrayAsCommaSeparated,
  formatProgram,
  formatProjectType,
  formatRoomFeatureZone,
} from '../../utils/attributeDisplay';

describe('attributeDisplay', () => {
  describe('formatArrayAsCommaSeparated', () => {
    it('returns null for null input', () => {
      expect(formatArrayAsCommaSeparated(null)).toBeNull();
    });

    it('returns null for undefined input', () => {
      expect(formatArrayAsCommaSeparated(undefined)).toBeNull();
    });

    it('returns null for empty array', () => {
      expect(formatArrayAsCommaSeparated([])).toBeNull();
    });

    it('returns null for array with only falsy values', () => {
      expect(formatArrayAsCommaSeparated(['', null, undefined] as any[])).toBeNull();
    });

    it('returns single value as-is for single-element array', () => {
      expect(formatArrayAsCommaSeparated(['BTS'])).toBe('BTS');
    });

    it('returns single value as-is for string input', () => {
      expect(formatArrayAsCommaSeparated('BTS')).toBe('BTS');
    });

    it('returns comma-separated string for two values', () => {
      expect(formatArrayAsCommaSeparated(['BTS', 'Retrofit'])).toBe('BTS, Retrofit');
    });

    it('returns comma-separated string for multiple values', () => {
      expect(formatArrayAsCommaSeparated(['BTS', 'Retrofit', 'STS', 'Expansion'])).toBe(
        'BTS, Retrofit, STS, Expansion'
      );
    });

    it('filters out falsy values before formatting', () => {
      expect(formatArrayAsCommaSeparated(['BTS', '', 'Retrofit', null, undefined] as any[])).toBe(
        'BTS, Retrofit'
      );
    });
  });

  describe('formatProgram', () => {
    it('returns null for null input', () => {
      expect(formatProgram(null)).toBeNull();
    });

    it('returns null for undefined input', () => {
      expect(formatProgram(undefined)).toBeNull();
    });

    it('returns null for empty array', () => {
      expect(formatProgram([])).toBeNull();
    });

    it('returns null for array with only falsy values', () => {
      expect(formatProgram(['', null, undefined] as any[])).toBeNull();
    });

    it('returns single program as-is', () => {
      expect(formatProgram(['GCF'])).toBe('GCF');
    });

    it('returns single program as-is for string input', () => {
      expect(formatProgram('GCF')).toBe('GCF');
    });

    it('returns comma-separated list for two programs', () => {
      expect(formatProgram(['GCF', 'ATS'])).toBe('GCF, ATS');
    });

    it('returns comma-separated list for three programs', () => {
      expect(formatProgram(['GCF', 'ATS', 'AMXL'])).toBe('GCF, ATS, AMXL');
    });

    it('returns "Cross-program" for four programs', () => {
      expect(formatProgram(['GCF', 'ATS', 'AMXL', 'IXD'])).toBe('Cross-program');
    });

    it('returns "Cross-program" for five programs', () => {
      expect(formatProgram(['GCF', 'ATS', 'AMXL', 'IXD', 'SC'])).toBe('Cross-program');
    });

    it('returns "Cross-program" for many programs', () => {
      expect(formatProgram(['GCF', 'ATS', 'AMXL', 'IXD', 'SC', 'Prime Air', 'WFM'])).toBe(
        'Cross-program'
      );
    });

    it('filters out falsy values before counting', () => {
      expect(formatProgram(['GCF', '', 'ATS', null, undefined] as any[])).toBe('GCF, ATS');
    });
  });

  describe('formatProjectType', () => {
    it('returns null for null input', () => {
      expect(formatProjectType(null)).toBeNull();
    });

    it('returns null for undefined input', () => {
      expect(formatProjectType(undefined)).toBeNull();
    });

    it('returns null for empty array', () => {
      expect(formatProjectType([])).toBeNull();
    });

    it('returns single type as-is', () => {
      expect(formatProjectType(['BTS'])).toBe('BTS');
    });

    it('returns single type as-is for string input', () => {
      expect(formatProjectType('BTS')).toBe('BTS');
    });

    it('returns comma-separated list for two types', () => {
      expect(formatProjectType(['BTS', 'Retrofit'])).toBe('BTS, Retrofit');
    });

    it('returns comma-separated list for multiple types', () => {
      expect(formatProjectType(['BTS', 'Retrofit', 'STS', 'Expansion'])).toBe(
        'BTS, Retrofit, STS, Expansion'
      );
    });

    it('filters out falsy values', () => {
      expect(formatProjectType(['BTS', '', 'Retrofit', null, undefined] as any[])).toBe(
        'BTS, Retrofit'
      );
    });
  });

  describe('formatRoomFeatureZone', () => {
    it('returns null for null input', () => {
      expect(formatRoomFeatureZone(null)).toBeNull();
    });

    it('returns null for undefined input', () => {
      expect(formatRoomFeatureZone(undefined)).toBeNull();
    });

    it('returns null for empty array', () => {
      expect(formatRoomFeatureZone([])).toBeNull();
    });

    it('returns single zone as-is', () => {
      expect(formatRoomFeatureZone(['Warehouse'])).toBe('Warehouse');
    });

    it('returns single zone as-is for string input', () => {
      expect(formatRoomFeatureZone('Warehouse')).toBe('Warehouse');
    });

    it('returns comma-separated list for two zones', () => {
      expect(formatRoomFeatureZone(['Warehouse', 'Office'])).toBe('Warehouse, Office');
    });

    it('returns comma-separated list for multiple zones', () => {
      expect(formatRoomFeatureZone(['Warehouse', 'Office', 'MEP', 'Site'])).toBe(
        'Warehouse, Office, MEP, Site'
      );
    });

    it('filters out falsy values', () => {
      expect(formatRoomFeatureZone(['Warehouse', '', 'Office', null, undefined] as any[])).toBe(
        'Warehouse, Office'
      );
    });
  });
});
