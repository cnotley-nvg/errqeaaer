import {
  buildAccFolderUrl,
  buildBim360FolderUrl,
  detectPlatform,
  isValidAccProjectId,
  isValidAccFolderId,
  buildBrsUrl,
  isValidBrsId,
} from '../../utils/accUrlBuilder';

describe('accUrlBuilder', () => {
  describe('detectPlatform', () => {
    it('should detect ACC platform when project ID has "b." prefix', () => {
      const projectId = 'b.7f89f6ea-5a3c-49ed-b024-599f9b9003cf';
      expect(detectPlatform(projectId)).toBe('ACC');
    });

    it('should detect BIM360 platform when project ID has no "b." prefix', () => {
      const projectId = 'a195ba78-ce59-436c-8fe4-29597d80dcb8';
      expect(detectPlatform(projectId)).toBe('BIM360');
    });
  });

  describe('buildBim360FolderUrl', () => {
    it('should build correct BIM360 URL', () => {
      const projectId = 'a195ba78-ce59-436c-8fe4-29597d80dcb8';
      const folderId = 'urn:adsk.wipprod:fs.folder:co.8rl67c1_S82DURRIUB_rQw';

      const result = buildBim360FolderUrl(projectId, folderId);

      expect(result).toBe(
        'https://docs.b360.autodesk.com/projects/a195ba78-ce59-436c-8fe4-29597d80dcb8/folders/urn:adsk.wipprod:fs.folder:co.8rl67c1_S82DURRIUB_rQw'
      );
    });

    it('should handle folder IDs with special characters', () => {
      const projectId = 'a195ba78-ce59-436c-8fe4-29597d80dcb8';
      const folderId = 'urn:adsk.wipprod:fs.folder:co.abc_123-XYZ';

      const result = buildBim360FolderUrl(projectId, folderId);

      expect(result).toContain('/folders/urn:adsk.wipprod:fs.folder:co.abc_123-XYZ');
    });
  });

  describe('buildAccFolderUrl', () => {
    describe('ACC platform (with "b." prefix)', () => {
      it('should build correct ACC URL with "b." prefix', () => {
        const projectId = 'b.7f89f6ea-5a3c-49ed-b024-599f9b9003cf';
        const folderId = 'urn:adsk.wipprod:fs.folder:co.vglRX7a0QiWvFEniu37PIA';

        const result = buildAccFolderUrl(projectId, folderId);

        expect(result).toBe(
          'https://acc.autodesk.com/docs/files/projects/7f89f6ea-5a3c-49ed-b024-599f9b9003cf?folderUrn=urn%3Aadsk.wipprod%3Afs.folder%3Aco.vglRX7a0QiWvFEniu37PIA'
        );
      });

      it('should properly URL encode folder URN with special characters', () => {
        const projectId = 'b.7f89f6ea-5a3c-49ed-b024-599f9b9003cf';
        const folderId = 'urn:adsk.wipprod:fs.folder:co.abc123XYZ';

        const result = buildAccFolderUrl(projectId, folderId);

        expect(result).toContain('folderUrn=urn%3Aadsk.wipprod%3Afs.folder%3Aco.abc123XYZ');
      });

      it('should include folderUrn query parameter', () => {
        const projectId = 'b.7f89f6ea-5a3c-49ed-b024-599f9b9003cf';
        const folderId = 'urn:adsk.wipprod:fs.folder:co.vglRX7a0QiWvFEniu37PIA';

        const result = buildAccFolderUrl(projectId, folderId);

        expect(result).toContain('folderUrn=');
      });
    });

    describe('BIM360 platform (without "b." prefix)', () => {
      it('should build correct BIM360 URL for project without "b." prefix', () => {
        const projectId = 'a195ba78-ce59-436c-8fe4-29597d80dcb8';
        const folderId = 'urn:adsk.wipprod:fs.folder:co.8rl67c1_S82DURRIUB_rQw';

        const result = buildAccFolderUrl(projectId, folderId);

        expect(result).toBe(
          'https://docs.b360.autodesk.com/projects/a195ba78-ce59-436c-8fe4-29597d80dcb8/folders/urn:adsk.wipprod:fs.folder:co.8rl67c1_S82DURRIUB_rQw'
        );
      });

      it('should detect BIM360 and build correct URL format', () => {
        const projectId = '7f89f6ea-5a3c-49ed-b024-599f9b9003cf';
        const folderId = 'urn:adsk.wipprod:fs.folder:co.vglRX7a0QiWvFEniu37PIA';

        const result = buildAccFolderUrl(projectId, folderId);

        // Should be BIM360 URL format (not ACC)
        expect(result).toContain('docs.b360.autodesk.com');
        expect(result).toContain('/projects/');
        expect(result).toContain('/folders/');
        // Should NOT have ACC query parameters
        expect(result).not.toContain('folderUrn=');
        expect(result).not.toContain('viewModel=');
      });
    });
  });

  describe('isValidAccProjectId', () => {
    it('should return true for valid project ID with "b." prefix', () => {
      const projectId = 'b.7f89f6ea-5a3c-49ed-b024-599f9b9003cf';
      expect(isValidAccProjectId(projectId)).toBe(true);
    });

    it('should return true for valid project ID without "b." prefix', () => {
      const projectId = '7f89f6ea-5a3c-49ed-b024-599f9b9003cf';
      expect(isValidAccProjectId(projectId)).toBe(true);
    });

    it('should return false for invalid UUID format', () => {
      expect(isValidAccProjectId('invalid-uuid')).toBe(false);
      expect(isValidAccProjectId('b.not-a-uuid')).toBe(false);
      expect(isValidAccProjectId('12345')).toBe(false);
    });

    it('should return false for null or undefined', () => {
      expect(isValidAccProjectId(null)).toBe(false);
      expect(isValidAccProjectId(undefined)).toBe(false);
    });

    it('should return false for empty string', () => {
      expect(isValidAccProjectId('')).toBe(false);
    });
  });

  describe('isValidAccFolderId', () => {
    it('should return true for valid folder URN', () => {
      const folderId = 'urn:adsk.wipprod:fs.folder:co.vglRX7a0QiWvFEniu37PIA';
      expect(isValidAccFolderId(folderId)).toBe(true);
    });

    it('should return true for valid folder URN with different ID', () => {
      const folderId = 'urn:adsk.wipprod:fs.folder:co.abc123XYZ';
      expect(isValidAccFolderId(folderId)).toBe(true);
    });

    it('should return false for invalid URN format', () => {
      expect(isValidAccFolderId('invalid-urn')).toBe(false);
      expect(isValidAccFolderId('urn:adsk.wipprod:fs.file:co.123')).toBe(false);
      expect(isValidAccFolderId('urn:different:fs.folder:co.123')).toBe(false);
    });

    it('should return false for null or undefined', () => {
      expect(isValidAccFolderId(null)).toBe(false);
      expect(isValidAccFolderId(undefined)).toBe(false);
    });

    it('should return false for empty string', () => {
      expect(isValidAccFolderId('')).toBe(false);
    });
  });

  describe('buildBrsUrl', () => {
    it('should build correct BRS URL', () => {
      const brsId = 'a1q3t00000BmdJHAAZ';
      const result = buildBrsUrl(brsId);
      expect(result).toBe(
        'https://amznfulfillment.my.site.com/brs/brs-detail?brsId=a1q3t00000BmdJHAAZ'
      );
    });
  });

  describe('isValidBrsId', () => {
    it('should return true for valid 15-character Salesforce ID', () => {
      const brsId = 'a1q3t00000BmdJH';
      expect(isValidBrsId(brsId)).toBe(true);
    });

    it('should return true for valid 18-character Salesforce ID', () => {
      const brsId = 'a1q3t00000BmdJHAAZ';
      expect(isValidBrsId(brsId)).toBe(true);
    });

    it('should return false for invalid length', () => {
      expect(isValidBrsId('short')).toBe(false);
      expect(isValidBrsId('a1q3t00000BmdJHAAZtoolong')).toBe(false);
    });

    it('should return false for null or undefined', () => {
      expect(isValidBrsId(null)).toBe(false);
      expect(isValidBrsId(undefined)).toBe(false);
    });

    it('should return false for empty string', () => {
      expect(isValidBrsId('')).toBe(false);
    });
  });
});
