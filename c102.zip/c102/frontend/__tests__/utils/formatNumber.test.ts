import { formatNumber } from '../../utils/formatNumber';

describe('formatNumber', () => {
  it('should format number with commas', () => {
    expect(formatNumber(5000)).toBe('5,000');
  });

  it('should format string number with commas', () => {
    expect(formatNumber('5000')).toBe('5,000');
  });

  it('should handle large numbers', () => {
    expect(formatNumber(652000)).toBe('652,000');
  });

  it('should handle small numbers without commas', () => {
    expect(formatNumber(500)).toBe('500');
  });

  it('should handle zero', () => {
    expect(formatNumber(0)).toBe('0');
  });

  it('should handle decimal numbers', () => {
    expect(formatNumber(5000.5)).toBe('5,001');
  });

  it('should return N/A for NaN', () => {
    expect(formatNumber('invalid')).toBe('N/A');
  });

  it('should return N/A for null', () => {
    expect(formatNumber(null)).toBe('N/A');
  });

  it('should return N/A for undefined', () => {
    expect(formatNumber(undefined)).toBe('N/A');
  });

  it('should return empty string for empty string', () => {
    expect(formatNumber('')).toBe('');
  });
});
