import { describe, expect, it } from '@jest/globals';
import { getScopedLogger } from '../../utils/logger';

describe('getScopedLogger', () => {
  it('creates a scoped logger with merged context', () => {
    const scopedLogger = getScopedLogger('standard-catalog', { feature: 'filters' });

    expect(typeof scopedLogger.info).toBe('function');
    expect(typeof scopedLogger.warn).toBe('function');
    expect(typeof scopedLogger.error).toBe('function');
    expect(typeof scopedLogger.child).toBe('function');
  });

  it('creates child loggers with additional context', () => {
    const scopedLogger = getScopedLogger('test-scope');
    const childLogger = scopedLogger.child({ userId: '123' });

    expect(typeof childLogger.info).toBe('function');
    expect(typeof childLogger.warn).toBe('function');
    expect(typeof childLogger.error).toBe('function');
  });

  it('logs info messages without throwing', () => {
    const logger = getScopedLogger('test');
    expect(() => logger.info('test message', { key: 'value' })).not.toThrow();
  });

  it('logs warn messages without throwing', () => {
    const logger = getScopedLogger('test');
    expect(() => logger.warn('warning message', { key: 'value' })).not.toThrow();
  });

  it('logs error messages without throwing', () => {
    const logger = getScopedLogger('test');
    expect(() => logger.error('error message', { key: 'value' })).not.toThrow();
  });

  it('child logger can log messages', () => {
    const parent = getScopedLogger('parent', { parentKey: 'parentValue' });
    const child = parent.child({ childKey: 'childValue' });
    expect(() => child.info('test')).not.toThrow();
  });

  it('creates logger without context parameter', () => {
    const logger = getScopedLogger('test-scope-only');
    expect(typeof logger.info).toBe('function');
    expect(() => logger.info('message')).not.toThrow();
  });

  it('logs messages without optional context', () => {
    const logger = getScopedLogger('test');
    expect(() => logger.info('no context')).not.toThrow();
    expect(() => logger.warn('no context')).not.toThrow();
    expect(() => logger.error('no context')).not.toThrow();
  });
});
