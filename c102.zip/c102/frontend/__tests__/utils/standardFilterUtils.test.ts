import { describe, expect, it } from '@jest/globals';
import type {
  PropertyFilterQuery,
  PropertyFilterTokenGroup,
} from '@cloudscape-design/components/collection-hooks';

import {
  buildFilterInput,
  collectTokens,
  mapTokenToQueryGroup,
  toFilterQueryInput,
} from '../../utils/standardFilterUtils';
import type { SortableField } from '../../hooks/useStandardCatalogPersistence';
import type { FilterTokenGroupInput } from '@amzn/global-realty-mosaic-graphql-schema';

const createTokenGroup = (
  entries: Array<PropertyFilterTokenGroup | PropertyFilterQuery['tokens'][number]>,
  operation: PropertyFilterQuery['operation'] = 'and'
): PropertyFilterTokenGroup => ({
  operation,
  tokens: entries as PropertyFilterTokenGroup['tokens'],
});

describe('standardFilterUtils', () => {
  it('normalizes tokens into query groups with values', () => {
    const multiValueGroup = mapTokenToQueryGroup({
      propertyKey: 'region',
      operator: '!=',
      value: undefined,
      values: ['North America', 'Europe, Middle East and Africa'],
    });

    expect(multiValueGroup).toEqual({
      propertyKey: 'region',
      operator: 'NOT_EQUALS',
      values: ['North America', 'Europe, Middle East and Africa'],
    });

    const singleValueGroup = mapTokenToQueryGroup({
      propertyKey: 'program',
      operator: '=',
      value: undefined,
      values: ['Cross program', ''],
    });

    expect(singleValueGroup).toEqual({
      propertyKey: 'program',
      operator: 'EQUALS',
      value: 'Cross program',
    });
  });

  it('returns null when token data is incomplete', () => {
    expect(mapTokenToQueryGroup({ propertyKey: '', operator: '=', value: 'value' })).toBeNull();
    expect(
      mapTokenToQueryGroup({ propertyKey: 'region', operator: undefined, value: 'value' })
    ).toBeNull();
  });

  it('collects nested token groups into a flat list', () => {
    const target: FilterTokenGroupInput[] = [];
    collectTokens(
      createTokenGroup([
        { propertyKey: 'name', operator: '=', value: 'Electrical standard' },
        createTokenGroup([
          { propertyKey: 'region', operator: '=', value: 'Europe, Middle East and Africa' },
        ]),
      ]),
      target
    );

    expect(target).toEqual([
      { propertyKey: 'name', operator: 'EQUALS', value: 'Electrical standard' },
      {
        propertyKey: 'region',
        operator: 'EQUALS',
        value: 'Europe, Middle East and Africa',
      },
    ]);
  });

  it('creates a filter query input from property filter state', () => {
    const query: PropertyFilterQuery = {
      operation: 'or',
      tokens: [{ propertyKey: 'name', operator: '=', value: 'Standard A' }],
      tokenGroups: [
        createTokenGroup([{ propertyKey: 'region', operator: '=', value: 'Latin America' }]),
      ],
    };

    const transformed = toFilterQueryInput(query);

    expect(transformed).toEqual({
      operation: 'OR',
      tokenGroups: expect.arrayContaining([
        { propertyKey: 'name', operator: 'EQUALS', value: 'Standard A' },
        { propertyKey: 'region', operator: 'EQUALS', value: 'Latin America' },
      ]),
    });
    expect(transformed?.tokenGroups).toHaveLength(2);

    expect(toFilterQueryInput({ operation: 'and', tokens: [], tokenGroups: [] })).toBeUndefined();
  });

  it('builds the standard filter input for the search hook', () => {
    const query: PropertyFilterQuery = {
      operation: 'and',
      tokens: [{ propertyKey: 'name', operator: '=', value: 'Standard B' }],
      tokenGroups: [],
    };
    const filterInput = buildFilterInput(query, 2, 'updatedAt', true, 20);

    expect(filterInput).toEqual({
      pageIdx: 1,
      limit: 20,
      orderBy: 'updatedAt',
      orderDesc: true,
      query: {
        operation: 'AND',
        tokenGroups: [{ propertyKey: 'name', operator: 'EQUALS', value: 'Standard B' }],
      },
    });

    const baseFilterInput = buildFilterInput(
      { operation: 'and', tokens: [], tokenGroups: [] },
      1,
      'name',
      false
    );
    expect(baseFilterInput).toEqual({
      pageIdx: 0,
      limit: 20,
      orderBy: 'name',
      orderDesc: false,
    });
  });
});
