import { describe, expect, it } from '@jest/globals';

import {
  createFilteringOptions,
  formatAttributeValue,
  formatStandardAttribute,
  formatUpdatedAt,
  formatVersion,
  listAttributeValues,
} from '../../utils/standardPresenters';
import type { Standard } from '../../components/standards/catalog/types';
import type { AttributeMap } from '@amzn/global-realty-mosaic-graphql-schema';

const createStandard = (attributes: AttributeMap, overrides: Partial<Standard> = {}): Standard => {
  const latestVersion = {
    id: 'std-version-1',
    version: 'v1',
    isLatest: true,
    attributes,
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-02T00:00:00.000Z',
    kits: [],
  } satisfies Standard['latestVersion'];

  return {
    id: 'standard-1',
    name: 'Fire safety',
    description: null,
    accProjectId: 'ACC-1',
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-02T00:00:00.000Z',
    latestVersion,
    ...overrides,
  } satisfies Standard;
};

describe('standardPresenters', () => {
  it('formats attribute values from attribute maps', () => {
    const attributes: AttributeMap = {
      region: 'North America',
      capacity: { value: 750, unit: 'Mbps' },
      tags: ['safety', 'retrofit'],
      isActive: true,
    };

    expect(formatAttributeValue(attributes, 'region')).toBe('North America');
    expect(formatAttributeValue(attributes, 'capacity')).toBe('750 Mbps');
    expect(formatAttributeValue(attributes, 'tags')).toBe('safety, retrofit');
    expect(formatAttributeValue(attributes, 'missing')).toBe('');

    expect(listAttributeValues(attributes, 'isActive')).toEqual(['Yes']);
  });

  it('formats boolean values correctly', () => {
    const attributes: AttributeMap = {
      isActive: true,
      isDisabled: false,
    };

    expect(formatAttributeValue(attributes, 'isActive')).toBe('Yes');
    expect(formatAttributeValue(attributes, 'isDisabled')).toBe('No');
  });

  it('formats numeric attributes with and without units', () => {
    const attributes: AttributeMap = {
      withUnit: { value: 100, unit: 'kW' },
      withoutUnit: { value: 50, unit: null },
    };

    expect(formatAttributeValue(attributes, 'withUnit')).toBe('100 kW');
    expect(formatAttributeValue(attributes, 'withoutUnit')).toBe('50');
  });

  it('formats plain number values', () => {
    const attributes: AttributeMap = {
      count: 42,
    };

    expect(formatAttributeValue(attributes, 'count')).toBe('42');
  });

  it('handles null and undefined attributes', () => {
    expect(formatAttributeValue(null, 'any')).toBe('');
    expect(formatAttributeValue(undefined, 'any')).toBe('');
  });

  it('handles null attribute values', () => {
    const attributes: AttributeMap = {
      nullValue: null,
      undefinedValue: undefined,
    };

    expect(formatAttributeValue(attributes, 'nullValue')).toBe('');
    expect(formatAttributeValue(attributes, 'undefinedValue')).toBe('');
  });

  it('formats standard attributes via latest version metadata', () => {
    const standard = createStandard({ program: 'Logistics', version: 'v3' });

    expect(formatStandardAttribute(standard, 'program')).toBe('Logistics');
    expect(formatVersion(standard)).toBe('v1');
    expect(formatUpdatedAt(standard)).toBe('2024-01-02T00:00:00.000Z');
  });

  it('builds filtering options from standards', () => {
    const options = createFilteringOptions([
      createStandard(
        {
          region: 'Europe, Middle East and Africa',
          program: ['ARS', 'AMZL'],
          projectType: 'retrofit',
        },
        { name: 'Standard A' }
      ),
      createStandard(
        { region: 'Asia Pacific', program: ['DSC', 'FSC'], projectType: 'build-to-suit' },
        { name: 'Standard B' }
      ),
    ]);

    const regionOptions = options
      .filter((option) => option.propertyKey === 'region')
      .map((option) => option.value);
    expect(regionOptions).toEqual(['Asia Pacific', 'Europe, Middle East and Africa']);

    const programOptions = options
      .filter((option) => option.propertyKey === 'program')
      .map((option) => option.value);
    expect(programOptions).toEqual(['AMZL', 'ARS', 'DSC', 'FSC']);

    expect(options).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ propertyKey: 'name', value: 'Standard A' }),
        expect.objectContaining({ propertyKey: 'projectType', value: 'retrofit' }),
        expect.objectContaining({ propertyKey: 'program', value: 'ARS' }),
        expect.objectContaining({ propertyKey: 'program', value: 'AMZL' }),
      ])
    );
  });
});
