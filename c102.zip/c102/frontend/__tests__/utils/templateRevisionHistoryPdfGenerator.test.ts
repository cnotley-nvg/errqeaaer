import { describe, expect, it, jest, beforeEach } from '@jest/globals';
import { generateTemplateRevisionHistoryPdf } from '../../utils/templateRevisionHistoryPdfGenerator';
import type {
  TemplateRevisionPdfData,
  LinkField,
} from '../../utils/templateRevisionHistoryPdfGenerator';

// Mock jsPDF and autoTable
const mockSave = jest.fn();
const mockText = jest.fn();
const mockSetFontSize = jest.fn();
const mockSetFont = jest.fn();
const mockSetLineWidth = jest.fn();
const mockLine = jest.fn();
const mockSplitTextToSize = jest.fn((text: string) => [text]);
const mockGetNumberOfPages = jest.fn(() => 2);
const mockGetCurrentPageInfo = jest.fn(() => ({ pageNumber: 1 }));

jest.mock('jspdf', () => ({
  __esModule: true,
  default: jest.fn().mockImplementation(() => ({
    internal: {
      pageSize: {
        getWidth: () => 210,
        getHeight: () => 297,
      },
    },
    save: mockSave,
    text: mockText,
    setFontSize: mockSetFontSize,
    setFont: mockSetFont,
    setLineWidth: mockSetLineWidth,
    line: mockLine,
    splitTextToSize: mockSplitTextToSize,
    getNumberOfPages: mockGetNumberOfPages,
    getCurrentPageInfo: mockGetCurrentPageInfo,
  })),
}));

jest.mock('jspdf-autotable', () => ({
  __esModule: true,
  default: jest.fn((_doc, options: any) => {
    // Simulate calling didDrawPage callback if provided
    if (options?.didDrawPage) {
      options.didDrawPage();
    }
  }),
}));

describe('templateRevisionHistoryPdfGenerator', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  const mockData: TemplateRevisionPdfData = {
    templateName: 'ARS NA Gen 14 Civil Template',
    versionRange: 'v2.0',
    description: 'Site plan template that delivers Gen 14 footprint options',
    generatedDate: 'November 18, 2025 at 11:37 AM',
    totalChanges: 3,
    changes: [
      {
        category: 'Architectural',
        title: 'Loading dock configuration',
        description: 'Increased dock door count and added weather protection canopies',
        dci: { text: 'DCI-2024A-303', url: null },
        dcr: { text: 'DCR-2024A-303', url: null },
        sheet: 'A-101',
        changeInCost: '$10,000',
      },
      {
        category: 'Civil',
        title: 'Parking lot layout optimization',
        description: 'Reconfigured parking spaces to accommodate EV charging stations',
        dci: { text: 'DCI-2024C-301', url: null },
        dcr: { text: 'DCR-2024C-301', url: null },
        sheet: 'C-201',
        changeInCost: '$25,000',
      },
      {
        category: 'Electrical',
        title: 'LED lighting conversion',
        description: 'Converted all warehouse and office lighting to high-efficiency LED fixtures',
        dci: { text: 'DCI-2024E-302', url: null },
        dcr: { text: 'DCR-2024E-302', url: null },
        sheet: 'E-301',
        changeInCost: '$15,000',
      },
    ],
  };

  describe('generateTemplateRevisionHistoryPdf', () => {
    it('should generate PDF with all required sections', () => {
      generateTemplateRevisionHistoryPdf(mockData);

      // Verify PDF was saved
      expect(mockSave).toHaveBeenCalledTimes(1);
      expect(mockSave).toHaveBeenCalledWith(
        expect.stringMatching(
          /ARS_NA_Gen_14_Civil_Template_Revision_History_\d{4}-\d{2}-\d{2}\.pdf/
        )
      );
    });

    it('should render document title', () => {
      generateTemplateRevisionHistoryPdf(mockData);

      // Check that title was rendered
      expect(mockText).toHaveBeenCalledWith(
        'Template Revision History',
        expect.any(Number),
        expect.any(Number)
      );
    });

    it('should render template metadata', () => {
      generateTemplateRevisionHistoryPdf(mockData);

      // Check metadata labels
      expect(mockText).toHaveBeenCalledWith(
        'Template Name:',
        expect.any(Number),
        expect.any(Number)
      );
      expect(mockText).toHaveBeenCalledWith('Version:', expect.any(Number), expect.any(Number));
      expect(mockText).toHaveBeenCalledWith('Description:', expect.any(Number), expect.any(Number));
      expect(mockText).toHaveBeenCalledWith('Generated:', expect.any(Number), expect.any(Number));
      expect(mockText).toHaveBeenCalledWith(
        'Total Changes:',
        expect.any(Number),
        expect.any(Number)
      );

      // Check metadata values
      expect(mockText).toHaveBeenCalledWith(
        mockData.templateName,
        expect.any(Number),
        expect.any(Number)
      );
      expect(mockText).toHaveBeenCalledWith(
        mockData.versionRange,
        expect.any(Number),
        expect.any(Number)
      );
      expect(mockText).toHaveBeenCalledWith(
        mockData.generatedDate,
        expect.any(Number),
        expect.any(Number)
      );
      expect(mockText).toHaveBeenCalledWith(
        String(mockData.totalChanges),
        expect.any(Number),
        expect.any(Number)
      );
    });

    it('should handle long descriptions with text wrapping', () => {
      generateTemplateRevisionHistoryPdf(mockData);

      // Verify splitTextToSize was called for description
      expect(mockSplitTextToSize).toHaveBeenCalledWith(mockData.description, expect.any(Number));
    });

    it('should render Change History section header', () => {
      generateTemplateRevisionHistoryPdf(mockData);

      expect(mockText).toHaveBeenCalledWith(
        'Change History',
        expect.any(Number),
        expect.any(Number)
      );
    });

    it('should draw horizontal line under title', () => {
      generateTemplateRevisionHistoryPdf(mockData);

      expect(mockSetLineWidth).toHaveBeenCalled();
      expect(mockLine).toHaveBeenCalled();
    });

    it('should set appropriate font sizes and styles', () => {
      generateTemplateRevisionHistoryPdf(mockData);

      // Title should use large font
      expect(mockSetFontSize).toHaveBeenCalledWith(20);

      // Section header should use medium font
      expect(mockSetFontSize).toHaveBeenCalledWith(14);

      // Content should use normal font
      expect(mockSetFontSize).toHaveBeenCalledWith(11);

      // Bold and normal font styles
      expect(mockSetFont).toHaveBeenCalledWith('helvetica', 'bold');
      expect(mockSetFont).toHaveBeenCalledWith('helvetica', 'normal');
    });

    it('should handle missing description', () => {
      const dataWithoutDescription: TemplateRevisionPdfData = {
        ...mockData,
        description: undefined,
      };

      generateTemplateRevisionHistoryPdf(dataWithoutDescription);

      // Should not crash and still save PDF
      expect(mockSave).toHaveBeenCalledTimes(1);
    });

    it('should handle empty changes array', () => {
      const dataWithNoChanges: TemplateRevisionPdfData = {
        ...mockData,
        changes: [],
        totalChanges: 0,
      };

      generateTemplateRevisionHistoryPdf(dataWithNoChanges);

      // Should still generate PDF with empty table
      expect(mockSave).toHaveBeenCalledTimes(1);
    });

    it('should sanitize template name in filename', () => {
      const dataWithSpecialChars: TemplateRevisionPdfData = {
        ...mockData,
        templateName: 'Test/Template\\With:Special*Chars?',
      };

      generateTemplateRevisionHistoryPdf(dataWithSpecialChars);

      // Filename should have special characters replaced with underscores
      expect(mockSave).toHaveBeenCalledWith(
        expect.stringMatching(
          /Test_Template_With_Special_Chars__Revision_History_\d{4}-\d{2}-\d{2}\.pdf/
        )
      );
    });

    it('should handle changes with missing fields', () => {
      const dataWithIncompleteChanges: TemplateRevisionPdfData = {
        ...mockData,
        changes: [
          {
            category: 'Structural',
            title: '',
            description: '',
            dci: null,
            dcr: null,
            sheet: null,
            changeInCost: null,
          },
        ],
      };

      generateTemplateRevisionHistoryPdf(dataWithIncompleteChanges);

      // Should still generate PDF without crashing
      expect(mockSave).toHaveBeenCalledTimes(1);
    });

    it('should include all changes in the PDF table', () => {
      const autoTableMock = require('jspdf-autotable').default;

      generateTemplateRevisionHistoryPdf(mockData);

      // Verify autoTable was called with correct data
      expect(autoTableMock).toHaveBeenCalledTimes(1);

      const callArgs = autoTableMock.mock.calls[0];
      const options = callArgs[1];

      // Check table has correct headers
      expect(options.head).toEqual([
        ['Discipline', 'Change', 'Description', 'DCI #', 'DCR #', 'Sheet', 'Change in Cost'],
      ]);

      // Check table has correct number of rows
      expect(options.body).toHaveLength(3);

      // Check table data matches input
      expect(options.body[0]).toEqual([
        'Architectural',
        'Loading dock configuration',
        'Increased dock door count and added weather protection canopies',
        'DCI-2024A-303',
        'DCR-2024A-303',
        'A-101',
        '$10,000',
      ]);
    });

    it('should configure table with proper styling', () => {
      const autoTableMock = require('jspdf-autotable').default;

      generateTemplateRevisionHistoryPdf(mockData);

      const callArgs = autoTableMock.mock.calls[0];
      const options = callArgs[1];

      // Verify table styling options
      expect(options.styles).toBeDefined();
      expect(options.styles.fontSize).toBe(9);
      expect(options.styles.cellPadding).toBe(4);
      expect(options.headStyles).toBeDefined();
      expect(options.theme).toBe('grid');
    });

    it('should not include columnStyles (for automatic width calculation)', () => {
      const autoTableMock = require('jspdf-autotable').default;

      generateTemplateRevisionHistoryPdf(mockData);

      const callArgs = autoTableMock.mock.calls[0];
      const options = callArgs[1];

      // Verify columnStyles is not defined (removed to fix vertical line artifact)
      expect(options.columnStyles).toBeUndefined();
    });

    it('should add page numbers in footer', () => {
      const autoTableMock = require('jspdf-autotable').default;

      generateTemplateRevisionHistoryPdf(mockData);

      const callArgs = autoTableMock.mock.calls[0];
      const options = callArgs[1];

      // Verify didDrawPage callback exists
      expect(options.didDrawPage).toBeDefined();
      expect(typeof options.didDrawPage).toBe('function');

      // The callback should have been called (our mock triggers it)
      expect(mockGetNumberOfPages).toHaveBeenCalled();
      expect(mockGetCurrentPageInfo).toHaveBeenCalled();
    });

    it('should use current date for filename timestamp', () => {
      const originalDate = Date;
      const mockDate = new Date('2025-03-15T10:30:00Z');
      global.Date = jest.fn(() => mockDate) as any;
      global.Date.now = originalDate.now;
      global.Date.parse = originalDate.parse;
      global.Date.UTC = originalDate.UTC;

      generateTemplateRevisionHistoryPdf(mockData);

      expect(mockSave).toHaveBeenCalledWith(expect.stringContaining('2025-03-15'));

      // Restore original Date
      global.Date = originalDate;
    });
  });
});
