import { createKitFilteringOptions, formatKitAttribute } from '../../utils/kitPresenters';

describe('formatKitAttribute', () => {
  it('formats scalar attribute types and joins non-empty values', () => {
    const kit = {
      latestVersion: {
        attributes: {
          boolKey: true,
          numKey: 42,
          strKey: 'hello',
          mixedArray: [true, false, ' x ', 0, null, undefined],
        },
      },
    } as any;

    expect(formatKitAttribute(kit, 'boolKey')).toBe('Yes');
    expect(formatKitAttribute(kit, 'numKey')).toBe('42');
    expect(formatKitAttribute(kit, 'strKey')).toBe('hello');
    expect(formatKitAttribute(kit, 'mixedArray')).toBe('Yes, No, x, 0');
  });

  it('formats numeric attribute objects with optional unit', () => {
    const kit = {
      latestVersion: {
        attributes: {
          withUnit: { value: 123.4, unit: 'kVA' },
          withoutUnit: { value: 200 },
          stringValue: { value: '300', unit: 'Amps' },
        },
      },
    } as any;

    expect(formatKitAttribute(kit, 'withUnit')).toBe('123.4 kVA');
    expect(formatKitAttribute(kit, 'withoutUnit')).toBe('200');
    expect(formatKitAttribute(kit, 'stringValue')).toBe('300 Amps');
  });

  it('handles missing attributes or keys gracefully', () => {
    const kit = { latestVersion: { attributes: null } } as any;
    expect(formatKitAttribute(kit, 'anything')).toBe('');
    expect(formatKitAttribute({} as any, 'anything')).toBe('');
  });

  it('stringifies objects without numeric value', () => {
    const kit = {
      latestVersion: {
        attributes: {
          obj: { a: 1, b: 'two' },
        },
      },
    } as any;

    expect(formatKitAttribute(kit, 'obj')).toBe(JSON.stringify({ a: 1, b: 'two' }));
  });
});

describe('createKitFilteringOptions', () => {
  it('builds filtering options for regions, programs, and use cases, trimming and dropping empties', () => {
    const options = {
      regions: [' NA ', '', 'EU'],
      programs: ['IXD', ' ', 'ARS'],
      projectTypes: ['pt1', 'pt2'],
    } as any;

    const filteringOptions = createKitFilteringOptions(options);

    expect(filteringOptions).toEqual([
      { propertyKey: 'region', value: 'NA', label: 'NA' },
      { propertyKey: 'region', value: 'EU', label: 'EU' },
      { propertyKey: 'program', value: 'IXD', label: 'Inbound Cross Dock (IXD)' },
      { propertyKey: 'program', value: 'ARS', label: 'Amazon Robotics Sortable (ARS)' },
      { propertyKey: 'projectType', value: 'pt1', label: 'pt1' },
      { propertyKey: 'projectType', value: 'pt2', label: 'pt2' },
    ]);
  });
});
