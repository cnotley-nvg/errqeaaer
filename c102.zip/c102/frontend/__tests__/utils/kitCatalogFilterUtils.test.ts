import { buildKitFilterInput } from '../../utils/kitCatalogFilterUtils';

describe('buildKitFilterInput', () => {
  it('returns empty filter for empty query', () => {
    const filter = buildKitFilterInput({ tokenGroups: [], tokens: [] } as any);
    expect(filter).toEqual({});
  });

  it('maps name/description tokens for supported operators and dedupes values', () => {
    const query = {
      tokens: [
        { propertyKey: 'name', operator: ':', value: '  alpha  ' },
        { propertyKey: 'name', operator: '=', values: ['alpha', 'beta', 'beta'] },
        { propertyKey: 'description', operator: '!=', value: '  desc  ' },
      ],
    } as any;

    const filter = buildKitFilterInput(query);

    expect(filter).toEqual({
      nameContains: ['alpha', 'beta'],
      descriptionContains: ['desc'],
    });
  });

  it('maps region/program/useCase only for = or : operators', () => {
    const query = {
      tokens: [
        { propertyKey: 'region', operator: ':', value: 'NA' },
        { propertyKey: 'program', operator: '=', value: 'IXD' },
        { propertyKey: 'useCase', operator: ':', values: ['u1', 'u2'] },
        // unsupported operators should be ignored for these keys
        { propertyKey: 'region', operator: '!=', value: 'EU' },
        { propertyKey: 'program', operator: '>', value: 'SSD' },
        { propertyKey: 'useCase', operator: 'contains', value: 'u3' },
      ],
    } as any;

    const filter = buildKitFilterInput(query);

    expect(filter).toEqual({
      regionIn: ['NA'],
      programIn: ['IXD'],
      useCaseIn: ['u1', 'u2'],
    });
  });

  it('flattens nested token groups and ignores unknown property keys', () => {
    const query = {
      tokenGroups: [
        {
          tokens: [
            { propertyKey: 'name', operator: ':', value: 'n1' },
            {
              tokens: [
                { propertyKey: 'program', operator: ':', value: 'ARS' },
                { propertyKey: 'unknown', operator: ':', value: 'x' },
              ],
            },
          ],
        },
      ],
    } as any;

    const filter = buildKitFilterInput(query);

    expect(filter).toEqual({
      nameContains: ['n1'],
      programIn: ['ARS'],
    });
  });

  it('drops tokens with no usable values', () => {
    const query = {
      tokens: [
        { propertyKey: 'name', operator: ':', value: '   ' },
        { propertyKey: 'region', operator: ':', values: [null, undefined, ''] },
        { propertyKey: 'description', operator: ':', value: null },
      ],
    } as any;

    const filter = buildKitFilterInput(query);
    expect(filter).toEqual({});
  });
});
