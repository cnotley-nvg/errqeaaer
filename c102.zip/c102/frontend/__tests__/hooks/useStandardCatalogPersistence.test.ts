import React from 'react';
import { beforeEach, describe, expect, it, jest } from '@jest/globals';
import { act, renderHook } from '@testing-library/react';
import { createMemoryHistory } from 'history';
import type { MemoryHistory } from 'history';
import { Router } from 'react-router-dom';

import {
  type SortableField,
  type StandardCatalogStateSnapshot,
  useStandardCatalogPersistence,
} from '../../hooks/useStandardCatalogPersistence';

jest.mock('../../utils/logger', () => {
  const warnMock = jest.fn();

  return {
    __esModule: true,
    getScopedLogger: () => ({
      info: jest.fn(),
      warn: warnMock,
      error: jest.fn(),
      child: jest.fn().mockReturnThis(),
    }),
    __TESTING__: { warnMock },
  };
});

const getWarnSpy = () =>
  (
    jest.requireMock('../../utils/logger') as {
      __TESTING__: { warnMock: jest.Mock };
    }
  ).__TESTING__.warnMock;

const createSnapshot = (
  overrides: Partial<StandardCatalogStateSnapshot> = {}
): StandardCatalogStateSnapshot => {
  const basePropertyFilter: StandardCatalogStateSnapshot['propertyFilterQuery'] = {
    operation: 'and',
    tokens: [],
    tokenGroups: [],
  };

  return {
    viewType: 'card',
    propertyFilterQuery: basePropertyFilter,
    sortingField: 'name',
    sortingDescending: false,
    pageIndex: 1,
    pageSize: 20,
    ...overrides,
  };
};

const renderPersistenceHook = (
  fallback: StandardCatalogStateSnapshot,
  initialEntry: string = '/'
) => {
  const history = createMemoryHistory({ initialEntries: [initialEntry] });
  const Wrapper: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
    const [location, setLocation] = React.useState(history.location);

    React.useLayoutEffect(() => history.listen((next) => setLocation(next.location)), [history]);

    return React.createElement(Router, { location, navigator: history }, children ?? null);
  };
  const rendered = renderHook(() => useStandardCatalogPersistence(fallback), { wrapper: Wrapper });

  // Error handling is done automatically by renderHook in newer versions

  return {
    history,
    result: rendered.result,
  };
};

describe('useStandardCatalogPersistence', () => {
  beforeEach(() => {
    const warnSpy = getWarnSpy();
    warnSpy.mockClear();
  });

  it('returns the fallback state when no search parameters exist', () => {
    const fallback = createSnapshot();

    const { result } = renderPersistenceHook(fallback);

    expect(result.current.initialState).toEqual(fallback);
  });

  it('hydrates the state from URL search parameters when valid data exists', () => {
    const filterState = encodeURIComponent(
      JSON.stringify({
        operation: 'or',
        tokens: [
          {
            propertyKey: 'name',
            operator: '=',
            value: 'Electrical standard',
          },
        ],
        tokenGroups: [
          {
            propertyKey: 'region',
            operator: '=',
            value: 'Europe, Middle East and Africa',
          },
        ],
      })
    );

    const initialEntry = `/?view=table&sort=name&desc=1&page=3&filter=${filterState}`;

    const fallback = createSnapshot();
    const { result } = renderPersistenceHook(fallback, initialEntry);

    expect(result.current.initialState).toEqual({
      viewType: 'table',
      sortingField: 'name',
      sortingDescending: true,
      pageIndex: 3,
      pageSize: 20, // Added from fallback since not in URL
      propertyFilterQuery: {
        operation: 'or',
        tokens: [
          {
            propertyKey: 'name',
            operator: '=',
            value: 'Electrical standard',
          },
        ],
        tokenGroups: [
          {
            propertyKey: 'region',
            operator: '=',
            value: 'Europe, Middle East and Africa',
          },
        ],
      },
    });
  });

  it('sanitizes unexpected values found in the URL', () => {
    const initialEntry =
      '/?view=grid&sort=unknown&desc=maybe&page=-2&filter=%7B%22operation%22%3A%22xor%22%7D';
    const fallback = createSnapshot();

    const { result } = renderPersistenceHook(fallback, initialEntry);

    expect(result.current.initialState).toEqual(fallback);
  });

  it('logs a warning and falls back when the filter parameter is invalid JSON', () => {
    const fallback = createSnapshot();
    const { result } = renderPersistenceHook(fallback, '/?filter=%7Binvalid-json');

    expect(result.current.initialState).toEqual(fallback);
    const warnSpy = getWarnSpy();
    expect(warnSpy).toHaveBeenCalledWith('Unable to restore catalog filters from URL', {
      message: expect.any(String),
      name: 'SyntaxError',
    });
  });

  it('persists state updates into the URL search parameters', () => {
    const fallback = createSnapshot();
    const { result, history } = renderPersistenceHook(fallback);

    const nextState = createSnapshot({
      viewType: 'table',
      pageIndex: 2,
      sortingField: 'updatedAt' as SortableField,
      sortingDescending: true,
      propertyFilterQuery: {
        operation: 'and',
        tokens: [
          {
            propertyKey: 'program',
            operator: '=',
            value: 'Cross program',
          },
        ],
        tokenGroups: [],
      },
    });

    act(() => {
      result.current.persistState(nextState);
    });

    expect(history.location.search).not.toEqual('');
    const params = new URLSearchParams(history.location.search);
    expect(params.get('view')).toBe('table');
    expect(params.get('sort')).toBe('updatedAt');
    expect(params.get('desc')).toBe('1');
    expect(params.get('page')).toBe('2');

    const filterValue = params.get('filter');
    expect(filterValue).not.toBeNull();
    const parsedFilter = filterValue ? JSON.parse(filterValue) : null;
    expect(parsedFilter).toEqual(nextState.propertyFilterQuery);
  });

  it('round-trips filters with special characters via URL encoding', () => {
    const fallback = createSnapshot();
    const { result, history } = renderPersistenceHook(fallback);

    const nextState = createSnapshot({
      propertyFilterQuery: {
        operation: 'and',
        tokens: [
          {
            propertyKey: 'name',
            operator: '=',
            value: 'Name with spaces & symbols?=yes, ok',
          },
        ],
        tokenGroups: [],
      },
    });

    act(() => {
      result.current.persistState(nextState);
    });

    const params = new URLSearchParams(history.location.search);
    const filterValue = params.get('filter');
    expect(filterValue).not.toBeNull();
    const parsedFilter = filterValue ? JSON.parse(filterValue) : null;
    expect(parsedFilter).toEqual(nextState.propertyFilterQuery);
  });

  it('logs a warning when filter serialization fails and still clears empty filters', () => {
    const fallback = createSnapshot();
    const { result, history } = renderPersistenceHook(
      fallback,
      '/?filter=%7B%22operation%22%3A%22and%22%2C%22tokenGroups%22%3A[]%7D'
    );

    const warnSpy = getWarnSpy();
    const originalStringify = JSON.stringify.bind(JSON);

    const stringifySpy = jest
      .spyOn(JSON, 'stringify')
      .mockImplementation((value: unknown, replacer?: unknown, space?: unknown) => {
        if (
          value &&
          typeof value === 'object' &&
          'tokenGroups' in (value as Record<string, unknown>)
        ) {
          throw new Error('boom');
        }

        return originalStringify(value, replacer as never, space as never);
      });

    const withTokens = createSnapshot({
      propertyFilterQuery: {
        operation: 'and',
        tokens: [
          {
            propertyKey: 'region',
            operator: '=',
            value: 'North America',
          },
        ],
        tokenGroups: [],
      },
    });

    act(() => {
      result.current.persistState(withTokens);
    });

    expect(history.location.search).toBe('');
    expect(warnSpy).toHaveBeenCalledWith('Unable to persist catalog filters in URL', {
      message: 'boom',
      name: 'Error',
    });

    stringifySpy.mockRestore();

    act(() => {
      result.current.persistState(createSnapshot());
    });

    expect(history.location.search).toBe('');
  });

  it('removes URL parameters when state matches the fallback snapshot', () => {
    const fallback = createSnapshot();
    const { result, history } = renderPersistenceHook(fallback, '/?view=table&page=3');

    act(() => {
      result.current.persistState(fallback);
    });

    expect(history.location.search).toBe('');
  });

  it('replaces the current history entry when persisting', () => {
    const fallback = createSnapshot();
    const { result, history } = renderPersistenceHook(fallback);

    const initialIndex = history.index;

    act(() => {
      result.current.persistState(
        createSnapshot({
          viewType: 'table',
          sortingField: 'region',
        })
      );
    });

    expect(history.index).toBe(initialIndex);
  });
});
