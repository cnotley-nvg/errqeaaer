import { describe, expect, it, beforeEach, jest } from '@jest/globals';
import { act, renderHook, waitFor } from '@testing-library/react';

import { useLatestStandardVersionsSearch } from '../../hooks/useLatestStandardVersionsSearch';
import type { FilterInput } from '@amzn/global-realty-mosaic-graphql-schema';

type StandardsRequestArgs = [unknown, { filter: FilterInput }?];
type StandardsRequest = (...args: StandardsRequestArgs) => Promise<unknown>;

jest.mock('../../api/graphqlClient', () => ({
  graphqlClient: {
    request: jest.fn<StandardsRequest>(),
  },
}));

const { graphqlClient } = require('../../api/graphqlClient') as {
  graphqlClient: {
    request: jest.MockedFunction<StandardsRequest>;
  };
};

const createFilter = (): FilterInput => ({
  pageIdx: 2,
  limit: 12,
  orderBy: 'name',
  orderDesc: false,
});

describe('useLatestStandardVersionsSearch', () => {
  beforeEach(() => {
    graphqlClient.request.mockReset();
  });

  it('requests standards and exposes the response payload', async () => {
    graphqlClient.request.mockResolvedValue({
      searchLatestStandardVersions: {
        items: [
          {
            id: 'v1',
            standardId: '1',
            version: 'v1',
            isLatest: true,
            accCreatedAt: '2024-01-01T00:00:00.000Z',
            accCreatedBy: 'user1',
            accUpdatedAt: '2024-01-02T00:00:00.000Z',
            accUpdatedBy: 'user1',
            createdAt: '2024-01-01T00:00:00.000Z',
            updatedAt: '2024-01-02T00:00:00.000Z',
            attributes: { region: 'North America' },
            standard: {
              id: '1',
              name: 'Electrical standard',
              description: null,
              accProjectId: 'ACC-1',
            },
          },
          {
            id: 'v2',
            standardId: '2',
            version: 'v2',
            isLatest: true,
            accCreatedAt: '2024-01-05T00:00:00.000Z',
            accCreatedBy: 'user2',
            accUpdatedAt: '2024-01-06T00:00:00.000Z',
            accUpdatedBy: 'user2',
            createdAt: '2024-01-05T00:00:00.000Z',
            updatedAt: '2024-01-06T00:00:00.000Z',
            attributes: { region: 'EMEA' },
            standard: {
              id: '2',
              name: 'Mechanical standard',
              description: null,
              accProjectId: 'ACC-2',
            },
          },
        ],
        total: 2,
        pageIdx: 2,
        limit: 12,
        hasNext: false,
      },
    });

    const filter = createFilter();
    const { result } = renderHook(() => useLatestStandardVersionsSearch({ filter }));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(graphqlClient.request).toHaveBeenCalledWith(expect.anything(), {
      filter: expect.objectContaining({ pageIdx: 2, limit: 12, orderBy: 'name', orderDesc: false }),
    });
    expect(result.current.items).toHaveLength(2);
    expect(result.current.totalCount).toBe(2);
    expect(result.current.pageIdx).toBe(2);
  });

  it('handles failing requests by exposing error messaging', async () => {
    graphqlClient.request.mockRejectedValue(new Error('Network down'));

    const filter = createFilter();
    const { result } = renderHook(() => useLatestStandardVersionsSearch({ filter }));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.error).toBe('Network down');
    expect(result.current.items).toEqual([]);
    expect(result.current.totalPages).toBe(1);
  });

  it('uses a fallback error message when rejection is not an Error instance', async () => {
    graphqlClient.request.mockRejectedValue('Service unavailable');

    const filter = createFilter();
    const { result } = renderHook(() => useLatestStandardVersionsSearch({ filter }));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.error).toBe('Unable to load standard versions.');
  });

  it('updates pagination state when refetching', async () => {
    graphqlClient.request.mockResolvedValueOnce({
      searchLatestStandardVersions: {
        items: [],
        total: 0,
        pageIdx: 2,
        limit: 12,
        hasNext: false,
      },
    });

    graphqlClient.request.mockResolvedValueOnce({
      searchLatestStandardVersions: {
        items: [
          {
            id: 'v3',
            standardId: '3',
            version: 'v3',
            isLatest: true,
            accCreatedAt: '2024-02-01T00:00:00.000Z',
            accCreatedBy: 'user3',
            accUpdatedAt: '2024-02-02T00:00:00.000Z',
            accUpdatedBy: 'user3',
            createdAt: '2024-02-01T00:00:00.000Z',
            updatedAt: '2024-02-02T00:00:00.000Z',
            attributes: {},
            standard: {
              id: '3',
              name: 'Fire safety',
              description: null,
              accProjectId: 'ACC-3',
            },
          },
        ],
        total: 48,
        pageIdx: 4,
        limit: 12,
        hasNext: false,
      },
    });

    const filter = createFilter();
    const { result } = renderHook(() => useLatestStandardVersionsSearch({ filter }));

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.pageIdx).toBe(2);

    await act(async () => {
      await result.current.refetch();
    });

    expect(result.current.pageIdx).toBe(4);
    expect(result.current.totalPages).toBe(4);
    expect(result.current.items[0]?.standard.name).toBe('Fire safety');
  });

  it('defaults missing response fields while preserving pagination inputs', async () => {
    graphqlClient.request.mockResolvedValue({ searchLatestStandardVersions: {} });

    const filter: FilterInput = { pageIdx: 5, limit: 25, orderBy: 'name' };
    const { result } = renderHook(() => useLatestStandardVersionsSearch({ filter }));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.items).toEqual([]);
    expect(result.current.totalPages).toBe(1);
    expect(result.current.pageIdx).toBe(5);
    expect(result.current.limit).toBe(25);
  });
});
