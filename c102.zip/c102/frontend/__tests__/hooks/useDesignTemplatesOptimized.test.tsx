import { renderHook, waitFor } from '@testing-library/react';
import { useDesignTemplatesOptimized } from '../../hooks/useDesignTemplatesOptimized';
import * as useLatestTemplateVersionsSearchModule from '../../hooks/useLatestTemplateVersionsSearch';
import type { TemplateVersionWithTemplate } from '../../hooks/useLatestTemplateVersionsSearch';

// Mock the useLatestTemplateVersionsSearch hook
jest.mock('../../hooks/useLatestTemplateVersionsSearch');

const mockUseLatestTemplateVersionsSearch =
  useLatestTemplateVersionsSearchModule.useLatestTemplateVersionsSearch as jest.MockedFunction<
    typeof useLatestTemplateVersionsSearchModule.useLatestTemplateVersionsSearch
  >;

describe('useDesignTemplatesOptimized', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should return loading state initially', () => {
    mockUseLatestTemplateVersionsSearch.mockReturnValue({
      items: [],
      totalCount: 0,
      totalPages: 1,
      pageIdx: 0,
      limit: 1000,
      loading: true,
      error: null,
      refetch: jest.fn(),
    });

    const { result } = renderHook(() => useDesignTemplatesOptimized());

    expect(result.current.loading).toBe(true);
    expect(result.current.templates).toEqual([]);
    expect(result.current.error).toBeNull();
  });

  it('should transform template versions to design templates correctly', async () => {
    const mockVersions: TemplateVersionWithTemplate[] = [
      {
        id: 'version-1',
        version: '1.0',
        isLatest: true,
        accFolderId: 'folder-1',
        brsId: null,
        createdAt: '2024-01-01T00:00:00Z',
        updatedAt: '2024-01-01T00:00:00Z',
        attributes: { facilityType: 'Data Center' },
        files: [],
        template: {
          id: 'template-1',
          name: 'Standard Data Center Template',
          description: 'A standard template for data centers',
          accProjectId: 'project-1',
        },
      },
      {
        id: 'version-2',
        version: '1.0',
        isLatest: true,
        accFolderId: 'folder-2',
        brsId: null,
        createdAt: '2024-01-02T00:00:00Z',
        updatedAt: '2024-01-02T00:00:00Z',
        attributes: { facilityType: 'Warehouse' },
        files: [],
        template: {
          id: 'template-2',
          name: 'Standard Warehouse Template',
          description: 'A standard template for warehouses',
          accProjectId: 'project-2',
        },
      },
    ];

    mockUseLatestTemplateVersionsSearch.mockReturnValue({
      items: mockVersions,
      totalCount: 2,
      totalPages: 1,
      pageIdx: 0,
      limit: 1000,
      loading: false,
      error: null,
      refetch: jest.fn(),
    });

    const { result } = renderHook(() => useDesignTemplatesOptimized());

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.templates).toHaveLength(2);
    expect(result.current.templates[0]).toEqual({
      id: 'template-1',
      name: 'Standard Data Center Template',
      description: 'A standard template for data centers',
      facilityTypes: ['Data Center'],
    });
    expect(result.current.templates[1]).toEqual({
      id: 'template-2',
      name: 'Standard Warehouse Template',
      description: 'A standard template for warehouses',
      facilityTypes: ['Warehouse'],
    });
  });

  it('should group multiple versions of the same template and deduplicate facility types', async () => {
    const mockVersions: TemplateVersionWithTemplate[] = [
      {
        id: 'version-1',
        version: '1.0',
        isLatest: true,
        accFolderId: 'folder-1',
        brsId: null,
        createdAt: '2024-01-01T00:00:00Z',
        updatedAt: '2024-01-01T00:00:00Z',
        attributes: { facilityType: 'Data Center' },
        files: [],
        template: {
          id: 'template-1',
          name: 'Multi-Purpose Template',
          description: 'Template for multiple facility types',
          accProjectId: 'project-1',
        },
      },
      {
        id: 'version-2',
        version: '2.0',
        isLatest: true,
        accFolderId: 'folder-2',
        brsId: null,
        createdAt: '2024-01-02T00:00:00Z',
        updatedAt: '2024-01-02T00:00:00Z',
        attributes: { facilityType: 'Warehouse' },
        files: [],
        template: {
          id: 'template-1', // Same template ID
          name: 'Multi-Purpose Template',
          description: 'Template for multiple facility types',
          accProjectId: 'project-1',
        },
      },
      {
        id: 'version-3',
        version: '3.0',
        isLatest: true,
        accFolderId: 'folder-3',
        brsId: null,
        createdAt: '2024-01-03T00:00:00Z',
        updatedAt: '2024-01-03T00:00:00Z',
        attributes: { facilityType: 'Data Center' }, // Duplicate facility type
        files: [],
        template: {
          id: 'template-1', // Same template ID
          name: 'Multi-Purpose Template',
          description: 'Template for multiple facility types',
          accProjectId: 'project-1',
        },
      },
    ];

    mockUseLatestTemplateVersionsSearch.mockReturnValue({
      items: mockVersions,
      totalCount: 3,
      totalPages: 1,
      pageIdx: 0,
      limit: 1000,
      loading: false,
      error: null,
      refetch: jest.fn(),
    });

    const { result } = renderHook(() => useDesignTemplatesOptimized());

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    // Should have only 1 template with 2 unique facility types
    expect(result.current.templates).toHaveLength(1);
    expect(result.current.templates[0]).toEqual({
      id: 'template-1',
      name: 'Multi-Purpose Template',
      description: 'Template for multiple facility types',
      facilityTypes: ['Data Center', 'Warehouse'], // Sorted and deduplicated
    });
  });

  it('should handle templates without facilityType attribute', async () => {
    const mockVersions: TemplateVersionWithTemplate[] = [
      {
        id: 'version-1',
        version: '1.0',
        isLatest: true,
        accFolderId: 'folder-1',
        brsId: null,
        createdAt: '2024-01-01T00:00:00Z',
        updatedAt: '2024-01-01T00:00:00Z',
        attributes: {}, // No facilityType
        files: [],
        template: {
          id: 'template-1',
          name: 'Generic Template',
          description: 'A template without facility type',
          accProjectId: 'project-1',
        },
      },
    ];

    mockUseLatestTemplateVersionsSearch.mockReturnValue({
      items: mockVersions,
      totalCount: 1,
      totalPages: 1,
      pageIdx: 0,
      limit: 1000,
      loading: false,
      error: null,
      refetch: jest.fn(),
    });

    const { result } = renderHook(() => useDesignTemplatesOptimized());

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.templates).toHaveLength(1);
    expect(result.current.templates[0]).toEqual({
      id: 'template-1',
      name: 'Generic Template',
      description: 'A template without facility type',
      facilityTypes: [], // Empty array when no facilityType
    });
  });

  it('should handle templates with null description', async () => {
    const mockVersions: TemplateVersionWithTemplate[] = [
      {
        id: 'version-1',
        version: '1.0',
        isLatest: true,
        accFolderId: 'folder-1',
        brsId: null,
        createdAt: '2024-01-01T00:00:00Z',
        updatedAt: '2024-01-01T00:00:00Z',
        attributes: { facilityType: 'Office' },
        files: [],
        template: {
          id: 'template-1',
          name: 'Office Template',
          description: null, // Null description
          accProjectId: 'project-1',
        },
      },
    ];

    mockUseLatestTemplateVersionsSearch.mockReturnValue({
      items: mockVersions,
      totalCount: 1,
      totalPages: 1,
      pageIdx: 0,
      limit: 1000,
      loading: false,
      error: null,
      refetch: jest.fn(),
    });

    const { result } = renderHook(() => useDesignTemplatesOptimized());

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.templates).toHaveLength(1);
    expect(result.current.templates[0].description).toBeNull();
  });

  it('should propagate error from underlying hook', async () => {
    const errorMessage = 'Failed to fetch template versions';

    mockUseLatestTemplateVersionsSearch.mockReturnValue({
      items: [],
      totalCount: 0,
      totalPages: 1,
      pageIdx: 0,
      limit: 1000,
      loading: false,
      error: errorMessage,
      refetch: jest.fn(),
    });

    const { result } = renderHook(() => useDesignTemplatesOptimized());

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.error).toBe(errorMessage);
    expect(result.current.templates).toEqual([]);
  });

  it('should sort facility types alphabetically within each template', async () => {
    const mockVersions: TemplateVersionWithTemplate[] = [
      {
        id: 'version-1',
        version: '1.0',
        isLatest: true,
        accFolderId: 'folder-1',
        brsId: null,
        createdAt: '2024-01-01T00:00:00Z',
        updatedAt: '2024-01-01T00:00:00Z',
        attributes: { facilityType: 'Warehouse' },
        files: [],
        template: {
          id: 'template-1',
          name: 'Multi-Facility Template',
          description: 'Template supporting multiple facilities',
          accProjectId: 'project-1',
        },
      },
      {
        id: 'version-2',
        version: '2.0',
        isLatest: true,
        accFolderId: 'folder-2',
        brsId: null,
        createdAt: '2024-01-02T00:00:00Z',
        updatedAt: '2024-01-02T00:00:00Z',
        attributes: { facilityType: 'Data Center' },
        files: [],
        template: {
          id: 'template-1', // Same template
          name: 'Multi-Facility Template',
          description: 'Template supporting multiple facilities',
          accProjectId: 'project-1',
        },
      },
      {
        id: 'version-3',
        version: '3.0',
        isLatest: true,
        accFolderId: 'folder-3',
        brsId: null,
        createdAt: '2024-01-03T00:00:00Z',
        updatedAt: '2024-01-03T00:00:00Z',
        attributes: { facilityType: 'Office' },
        files: [],
        template: {
          id: 'template-1', // Same template
          name: 'Multi-Facility Template',
          description: 'Template supporting multiple facilities',
          accProjectId: 'project-1',
        },
      },
    ];

    mockUseLatestTemplateVersionsSearch.mockReturnValue({
      items: mockVersions,
      totalCount: 3,
      totalPages: 1,
      pageIdx: 0,
      limit: 1000,
      loading: false,
      error: null,
      refetch: jest.fn(),
    });

    const { result } = renderHook(() => useDesignTemplatesOptimized());

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.templates[0].facilityTypes).toEqual([
      'Data Center',
      'Office',
      'Warehouse',
    ]); // Alphabetically sorted
  });

  it('should call useLatestTemplateVersionsSearch with correct filter parameters', () => {
    mockUseLatestTemplateVersionsSearch.mockReturnValue({
      items: [],
      totalCount: 0,
      totalPages: 1,
      pageIdx: 0,
      limit: 1000,
      loading: false,
      error: null,
      refetch: jest.fn(),
    });

    renderHook(() => useDesignTemplatesOptimized());

    expect(mockUseLatestTemplateVersionsSearch).toHaveBeenCalledWith({
      filter: {
        pageIdx: 0,
        limit: 1000,
        orderBy: 'name',
        orderDesc: false,
      },
    });
  });
});
