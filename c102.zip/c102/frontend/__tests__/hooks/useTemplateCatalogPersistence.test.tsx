import React from 'react';
import { beforeEach, describe, expect, it, jest } from '@jest/globals';
import { act, renderHook } from '@testing-library/react';
import { createMemoryHistory } from 'history';
import type { MemoryHistory } from 'history';
import { Router } from 'react-router-dom';

import {
  type SortableTemplateField,
  type TemplateCatalogStateSnapshot,
  useTemplateCatalogPersistence,
} from '../../hooks/useTemplateCatalogPersistence';

jest.mock('../../utils/logger', () => {
  const warnMock = jest.fn();

  return {
    __esModule: true,
    getScopedLogger: () => ({
      info: jest.fn(),
      warn: warnMock,
      error: jest.fn(),
      child: jest.fn().mockReturnThis(),
    }),
    __TESTING__: { warnMock },
  };
});

const getWarnSpy = () =>
  (
    jest.requireMock('../../utils/logger') as {
      __TESTING__: { warnMock: jest.Mock };
    }
  ).__TESTING__.warnMock;

const createSnapshot = (
  overrides: Partial<TemplateCatalogStateSnapshot> = {}
): TemplateCatalogStateSnapshot => {
  const basePropertyFilter: TemplateCatalogStateSnapshot['propertyFilterQuery'] = {
    operation: 'and',
    tokens: [],
    tokenGroups: [],
  };

  return {
    viewType: 'card',
    propertyFilterQuery: basePropertyFilter,
    sortingField: 'name',
    sortingDescending: false,
    pageIndex: 1,
    pageSize: 20,
    ...overrides,
  };
};

const renderWithHistory = (fallback: TemplateCatalogStateSnapshot, initialUrl = '/templates') => {
  const history = createMemoryHistory({ initialEntries: [initialUrl] });
  const Wrapper: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
    const [location, setLocation] = React.useState(history.location);

    React.useLayoutEffect(() => history.listen((next) => setLocation(next.location)), []);

    return React.createElement(Router, { location, navigator: history }, children ?? null);
  };

  const rendered = renderHook(() => useTemplateCatalogPersistence(fallback), { wrapper: Wrapper });

  return { ...rendered, history };
};

describe('useTemplateCatalogPersistence', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('URL parsing', () => {
    it('should initialize with fallback state when URL has no params', () => {
      const fallback = createSnapshot();
      const { result } = renderWithHistory(fallback, '/templates');

      expect(result.current.initialState).toEqual(fallback);
    });

    it('should parse viewType from URL', () => {
      const fallback = createSnapshot();
      const { result } = renderWithHistory(fallback, '/templates?view=table');

      expect(result.current.initialState.viewType).toBe('table');
    });

    it('should parse sortingField from URL', () => {
      const fallback = createSnapshot();
      const { result } = renderWithHistory(fallback, '/templates?sort=capacity');

      expect(result.current.initialState.sortingField).toBe('capacity');
    });

    it('should parse sortingDescending from URL', () => {
      const fallback = createSnapshot();
      const { result } = renderWithHistory(fallback, '/templates?desc=1');

      expect(result.current.initialState.sortingDescending).toBe(true);
    });

    it('should parse pageIndex from URL', () => {
      const fallback = createSnapshot();
      const { result } = renderWithHistory(fallback, '/templates?page=5');

      expect(result.current.initialState.pageIndex).toBe(5);
    });

    it('should parse filter tokens from URL', () => {
      const fallback = createSnapshot();
      const filterJson = JSON.stringify({
        operation: 'and',
        tokens: [{ propertyKey: 'region', operator: '=', value: 'NA' }],
      });
      const { result } = renderWithHistory(
        fallback,
        `/templates?filter=${encodeURIComponent(filterJson)}`
      );

      expect(result.current.initialState.propertyFilterQuery).toEqual({
        operation: 'and',
        tokens: [{ propertyKey: 'region', operator: '=', value: 'NA' }],
        tokenGroups: [],
      });
    });

    it('should parse complex filter with multiple tokens', () => {
      const fallback = createSnapshot();
      const filterJson = JSON.stringify({
        operation: 'or',
        tokens: [
          { propertyKey: 'region', operator: '=', value: 'NA' },
          { propertyKey: 'capacity', operator: '>=', value: '100000' },
          { propertyKey: 'program', operator: ':', value: 'AMZL' },
        ],
      });
      const { result } = renderWithHistory(
        fallback,
        `/templates?filter=${encodeURIComponent(filterJson)}`
      );

      expect(result.current.initialState.propertyFilterQuery.tokens).toHaveLength(3);
      expect(result.current.initialState.propertyFilterQuery.operation).toBe('or');
    });

    it('should fallback to default for invalid viewType', () => {
      const fallback = createSnapshot({ viewType: 'card' });
      const { result } = renderWithHistory(fallback, '/templates?view=invalid');

      expect(result.current.initialState.viewType).toBe('card');
    });

    it('should fallback to default for invalid sortField', () => {
      const fallback = createSnapshot({ sortingField: 'name' });
      const { result } = renderWithHistory(fallback, '/templates?sort=invalidField');

      expect(result.current.initialState.sortingField).toBe('name');
    });

    it('should fallback to default for invalid pageIndex', () => {
      const fallback = createSnapshot({ pageIndex: 1 });
      const { result } = renderWithHistory(fallback, '/templates?page=invalid');

      expect(result.current.initialState.pageIndex).toBe(1);
    });

    it('should fallback to default for malformed filter JSON', () => {
      const fallback = createSnapshot();
      const warnSpy = getWarnSpy();
      const { result } = renderWithHistory(fallback, '/templates?filter={invalid json}');

      expect(result.current.initialState.propertyFilterQuery).toEqual(fallback.propertyFilterQuery);
      expect(warnSpy).toHaveBeenCalledWith(
        'Unable to restore catalog filters from URL',
        expect.objectContaining({ message: expect.any(String) })
      );
    });

    it('should validate all 21 sortable fields', () => {
      const validFields: SortableTemplateField[] = [
        'name',
        'accProjectId',
        'updatedAt',
        'createdAt',
        'region',
        'program',
        'capacity',
        'stories',
        'facilityType',
        'businessUnit',
        'siteAcreage',
        'dockDoorCount',
        'totalTrailerParking',
        'maxWeeklyHeadcount',
        'powerKva',
        'createdBy',
        'grossSquareFootage',
        'peakShiftHeadcount',
        'clearHeightFtM',
        'dspParking',
        'generation',
      ];

      validFields.forEach((field) => {
        const fallback = createSnapshot();
        const { result } = renderWithHistory(fallback, `/templates?sort=${field}`);
        expect(result.current.initialState.sortingField).toBe(field);
      });
    });
  });

  describe('URL writing', () => {
    it('should write viewType to URL when different from default', () => {
      const fallback = createSnapshot({ viewType: 'card' });
      const { result, history } = renderWithHistory(fallback);

      act(() => {
        result.current.persistState(createSnapshot({ viewType: 'table' }));
      });

      expect(history.location.search).toContain('view=table');
    });

    it('should remove viewType from URL when returning to default', () => {
      const fallback = createSnapshot({ viewType: 'card' });
      const { result, history } = renderWithHistory(fallback, '/templates?view=table');

      act(() => {
        result.current.persistState(createSnapshot({ viewType: 'card' }));
      });

      expect(history.location.search).not.toContain('view=');
    });

    it('should write sorting to URL', () => {
      const fallback = createSnapshot();
      const { result, history } = renderWithHistory(fallback);

      act(() => {
        result.current.persistState(
          createSnapshot({
            sortingField: 'capacity',
            sortingDescending: true,
          })
        );
      });

      expect(history.location.search).toContain('sort=capacity');
      expect(history.location.search).toContain('desc=1');
    });

    it('should write pageIndex to URL', () => {
      const fallback = createSnapshot();
      const { result, history } = renderWithHistory(fallback);

      act(() => {
        result.current.persistState(createSnapshot({ pageIndex: 3 }));
      });

      expect(history.location.search).toContain('page=3');
    });

    it('should write filters to URL as JSON', () => {
      const fallback = createSnapshot();
      const { result, history } = renderWithHistory(fallback);

      act(() => {
        result.current.persistState(
          createSnapshot({
            propertyFilterQuery: {
              operation: 'and',
              tokens: [{ propertyKey: 'region', operator: '=', value: 'NA' }],
            },
          })
        );
      });

      expect(history.location.search).toContain('filter=');
      const params = new URLSearchParams(history.location.search);
      const filter = params.get('filter');
      expect(filter).toBeTruthy();
      const parsed = JSON.parse(filter!);
      expect(parsed.tokens).toHaveLength(1);
      expect(parsed.tokens[0].propertyKey).toBe('region');
    });

    it('should remove filter param when filters are cleared', () => {
      const fallback = createSnapshot();
      const filterJson = JSON.stringify({
        operation: 'and',
        tokens: [{ propertyKey: 'region', operator: '=', value: 'NA' }],
      });
      const { result, history } = renderWithHistory(
        fallback,
        `/templates?filter=${encodeURIComponent(filterJson)}`
      );

      act(() => {
        result.current.persistState(
          createSnapshot({
            propertyFilterQuery: { operation: 'and', tokens: [] },
          })
        );
      });

      expect(history.location.search).not.toContain('filter=');
    });

    it('should write multiple params simultaneously', () => {
      const fallback = createSnapshot();
      const { result, history } = renderWithHistory(fallback);

      act(() => {
        result.current.persistState(
          createSnapshot({
            viewType: 'table',
            sortingField: 'capacity',
            sortingDescending: true,
            pageIndex: 2,
            propertyFilterQuery: {
              operation: 'and',
              tokens: [{ propertyKey: 'region', operator: '=', value: 'NA' }],
            },
          })
        );
      });

      expect(history.location.search).toContain('view=table');
      expect(history.location.search).toContain('sort=capacity');
      expect(history.location.search).toContain('desc=1');
      expect(history.location.search).toContain('page=2');
      expect(history.location.search).toContain('filter=');
    });

    it('should use replace mode (not push) for history', () => {
      const fallback = createSnapshot();
      const { result, history } = renderWithHistory(fallback);

      const initialLength = history.index + 1;

      act(() => {
        result.current.persistState(createSnapshot({ viewType: 'table' }));
      });

      // History length should not increase (replace mode)
      expect(history.index + 1).toBe(initialLength);
    });
  });

  describe('Filter encoding', () => {
    it('should encode empty filter as null', () => {
      const fallback = createSnapshot();
      const { result, history } = renderWithHistory(fallback);

      act(() => {
        result.current.persistState(
          createSnapshot({
            propertyFilterQuery: { operation: 'and', tokens: [] },
          })
        );
      });

      expect(history.location.search).not.toContain('filter=');
    });

    it('should encode simple filter', () => {
      const fallback = createSnapshot();
      const { result, history } = renderWithHistory(fallback);

      act(() => {
        result.current.persistState(
          createSnapshot({
            propertyFilterQuery: {
              operation: 'and',
              tokens: [{ propertyKey: 'name', operator: ':', value: 'test' }],
            },
          })
        );
      });

      const params = new URLSearchParams(history.location.search);
      const filter = params.get('filter');
      const parsed = JSON.parse(filter!);

      expect(parsed).toEqual({
        operation: 'and',
        tokens: [{ propertyKey: 'name', operator: ':', value: 'test' }],
        tokenGroups: [],
      });
    });

    it('should encode complex filter with multiple operators', () => {
      const fallback = createSnapshot();
      const { result, history } = renderWithHistory(fallback);

      act(() => {
        result.current.persistState(
          createSnapshot({
            propertyFilterQuery: {
              operation: 'or',
              tokens: [
                { propertyKey: 'capacity', operator: '>=', value: '100000' },
                { propertyKey: 'region', operator: '!=', value: 'EU' },
                { propertyKey: 'program', operator: '^', value: 'AM' },
              ],
            },
          })
        );
      });

      const params = new URLSearchParams(history.location.search);
      const filter = params.get('filter');
      const parsed = JSON.parse(filter!);

      expect(parsed.tokens).toHaveLength(3);
      expect(parsed.operation).toBe('or');
    });
  });

  describe('Browser navigation', () => {
    it('should restore state when navigating back', () => {
      const fallback = createSnapshot();
      const { result, history } = renderWithHistory(fallback);

      // Set state 1
      act(() => {
        result.current.persistState(createSnapshot({ viewType: 'table' }));
      });

      // Set state 2
      act(() => {
        result.current.persistState(
          createSnapshot({ viewType: 'table', sortingField: 'capacity' })
        );
      });

      // Navigate to different page
      act(() => {
        history.push('/kits');
      });

      // Navigate back
      act(() => {
        history.back();
      });

      // Should restore previous state
      expect(history.location.search).toContain('view=table');
      expect(history.location.search).toContain('sort=capacity');
    });
  });

  describe('Edge cases', () => {
    it('should handle page index less than 1', () => {
      const fallback = createSnapshot();
      const { result } = renderWithHistory(fallback, '/templates?page=0');

      expect(result.current.initialState.pageIndex).toBe(1);
    });

    it('should handle negative page index', () => {
      const fallback = createSnapshot();
      const { result } = renderWithHistory(fallback, '/templates?page=-5');

      expect(result.current.initialState.pageIndex).toBe(1);
    });

    it('should handle non-numeric page index', () => {
      const fallback = createSnapshot();
      const { result } = renderWithHistory(fallback, '/templates?page=abc');

      expect(result.current.initialState.pageIndex).toBe(1);
    });

    it('should handle desc=0 as false', () => {
      const fallback = createSnapshot();
      const { result } = renderWithHistory(fallback, '/templates?desc=0');

      expect(result.current.initialState.sortingDescending).toBe(false);
    });

    it('should handle desc=false as false', () => {
      const fallback = createSnapshot();
      const { result } = renderWithHistory(fallback, '/templates?desc=false');

      expect(result.current.initialState.sortingDescending).toBe(false);
    });

    it('should handle empty filter param', () => {
      const fallback = createSnapshot();
      const { result } = renderWithHistory(fallback, '/templates?filter=');

      expect(result.current.initialState.propertyFilterQuery).toEqual(fallback.propertyFilterQuery);
    });

    it('should handle filter with missing tokens array', () => {
      const fallback = createSnapshot();
      const filterJson = JSON.stringify({ operation: 'and' });
      const { result } = renderWithHistory(
        fallback,
        `/templates?filter=${encodeURIComponent(filterJson)}`
      );

      expect(result.current.initialState.propertyFilterQuery.tokens).toEqual([]);
    });
  });
});
