import { describe, expect, it, jest, beforeEach } from '@jest/globals';
import { act, renderHook, waitFor } from '@testing-library/react';

import {
  useStandardCatalogControls,
  type PropertyFilterQuery,
} from '../../hooks/useStandardCatalogControls';

const persistStateMock = jest.fn();

const createCatalogSnapshot = () => ({
  viewType: 'table' as const,
  propertyFilterQuery: {
    operation: 'and',
    tokens: [],
    tokenGroups: [],
  } satisfies PropertyFilterQuery,
  sortingField: 'name' as const,
  sortingDescending: false,
  pageIndex: 3,
  pageSize: 20, // Add default page size
});

jest.mock('../../hooks/useStandardCatalogPersistence', () => {
  const actual = jest.requireActual<typeof import('../../hooks/useStandardCatalogPersistence')>(
    '../../hooks/useStandardCatalogPersistence'
  );
  return {
    ...actual,
    useStandardCatalogPersistence: jest.fn(() => ({
      initialState: createCatalogSnapshot(),
      persistState: persistStateMock,
    })),
  };
});

describe('useStandardCatalogControls', () => {
  beforeEach(() => {
    persistStateMock.mockClear();
  });

  it('initializes from persistent state and builds a filter input', () => {
    const { result } = renderHook(() => useStandardCatalogControls());

    // Check that initial state is loaded from persistence
    expect(result.current.viewType).toBe('table');
    expect(result.current.pageIndex).toBe(3);
    expect(result.current.filterInput.orderBy).toBe('name');
    expect(result.current.filterInput.orderDesc).toBe(false);
    expect(result.current.filterInput.pageIdx).toBe(2);

    // persistState should NOT be called on mount when state matches initialState
    // (this is an optimization to prevent unnecessary URL updates)
    expect(persistStateMock).not.toHaveBeenCalled();
  });

  it('updates property filter query and resets pagination', async () => {
    const { result } = renderHook(() => useStandardCatalogControls());

    const nextQuery: PropertyFilterQuery = {
      operation: 'or',
      tokens: [{ propertyKey: 'name', operator: '=', value: 'Electrical standard' }],
      tokenGroups: [],
    };

    act(() => {
      result.current.handlePropertyFilterChange(nextQuery);
    });

    expect(result.current.propertyFilterQuery).toEqual(nextQuery);
    expect(result.current.pageIndex).toBe(1);

    await waitFor(() => {
      expect(persistStateMock).toHaveBeenLastCalledWith(
        expect.objectContaining({ pageIndex: 1, propertyFilterQuery: nextQuery })
      );
    });
  });

  it('handles sorting and pagination interactions', async () => {
    const { result } = renderHook(() => useStandardCatalogControls());

    act(() => {
      result.current.handleSortingChange('name', false);
    });

    expect(result.current.sortingField).toBe('name');
    expect(result.current.sortingDescending).toBe(false);
    expect(result.current.pageIndex).toBe(1);

    act(() => {
      result.current.handlePageChange(4);
    });

    expect(result.current.pageIndex).toBe(4);

    await waitFor(() => {
      expect(persistStateMock).toHaveBeenLastCalledWith(
        expect.objectContaining({ sortingField: 'name', pageIndex: 4 })
      );
    });
  });

  it('handles page size changes and resets to first page', async () => {
    const { result } = renderHook(() => useStandardCatalogControls());

    // Navigate to page 3
    act(() => {
      result.current.handlePageChange(3);
    });

    expect(result.current.pageIndex).toBe(3);
    expect(result.current.pageSize).toBe(20); // default from constants

    // Change page size
    act(() => {
      result.current.handlePageSizeChange(50);
    });

    expect(result.current.pageSize).toBe(50);
    expect(result.current.pageIndex).toBe(1); // should reset to first page

    await waitFor(() => {
      expect(persistStateMock).toHaveBeenLastCalledWith(expect.objectContaining({ pageIndex: 1 }));
    });
  });

  it('handles view type changes and persists to localStorage', async () => {
    const localStorageMock = {
      getItem: jest.fn(),
      setItem: jest.fn(),
      removeItem: jest.fn(),
      clear: jest.fn(),
      key: jest.fn(),
      length: 0,
    };
    Object.defineProperty(window, 'localStorage', {
      value: localStorageMock,
      writable: true,
    });

    const { result } = renderHook(() => useStandardCatalogControls());

    // Change to table view
    act(() => {
      result.current.handleViewTypeChange('table');
    });

    expect(result.current.viewType).toBe('table');
    // Now viewType is stored in unified V3 preferences
    expect(localStorageMock.setItem).toHaveBeenCalledWith(
      'standard-catalog-preferences',
      expect.stringContaining('"viewType":"table"')
    );

    // Change to card view
    act(() => {
      result.current.handleViewTypeChange('card');
    });

    expect(result.current.viewType).toBe('card');
    // Now viewType is stored in unified V3 preferences
    expect(localStorageMock.setItem).toHaveBeenCalledWith(
      'standard-catalog-preferences',
      expect.stringContaining('"viewType":"card"')
    );

    await waitFor(() => {
      expect(persistStateMock).toHaveBeenLastCalledWith(
        expect.objectContaining({ viewType: 'card' })
      );
    });
  });

  it('handles localStorage errors gracefully when reading initial view type', () => {
    const localStorageMock = {
      getItem: jest.fn(() => {
        throw new Error('localStorage is disabled');
      }),
      setItem: jest.fn(),
      removeItem: jest.fn(),
      clear: jest.fn(),
      key: jest.fn(),
      length: 0,
    };
    Object.defineProperty(window, 'localStorage', {
      value: localStorageMock,
      writable: true,
    });

    const consoleWarnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});

    const { result } = renderHook(() => useStandardCatalogControls());

    // Should fall back to default view type ('card')
    expect(result.current.viewType).toBeDefined();
    // With versioned storage, errors are handled internally - no console warnings needed
    // expect(consoleWarnSpy).toHaveBeenCalledWith(...)

    consoleWarnSpy.mockRestore();
  });

  it('handles localStorage errors gracefully when saving view type', () => {
    const localStorageMock = {
      getItem: jest.fn(),
      setItem: jest.fn(() => {
        throw new Error('localStorage quota exceeded');
      }),
      removeItem: jest.fn(),
      clear: jest.fn(),
      key: jest.fn(),
      length: 0,
    };
    Object.defineProperty(window, 'localStorage', {
      value: localStorageMock,
      writable: true,
    });

    const consoleWarnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});

    const { result } = renderHook(() => useStandardCatalogControls());

    act(() => {
      result.current.handleViewTypeChange('table');
    });

    // View type should still change even if localStorage fails
    expect(result.current.viewType).toBe('table');
    // With versioned storage, errors are handled internally - no console warnings needed
    // expect(consoleWarnSpy).toHaveBeenCalledWith(...)

    consoleWarnSpy.mockRestore();
  });

  it('handles invalid JSON in localStorage when reading view type', () => {
    const localStorageMock = {
      getItem: jest.fn(() => 'invalid json'),
      setItem: jest.fn(),
      removeItem: jest.fn(),
      clear: jest.fn(),
      key: jest.fn(),
      length: 0,
    };
    Object.defineProperty(window, 'localStorage', {
      value: localStorageMock,
      writable: true,
    });

    const consoleWarnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});

    const { result } = renderHook(() => useStandardCatalogControls());

    // Should fall back to default view type
    expect(result.current.viewType).toBeDefined();
    // With versioned storage, errors are handled internally - no console warnings needed
    // expect(consoleWarnSpy).toHaveBeenCalledWith(...)

    consoleWarnSpy.mockRestore();
  });

  it('handles unexpected view type values in localStorage', () => {
    const localStorageMock = {
      getItem: jest.fn(() => JSON.stringify({ viewType: 'invalid-view-type' })),
      setItem: jest.fn(),
      removeItem: jest.fn(),
      clear: jest.fn(),
      key: jest.fn(),
      length: 0,
    };
    Object.defineProperty(window, 'localStorage', {
      value: localStorageMock,
      writable: true,
    });

    const { result } = renderHook(() => useStandardCatalogControls());

    // Should fall back to default view type ('card') when value is invalid
    expect(result.current.viewType).toBeDefined();
    expect(['card', 'table']).toContain(result.current.viewType);
  });
});
