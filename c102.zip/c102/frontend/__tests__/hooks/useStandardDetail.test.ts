import { describe, expect, it, beforeEach, jest } from '@jest/globals';
import { act, renderHook, waitFor } from '@testing-library/react';

import { useStandardDetail } from '../../hooks/useStandardDetail';
import type { AttributeMap } from '@amzn/global-realty-mosaic-graphql-schema';

type RequestArgs = [unknown, { id?: string }?];
type RequestMock = (...args: RequestArgs) => Promise<GraphQLResponse>;

jest.mock('../../api/graphqlClient', () => ({
  graphqlClient: {
    request: jest.fn<RequestMock>(),
  },
}));

const { graphqlClient } = require('../../api/graphqlClient') as {
  graphqlClient: {
    request: jest.MockedFunction<RequestMock>;
  };
};

const requestMock = graphqlClient.request;

interface StandardVersionRecord {
  id: string;
  version: string;
  isLatest: boolean;
  accFolderId: string;
  accFileId?: string | null;
  createdAt: string;
  updatedAt: string;
  attributes: AttributeMap;
  kits: Array<{
    id: string;
    version: string;
    kit: {
      id: string;
      name: string;
    };
  }>;
}

interface StandardRecord {
  id: string;
  name: string;
  description?: string | null;
  accProjectId: string;
  createdAt: string;
  updatedAt: string;
  latestVersion: StandardVersionRecord | null;
  versions: StandardVersionRecord[];
}

type GraphQLResponse = { standard: StandardRecord | null };

const createVersion = (
  attributes: AttributeMap,
  overrides: Partial<StandardVersionRecord> = {}
): StandardVersionRecord => ({
  id: overrides.id ?? 'std-1-v1',
  version: overrides.version ?? 'v1',
  isLatest: overrides.isLatest ?? true,
  accFolderId: overrides.accFolderId ?? 'folder-1',
  accFileId: overrides.accFileId ?? 'file-1',
  createdAt: overrides.createdAt ?? '2024-03-01T00:00:00.000Z',
  updatedAt: overrides.updatedAt ?? '2024-03-02T00:00:00.000Z',
  attributes,
  kits: overrides.kits ?? [
    {
      id: 'kit-1',
      version: '1.0.0',
      kit: {
        id: 'kit-1',
        name: 'Safety starter',
      },
    },
  ],
});

const createStandard = (
  attributes: AttributeMap,
  overrides: Partial<StandardRecord> = {}
): StandardRecord => {
  const version = createVersion(attributes, overrides.latestVersion ? overrides.latestVersion : {});
  return {
    id: overrides.id ?? 'std-1',
    name: overrides.name ?? 'Standard detail',
    description: overrides.description ?? 'Detailed overview of the standard',
    accProjectId: overrides.accProjectId ?? 'ACC-1',
    createdAt: overrides.createdAt ?? '2024-03-01T00:00:00.000Z',
    updatedAt: overrides.updatedAt ?? '2024-03-02T00:00:00.000Z',
    latestVersion: overrides.latestVersion ?? version,
    versions: overrides.versions ?? [version],
  } satisfies StandardRecord;
};

describe('useStandardDetail', () => {
  beforeEach(() => {
    requestMock.mockReset();
  });

  it('returns an error when the id is missing', async () => {
    const { result } = renderHook(() => useStandardDetail());

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.error).toBe('Standard id is required.');
    expect(result.current.standard).toBeNull();
    expect(requestMock).not.toHaveBeenCalled();
  });

  it('fetches standard details when an id is provided', async () => {
    requestMock.mockResolvedValue({
      standard: createStandard({ region: 'North America' }),
    });

    const { result } = renderHook(() => useStandardDetail('std-1'));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(requestMock).toHaveBeenCalledWith(expect.anything(), { id: 'std-1' });
    expect(result.current.standard?.name).toBe('Standard detail');
    expect(result.current.standard?.latestVersion?.attributes.region).toBe('North America');
  });

  it('captures request errors', async () => {
    requestMock.mockRejectedValue(new Error('Boom'));

    const { result } = renderHook(() => useStandardDetail('std-2'));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.error).toBe('Boom');
    expect(result.current.standard).toBeNull();
  });

  it('supports refetching', async () => {
    requestMock.mockResolvedValueOnce({ standard: null });
    requestMock.mockResolvedValueOnce({
      standard: createStandard({ region: 'EMEA' }, { id: 'std-3', name: 'Refetched' }),
    });

    const { result } = renderHook(() => useStandardDetail('std-3'));

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.standard).toBeNull();

    await act(async () => {
      await result.current.refetch();
    });

    expect(result.current.standard?.name).toBe('Refetched');
    expect(result.current.standard?.latestVersion?.attributes.region).toBe('EMEA');
  });

  it('handles standards without versions', async () => {
    requestMock.mockResolvedValue({
      standard: {
        id: 'std-4',
        name: 'Empty standard',
        description: null,
        accProjectId: 'ACC-4',
        createdAt: '2024-05-01T00:00:00.000Z',
        updatedAt: '2024-05-02T00:00:00.000Z',
        latestVersion: null,
        versions: [],
      },
    });

    const { result } = renderHook(() => useStandardDetail('std-4'));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.standard?.latestVersion).toBeNull();
    expect(result.current.standard?.versions).toEqual([]);
  });
});
