import { renderHook, act } from '@testing-library/react';
import { useTablePreferences } from '../../hooks/useTablePreferences';

describe('useTablePreferences', () => {
  const testKey = 'test-table-preferences';
  const defaultPreferences = {
    pageSize: 20,
    visibleContent: ['col1', 'col2', 'col3'],
  };

  beforeEach(() => {
    // Clear localStorage before each test
    localStorage.clear();
  });

  it('should initialize with default preferences when localStorage is empty', () => {
    const { result } = renderHook(() => useTablePreferences(testKey, defaultPreferences));
    const [preferences, , resetPreferences] = result.current;

    expect(preferences).toEqual(defaultPreferences);
    expect(typeof resetPreferences).toBe('function');
  });

  it('should load preferences from localStorage if they exist', () => {
    const storedPreferences = {
      pageSize: 50,
      visibleContent: ['col1'],
    };
    localStorage.setItem(testKey, JSON.stringify(storedPreferences));

    const { result } = renderHook(() => useTablePreferences(testKey, defaultPreferences));
    const [preferences] = result.current;

    expect(preferences).toEqual(storedPreferences);
  });

  it('should merge stored preferences with defaults', () => {
    const partialStored = {
      pageSize: 100,
    };
    localStorage.setItem(testKey, JSON.stringify(partialStored));

    const { result } = renderHook(() => useTablePreferences(testKey, defaultPreferences));
    const [preferences] = result.current;

    expect(preferences).toEqual({
      ...defaultPreferences,
      ...partialStored,
    });
  });

  it('should update preferences and save to localStorage', () => {
    const { result } = renderHook(() => useTablePreferences(testKey, defaultPreferences));
    const [, updatePreferences] = result.current;

    const newPreferences = {
      pageSize: 10,
      visibleContent: ['col1', 'col2'],
    };

    act(() => {
      updatePreferences(newPreferences);
    });

    const [updatedPreferences] = result.current;
    expect(updatedPreferences.pageSize).toBe(10);
    expect(updatedPreferences.visibleContent).toEqual(['col1', 'col2']);

    // Check localStorage
    const stored = localStorage.getItem(testKey);
    expect(stored).toBeTruthy();
    const parsedStored = JSON.parse(stored!);
    expect(parsedStored.pageSize).toBe(10);
    expect(parsedStored.visibleContent).toEqual(['col1', 'col2']);
  });

  it('should handle readonly arrays from CollectionPreferences', () => {
    const { result } = renderHook(() => useTablePreferences(testKey, defaultPreferences));
    const [, updatePreferences] = result.current;

    const readonlyPreferences = {
      pageSize: 50,
      visibleContent: ['col1'] as readonly string[],
    };

    act(() => {
      updatePreferences(readonlyPreferences);
    });

    const [updatedPreferences] = result.current;
    expect(updatedPreferences.visibleContent).toEqual(['col1']);
  });

  it('should handle corrupted localStorage data gracefully', () => {
    localStorage.setItem(testKey, 'invalid-json{');

    const { result } = renderHook(() => useTablePreferences(testKey, defaultPreferences));
    const [preferences] = result.current;

    // Should fall back to default preferences
    expect(preferences).toEqual(defaultPreferences);
  });

  it('should handle undefined visibleContent', () => {
    const { result } = renderHook(() => useTablePreferences(testKey, defaultPreferences));
    const [, updatePreferences] = result.current;

    act(() => {
      updatePreferences({
        pageSize: 30,
        visibleContent: undefined,
      });
    });

    const [updatedPreferences] = result.current;
    expect(updatedPreferences.visibleContent).toBeUndefined();
  });

  it('should reset preferences to defaults and clear localStorage', () => {
    const { result } = renderHook(() => useTablePreferences(testKey, defaultPreferences));
    const [, updatePreferences, resetPreferences] = result.current;

    // First, update preferences
    act(() => {
      updatePreferences({
        pageSize: 100,
        visibleContent: ['col1'],
      });
    });

    // Verify they were updated
    const [updatedPreferences] = result.current;
    expect(updatedPreferences.pageSize).toBe(100);

    // Now reset
    act(() => {
      resetPreferences();
    });

    // Verify reset to defaults
    const [resetPrefs] = result.current;
    expect(resetPrefs).toEqual(defaultPreferences);

    // Verify localStorage was cleared
    const stored = localStorage.getItem(testKey);
    expect(stored).toBeNull();
  });

  it('should filter out deprecated columns from stored preferences', () => {
    const storedPreferences = {
      pageSize: 20,
      contentDisplay: [
        { id: 'name', visible: true },
        { id: 'region', visible: true },
        { id: 'accProjectId', visible: false }, // Deprecated column
        { id: 'program', visible: true },
      ],
    };
    localStorage.setItem(testKey, JSON.stringify(storedPreferences));

    const deprecatedColumns = ['accProjectId'];
    const { result } = renderHook(() =>
      useTablePreferences(testKey, defaultPreferences, deprecatedColumns)
    );
    const [preferences] = result.current;

    // accProjectId should be filtered out
    expect(preferences.contentDisplay).toEqual([
      { id: 'name', visible: true },
      { id: 'region', visible: true },
      { id: 'program', visible: true },
    ]);
  });

  it('should handle multiple deprecated columns', () => {
    const storedPreferences = {
      pageSize: 20,
      contentDisplay: [
        { id: 'name', visible: true },
        { id: 'oldColumn1', visible: false },
        { id: 'region', visible: true },
        { id: 'oldColumn2', visible: false },
        { id: 'program', visible: true },
      ],
    };
    localStorage.setItem(testKey, JSON.stringify(storedPreferences));

    const deprecatedColumns = ['oldColumn1', 'oldColumn2'];
    const { result } = renderHook(() =>
      useTablePreferences(testKey, defaultPreferences, deprecatedColumns)
    );
    const [preferences] = result.current;

    // Both deprecated columns should be filtered out
    expect(preferences.contentDisplay).toEqual([
      { id: 'name', visible: true },
      { id: 'region', visible: true },
      { id: 'program', visible: true },
    ]);
  });

  it('should work normally when no deprecated columns specified', () => {
    const storedPreferences = {
      pageSize: 20,
      contentDisplay: [
        { id: 'name', visible: true },
        { id: 'region', visible: true },
        { id: 'accProjectId', visible: false },
      ],
    };
    localStorage.setItem(testKey, JSON.stringify(storedPreferences));

    const { result } = renderHook(() => useTablePreferences(testKey, defaultPreferences));
    const [preferences] = result.current;

    // Should keep all columns when no deprecatedColumns specified
    expect(preferences.contentDisplay).toEqual(storedPreferences.contentDisplay);
  });
});
