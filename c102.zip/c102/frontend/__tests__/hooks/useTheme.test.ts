import { beforeEach, describe, expect, it, jest } from '@jest/globals';
import { act, renderHook } from '@testing-library/react';

import { useTheme } from '../../hooks/useTheme';

const matchMediaMock = jest.fn();

jest.mock('@amzn/awsui-global-styles', () => ({
  applyMode: jest.fn(),
  Mode: { Light: 'light', Dark: 'dark' },
}));

beforeEach(() => {
  matchMediaMock.mockReturnValue({
    matches: false,
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
  });
  Object.defineProperty(window, 'matchMedia', { value: matchMediaMock, configurable: true });
  localStorage.clear();
});

describe('useTheme', () => {
  it('initializes from prefers-color-scheme when no stored value exists', () => {
    matchMediaMock.mockReturnValueOnce({ matches: true });

    const { result } = renderHook(() => useTheme());

    expect(result.current.theme).toBe('dark');
  });

  it('toggles theme and persists the selection', () => {
    const { result } = renderHook(() => useTheme());

    expect(result.current.theme).toBe('light');

    act(() => {
      result.current.toggleTheme();
    });

    expect(result.current.theme).toBe('dark');
    expect(localStorage.getItem('cloudscape-theme')).toBe('dark');
  });

  it('respects stored theme preferences', () => {
    localStorage.setItem('cloudscape-theme', 'dark');

    const { result } = renderHook(() => useTheme());

    expect(result.current.theme).toBe('dark');
  });
});
