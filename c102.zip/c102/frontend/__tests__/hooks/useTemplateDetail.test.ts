import { describe, expect, it, beforeEach, jest } from '@jest/globals';
import { act, renderHook, waitFor } from '@testing-library/react';

import { useTemplateDetail } from '../../hooks/useTemplateDetail';
import type { AttributeMap } from '@amzn/global-realty-mosaic-graphql-schema';

jest.mock('../../api/graphqlClient', () => ({
  graphqlClient: {
    request: jest.fn(),
  },
}));

const { graphqlClient } = require('../../api/graphqlClient') as {
  graphqlClient: {
    request: jest.Mock;
  };
};

const requestMock = graphqlClient.request as jest.MockedFunction<
  (...args: [unknown, { id?: string }?]) => Promise<GraphQLResponse>
>;

interface TemplateVersionRecord {
  id: string;
  version: string;
  isLatest: boolean;
  accFolderId: string;
  brsId?: string | null;
  createdAt: string;
  updatedAt: string;
  attributes: AttributeMap;
  files: Array<{ id: string; accFileId: string; createdAt: string }>;
}

interface TemplateRecord {
  id: string;
  name: string;
  description?: string | null;
  accProjectId: string;
  createdAt: string;
  updatedAt: string;
  latestVersion: { id: string } | null;
  versions: TemplateVersionRecord[];
}

type GraphQLResponse = { template: TemplateRecord | null };

const createVersionRecord = (
  attributes: AttributeMap,
  overrides: Partial<TemplateVersionRecord> = {}
): TemplateVersionRecord => ({
  id: 'tpl-1-v1',
  version: 'v1',
  isLatest: true,
  accFolderId: 'folder-1',
  brsId: 'BRS-1',
  createdAt: '2024-01-01T00:00:00.000Z',
  updatedAt: '2024-01-02T00:00:00.000Z',
  attributes,
  files: [{ id: 'file-1', accFileId: 'acc-file-1', createdAt: '2024-01-02T00:00:00.000Z' }],
  ...overrides,
});

const createTemplateRecord = (
  attributes: AttributeMap,
  overrides: Partial<TemplateRecord> = {}
): TemplateRecord => {
  const version = createVersionRecord(
    attributes,
    overrides.latestVersion ? { id: overrides.latestVersion.id } : {}
  );

  return {
    id: 'tpl-1',
    name: 'Template 1',
    description: null,
    accProjectId: 'ACC-1',
    createdAt: '2024-01-01T00:00:00.000Z',
    updatedAt: '2024-01-02T00:00:00.000Z',
    latestVersion: { id: version.id },
    versions: [version],
    ...overrides,
  } satisfies TemplateRecord;
};

describe('useTemplateDetail', () => {
  beforeEach(() => {
    requestMock.mockReset();
  });

  it('indicates an error when no id is supplied', async () => {
    const { result } = renderHook(() => useTemplateDetail());

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.error).toBe('Template id is required.');
    expect(result.current.template).toBeNull();
  });

  it('loads template detail data', async () => {
    requestMock.mockResolvedValue({
      template: createTemplateRecord({ region: 'North America' }),
    });

    const { result } = renderHook(() => useTemplateDetail('tpl-1'));

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.template?.name).toBe('Template 1');
    expect(result.current.error).toBeNull();
  });

  it('handles request failures', async () => {
    requestMock.mockRejectedValue(new Error('Template missing'));

    const { result } = renderHook(() => useTemplateDetail('tpl-2'));

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.error).toBe('Template missing');
    expect(result.current.template).toBeNull();
  });

  it('supports refetch', async () => {
    requestMock.mockResolvedValueOnce({ template: null });
    requestMock.mockResolvedValueOnce({
      template: createTemplateRecord(
        { region: 'Europe, Middle East and Africa' },
        {
          id: 'tpl-3',
          name: 'Refetched template',
        }
      ),
    });

    const { result } = renderHook(() => useTemplateDetail('tpl-3'));

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.template).toBeNull();

    await act(async () => {
      await result.current.refetch();
    });

    expect(result.current.template?.name).toBe('Refetched template');
  });
});
