import { renderHook, act } from '@testing-library/react';
import { beforeEach, jest } from '@jest/globals';
import { useTemplateCatalogControls } from '../../hooks/useTemplateCatalogControls';
import type { PropertyFilterProps } from '@amzn/awsui-components-console';

const persistStateMock = jest.fn();

const createCatalogSnapshot = () => ({
  viewType: 'card' as const,
  propertyFilterQuery: {
    operation: 'and',
    tokens: [],
  } satisfies PropertyFilterProps.Query,
  sortingField: 'name' as const,
  sortingDescending: false,
  pageIndex: 1,
  pageSize: 20,
});

jest.mock('../../hooks/useTemplateCatalogPersistence', () => {
  const actual = jest.requireActual<typeof import('../../hooks/useTemplateCatalogPersistence')>(
    '../../hooks/useTemplateCatalogPersistence'
  );
  return {
    ...actual,
    useTemplateCatalogPersistence: jest.fn(() => ({
      initialState: createCatalogSnapshot(),
      persistState: persistStateMock,
    })),
  };
});

describe('useTemplateCatalogControls', () => {
  beforeEach(() => {
    persistStateMock.mockClear();
  });
  it('should initialize with default values', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    expect(result.current.viewType).toBe('card');
    expect(result.current.sortingField).toBe('name');
    expect(result.current.sortingDescending).toBe(false);
    expect(result.current.pageIndex).toBe(1);
    expect(result.current.propertyFilterQuery).toEqual({
      tokens: [],
      operation: 'and',
    });
    expect(result.current.filterInput).toEqual({
      pageIdx: 0,
      limit: 20,
      orderBy: 'name',
      orderDesc: false,
      query: undefined,
    });
  });

  it('should change view type', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    act(() => {
      result.current.handleViewTypeChange('table');
    });

    expect(result.current.viewType).toBe('table');
  });

  it('should change sorting field and reset page', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    // Set page to 3
    act(() => {
      result.current.handlePageChange(3);
    });

    expect(result.current.pageIndex).toBe(3);

    // Change sorting should reset page to 1
    act(() => {
      result.current.handleSortingChange('updatedAt', true);
    });

    expect(result.current.sortingField).toBe('updatedAt');
    expect(result.current.sortingDescending).toBe(true);
    expect(result.current.pageIndex).toBe(1);
    expect(result.current.filterInput.orderBy).toBe('updatedAt');
    expect(result.current.filterInput.orderDesc).toBe(true);
  });

  it('should change page index', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    act(() => {
      result.current.handlePageChange(5);
    });

    expect(result.current.pageIndex).toBe(5);
    expect(result.current.filterInput.pageIdx).toBe(4); // 0-indexed
  });

  it('should handle property filter and reset page', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    // Set page to 2
    act(() => {
      result.current.handlePageChange(2);
    });

    expect(result.current.pageIndex).toBe(2);

    // Property filter should reset page to 1
    act(() => {
      result.current.handlePropertyFilterChange({
        tokens: [
          {
            propertyKey: 'name',
            operator: ':',
            value: 'warehouse',
          },
        ],
        operation: 'and',
      });
    });

    expect(result.current.pageIndex).toBe(1);
    expect(result.current.filterInput.query).toEqual({
      operation: 'AND',
      tokenGroups: [
        {
          propertyKey: 'name',
          operator: 'CONTAINS',
          value: 'warehouse',
        },
      ],
    });
  });

  it('should trim property filter values', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    act(() => {
      result.current.handlePropertyFilterChange({
        tokens: [
          {
            propertyKey: 'name',
            operator: ':',
            value: '  warehouse  ',
          },
        ],
        operation: 'and',
      });
    });

    // The trimming happens in collectPropertyFilterTokens
    expect(result.current.filterInput.query?.tokenGroups?.[0]?.value).toBe('warehouse');
  });

  it('should clear property filter when empty tokens provided', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    // First set a property filter
    act(() => {
      result.current.handlePropertyFilterChange({
        tokens: [
          {
            propertyKey: 'name',
            operator: ':',
            value: 'warehouse',
          },
        ],
        operation: 'and',
      });
    });

    expect(result.current.filterInput.query?.tokenGroups).toHaveLength(1);

    // Then clear it
    act(() => {
      result.current.handlePropertyFilterChange({
        tokens: [],
        operation: 'and',
      });
    });

    expect(result.current.filterInput.query).toBeUndefined();
  });

  it('should handle property filter tokens and reset page', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    // Set page to 2
    act(() => {
      result.current.handlePageChange(2);
    });

    const query: PropertyFilterProps.Query = {
      tokens: [
        { propertyKey: 'region', value: 'NA', operator: '=' },
        { propertyKey: 'facilityType', value: 'ARS', operator: '=' },
      ],
      operation: 'and',
    };

    act(() => {
      result.current.handlePropertyFilterChange(query);
    });

    expect(result.current.propertyFilterQuery).toEqual(query);
    expect(result.current.pageIndex).toBe(1);
    expect(result.current.filterInput.query?.tokenGroups).toHaveLength(2);
  });

  it('should handle facilityType property filter and reset page', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    // Set page to 2
    act(() => {
      result.current.handlePageChange(2);
    });

    act(() => {
      result.current.handlePropertyFilterChange({
        tokens: [
          {
            propertyKey: 'facilityType',
            operator: '=',
            value: 'ARS',
          },
        ],
        operation: 'and',
      });
    });

    expect(result.current.pageIndex).toBe(1);
    expect(result.current.filterInput.query?.tokenGroups).toContainEqual({
      propertyKey: 'facilityType',
      operator: 'EQUALS',
      value: 'ARS',
    });
  });

  it('should clear facilityType filter when tokens are empty', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    // First set a facilityType filter
    act(() => {
      result.current.handlePropertyFilterChange({
        tokens: [
          {
            propertyKey: 'facilityType',
            operator: '=',
            value: 'ARS',
          },
        ],
        operation: 'and',
      });
    });

    expect(result.current.filterInput.query?.tokenGroups).toHaveLength(1);

    // Then clear it
    act(() => {
      result.current.handlePropertyFilterChange({
        tokens: [],
        operation: 'and',
      });
    });

    expect(result.current.filterInput.query).toBeUndefined();
  });

  it('should handle multiple filters combined', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    // Add property filters including type
    const query: PropertyFilterProps.Query = {
      tokens: [
        { propertyKey: 'region', value: 'NA', operator: '=' },
        { propertyKey: 'facilityType', value: 'ARS', operator: '=' },
      ],
      operation: 'and',
    };

    act(() => {
      result.current.handlePropertyFilterChange(query);
    });

    // All filters should be present in filterInput
    const tokenGroups = result.current.filterInput.query?.tokenGroups ?? [];
    expect(tokenGroups).toHaveLength(2); // region + facilityType

    expect(tokenGroups).toContainEqual({
      propertyKey: 'region',
      operator: 'EQUALS',
      value: 'NA',
    });
    expect(tokenGroups).toContainEqual({
      propertyKey: 'facilityType',
      operator: 'EQUALS',
      value: 'ARS',
    });
  });

  it('should maintain stable filterInput reference when values do not change', () => {
    const { result, rerender } = renderHook(() => useTemplateCatalogControls());

    const firstFilterInput = result.current.filterInput;

    // Rerender without changing anything
    rerender();

    const secondFilterInput = result.current.filterInput;

    // Should be the same reference
    expect(firstFilterInput).toBe(secondFilterInput);
  });

  it('should create new filterInput reference when property filters change', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    const firstFilterInput = result.current.filterInput;

    act(() => {
      result.current.handlePropertyFilterChange({
        tokens: [
          {
            propertyKey: 'name',
            operator: ':',
            value: 'test',
          },
        ],
        operation: 'and',
      });
    });

    const secondFilterInput = result.current.filterInput;

    // Should be a different reference
    expect(firstFilterInput).not.toBe(secondFilterInput);
  });

  it('should handle complex property filter with tokenGroups', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    const query: PropertyFilterProps.Query = {
      tokens: [],
      tokenGroups: [
        {
          tokens: [
            { propertyKey: 'region', value: 'NA', operator: '=' },
            { propertyKey: 'program', value: 'Prime', operator: '=' },
          ],
          operation: 'and',
        },
      ],
      operation: 'or',
    };

    act(() => {
      result.current.handlePropertyFilterChange(query);
    });

    expect(result.current.filterInput.query?.tokenGroups).toHaveLength(2);
  });

  it('should handle array values in property filter tokens', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    const query: PropertyFilterProps.Query = {
      tokens: [{ propertyKey: 'region', value: ['NA', 'EU'], operator: '=' }],
      operation: 'and',
    };

    act(() => {
      result.current.handlePropertyFilterChange(query);
    });

    // Should create single token with values array
    const tokenGroups = result.current.filterInput.query?.tokenGroups ?? [];
    expect(tokenGroups).toHaveLength(1);
    expect(tokenGroups[0]).toEqual({
      propertyKey: 'region',
      operator: 'EQUALS',
      values: ['NA', 'EU'],
    });
  });

  it('should ignore empty or whitespace-only filter values', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    const query: PropertyFilterProps.Query = {
      tokens: [
        { propertyKey: 'region', value: '   ', operator: '=' },
        { propertyKey: 'program', value: '', operator: '=' },
      ],
      operation: 'and',
    };

    act(() => {
      result.current.handlePropertyFilterChange(query);
    });

    // Should not create any token groups
    expect(result.current.filterInput.query).toBeUndefined();
  });

  it('should handle sorting by all sortable fields', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    const sortableFields = [
      'name',
      'accProjectId',
      'updatedAt',
      'createdAt',
      'region',
      'program',
      'capacity',
      'stories',
      'facilityType',
    ] as const;

    sortableFields.forEach((field) => {
      act(() => {
        result.current.handleSortingChange(field, true);
      });

      expect(result.current.sortingField).toBe(field);
      expect(result.current.filterInput.orderBy).toBe(field);
    });
  });

  it('should convert 1-indexed pageIndex to 0-indexed pageIdx in filterInput', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    act(() => {
      result.current.handlePageChange(1);
    });
    expect(result.current.filterInput.pageIdx).toBe(0);

    act(() => {
      result.current.handlePageChange(2);
    });
    expect(result.current.filterInput.pageIdx).toBe(1);

    act(() => {
      result.current.handlePageChange(10);
    });
    expect(result.current.filterInput.pageIdx).toBe(9);
  });

  it('should handle negative page numbers gracefully', () => {
    const { result } = renderHook(() => useTemplateCatalogControls());

    act(() => {
      result.current.handlePageChange(-5);
    });

    // Should clamp to 0 in filterInput (page 1 in UI)
    expect(result.current.pageIndex).toBe(-5); // UI state preserved
    expect(result.current.filterInput.pageIdx).toBe(0); // Backend gets 0
  });

  describe('multi-value filter token conversion', () => {
    it('should create single token with values array for multi-value filters', () => {
      const { result } = renderHook(() => useTemplateCatalogControls());

      // Simulate PropertyFilter returning an array value for multi-select (enum tokenType)
      const multiValueQuery: PropertyFilterProps.Query = {
        operation: 'and',
        tokens: [
          {
            propertyKey: 'program',
            operator: '=',
            value: ['ARS', 'IXD'], // Multi-select checkbox values
          },
        ],
      };

      act(() => {
        result.current.handlePropertyFilterChange(multiValueQuery);
      });

      // Verify filterInput has single token with values array
      const { filterInput } = result.current;
      expect(filterInput.query).toBeDefined();
      expect(filterInput.query?.tokenGroups).toHaveLength(1);
      expect(filterInput.query?.tokenGroups[0]).toEqual({
        propertyKey: 'program',
        operator: 'EQUALS',
        values: ['ARS', 'IXD'],
      });
      expect(filterInput.query?.operation).toBe('AND');
    });

    it('should handle mixed single and multi-value filters', () => {
      const { result } = renderHook(() => useTemplateCatalogControls());

      const mixedQuery: PropertyFilterProps.Query = {
        operation: 'and',
        tokens: [
          {
            propertyKey: 'program',
            operator: '=',
            value: ['ARS', 'IXD'], // Multi-value
          },
          {
            propertyKey: 'region',
            operator: '=',
            value: 'NA', // Single value
          },
        ],
      };

      act(() => {
        result.current.handlePropertyFilterChange(mixedQuery);
      });

      const { filterInput } = result.current;
      expect(filterInput.query?.tokenGroups).toHaveLength(2);
      expect(filterInput.query?.tokenGroups).toContainEqual({
        propertyKey: 'program',
        operator: 'EQUALS',
        values: ['ARS', 'IXD'],
      });
      expect(filterInput.query?.tokenGroups).toContainEqual({
        propertyKey: 'region',
        operator: 'EQUALS',
        value: 'NA',
      });
    });

    it('should handle empty array values gracefully', () => {
      const { result } = renderHook(() => useTemplateCatalogControls());

      const emptyArrayQuery: PropertyFilterProps.Query = {
        operation: 'and',
        tokens: [
          {
            propertyKey: 'program',
            operator: '=',
            value: [], // Empty array
          },
        ],
      };

      act(() => {
        result.current.handlePropertyFilterChange(emptyArrayQuery);
      });

      const { filterInput } = result.current;
      // Empty array should result in no tokens
      expect(filterInput.query).toBeUndefined();
    });

    it('should filter out null/undefined/empty values from arrays', () => {
      const { result } = renderHook(() => useTemplateCatalogControls());

      const arrayWithNullsQuery: PropertyFilterProps.Query = {
        operation: 'and',
        tokens: [
          {
            propertyKey: 'program',
            operator: '=',
            value: ['ARS', null, undefined, 'IXD', ''], // Mixed values
          },
        ],
      };

      act(() => {
        result.current.handlePropertyFilterChange(arrayWithNullsQuery);
      });

      const { filterInput } = result.current;
      // Should only include 'ARS' and 'IXD' (empty string filtered out)
      expect(filterInput.query?.tokenGroups).toHaveLength(1);
      expect(filterInput.query?.tokenGroups[0]).toEqual({
        propertyKey: 'program',
        operator: 'EQUALS',
        values: ['ARS', 'IXD'],
      });
    });

    it('should respect OR operation for multi-value filters', () => {
      const { result } = renderHook(() => useTemplateCatalogControls());

      const orQuery: PropertyFilterProps.Query = {
        operation: 'or',
        tokens: [
          {
            propertyKey: 'program',
            operator: '=',
            value: ['ARS', 'IXD'],
          },
        ],
      };

      act(() => {
        result.current.handlePropertyFilterChange(orQuery);
      });

      const { filterInput } = result.current;
      expect(filterInput.query?.operation).toBe('OR');
      expect(filterInput.query?.tokenGroups).toHaveLength(1);
      expect(filterInput.query?.tokenGroups[0]).toEqual({
        propertyKey: 'program',
        operator: 'EQUALS',
        values: ['ARS', 'IXD'],
      });
    });

    it('should handle three or more multi-values', () => {
      const { result } = renderHook(() => useTemplateCatalogControls());

      const threeValuesQuery: PropertyFilterProps.Query = {
        operation: 'and',
        tokens: [
          {
            propertyKey: 'program',
            operator: '=',
            value: ['ARS', 'IXD', 'Prime'],
          },
        ],
      };

      act(() => {
        result.current.handlePropertyFilterChange(threeValuesQuery);
      });

      const { filterInput } = result.current;
      expect(filterInput.query?.tokenGroups).toHaveLength(1);
      expect(filterInput.query?.tokenGroups[0]).toEqual({
        propertyKey: 'program',
        operator: 'EQUALS',
        values: ['ARS', 'IXD', 'Prime'],
      });
    });
  });
});
