import { renderHook, waitFor } from '@testing-library/react';
import {
  useTemplateFilterOptions,
  ALL_TEMPLATE_FILTER_FIELDS,
} from '../../hooks/useTemplateFilterOptions';
import { graphqlClient } from '../../api/graphqlClient';

jest.mock('../../api/graphqlClient', () => ({
  graphqlClient: {
    request: jest.fn(),
  },
}));

const mockedGraphqlClient = graphqlClient as jest.Mocked<typeof graphqlClient>;

describe('useTemplateFilterOptions', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should fetch filter options for a single field', async () => {
    const mockOptions = ['ARS', 'IXD', 'Prime'];
    mockedGraphqlClient.request.mockResolvedValue({
      program: mockOptions,
    });

    const { result } = renderHook(() => useTemplateFilterOptions(['program']));

    // Initially loading
    expect(result.current.loading).toBe(true);
    expect(result.current.filteringOptions).toEqual([]);
    expect(result.current.error).toBeNull();

    // Wait for data to load
    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.filteringOptions).toEqual([
      { propertyKey: 'program', value: 'ARS', label: 'Amazon Robotics Sortable (ARS)' },
      { propertyKey: 'program', value: 'IXD', label: 'Inbound Cross Dock (IXD)' },
      { propertyKey: 'program', value: 'Prime', label: 'Prime' },
    ]);
    expect(result.current.error).toBeNull();
    expect(mockedGraphqlClient.request).toHaveBeenCalledTimes(1);
  });

  it('should batch multiple fields in one request', async () => {
    mockedGraphqlClient.request.mockResolvedValue({
      region: ['NA', 'EU'],
      program: ['ARS', 'IXD'],
    });

    const { result } = renderHook(() => useTemplateFilterOptions(['region', 'program']));

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.filteringOptions).toEqual([
      { propertyKey: 'region', value: 'NA', label: 'NA' },
      { propertyKey: 'region', value: 'EU', label: 'EU' },
      { propertyKey: 'program', value: 'ARS', label: 'Amazon Robotics Sortable (ARS)' },
      { propertyKey: 'program', value: 'IXD', label: 'Inbound Cross Dock (IXD)' },
    ]);
    expect(mockedGraphqlClient.request).toHaveBeenCalledTimes(1);
  });

  it('should deduplicate field names', async () => {
    mockedGraphqlClient.request.mockResolvedValue({
      region: ['NA', 'EU'],
    });

    const { result } = renderHook(() => useTemplateFilterOptions(['region', 'region', 'region']));

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    // Should only query region once
    expect(result.current.filteringOptions).toEqual([
      { propertyKey: 'region', value: 'NA', label: 'NA' },
      { propertyKey: 'region', value: 'EU', label: 'EU' },
    ]);
    expect(mockedGraphqlClient.request).toHaveBeenCalledTimes(1);
  });

  it('should format program labels correctly', async () => {
    mockedGraphqlClient.request.mockResolvedValue({
      program: ['IXD', 'SSD'],
    });

    const { result } = renderHook(() => useTemplateFilterOptions(['program']));

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    // Program values should be formatted (formatProgramLabel is actual behavior)
    expect(result.current.filteringOptions).toEqual([
      { propertyKey: 'program', value: 'IXD', label: 'Inbound Cross Dock (IXD)' },
      { propertyKey: 'program', value: 'SSD', label: 'Sub Same Day (SSD)' },
    ]);
  });

  it('should handle errors', async () => {
    const mockError = new Error('Network error');
    mockedGraphqlClient.request.mockRejectedValue(mockError);

    const { result } = renderHook(() => useTemplateFilterOptions(['region']));

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.filteringOptions).toEqual([]);
    expect(result.current.error).toEqual(mockError);
  });

  it('should refetch when fields change', async () => {
    mockedGraphqlClient.request
      .mockResolvedValueOnce({ program: ['ARS', 'Prime'] })
      .mockResolvedValueOnce({ region: ['NA', 'EU', 'APAC'] });

    const { result, rerender } = renderHook(({ fields }) => useTemplateFilterOptions(fields), {
      initialProps: { fields: ['program'] },
    });

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.filteringOptions).toEqual([
      { propertyKey: 'program', value: 'ARS', label: 'Amazon Robotics Sortable (ARS)' },
      { propertyKey: 'program', value: 'Prime', label: 'Prime' },
    ]);

    // Change fields
    rerender({ fields: ['region'] });

    await waitFor(() => {
      expect(result.current.filteringOptions).toEqual([
        { propertyKey: 'region', value: 'NA', label: 'NA' },
        { propertyKey: 'region', value: 'EU', label: 'EU' },
        { propertyKey: 'region', value: 'APAC', label: 'APAC' },
      ]);
    });

    expect(mockedGraphqlClient.request).toHaveBeenCalledTimes(2);
  });

  it('should return empty array when no options available', async () => {
    mockedGraphqlClient.request.mockResolvedValue({
      version: [],
    });

    const { result } = renderHook(() => useTemplateFilterOptions(['version']));

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.filteringOptions).toEqual([]);
    expect(result.current.error).toBeNull();
  });

  it('should handle empty fields array', async () => {
    const { result } = renderHook(() => useTemplateFilterOptions([]));

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.filteringOptions).toEqual([]);
    expect(result.current.error).toBeNull();
    // Should not make any GraphQL request
    expect(mockedGraphqlClient.request).not.toHaveBeenCalled();
  });

  it('should cleanup on unmount', async () => {
    mockedGraphqlClient.request.mockImplementation(
      () => new Promise((resolve) => setTimeout(() => resolve({ program: ['test'] }), 100))
    );

    const { result, unmount } = renderHook(() => useTemplateFilterOptions(['program']));

    expect(result.current.loading).toBe(true);

    // Unmount before request completes
    unmount();

    // Should not update state after unmount
    await new Promise((resolve) => setTimeout(resolve, 150));

    // No assertion needed - just ensuring no state updates after unmount
  });

  it('should work with ALL_TEMPLATE_FILTER_FIELDS constant', async () => {
    const mockResponse = {
      name: ['Template1'],
      region: ['NA'],
      facilityType: ['FC'],
      program: ['IXD'],
      businessUnit: ['AMZL'],
      generation: ['Gen5'],
      createdBy: ['user1'],
      version: ['1.0.0'],
    };
    mockedGraphqlClient.request.mockResolvedValue(mockResponse);

    const { result } = renderHook(() => useTemplateFilterOptions(ALL_TEMPLATE_FILTER_FIELDS));

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    // Should have options for all 8 fields
    expect(result.current.filteringOptions.length).toBe(8);
    expect(result.current.filteringOptions).toEqual([
      { propertyKey: 'name', value: 'Template1', label: 'Template1' },
      { propertyKey: 'region', value: 'NA', label: 'NA' },
      { propertyKey: 'facilityType', value: 'FC', label: 'FC' },
      { propertyKey: 'program', value: 'IXD', label: 'Inbound Cross Dock (IXD)' },
      { propertyKey: 'businessUnit', value: 'AMZL', label: 'AMZL' },
      { propertyKey: 'generation', value: 'Gen5', label: 'Gen5' },
      { propertyKey: 'createdBy', value: 'user1', label: 'user1' },
      { propertyKey: 'version', value: '1.0.0', label: '1.0.0' },
    ]);
    expect(mockedGraphqlClient.request).toHaveBeenCalledTimes(1);
  });
});
