/**
 * @jest-environment jsdom
 *
 * Integration test comparing filter options query performance
 * Demonstrates the improvement from batching multiple field queries into one request
 */

import { renderHook, waitFor } from '@testing-library/react';
import {
  useTemplateFilterOptions,
  ALL_TEMPLATE_FILTER_FIELDS,
} from '../../hooks/useTemplateFilterOptions';
import { graphqlClient } from '../../api/graphqlClient';

jest.mock('../../api/graphqlClient', () => ({
  graphqlClient: {
    request: jest.fn(),
  },
}));

const mockedGraphqlClient = graphqlClient as jest.Mocked<typeof graphqlClient>;

describe('Filter Options Performance Integration', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Batched vs Non-Batched Performance', () => {
    it('should batch 8 field queries into 1 HTTP request', async () => {
      // Mock response for all 8 fields
      const mockResponse = {
        name: ['Template A', 'Template B'],
        region: ['NA', 'EU', 'APAC'],
        facilityType: ['FC', 'SC', 'DS'],
        program: ['IXD', 'ARS', 'SSD'],
        businessUnit: ['AMZL', 'WWCS'],
        generation: ['Gen5', 'Gen6'],
        createdBy: ['user1', 'user2'],
        version: ['1.0.0', '2.0.0'],
      };

      mockedGraphqlClient.request.mockResolvedValue(mockResponse);

      const startTime = performance.now();

      const { result } = renderHook(() => useTemplateFilterOptions(ALL_TEMPLATE_FILTER_FIELDS));

      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });

      const endTime = performance.now();

      // Verify only 1 HTTP request was made
      expect(mockedGraphqlClient.request).toHaveBeenCalledTimes(1);

      // Verify the query object was passed (existence check)
      const callArgs = mockedGraphqlClient.request.mock.calls[0];
      expect(callArgs[0]).toBeDefined();

      // Verify all results are properly formatted
      expect(result.current.filteringOptions.length).toBeGreaterThan(0);

      // Verify each field type is represented
      const propertyKeys = new Set(result.current.filteringOptions.map((opt) => opt.propertyKey));
      expect(propertyKeys.size).toBe(8);
      expect(propertyKeys).toContain('name');
      expect(propertyKeys).toContain('region');
      expect(propertyKeys).toContain('program');

      console.log(`✓ Batched query completed in ${(endTime - startTime).toFixed(2)}ms`);
      console.log(`✓ ${result.current.filteringOptions.length} total options loaded`);
      console.log(`✓ 1 HTTP request for 8 fields (87.5% reduction vs 8 separate requests)`);
    });

    it('should demonstrate performance difference: batched vs sequential', async () => {
      // Simulate network latency
      const SIMULATED_LATENCY_MS = 50;

      // Test 1: Sequential (old approach) - simulate 8 separate requests
      const sequentialStartTime = performance.now();
      let sequentialRequestCount = 0;

      for (const field of ALL_TEMPLATE_FILTER_FIELDS) {
        // Simulate individual request with latency
        await new Promise((resolve) => setTimeout(resolve, SIMULATED_LATENCY_MS));
        sequentialRequestCount++;
      }

      const sequentialEndTime = performance.now();
      const sequentialDuration = sequentialEndTime - sequentialStartTime;

      // Test 2: Batched (new approach) - 1 request
      const mockResponse = {
        name: ['Template A'],
        region: ['NA'],
        facilityType: ['FC'],
        program: ['IXD'],
        businessUnit: ['AMZL'],
        generation: ['Gen5'],
        createdBy: ['user1'],
        version: ['1.0.0'],
      };

      mockedGraphqlClient.request.mockImplementation(async () => {
        // Simulate single batched request with latency
        await new Promise((resolve) => setTimeout(resolve, SIMULATED_LATENCY_MS));
        return mockResponse;
      });

      const batchedStartTime = performance.now();

      const { result } = renderHook(() => useTemplateFilterOptions(ALL_TEMPLATE_FILTER_FIELDS));

      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });

      const batchedEndTime = performance.now();
      const batchedDuration = batchedEndTime - batchedStartTime;

      // Calculate improvement
      const improvement = ((sequentialDuration - batchedDuration) / sequentialDuration) * 100;

      // Performance assertions
      expect(sequentialRequestCount).toBe(8);
      expect(mockedGraphqlClient.request).toHaveBeenCalledTimes(1);
      expect(batchedDuration).toBeLessThan(sequentialDuration);

      console.log('\n=== Performance Comparison ===');
      console.log(`Sequential (8 requests): ${sequentialDuration.toFixed(2)}ms`);
      console.log(`Batched (1 request):     ${batchedDuration.toFixed(2)}ms`);
      console.log(`Improvement:             ${improvement.toFixed(1)}% faster`);
      console.log(
        `Latency saved:           ${(sequentialDuration - batchedDuration).toFixed(2)}ms`
      );
      console.log('==============================\n');

      // With 50ms latency per request, expect ~75% improvement
      // Sequential: ~400ms (8 * 50ms)
      // Batched: ~50ms (1 * 50ms)
      expect(improvement).toBeGreaterThan(70);
    });
  });

  describe('Batching Behavior', () => {
    it('should deduplicate fields before making request', async () => {
      // Test with duplicate field names
      mockedGraphqlClient.request.mockResolvedValue({
        region: ['NA', 'EU'],
        program: ['IXD', 'ARS'],
      });

      const { result } = renderHook(() =>
        useTemplateFilterOptions(['region', 'program', 'region', 'program'])
      );

      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });

      // Should only make 1 request
      expect(mockedGraphqlClient.request).toHaveBeenCalledTimes(1);

      // Verify query was called (deduplication happens internally)
      expect(mockedGraphqlClient.request).toHaveBeenCalled();

      // Should have correct number of results (no duplicates in output)
      const regionOptions = result.current.filteringOptions.filter(
        (opt) => opt.propertyKey === 'region'
      );
      const programOptions = result.current.filteringOptions.filter(
        (opt) => opt.propertyKey === 'program'
      );

      expect(regionOptions.length).toBe(2); // NA, EU
      expect(programOptions.length).toBe(2); // IXD, ARS
    });

    it('should handle dynamic field selection efficiently', async () => {
      // Simulate user selecting different filter fields in UI
      const scenarios = [
        { fields: ['region'], expectedCount: 1 },
        { fields: ['region', 'program'], expectedCount: 2 },
        { fields: ['region', 'program', 'facilityType'], expectedCount: 3 },
        { fields: ALL_TEMPLATE_FILTER_FIELDS, expectedCount: 8 },
      ];

      for (const scenario of scenarios) {
        jest.clearAllMocks();

        const mockResponse = Object.fromEntries(
          scenario.fields.map((field) => [field, [`${field}-value`]])
        );

        mockedGraphqlClient.request.mockResolvedValue(mockResponse);

        const { result } = renderHook(() => useTemplateFilterOptions(scenario.fields));

        await waitFor(() => {
          expect(result.current.loading).toBe(false);
        });

        // Each scenario should only make 1 request regardless of field count
        expect(mockedGraphqlClient.request).toHaveBeenCalledTimes(1);

        // Verify correct number of property keys in results
        const propertyKeys = new Set(result.current.filteringOptions.map((opt) => opt.propertyKey));
        expect(propertyKeys.size).toBe(scenario.expectedCount);
      }

      console.log('✓ All dynamic field selections batched into single requests');
    });
  });

  describe('Real-World Catalog Performance', () => {
    it('should efficiently load catalog filter options', async () => {
      // Simulate realistic catalog data
      const mockCatalogResponse = {
        name: Array.from({ length: 50 }, (_, i) => `Template ${i + 1}`),
        region: ['NA', 'EU', 'APAC', 'CN', 'IN'],
        facilityType: ['FC', 'SC', 'DS', 'XL', 'TNS'],
        program: ['IXD', 'ARS', 'SSD', 'Prime', 'Fresh', 'Pantry'],
        businessUnit: ['AMZL', 'WWCS', 'AFTL', 'ATS'],
        generation: ['Gen4', 'Gen5', 'Gen6', 'Gen7'],
        createdBy: Array.from({ length: 20 }, (_, i) => `user${i + 1}`),
        version: ['1.0.0', '1.1.0', '2.0.0', '2.1.0', '3.0.0'],
      };

      mockedGraphqlClient.request.mockResolvedValue(mockCatalogResponse);

      const { result } = renderHook(() => useTemplateFilterOptions(ALL_TEMPLATE_FILTER_FIELDS));

      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });

      // Calculate total options
      const totalOptions = result.current.filteringOptions.length;

      // Verify correct transformation to PropertyFilterOptions
      expect(result.current.filteringOptions.every((opt) => opt.propertyKey)).toBe(true);
      expect(result.current.filteringOptions.every((opt) => opt.value)).toBe(true);
      expect(result.current.filteringOptions.every((opt) => opt.label)).toBe(true);

      // Verify performance metrics
      expect(mockedGraphqlClient.request).toHaveBeenCalledTimes(1);
      expect(totalOptions).toBeGreaterThan(50);

      console.log(`✓ Catalog loaded ${totalOptions} filter options in 1 request`);
      console.log(
        `✓ Breakdown: ${mockCatalogResponse.name.length} names, ${mockCatalogResponse.region.length} regions, etc.`
      );
    });

    it('should handle catalog with no filter options gracefully', async () => {
      const emptyMockResponse = {
        name: [],
        region: [],
        facilityType: [],
        program: [],
        businessUnit: [],
        generation: [],
        createdBy: [],
        version: [],
      };

      mockedGraphqlClient.request.mockResolvedValue(emptyMockResponse);

      const { result } = renderHook(() => useTemplateFilterOptions(ALL_TEMPLATE_FILTER_FIELDS));

      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });

      // Should still make only 1 request
      expect(mockedGraphqlClient.request).toHaveBeenCalledTimes(1);

      // Should return empty array
      expect(result.current.filteringOptions).toEqual([]);
      expect(result.current.error).toBeNull();

      console.log('✓ Empty catalog handled efficiently with 1 request');
    });
  });

  describe('Network Efficiency Metrics', () => {
    it('should calculate and verify network savings', async () => {
      const mockResponse = {
        name: ['A', 'B'],
        region: ['NA', 'EU'],
        facilityType: ['FC'],
        program: ['IXD'],
        businessUnit: ['AMZL'],
        generation: ['Gen5'],
        createdBy: ['user1'],
        version: ['1.0.0'],
      };

      mockedGraphqlClient.request.mockResolvedValue(mockResponse);

      const { result } = renderHook(() => useTemplateFilterOptions(ALL_TEMPLATE_FILTER_FIELDS));

      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });

      // Metrics
      const fieldCount = ALL_TEMPLATE_FILTER_FIELDS.length;
      const requestsMade = mockedGraphqlClient.request.mock.calls.length;
      const requestsSaved = fieldCount - requestsMade;
      const reductionPercentage = (requestsSaved / fieldCount) * 100;

      expect(requestsMade).toBe(1);
      expect(requestsSaved).toBe(7);
      expect(reductionPercentage).toBe(87.5);

      console.log('\n=== Network Efficiency Metrics ===');
      console.log(`Fields requested:     ${fieldCount}`);
      console.log(`HTTP requests made:   ${requestsMade}`);
      console.log(`HTTP requests saved:  ${requestsSaved}`);
      console.log(`Reduction:            ${reductionPercentage}%`);
      console.log('==================================\n');
    });
  });
});
