import { renderHook, waitFor, act } from '@testing-library/react';
import { graphqlClient } from '../../api/graphqlClient';
import { useLatestTemplateVersionsSearch } from '../../hooks/useLatestTemplateVersionsSearch';
import type { FilterInput } from '@amzn/global-realty-mosaic-graphql-schema';

jest.mock('../../api/graphqlClient');

const mockGraphqlClient = graphqlClient as jest.Mocked<typeof graphqlClient>;

describe('useLatestTemplateVersionsSearch', () => {
  const mockFilter: FilterInput = {
    pageIdx: 0,
    limit: 20,
    orderBy: 'name',
    orderDesc: false,
  };

  const mockResponse = {
    searchLatestTemplateVersions: {
      items: [
        {
          id: 'tv-1',
          version: '1.0',
          isLatest: true,
          accFolderId: 'folder-1',
          brsId: 'brs-1',
          createdAt: '2025-01-01T00:00:00.000Z',
          updatedAt: '2025-01-01T00:00:00.000Z',
          attributes: { facilityType: 'ARS' },
          files: [{ id: 'file-1', accFileId: 'acc-file-1' }],
          template: {
            id: 'tpl-1',
            name: 'Template A',
            description: 'Description A',
            accProjectId: 'proj-1',
          },
        },
        {
          id: 'tv-2',
          version: '2.0',
          isLatest: true,
          accFolderId: 'folder-2',
          brsId: null,
          createdAt: '2025-01-02T00:00:00.000Z',
          updatedAt: '2025-01-02T00:00:00.000Z',
          attributes: { facilityType: 'IXD' },
          files: [],
          template: {
            id: 'tpl-2',
            name: 'Template B',
            description: null,
            accProjectId: 'proj-2',
          },
        },
      ],
      total: 2,
      pageIdx: 0,
      limit: 20,
      hasNext: false,
    },
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should fetch and return template versions on mount', async () => {
    mockGraphqlClient.request.mockResolvedValueOnce(mockResponse);

    const { result } = renderHook(() => useLatestTemplateVersionsSearch({ filter: mockFilter }));

    expect(result.current.loading).toBe(true);
    expect(result.current.items).toEqual([]);

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.items).toHaveLength(2);
    expect(result.current.items[0]).toEqual({
      id: 'tv-1',
      version: '1.0',
      isLatest: true,
      accFolderId: 'folder-1',
      brsId: 'brs-1',
      createdAt: '2025-01-01T00:00:00.000Z',
      updatedAt: '2025-01-01T00:00:00.000Z',
      attributes: { facilityType: 'ARS' },
      files: [{ id: 'file-1', accFileId: 'acc-file-1' }],
      template: {
        id: 'tpl-1',
        name: 'Template A',
        description: 'Description A',
        accProjectId: 'proj-1',
        heroImageUrl: null,
      },
    });
    expect(result.current.totalCount).toBe(2);
    expect(result.current.totalPages).toBe(1);
    expect(result.current.pageIdx).toBe(0);
    expect(result.current.limit).toBe(20);
    expect(result.current.error).toBeNull();
  });

  it('should handle null brsId and description', async () => {
    mockGraphqlClient.request.mockResolvedValueOnce(mockResponse);

    const { result } = renderHook(() => useLatestTemplateVersionsSearch({ filter: mockFilter }));

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.items[1].brsId).toBeNull();
    expect(result.current.items[1].template.description).toBeNull();
  });

  it('should calculate total pages correctly', async () => {
    const responseWithPagination = {
      ...mockResponse,
      searchLatestTemplateVersions: {
        ...mockResponse.searchLatestTemplateVersions,
        total: 45,
        limit: 20,
      },
    };

    mockGraphqlClient.request.mockResolvedValueOnce(responseWithPagination);

    const { result } = renderHook(() => useLatestTemplateVersionsSearch({ filter: mockFilter }));

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.totalPages).toBe(3); // Math.ceil(45 / 20) = 3
  });

  it('should handle empty results', async () => {
    const emptyResponse = {
      searchLatestTemplateVersions: {
        items: [],
        total: 0,
        pageIdx: 0,
        limit: 20,
        hasNext: false,
      },
    };

    mockGraphqlClient.request.mockResolvedValueOnce(emptyResponse);

    const { result } = renderHook(() => useLatestTemplateVersionsSearch({ filter: mockFilter }));

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.items).toEqual([]);
    expect(result.current.totalCount).toBe(0);
    expect(result.current.totalPages).toBe(1);
    expect(result.current.error).toBeNull();
  });

  it('should handle errors and set error message', async () => {
    const errorMessage = 'Network error';
    mockGraphqlClient.request.mockRejectedValueOnce(new Error(errorMessage));

    const { result } = renderHook(() => useLatestTemplateVersionsSearch({ filter: mockFilter }));

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.items).toEqual([]);
    expect(result.current.totalCount).toBe(0);
    expect(result.current.totalPages).toBe(1);
    expect(result.current.error).toBe(errorMessage);
  });

  it('should handle non-Error exceptions', async () => {
    mockGraphqlClient.request.mockRejectedValueOnce('string error');

    const { result } = renderHook(() => useLatestTemplateVersionsSearch({ filter: mockFilter }));

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.error).toBe('Unable to load template versions.');
  });

  it('should refetch data when refetch is called', async () => {
    mockGraphqlClient.request.mockResolvedValueOnce(mockResponse);

    const { result } = renderHook(() => useLatestTemplateVersionsSearch({ filter: mockFilter }));

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(mockGraphqlClient.request).toHaveBeenCalledTimes(1);

    const updatedResponse = {
      ...mockResponse,
      searchLatestTemplateVersions: {
        ...mockResponse.searchLatestTemplateVersions,
        total: 3,
      },
    };
    mockGraphqlClient.request.mockResolvedValueOnce(updatedResponse);

    await act(async () => {
      await result.current.refetch();
    });

    await waitFor(() => {
      expect(result.current.totalCount).toBe(3);
    });

    expect(mockGraphqlClient.request).toHaveBeenCalledTimes(2);
  });

  it('should refetch when filter changes', async () => {
    mockGraphqlClient.request.mockResolvedValueOnce(mockResponse);

    const { result, rerender } = renderHook(
      ({ filter }) => useLatestTemplateVersionsSearch({ filter }),
      {
        initialProps: { filter: mockFilter },
      }
    );

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(mockGraphqlClient.request).toHaveBeenCalledTimes(1);

    const newFilter: FilterInput = {
      ...mockFilter,
      pageIdx: 1,
    };

    mockGraphqlClient.request.mockResolvedValueOnce(mockResponse);

    rerender({ filter: newFilter });

    await waitFor(() => {
      expect(mockGraphqlClient.request).toHaveBeenCalledTimes(2);
    });

    expect(mockGraphqlClient.request).toHaveBeenLastCalledWith(
      expect.any(String),
      expect.objectContaining({
        filter: expect.objectContaining({
          pageIdx: 1,
        }),
      })
    );
  });

  it('should handle filter with query tokens', async () => {
    const filterWithQuery: FilterInput = {
      ...mockFilter,
      query: {
        operation: 'AND',
        tokenGroups: [
          { propertyKey: 'name', operator: 'CONTAINS', value: 'Template' },
          { propertyKey: 'facilityType', operator: 'EQUALS', value: 'ARS' },
        ],
      },
    };

    mockGraphqlClient.request.mockResolvedValueOnce(mockResponse);

    const { result } = renderHook(() =>
      useLatestTemplateVersionsSearch({ filter: filterWithQuery })
    );

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(mockGraphqlClient.request).toHaveBeenCalledWith(
      expect.any(String),
      expect.objectContaining({
        filter: expect.objectContaining({
          query: expect.objectContaining({
            operation: 'AND',
            tokenGroups: expect.arrayContaining([
              expect.objectContaining({
                propertyKey: 'name',
                operator: 'CONTAINS',
                value: 'Template',
              }),
            ]),
          }),
        }),
      })
    );
  });

  it('should NOT refetch when filter object reference changes but values are the same', async () => {
    mockGraphqlClient.request.mockResolvedValueOnce(mockResponse);

    const { result, rerender } = renderHook(
      ({ filter }) => useLatestTemplateVersionsSearch({ filter }),
      {
        initialProps: { filter: mockFilter },
      }
    );

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(mockGraphqlClient.request).toHaveBeenCalledTimes(1);

    // Create a new object with same values
    const sameFilter: FilterInput = {
      pageIdx: 0,
      limit: 20,
      orderBy: 'name',
      orderDesc: false,
    };

    rerender({ filter: sameFilter });

    // Should NOT trigger new fetch because filter values are the same
    // The hook uses JSON stringification to prevent unnecessary re-fetches
    await waitFor(() => {
      expect(mockGraphqlClient.request).toHaveBeenCalledTimes(1);
    });
  });

  it('should handle zero limit gracefully', async () => {
    const responseWithZeroLimit = {
      searchLatestTemplateVersions: {
        items: [],
        total: 10,
        pageIdx: 0,
        limit: 0,
        hasNext: false,
      },
    };

    mockGraphqlClient.request.mockResolvedValueOnce(responseWithZeroLimit);

    const filterWithZeroLimit: FilterInput = {
      ...mockFilter,
      limit: 0,
    };

    const { result } = renderHook(() =>
      useLatestTemplateVersionsSearch({ filter: filterWithZeroLimit })
    );

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.totalPages).toBe(1); // Should default to 1 when limit is 0
  });

  it('should set loading state during refetch', async () => {
    mockGraphqlClient.request.mockResolvedValueOnce(mockResponse);

    const { result } = renderHook(() => useLatestTemplateVersionsSearch({ filter: mockFilter }));

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    let resolveRequest: (value: any) => void;
    const requestPromise = new Promise((resolve) => {
      resolveRequest = resolve;
    });

    mockGraphqlClient.request.mockImplementation(() => requestPromise);

    act(() => {
      result.current.refetch();
    });

    // Loading should be true during refetch
    await waitFor(() => {
      expect(result.current.loading).toBe(true);
    });

    // Resolve the request
    act(() => {
      resolveRequest!(mockResponse);
    });

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });
  });

  it('should handle missing optional fields gracefully', async () => {
    const responseWithMissingFields = {
      searchLatestTemplateVersions: {
        items: [
          {
            id: 'tv-1',
            version: '1.0',
            isLatest: true,
            accFolderId: 'folder-1',
            brsId: undefined,
            createdAt: '2025-01-01T00:00:00.000Z',
            updatedAt: '2025-01-01T00:00:00.000Z',
            attributes: null,
            files: [],
            template: {
              id: 'tpl-1',
              name: 'Template A',
              description: undefined,
              accProjectId: 'proj-1',
            },
          },
        ],
        total: 1,
        pageIdx: 0,
        limit: 20,
        hasNext: false,
      },
    };

    mockGraphqlClient.request.mockResolvedValueOnce(responseWithMissingFields);

    const { result } = renderHook(() => useLatestTemplateVersionsSearch({ filter: mockFilter }));

    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });

    expect(result.current.items[0].brsId).toBeNull();
    expect(result.current.items[0].attributes).toEqual({});
    expect(result.current.items[0].template.description).toBeNull();
  });
});
