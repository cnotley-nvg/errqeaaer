import { act, renderHook } from '@testing-library/react';

import { useFeedback } from '../../components/shared/hooks/useFeedback';

describe('useFeedback', () => {
  it('sets and clears feedback', () => {
    const { result } = renderHook(() => useFeedback());

    act(() => {
      result.current.showSuccess('All good');
    });

    expect(result.current.feedback).toEqual({ type: 'success', message: 'All good' });

    act(() => {
      result.current.clearFeedback();
    });

    expect(result.current.feedback).toBeNull();
  });
});
