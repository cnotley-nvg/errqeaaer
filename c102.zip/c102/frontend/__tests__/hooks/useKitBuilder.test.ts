import { beforeEach, describe, expect, it, jest } from '@jest/globals';
import { act, renderHook, waitFor } from '@testing-library/react';

import {
  type CreateKitFormInput,
  type KitCompatibleStandardsInput,
  type KitCompatibleStandard,
  type KitOptionsData,
  useCreateKit,
  useKitCompatibleStandards,
  useKitOptions,
} from '../../hooks/useKitBuilder';

type GraphqlRequest = (query: unknown, variables?: Record<string, unknown>) => Promise<unknown>;

jest.mock('../../api/graphqlClient', () => ({
  graphqlClient: {
    request: jest.fn<GraphqlRequest>(),
  },
}));

const { graphqlClient } = require('../../api/graphqlClient') as {
  graphqlClient: {
    request: jest.MockedFunction<GraphqlRequest>;
  };
};

const createKitOptionsPayload = (options: Partial<KitOptionsData> = {}) => ({
  kitOptions: {
    regions: [],
    programs: [],
    useCases: [],
    projectTypes: [],
    roomFeatureZones: [],
    dataTypes: [],
    ...options,
  },
});

const createStandard = (overrides: Partial<KitCompatibleStandard> = {}): KitCompatibleStandard => ({
  id: 'sv-1',
  standardId: 'standard-1',
  standardName: 'Loading Dock Safety',
  version: '1.0.0',
  region: 'North America',
  program: ['GEN5'],
  projectType: ['Retrofit'],
  roomFeatureZone: ['Dock - Safety'],
  dataType: 'Safety Guidelines',
  ...overrides,
});

describe('useKitOptions', () => {
  beforeEach(() => {
    graphqlClient.request.mockReset();
  });

  it('loads kit options on mount and exposes the payload', async () => {
    const payload = createKitOptionsPayload({
      regions: ['North America', 'Europe'],
      programs: ['GEN5'],
      projectTypes: ['Retrofit'],
      roomFeatureZones: ['Dock - Safety'],
      dataTypes: ['Safety'],
    });
    graphqlClient.request.mockResolvedValue(payload);

    const { result } = renderHook(() => useKitOptions());

    expect(result.current.loading).toBe(true);

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(graphqlClient.request).toHaveBeenCalledTimes(1);
    expect(graphqlClient.request.mock.calls[0]?.[1]).toBeUndefined();
    expect(result.current.options).toEqual(payload.kitOptions);
    expect(result.current.error).toBeNull();
    expect(result.current.isLoaded).toBe(true);
  });

  it('exposes fallback error state when the request fails', async () => {
    graphqlClient.request.mockRejectedValue('Service unavailable');

    const { result } = renderHook(() => useKitOptions());

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.options).toEqual(createKitOptionsPayload().kitOptions);
    expect(result.current.error).toBe('Unable to load kit options.');
    expect(result.current.isLoaded).toBe(true);
  });

  it('supports refetching to refresh option values', async () => {
    graphqlClient.request.mockResolvedValueOnce(createKitOptionsPayload());
    graphqlClient.request.mockResolvedValueOnce(
      createKitOptionsPayload({
        regions: ['APAC'],
        programs: ['Automation'],
      })
    );

    const { result } = renderHook(() => useKitOptions());

    await waitFor(() => expect(result.current.loading).toBe(false));

    await act(async () => {
      await result.current.refetch();
    });

    expect(graphqlClient.request).toHaveBeenCalledTimes(2);
    expect(result.current.options.regions).toEqual(['APAC']);
    expect(result.current.isLoaded).toBe(true);
  });
});

describe('useKitCompatibleStandards', () => {
  beforeEach(() => {
    graphqlClient.request.mockReset();
  });

  it('fetches compatible standards using normalized filters', async () => {
    const standard = createStandard();
    graphqlClient.request.mockResolvedValue({ kitCompatibleStandards: [standard] });

    const filters: KitCompatibleStandardsInput = {
      regions: ['  North America  '],
      programs: ['  GEN5  '],
      projectTypes: ['  Retrofit '],
      roomFeatureZones: [' Dock - Safety '],
      dataTypes: [' Safety Guidelines '],
    };

    const { result } = renderHook(
      ({ currentFilters }: { currentFilters: KitCompatibleStandardsInput | null }) =>
        useKitCompatibleStandards(currentFilters),
      { initialProps: { currentFilters: filters } }
    );

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(graphqlClient.request).toHaveBeenCalledWith(expect.anything(), {
      input: {
        regions: ['North America'],
        programs: ['GEN5'],
        projectTypes: ['Retrofit'],
        roomFeatureZones: ['Dock - Safety'],
        dataTypes: ['Safety Guidelines'],
      },
    });
    expect(result.current.standards).toEqual([standard]);
    expect(result.current.error).toBeNull();
    expect(result.current.hasFetched).toBe(true);
  });

  it('clears state when filters are incomplete', async () => {
    graphqlClient.request.mockResolvedValue({ kitCompatibleStandards: [createStandard()] });

    const { result, rerender } = renderHook(
      ({ currentFilters }: { currentFilters: KitCompatibleStandardsInput | null }) =>
        useKitCompatibleStandards(currentFilters),
      {
        initialProps: {
          currentFilters: {
            regions: ['North America'],
            projectTypes: ['Retrofit'],
            programs: [],
            roomFeatureZones: [],
            dataTypes: [],
          },
        },
      }
    );

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.hasFetched).toBe(true);

    rerender({
      currentFilters: {
        regions: ['   '],
        projectTypes: ['   '],
        programs: [],
        roomFeatureZones: [],
        dataTypes: [],
      },
    });

    await waitFor(() => expect(result.current.hasFetched).toBe(false));
    expect(result.current.standards).toEqual([]);
  });

  it('fetches compatible standards when only optional filters are supplied', async () => {
    const standard = createStandard();
    graphqlClient.request.mockResolvedValue({ kitCompatibleStandards: [standard] });

    const { result } = renderHook(
      ({ currentFilters }: { currentFilters: KitCompatibleStandardsInput | null }) =>
        useKitCompatibleStandards(currentFilters),
      {
        initialProps: {
          currentFilters: {
            programs: ['  GEN5  '],
          },
        },
      }
    );

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(graphqlClient.request).toHaveBeenCalledWith(expect.anything(), {
      input: {
        programs: ['GEN5'],
      },
    });
    expect(result.current.standards).toEqual([standard]);
    expect(result.current.hasFetched).toBe(true);
  });

  it('reports errors from the underlying request', async () => {
    graphqlClient.request.mockRejectedValue(new Error('Upstream unavailable'));

    const { result } = renderHook(
      ({ currentFilters }: { currentFilters: KitCompatibleStandardsInput | null }) =>
        useKitCompatibleStandards(currentFilters),
      {
        initialProps: {
          currentFilters: {
            regions: ['North America'],
            projectTypes: ['Retrofit'],
            programs: [],
            roomFeatureZones: [],
            dataTypes: [],
          },
        },
      }
    );

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.error).toBe('Upstream unavailable');
    expect(result.current.standards).toEqual([]);
    expect(result.current.hasFetched).toBe(true);
  });

  it('skips refetching when no filters have been supplied', async () => {
    const { result } = renderHook(() => useKitCompatibleStandards(null));

    expect(result.current.loading).toBe(false);
    expect(result.current.hasFetched).toBe(false);
    expect(graphqlClient.request).not.toHaveBeenCalled();

    await act(async () => {
      const response = await result.current.refetch();
      expect(response).toEqual([]);
    });

    expect(graphqlClient.request).not.toHaveBeenCalled();
  });

  it('supports refetching with the latest filters', async () => {
    graphqlClient.request
      .mockResolvedValueOnce({ kitCompatibleStandards: [createStandard({ id: 'sv-1' })] })
      .mockResolvedValueOnce({ kitCompatibleStandards: [createStandard({ id: 'sv-2' })] });

    const filters: KitCompatibleStandardsInput = {
      regions: ['North America'],
      projectTypes: ['Retrofit'],
      programs: ['GEN5'],
      roomFeatureZones: [],
      dataTypes: [],
    };

    const { result } = renderHook(
      ({ currentFilters }: { currentFilters: KitCompatibleStandardsInput | null }) =>
        useKitCompatibleStandards(currentFilters),
      { initialProps: { currentFilters: filters } }
    );

    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.standards).toHaveLength(1);

    await act(async () => {
      await result.current.refetch();
    });

    expect(graphqlClient.request).toHaveBeenCalledTimes(2);
    expect(result.current.standards[0]?.id).toBe('sv-2');
  });
});

describe('useCreateKit', () => {
  beforeEach(() => {
    graphqlClient.request.mockReset();
  });

  const buildInput = (overrides: Partial<CreateKitFormInput> = {}): CreateKitFormInput => ({
    name: 'Dock Safety Demo',
    description: '  Demo description  ',
    region: 'North America',
    program: ['GEN5'],
    projectType: ['Retrofit'],
    roomFeatureZone: ['Dock - Safety'],
    dataType: 'Safety Guidelines',
    standardVersionIds: ['sv-1', 'sv-2'],
    ...overrides,
  });

  it('creates a kit and exposes the created kit name', async () => {
    graphqlClient.request.mockResolvedValue({
      createKit: {
        success: true,
        message: null,
        kit: { id: 'kit-1', name: 'Approved Dock Kit' },
      },
    });

    const { result } = renderHook(() => useCreateKit());
    const input = buildInput();

    await act(async () => {
      const created = await result.current.createKit(input);

      expect(created).toEqual({ id: 'kit-1', name: 'Approved Dock Kit' });
    });

    expect(graphqlClient.request).toHaveBeenCalledWith(expect.anything(), {
      input: {
        name: 'Dock Safety Demo',
        desc: 'Demo description',
        initialVersion: {
          version: '1.0.0',
          standardVersionIds: ['sv-1', 'sv-2'],
          attributes: {
            region: 'North America',
            program: ['GEN5'],
            projectType: ['Retrofit'],
            roomFeatureZone: ['Dock - Safety'],
            dataType: 'Safety Guidelines',
          },
        },
      },
    });

    expect(result.current.error).toBeNull();
    expect(result.current.createdKitName).toBe('Approved Dock Kit');
    expect(result.current.loading).toBe(false);
  });

  it('falls back to the submitted name when response omits kit details', async () => {
    graphqlClient.request.mockResolvedValue({
      createKit: {
        success: true,
        message: null,
        kit: null,
      },
    });

    const { result } = renderHook(() => useCreateKit());
    const input = buildInput({
      description: '  ',
      program: null,
      roomFeatureZone: null,
      dataType: null,
    });

    await act(async () => {
      const created = await result.current.createKit(input);

      expect(created).toBeNull();
    });

    expect(graphqlClient.request).toHaveBeenCalledWith(expect.anything(), {
      input: {
        name: 'Dock Safety Demo',
        desc: undefined,
        initialVersion: {
          version: '1.0.0',
          standardVersionIds: ['sv-1', 'sv-2'],
          attributes: {
            region: 'North America',
            projectType: ['Retrofit'],
          },
        },
      },
    });

    expect(result.current.createdKitName).toBe('Dock Safety Demo');
    expect(result.current.error).toBeNull();
  });

  it('captures API error messages when the mutation returns unsuccessfully', async () => {
    graphqlClient.request.mockResolvedValue({
      createKit: {
        success: false,
        message: 'Name already exists',
        kit: null,
      },
    });

    const { result } = renderHook(() => useCreateKit());

    await act(async () => {
      const response = await result.current.createKit(buildInput());
      expect(response).toBeNull();
    });

    expect(result.current.error).toBe('Name already exists');
    expect(result.current.createdKitName).toBeNull();
  });

  it('handles thrown errors by exposing the rejection message', async () => {
    graphqlClient.request.mockRejectedValue(new Error('Network error'));

    const { result } = renderHook(() => useCreateKit());

    await act(async () => {
      const response = await result.current.createKit(buildInput());
      expect(response).toBeNull();
    });

    expect(result.current.error).toBe('Network error');
    expect(result.current.createdKitName).toBeNull();
  });

  it('resets error and created-kit state when requested', async () => {
    graphqlClient.request.mockResolvedValue({
      createKit: {
        success: false,
        message: 'Failure',
        kit: null,
      },
    });

    const { result } = renderHook(() => useCreateKit());

    await act(async () => {
      await result.current.createKit(buildInput());
    });

    expect(result.current.error).toBe('Failure');

    act(() => {
      result.current.reset();
    });

    expect(result.current.error).toBeNull();
    expect(result.current.createdKitName).toBeNull();
  });
});
