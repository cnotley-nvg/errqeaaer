import { renderHook } from '@testing-library/react';
import { useDebounce } from '../../hooks/useDebounce';

describe('useDebounce', () => {
  it('should call callback function', async () => {
    const callback = jest.fn();
    const timeout = 300;

    jest.useFakeTimers();
    const { result, unmount } = renderHook(() => useDebounce(callback, timeout));
    result.current();
    jest.runAllTimers();

    expect(callback).toHaveBeenCalled();

    unmount();
  });

  it('should call only once', async () => {
    const callback = jest.fn();
    const timeout = 100;

    jest.useFakeTimers();
    const { result, unmount } = renderHook(() => useDebounce(callback, timeout));
    result.current();
    result.current();
    jest.runAllTimers();

    expect(callback).toHaveBeenCalledTimes(1);

    unmount();
  });

  it('should call 2 times with delay', async () => {
    const callback = jest.fn();
    const timeout = 100;

    jest.useFakeTimers();
    const { result, unmount } = renderHook(() => useDebounce(callback, timeout));
    result.current();

    setTimeout(() => {
      result.current();
    }, timeout * 2);
    jest.runAllTimers();

    expect(callback).toHaveBeenCalledTimes(2);

    unmount();
  });

  it('should call with correct parameters', async () => {
    const callback = jest.fn();
    const timeout = 100;
    const props = [
      1,
      60,
      'test string',
      { test: 'test', list: [], date: new Date() },
      [1, 10, 100],
    ];

    jest.useFakeTimers();
    const { result, unmount } = renderHook(() => useDebounce(callback, timeout));
    result.current(props);
    jest.runAllTimers();

    expect(callback).toHaveBeenCalledWith(props);

    unmount();
  });
});
