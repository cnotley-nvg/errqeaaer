import { __testables } from '../../api/graphqlClient';

const { resolveGraphqlEndpoint, coerceEndpoint, defaultEndpoint } = __testables;

describe('graphqlClient configuration', () => {
  describe('coerceEndpoint', () => {
    it('returns the default when candidate is undefined', () => {
      expect(coerceEndpoint(undefined)).toBe(defaultEndpoint);
    });

    it('returns the default when candidate is blank', () => {
      expect(coerceEndpoint('   ')).toBe(defaultEndpoint);
    });

    it('returns a trimmed custom endpoint when present', () => {
      expect(coerceEndpoint('  https://example/graphql  ')).toBe('https://example/graphql');
    });
  });

  describe('resolveGraphqlEndpoint', () => {
    it('prefers VITE_GRAPHQL_ENDPOINT when provided', () => {
      const endpoint = resolveGraphqlEndpoint({ VITE_GRAPHQL_ENDPOINT: 'https://prod/graphql' });
      expect(endpoint).toBe('https://prod/graphql');
    });

    it('falls back to the default endpoint when env is empty', () => {
      const endpoint = resolveGraphqlEndpoint({ VITE_GRAPHQL_ENDPOINT: '   ' });
      expect(endpoint).toBe(defaultEndpoint);
    });

    it('falls back to the default endpoint when env is missing', () => {
      const endpoint = resolveGraphqlEndpoint();
      expect(endpoint).toBe(defaultEndpoint);
    });
  });
});
