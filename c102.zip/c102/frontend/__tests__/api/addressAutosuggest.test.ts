import { getAddressSuggestions } from '../../api/addressAutosuggest';
import { graphqlClient } from '../../api/graphqlClient';

jest.mock('../../api/graphqlClient');

describe('addressAutosuggest API', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('getAddressSuggestions', () => {
    it('returns address suggestions from GraphQL query', async () => {
      const mockSuggestions = [
        {
          label: '123 Main St, Seattle, WA 98109, USA',
          address: '123 Main St, Seattle, WA 98109, USA',
          city: 'Seattle',
          state: 'WA',
          zipcode: '98109',
          country: 'USA',
          latitude: 47.6062,
          longitude: -122.3321,
        },
        {
          label: '456 Main Ave, Seattle, WA 98101, USA',
          address: '456 Main Ave, Seattle, WA 98101, USA',
          city: 'Seattle',
          state: 'WA',
          zipcode: '98101',
          country: 'USA',
          latitude: 47.6101,
          longitude: -122.3297,
        },
      ];

      (graphqlClient.request as jest.Mock).mockResolvedValue({
        getAddressSuggestions: mockSuggestions,
      });

      const result = await getAddressSuggestions('123 Main');

      expect(result).toEqual(mockSuggestions);
      expect(graphqlClient.request).toHaveBeenCalled();
    });

    it('returns empty array when text is less than 2 characters', async () => {
      const result = await getAddressSuggestions('a');

      expect(result).toEqual([]);
      expect(graphqlClient.request).not.toHaveBeenCalled();
    });

    it('returns empty array when text is empty', async () => {
      const result = await getAddressSuggestions('');

      expect(result).toEqual([]);
      expect(graphqlClient.request).not.toHaveBeenCalled();
    });

    it('returns empty array when text is only whitespace', async () => {
      const result = await getAddressSuggestions('   ');

      expect(result).toEqual([]);
      expect(graphqlClient.request).not.toHaveBeenCalled();
    });

    it('passes country and city parameters to GraphQL query', async () => {
      (graphqlClient.request as jest.Mock).mockResolvedValue({
        getAddressSuggestions: [],
      });

      await getAddressSuggestions('Main St', 'USA', 'Seattle');

      expect(graphqlClient.request).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          text: 'Main St',
          country: 'USA',
          city: 'Seattle',
        })
      );
    });

    it('handles GraphQL errors gracefully', async () => {
      (graphqlClient.request as jest.Mock).mockRejectedValue(new Error('GraphQL Error'));

      const result = await getAddressSuggestions('Main St');

      expect(result).toEqual([]);
    });

    it('returns empty array when response is missing suggestions', async () => {
      (graphqlClient.request as jest.Mock).mockResolvedValue({});

      const result = await getAddressSuggestions('Main St');

      expect(result).toEqual([]);
    });

    it('returns empty array when suggestions is null', async () => {
      (graphqlClient.request as jest.Mock).mockResolvedValue({
        getAddressSuggestions: null,
      });

      const result = await getAddressSuggestions('Main St');

      expect(result).toEqual([]);
    });
  });
});
