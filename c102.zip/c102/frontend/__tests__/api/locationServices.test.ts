import { geocodeAddress, reverseGeocodeCoordinates } from '../../api/locationServices';
import { graphqlClient } from '../../api/graphqlClient';

jest.mock('../../api/graphqlClient');

describe('locationServices API', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('geocodeAddress', () => {
    it('returns geocoded result from GraphQL query', async () => {
      const mockResult = {
        latitude: 47.6062,
        longitude: -122.3321,
        address: '123 Main St, Seattle, WA 98109, USA',
        city: 'Seattle',
        state: 'WA',
        zipcode: '98109',
        country: 'USA',
      };

      (graphqlClient.request as jest.Mock).mockResolvedValue({
        geocodeAddress: mockResult,
      });

      const result = await geocodeAddress('123 Main St', '98109');

      expect(result).toEqual(mockResult);
      expect(graphqlClient.request).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          address: '123 Main St',
          zipcode: '98109',
        })
      );
    });

    it('returns null when geocoding fails', async () => {
      (graphqlClient.request as jest.Mock).mockResolvedValue({
        geocodeAddress: null,
      });

      const result = await geocodeAddress('nonexistent');

      expect(result).toBeNull();
    });

    it('handles GraphQL errors gracefully', async () => {
      (graphqlClient.request as jest.Mock).mockRejectedValue(new Error('GraphQL Error'));

      const result = await geocodeAddress('Main St');

      expect(result).toBeNull();
    });

    it('passes zipcode as optional parameter', async () => {
      (graphqlClient.request as jest.Mock).mockResolvedValue({
        geocodeAddress: null,
      });

      await geocodeAddress('Main St');

      expect(graphqlClient.request).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          address: 'Main St',
          zipcode: undefined,
        })
      );
    });

    it('returns undefined when response is missing geocodeAddress', async () => {
      (graphqlClient.request as jest.Mock).mockResolvedValue({});

      const result = await geocodeAddress('Main St');

      expect(result).toBeUndefined();
    });
  });

  describe('reverseGeocodeCoordinates', () => {
    it('returns address details from GraphQL query', async () => {
      const mockResult = {
        latitude: 47.6062,
        longitude: -122.3321,
        address: '123 Main St, Seattle, WA 98109, USA',
        city: 'Seattle',
        state: 'WA',
        zipcode: '98109',
        country: 'USA',
      };

      (graphqlClient.request as jest.Mock).mockResolvedValue({
        reverseGeocodeCoordinates: mockResult,
      });

      const result = await reverseGeocodeCoordinates(47.6062, -122.3321);

      expect(result).toEqual(mockResult);
      expect(graphqlClient.request).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          latitude: 47.6062,
          longitude: -122.3321,
        })
      );
    });

    it('returns null when reverse geocoding fails', async () => {
      (graphqlClient.request as jest.Mock).mockResolvedValue({
        reverseGeocodeCoordinates: null,
      });

      const result = await reverseGeocodeCoordinates(0, 0);

      expect(result).toBeNull();
    });

    it('handles GraphQL errors gracefully', async () => {
      (graphqlClient.request as jest.Mock).mockRejectedValue(new Error('GraphQL Error'));

      const result = await reverseGeocodeCoordinates(47.6062, -122.3321);

      expect(result).toBeNull();
    });

    it('returns undefined when response is missing reverseGeocodeCoordinates', async () => {
      (graphqlClient.request as jest.Mock).mockResolvedValue({});

      const result = await reverseGeocodeCoordinates(47.6062, -122.3321);

      expect(result).toBeUndefined();
    });

    it('handles negative coordinates', async () => {
      (graphqlClient.request as jest.Mock).mockResolvedValue({
        reverseGeocodeCoordinates: null,
      });

      await reverseGeocodeCoordinates(-33.8688, 151.2093);

      expect(graphqlClient.request).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          latitude: -33.8688,
          longitude: 151.2093,
        })
      );
    });
  });
});
