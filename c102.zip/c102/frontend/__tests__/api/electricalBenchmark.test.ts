import {
  fetchElectricalLookupTable,
  calculateElectrical,
  type ElectricalCalculatorInput,
} from '../../api/electricalBenchmark';
import { graphqlClient } from '../../api/graphqlClient';

jest.mock('../../api/graphqlClient');

const mockedGraphqlClient = graphqlClient as jest.Mocked<typeof graphqlClient>;

describe('electricalBenchmark API', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('fetchElectricalLookupTable', () => {
    it('fetches lookup table for a given template version ID', async () => {
      const mockLookupData = {
        electricalLoadLookupsByTemplateVersion: [
          {
            category: 'IT Equipment',
            connectedLoadKVA: 500,
            demandDiversityFactor: 0.8,
            utilityDemandFactor: 0.9,
          },
          {
            category: 'Cooling',
            connectedLoadKVA: 300,
            demandDiversityFactor: 0.7,
            utilityDemandFactor: 0.85,
          },
        ],
      };

      mockedGraphqlClient.request.mockResolvedValue(mockLookupData);

      const result = await fetchElectricalLookupTable('template-version-123');

      expect(mockedGraphqlClient.request).toHaveBeenCalledWith(expect.any(String), {
        templateVersionId: 'template-version-123',
      });
      expect(result).toEqual(mockLookupData);
      expect(result.electricalLoadLookupsByTemplateVersion).toHaveLength(2);
    });

    it('handles empty lookup table', async () => {
      const mockEmptyData = {
        electricalLoadLookupsByTemplateVersion: [],
      };

      mockedGraphqlClient.request.mockResolvedValue(mockEmptyData);

      const result = await fetchElectricalLookupTable('template-version-no-data');

      expect(result.electricalLoadLookupsByTemplateVersion).toHaveLength(0);
    });

    it('throws error when request fails', async () => {
      mockedGraphqlClient.request.mockRejectedValue(new Error('GraphQL error'));

      await expect(fetchElectricalLookupTable('invalid-id')).rejects.toThrow('GraphQL error');
    });
  });

  describe('calculateElectrical', () => {
    it('calculates electrical loads with valid input', async () => {
      const mockCalculationResult = {
        calculateElectrical: {
          categoryLoads: [
            {
              category: 'IT Equipment',
              connectedLoad: { kVA: 500, amps: 601 },
              demandDiversityFactor: 0.8,
              diversifiedLoad: { kVA: 400, amps: 481 },
              utilityDemandFactor: 0.9,
              utilityPowerDemand: { kVA: 450, amps: 541 },
            },
          ],
          total: {
            connectedLoad: { kVA: 1000, amps: 1202 },
            diversifiedLoad: { kVA: 800, amps: 962 },
            utilityPowerDemand: { kVA: 900, amps: 1082 },
          },
          o1: { kVA: 1240, amps: 1495 },
          o2: { kVA: 485, amps: 585 },
          o3: { kVA: 755, amps: 910 },
          o4: 800,
        },
      };

      mockedGraphqlClient.request.mockResolvedValue(mockCalculationResult);

      const input: ElectricalCalculatorInput = {
        latitude: 47.6062,
        longitude: -122.3321,
        voltage: 480,
        area: 50000,
        roofFactor: 0.8,
        solarPowerDensity: 10,
        lookupTable: [
          {
            category: 'IT Equipment',
            connectedLoadKVA: 500,
            demandDiversityFactor: 0.8,
            utilityDemandFactor: 0.9,
          },
        ],
      };

      const result = await calculateElectrical(input);

      expect(mockedGraphqlClient.request).toHaveBeenCalledWith(expect.any(String), { input });
      expect(result.calculateElectrical.o1.kVA).toBe(1240);
      expect(result.calculateElectrical.o4).toBe(800);
    });

    it('handles calculation with zero solar power', async () => {
      const mockResultNoSolar = {
        calculateElectrical: {
          categoryLoads: [],
          total: {
            connectedLoad: { kVA: 1000, amps: 1202 },
            diversifiedLoad: { kVA: 800, amps: 962 },
            utilityPowerDemand: { kVA: 900, amps: 1082 },
          },
          o1: { kVA: 1000, amps: 1202 },
          o2: { kVA: 0, amps: 0 }, // No solar
          o3: { kVA: 1000, amps: 1202 }, // Same as O1
          o4: 500,
        },
      };

      mockedGraphqlClient.request.mockResolvedValue(mockResultNoSolar);

      const input: ElectricalCalculatorInput = {
        latitude: 30.0, // Non-solar state
        longitude: -95.0,
        voltage: 480,
        area: 50000,
        roofFactor: 0.8,
        solarPowerDensity: 10,
        lookupTable: [
          {
            category: 'IT Equipment',
            connectedLoadKVA: 1000,
            demandDiversityFactor: 1.0,
            utilityDemandFactor: 1.0,
          },
        ],
      };

      const result = await calculateElectrical(input);

      expect(result.calculateElectrical.o2.kVA).toBe(0);
      expect(result.calculateElectrical.o3.kVA).toBe(1000);
    });

    it('throws error when calculation fails', async () => {
      mockedGraphqlClient.request.mockRejectedValue(new Error('Calculation error'));

      const input: ElectricalCalculatorInput = {
        latitude: 47.6062,
        longitude: -122.3321,
        voltage: 480,
        area: 50000,
        roofFactor: 0.8,
        solarPowerDensity: 10,
        lookupTable: [],
      };

      await expect(calculateElectrical(input)).rejects.toThrow('Calculation error');
    });
  });
});
