import { FeatureFlag, getUnleashConfig, isUnleashConfigured } from '../../config/featureFlags';

describe('featureFlags config', () => {
  describe('FeatureFlag enum', () => {
    it('should export MosaicTestBanner flag', () => {
      expect(FeatureFlag.MosaicTestBanner).toBe('MosaicTestBanner');
    });
  });

  describe('getUnleashConfig', () => {
    it('should have expected structure', () => {
      const config = getUnleashConfig();
      expect(config).toHaveProperty('url');
      expect(config).toHaveProperty('clientKey');
      expect(config).toHaveProperty('appName');
      expect(config).toHaveProperty('environment');
      expect(config).toHaveProperty('refreshInterval');
    });

    it('should have appName set to mosaic', () => {
      expect(getUnleashConfig().appName).toBe('mosaic');
    });

    it('should have refreshInterval set to 60', () => {
      expect(getUnleashConfig().refreshInterval).toBe(60);
    });
  });

  describe('isUnleashConfigured', () => {
    it('should return boolean', () => {
      const result = isUnleashConfigured();
      expect(typeof result).toBe('boolean');
    });
  });
});
