import { describe, expect, it, jest } from '@jest/globals';
import { render, screen } from '@testing-library/react';

import { TemplateRevisionHistory } from '../../../../components/templates/detail/TemplateRevisionHistory';

// Mock the useTemplateVersionChangesMap hook with realistic data
jest.mock('../../../../components/templates/hooks/useTemplateVersionChanges', () => ({
  useTemplateVersionChangesMap: jest.fn(() => ({
    changesByVersionId: {
      v1: [
        {
          id: 'chg1',
          templateVersionId: 'v1',
          category: 'Structural',
          title: 'Updated foundation design',
          description: 'Modified foundation specs for seismic zones',
          dci: { text: 'DCI-12345', url: null },
          dcr: { text: 'DCR-54321', url: null },
          sheet: 'E-101',
          changeInCost: '$5,000',
        },
        {
          id: 'chg2',
          templateVersionId: 'v1',
          category: 'Electrical',
          title: 'Load panel upgrade',
          description: 'Updated electrical panels for increased capacity',
          dci: { text: 'DCI-12346', url: null },
          dcr: { text: 'DCR-54322', url: null },
          sheet: 'E-102',
          changeInCost: '$3,500',
        },
      ],
    },
    loading: false,
    error: null,
  })),
}));

const defaultProps = {
  templateVersionId: 'v1',
  templateName: 'ARS NA Gen 14 Civil Template',
  templateVersion: 'v2.0',
  templateDescription: 'Site plan template that delivers Gen 14 footprint options',
};

describe('TemplateRevisionHistory', () => {
  it('renders all changes from the template version', () => {
    render(<TemplateRevisionHistory {...defaultProps} />);

    // Should show total count of changes for this version
    expect(screen.getByText('Revision log (2)')).toBeTruthy();

    // Should display all disciplines
    expect(screen.getByText('Structural')).toBeTruthy();
    expect(screen.getByText('Electrical')).toBeTruthy();
  });

  it('displays all column headers correctly', () => {
    render(<TemplateRevisionHistory {...defaultProps} />);

    expect(screen.getByText('Discipline')).toBeTruthy();
    expect(screen.getByText('Title')).toBeTruthy();
    expect(screen.getByText('Description')).toBeTruthy();
    expect(screen.getByText('DCI #')).toBeTruthy();
    expect(screen.getByText('DCR #')).toBeTruthy();
    expect(screen.getByText('Sheet')).toBeTruthy();
    expect(screen.getByText('Change in Cost')).toBeTruthy();
  });

  it('displays DCI numbers as plain text', () => {
    render(<TemplateRevisionHistory {...defaultProps} />);

    // DCI numbers should be visible
    expect(screen.getByText('DCI-12345')).toBeTruthy();
    expect(screen.getByText('DCI-12346')).toBeTruthy();
  });

  it('displays change titles', () => {
    render(<TemplateRevisionHistory {...defaultProps} />);

    expect(screen.getByText('Updated foundation design')).toBeTruthy();
    expect(screen.getByText('Load panel upgrade')).toBeTruthy();
  });

  it('displays change descriptions', () => {
    render(<TemplateRevisionHistory {...defaultProps} />);

    expect(screen.getByText('Modified foundation specs for seismic zones')).toBeTruthy();
    expect(screen.getByText('Updated electrical panels for increased capacity')).toBeTruthy();
  });

  it('shows PropertyFilter search bar', () => {
    render(<TemplateRevisionHistory {...defaultProps} />);

    // Check for search/filter component (PropertyFilter renders as combobox)
    const filterInput = screen.getByRole('combobox', { name: /filter template version changes/i });
    expect(filterInput).toBeTruthy();
  });

  it('supports multi-select filtering for Discipline property', () => {
    render(<TemplateRevisionHistory {...defaultProps} />);

    // Verify PropertyFilter is rendered (which supports multi-select via enum tokenType)
    const filterInput = screen.getByRole('combobox', { name: /filter template version changes/i });
    expect(filterInput).toBeTruthy();

    // Note: Actual multi-select dropdown behavior is tested via integration tests
    // The enum tokenType configuration enables checkboxes automatically in Cloudscape
  });
});
