import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import { BrsLink } from '../../../../components/templates/common/BrsLink';

describe('BrsLink', () => {
  const validBrsId = 'a1q3t00000BmdJHAAZ';

  it('renders a link when valid BRS ID is provided', () => {
    render(<BrsLink brsId={validBrsId} />);

    const link = screen.getByRole('link', { name: 'View BRS' });
    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute('href');
    expect(link.getAttribute('href')).toContain('amznfulfillment.my.site.com/brs/brs-detail');
    expect(link.getAttribute('href')).toContain(validBrsId);
  });

  it('renders a link with custom label', () => {
    render(<BrsLink brsId={validBrsId} label="Open BRS" />);

    const link = screen.getByRole('link', { name: 'Open BRS' });
    expect(link).toBeInTheDocument();
  });

  it('renders "–" when BRS ID is null', () => {
    render(<BrsLink brsId={null} />);
    expect(screen.getByText('–')).toBeInTheDocument();
    expect(screen.queryByRole('link')).not.toBeInTheDocument();
  });

  it('renders "–" when BRS ID is undefined', () => {
    render(<BrsLink brsId={undefined} />);
    expect(screen.getByText('–')).toBeInTheDocument();
    expect(screen.queryByRole('link')).not.toBeInTheDocument();
  });

  it('renders "–" when BRS ID is empty string', () => {
    render(<BrsLink brsId="" />);
    expect(screen.getByText('–')).toBeInTheDocument();
    expect(screen.queryByRole('link')).not.toBeInTheDocument();
  });

  it('renders "–" when BRS ID is invalid format', () => {
    render(<BrsLink brsId="invalid-id" />);
    expect(screen.getByText('–')).toBeInTheDocument();
    expect(screen.queryByRole('link')).not.toBeInTheDocument();
  });

  it('renders link with external attribute', () => {
    render(<BrsLink brsId={validBrsId} />);

    const link = screen.getByRole('link', { name: 'View BRS' });
    expect(link).toHaveAttribute('target', '_blank');
    expect(link).toHaveAttribute('rel', 'noopener noreferrer');
  });
});
