import React from 'react';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { KitStandardsList } from '../../../components/kits/detail/KitStandardsList';
import type { KitDetailData } from '../../../hooks/useKitDetail';

const mockKitWithStandards: KitDetailData = {
  id: 'kit-1',
  name: 'Test Kit',
  description: 'Test kit description',
  createdAt: '2024-01-15T10:00:00Z',
  updatedAt: '2024-01-20T15:30:00Z',
  latestVersion: {
    id: 'version-1',
    version: '1.0',
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-01-20T15:30:00Z',
    attributes: {},
    standards: [
      {
        id: 'standard-version-1',
        standardId: 'standard-1',
        standardName: 'Test Standard 1',
        version: '2.0',
        attributes: {
          region: 'NA',
          program: 'Fulfillment Center',
          projectType: 'New Build',
          roomFeatureZone: 'Office',
          dataType: 'BIM',
        },
      },
      {
        id: 'standard-version-2',
        standardId: 'standard-2',
        standardName: 'Test Standard 2',
        version: '1.5',
        attributes: {
          region: 'EU',
          program: 'Sort Center',
          projectType: 'Renovation',
        },
      },
    ],
  },
};

const mockKitWithoutStandards: KitDetailData = {
  ...mockKitWithStandards,
  latestVersion: {
    ...mockKitWithStandards.latestVersion!,
    standards: [],
  },
};

describe('KitStandardsList', () => {
  it('renders standards count in header', () => {
    render(
      <MemoryRouter>
        <KitStandardsList kit={mockKitWithStandards} />
      </MemoryRouter>
    );

    expect(screen.getByText('Standards (2)')).toBeDefined();
  });

  it('renders all standard cards', () => {
    render(
      <MemoryRouter>
        <KitStandardsList kit={mockKitWithStandards} />
      </MemoryRouter>
    );

    expect(screen.getByText('Test Standard 1')).toBeDefined();
    expect(screen.getByText('Test Standard 2')).toBeDefined();
  });

  it('renders download buttons for each standard', () => {
    render(
      <MemoryRouter>
        <KitStandardsList kit={mockKitWithStandards} />
      </MemoryRouter>
    );

    const downloadButtons = screen.getAllByRole('button', { name: /Download/i });
    expect(downloadButtons.length).toBe(2);
  });

  it('renders empty state when no standards', () => {
    render(
      <MemoryRouter>
        <KitStandardsList kit={mockKitWithoutStandards} />
      </MemoryRouter>
    );

    expect(screen.getByText('Standards (0)')).toBeDefined();
    expect(screen.getByText('No standards')).toBeDefined();
    expect(screen.getByText('This kit does not contain any standards yet.')).toBeDefined();
  });

  it('handles null kit gracefully', () => {
    render(
      <MemoryRouter>
        <KitStandardsList kit={null} />
      </MemoryRouter>
    );

    expect(screen.getByText('Standards (0)')).toBeDefined();
    expect(screen.getByText('No standards')).toBeDefined();
  });

  it('handles kit without latest version', () => {
    const kitWithoutVersion = {
      ...mockKitWithStandards,
      latestVersion: null,
    };

    render(
      <MemoryRouter>
        <KitStandardsList kit={kitWithoutVersion} />
      </MemoryRouter>
    );

    expect(screen.getByText('Standards (0)')).toBeDefined();
    expect(screen.getByText('No standards')).toBeDefined();
  });
});
