import React from 'react';
import { render, screen } from '@testing-library/react';
import { KitOverviewMetadata } from '../../../components/kits/detail/KitOverviewMetadata';
import type { KitDetailData } from '../../../hooks/useKitDetail';

const mockKit: KitDetailData = {
  id: 'kit-1',
  name: 'Test Kit',
  description: 'Test kit description',
  createdAt: '2024-01-15T10:00:00Z',
  updatedAt: '2024-01-20T15:30:00Z',
  latestVersion: {
    id: 'version-1',
    version: '1.0',
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-01-20T15:30:00Z',
    attributes: {
      region: 'NA',
      dataType: 'BIM',
      program: 'Fulfillment Center',
      projectType: 'New Build',
      roomFeatureZone: 'Office',
      keyLabel: 'Standard Office',
      createdBy: 'testuser',
    },
    standards: [],
  },
};

describe('KitOverviewMetadata', () => {
  it('renders all metadata fields with values', () => {
    render(<KitOverviewMetadata kit={mockKit} />);

    expect(screen.getByText('Region')).toBeDefined();
    expect(screen.getByText('NA')).toBeDefined();

    expect(screen.getByText('Data type')).toBeDefined();
    expect(screen.getByText('BIM')).toBeDefined();

    expect(screen.getByText('Program')).toBeDefined();
    expect(screen.getByText('Fulfillment Center')).toBeDefined();

    expect(screen.getByText('Project type')).toBeDefined();
    expect(screen.getByText('New Build')).toBeDefined();

    expect(screen.getByText('Room/Feature/Zone')).toBeDefined();
    expect(screen.getByText('Office')).toBeDefined();

    expect(screen.getByText('Key label')).toBeDefined();
    expect(screen.getByText('Standard Office')).toBeDefined();

    expect(screen.getByText('Created by')).toBeDefined();
    expect(screen.getByText('Created on')).toBeDefined();
  });

  it('renders fallback "—" for missing attributes', () => {
    const kitWithMissingData: KitDetailData = {
      ...mockKit,
      latestVersion: {
        ...mockKit.latestVersion!,
        attributes: {},
      },
    };

    render(<KitOverviewMetadata kit={kitWithMissingData} />);

    const fallbacks = screen.getAllByText('—');
    expect(fallbacks.length).toBeGreaterThan(0);
  });

  it('renders PhoneToolLink for created by field', () => {
    render(<KitOverviewMetadata kit={mockKit} />);

    const phoneToolLink = screen.getByRole('link', { name: 'testuser' });
    expect(phoneToolLink).toBeDefined();
    expect(phoneToolLink.getAttribute('href')).toContain('phonetool.amazon.com');
  });

  it('formats created date correctly', () => {
    render(<KitOverviewMetadata kit={mockKit} />);

    expect(screen.getByText('Created on')).toBeDefined();
    // Date should be formatted - check that it's not the raw ISO string
    const dateElements = screen.queryByText('2024-01-15T10:00:00Z');
    expect(dateElements).toBeNull();
  });

  it('handles kit without latest version', () => {
    const kitWithoutVersion: KitDetailData = {
      ...mockKit,
      latestVersion: null,
    };

    render(<KitOverviewMetadata kit={kitWithoutVersion} />);

    // Should render with all fallback values
    const fallbacks = screen.getAllByText('—');
    expect(fallbacks.length).toBeGreaterThan(0);
  });
});
