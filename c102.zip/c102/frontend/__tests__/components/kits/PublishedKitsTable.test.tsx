import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';

const tableMock = jest.fn((props: any) => (
  <div data-testid="table-mock">
    {props.items?.map((item: any) => (
      <div key={item.id}>{props.columnDefinitions[0].cell(item)}</div>
    ))}
    {props.items?.length === 0 ? props.empty : null}
  </div>
));

jest.mock('@amzn/awsui-components-console', () => {
  const actual = jest.requireActual('@amzn/awsui-components-console');
  return {
    ...actual,
    Table: (props: any) => tableMock(props),
    Link: ({ children, onFollow, href }: any) => (
      <a href={href} onClick={(e) => onFollow?.(e)}>
        {children}
      </a>
    ),
  };
});

const navigateMock = jest.fn();
const locationMock = { search: '?q=1', pathname: '/kits' };

jest.mock('react-router-dom', () => {
  const actual = jest.requireActual('react-router-dom');
  return {
    ...actual,
    useNavigate: () => navigateMock,
    useLocation: () => locationMock,
  };
});

jest.mock('../../../utils/kitPresenters', () => ({
  formatKitAttribute: (kit: any, key: string) => kit.attributes?.[key],
}));

jest.mock('../../../utils/formatDate', () => ({
  formatDateShort: (value: string) => `formatted:${value}`,
}));

describe('PublishedKitsTable', () => {
  beforeEach(() => {
    navigateMock.mockClear();
    tableMock.mockClear();
  });

  it('renders kit name as link and navigates on follow', () => {
    const { PublishedKitsTable } = require('../../../components/kits/catalog/PublishedKitsTable');

    render(
      <PublishedKitsTable
        items={[
          {
            id: 'kit-1',
            name: 'Kit One',
            desc: 'desc',
            attributes: { region: 'NA', program: 'GEN5', useCase: 'UC' },
          },
        ]}
        loading={false}
        sortingField="name"
        sortingDescending={false}
        onSortingChange={jest.fn()}
      />
    );

    const link = screen.getByText('Kit One');
    expect(link).toHaveAttribute('href', '/kits/kit-1?q=1');

    fireEvent.click(link);
    expect(navigateMock).toHaveBeenCalledWith('/kits/kit-1?q=1');
  });

  it('renders attribute-driven columns and created on', () => {
    const { PublishedKitsTable } = require('../../../components/kits/catalog/PublishedKitsTable');
    const item = {
      id: 'kit-1',
      name: 'Kit One',
      desc: 'desc',
      createdAt: '2025-01-01T00:00:00.000Z',
      latestVersion: { createdAt: '2025-12-21T00:00:00.000Z' },
      attributes: {
        roomFeatureZone: 'Zone A',
        dataType: 'Metrics',
        keyLabel: 'Key A',
        createdBy: 'creator',
      },
    };

    render(
      <PublishedKitsTable
        items={[item]}
        loading={false}
        sortingField="name"
        sortingDescending={false}
        onSortingChange={jest.fn()}
      />
    );

    const columnDefinitions = tableMock.mock.calls[0][0].columnDefinitions;
    const roomFeatureColumn = columnDefinitions.find(
      (column: any) => column.id === 'roomFeatureZone'
    );
    const dataTypeColumn = columnDefinitions.find((column: any) => column.id === 'dataType');
    const keyLabelColumn = columnDefinitions.find((column: any) => column.id === 'keyLabel');
    const createdByColumn = columnDefinitions.find((column: any) => column.id === 'createdBy');
    const createdOnColumn = columnDefinitions.find((column: any) => column.id === 'createdOn');

    expect(roomFeatureColumn?.cell(item)).toBe('Zone A');
    expect(dataTypeColumn?.cell(item)).toBe('Metrics');
    expect(keyLabelColumn?.cell(item)).toBe('Key A');
    expect(createdByColumn?.cell(item)).toBe('creator');
    expect(createdOnColumn?.cell(item)).toBe('formatted:2025-12-21T00:00:00.000Z');
  });

  it('passes sorting props through to Table', () => {
    const { PublishedKitsTable } = require('../../../components/kits/catalog/PublishedKitsTable');
    const onSortingChange = jest.fn();

    render(
      <PublishedKitsTable
        items={[]}
        loading={true}
        sortingField="name"
        sortingDescending={true}
        onSortingChange={onSortingChange}
      />
    );

    expect(tableMock).toHaveBeenCalledWith(
      expect.objectContaining({
        loading: true,
        sortingColumn: { sortingField: 'name' },
        sortingDescending: true,
        onSortingChange,
        trackBy: 'id',
      })
    );
  });

  it('shows empty state when items are empty', () => {
    const { PublishedKitsTable } = require('../../../components/kits/catalog/PublishedKitsTable');

    render(
      <PublishedKitsTable
        items={[]}
        loading={false}
        sortingField="name"
        sortingDescending={false}
        onSortingChange={jest.fn()}
      />
    );

    expect(screen.getByText('No kits')).toBeInTheDocument();
  });
});
