import React from 'react';
import { render } from '@testing-library/react';

const filterSearchBarMock = jest.fn((_props: any) => <div data-testid="filter-search-bar" />);

jest.mock('../../../components/shared/FilterSearchBar', () => ({
  FilterSearchBar: (props: any) => filterSearchBarMock(props),
}));

describe('PublishedKitsToolbar', () => {
  beforeEach(() => {
    filterSearchBarMock.mockClear();
  });

  it('passes filtering properties and handlers to FilterSearchBar', () => {
    const {
      PublishedKitsToolbar,
    } = require('../../../components/kits/catalog/PublishedKitsToolbar');
    const onPropertyFilterChange = jest.fn();
    const query = { operation: 'and', tokens: [], tokenGroups: [] };

    render(
      <PublishedKitsToolbar
        propertyFilterQuery={query}
        onPropertyFilterChange={onPropertyFilterChange}
        filteringOptions={[{ propertyKey: 'name', value: 'Kit One' }]}
      />
    );

    expect(filterSearchBarMock).toHaveBeenCalledWith(
      expect.objectContaining({
        placeholder: 'Find resources',
        ariaLabel: 'Filter published kits',
        filteringProperties: expect.arrayContaining([expect.objectContaining({ key: 'name' })]),
        filteringOptions: expect.arrayContaining([
          expect.objectContaining({ propertyKey: 'name', value: 'Kit One' }),
        ]),
      })
    );

    const passedProps = filterSearchBarMock.mock.calls[0][0];
    passedProps.onPropertyFilterTokensChange({
      operation: 'and',
      tokens: [{ propertyKey: 'name', value: 'Kit One' }],
    });
    expect(onPropertyFilterChange).toHaveBeenCalled();
  });
});
