import { PublishedKitsTable, PublishedKitsToolbar } from '../../../components/kits/catalog';

describe('kits catalog index exports', () => {
  it('re-exports PublishedKitsTable and PublishedKitsToolbar', () => {
    expect(PublishedKitsTable).toBeDefined();
    expect(PublishedKitsToolbar).toBeDefined();
  });
});
