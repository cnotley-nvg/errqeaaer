import React from 'react';
import { render, screen } from '@testing-library/react';

import { CatalogFilters } from '../../../../components/standards/catalog/CatalogFilters';

describe('CatalogFilters', () => {
  it('renders property filter with provided count text', () => {
    render(
      <CatalogFilters
        query={{ tokens: [], operation: 'and' }}
        onQueryChange={() => undefined}
        totalCount={3}
        filteringOptions={[]}
      />
    );

    expect(screen.getByPlaceholderText('Find resources')).toBeInTheDocument();
  });
});
