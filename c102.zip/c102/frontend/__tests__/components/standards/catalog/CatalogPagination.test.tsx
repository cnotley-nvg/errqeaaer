import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';

import { CatalogPagination } from '../../../../components/shared/CatalogPagination';

describe('CatalogPagination', () => {
  it('renders pagination when multiple pages exist', () => {
    const handlePageChange = jest.fn();
    render(
      <CatalogPagination currentPageIndex={1} pagesCount={3} onPageChange={handlePageChange} />
    );

    fireEvent.click(screen.getByRole('button', { name: 'Next page' }));

    expect(handlePageChange).toHaveBeenCalledWith(2);
  });

  it('does not render when single page', () => {
    const { container } = render(
      <CatalogPagination currentPageIndex={1} pagesCount={1} onPageChange={() => undefined} />
    );

    expect(container).toBeEmptyDOMElement();
  });
});
