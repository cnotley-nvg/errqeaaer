import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';

import { CatalogViewToggle } from '../../../../components/standards/catalog/CatalogViewToggle';

describe('CatalogViewToggle', () => {
  it('invokes callback when view type changes', () => {
    const handleChange = jest.fn();

    render(<CatalogViewToggle viewType="card" onViewTypeChange={handleChange} />);

    fireEvent.click(screen.getByRole('button', { name: 'Table view' }));

    expect(handleChange).toHaveBeenCalledWith('table');
  });
});
