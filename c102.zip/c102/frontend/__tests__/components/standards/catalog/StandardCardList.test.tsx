import React from 'react';
import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';

import { StandardCardList } from '../../../../components/standards/catalog/StandardCardList';
import type { StandardVersionWithStandard } from '../../../../hooks/useLatestStandardVersionsSearch';

const mockStandardWithApproval: StandardVersionWithStandard = {
  id: 'version-1',
  standardId: 'standard-1',
  version: '1.0',
  isLatest: true,
  accFolderId: 'folder-123',
  attributes: {
    region: 'EU',
    projectType: 'BTS',
    program: ['AMXL'],
    approvalLink: 'https://approvals.amazon.com/approval/12345',
  },
  accCreatedAt: '2024-01-01T00:00:00Z',
  accCreatedBy: 'testuser',
  accUpdatedAt: '2024-01-15T00:00:00Z',
  accUpdatedBy: 'testuser',
  publishedOn: '2024-01-15T00:00:00Z',
  firstPublishedOn: '2024-01-01T00:00:00Z',
  createdAt: '2024-01-01T00:00:00Z',
  updatedAt: '2024-01-15T00:00:00Z',
  standard: {
    id: 'standard-1',
    name: 'Test Standard',
    description: 'Test Description',
    accProjectId: 'project-123',
  },
};

const mockStandardWithoutApproval: StandardVersionWithStandard = {
  ...mockStandardWithApproval,
  id: 'version-2',
  attributes: {
    region: 'EU',
    projectType: 'BTS',
    program: ['AMXL'],
    // No approvalLink
  },
};

const mockPreferences = {
  contentDisplay: [
    { id: 'region', visible: true },
    { id: 'projectType', visible: true },
    { id: 'approvalInformation', visible: true },
  ],
};

describe('StandardCardList - Approval Link Rendering', () => {
  it('should render approval link when approvalLink attribute exists', () => {
    render(
      <BrowserRouter>
        <StandardCardList
          items={[mockStandardWithApproval]}
          loading={false}
          empty={<div>No items</div>}
          preferences={mockPreferences}
        />
      </BrowserRouter>
    );

    // Check that approval link is rendered
    const approvalLink = screen.getByText('View approval');
    expect(approvalLink).toBeInTheDocument();
    expect(approvalLink.closest('a')).toHaveAttribute(
      'href',
      'https://approvals.amazon.com/approval/12345'
    );
  });

  it('should render dash when approvalLink attribute is missing', () => {
    const { container } = render(
      <BrowserRouter>
        <StandardCardList
          items={[mockStandardWithoutApproval]}
          loading={false}
          empty={<div>No items</div>}
          preferences={mockPreferences}
        />
      </BrowserRouter>
    );

    // Debug: log what's actually rendered
    console.log('Rendered HTML:', container.innerHTML);

    // Should render "–" when no approval link
    expect(screen.getByText('Approval information')).toBeInTheDocument();
    expect(screen.getByText('–')).toBeInTheDocument();
  });

  it('should not render approval section when not in visible fields', () => {
    const preferencesWithoutApproval = {
      contentDisplay: [
        { id: 'region', visible: true },
        { id: 'projectType', visible: true },
      ],
    };

    render(
      <BrowserRouter>
        <StandardCardList
          items={[mockStandardWithApproval]}
          loading={false}
          empty={<div>No items</div>}
          preferences={preferencesWithoutApproval}
        />
      </BrowserRouter>
    );

    // Approval information should not be rendered
    expect(screen.queryByText('Approval information')).not.toBeInTheDocument();
  });
});
