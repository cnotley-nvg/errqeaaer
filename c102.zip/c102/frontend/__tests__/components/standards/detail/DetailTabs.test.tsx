import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';

import { DetailTabs } from '../../../../components/standards/detail/DetailTabs';

const tabs = [
  { id: 'overview', label: 'Overview', content: <div>Overview content</div> },
  { id: 'versions', label: 'Versions', content: <div>Versions content</div> },
];

describe('DetailTabs', () => {
  it('notifies consumers when tab changes', () => {
    const handleTabChange = jest.fn();

    render(
      <DetailTabs
        ariaLabel="Standard detail"
        activeTabId="overview"
        tabs={tabs}
        onTabChange={handleTabChange}
      />
    );

    fireEvent.click(screen.getByRole('tab', { name: 'Versions' }));

    expect(handleTabChange).toHaveBeenCalledWith('versions');
  });
});
