import React from 'react';
import { render, screen } from '@testing-library/react';

import { DocumentPreview } from '../../../../components/standards/detail/DocumentPreview';

const baseState = {
  viewerUrl: null,
  downloadUrl: null,
  loading: false,
  error: null,
};

describe('DocumentPreview', () => {
  it('renders loading indicator when fetching', () => {
    render(
      <DocumentPreview standardName="Standard A" documentState={{ ...baseState, loading: true }} />
    );

    expect(screen.getByText('Generating document preview')).toBeInTheDocument();
  });

  it('renders iframe when viewer url present', () => {
    render(
      <DocumentPreview
        standardName="Standard A"
        documentState={{ ...baseState, viewerUrl: 'https://example.com/doc.pdf' }}
      />
    );

    expect(screen.getByTitle('Standard A PDF')).toBeInTheDocument();
  });

  it('renders unavailable state when no data', () => {
    render(<DocumentPreview standardName="Standard A" documentState={baseState} />);

    expect(screen.getByText('PDF preview unavailable')).toBeInTheDocument();
  });
});
