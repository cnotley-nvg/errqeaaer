import React from 'react';
import { render, screen } from '@testing-library/react';

import { PlaceholderSection } from '../../../../components/standards/detail/PlaceholderSection';

describe('PlaceholderSection', () => {
  it('renders title and default message', () => {
    render(<PlaceholderSection title="Key items" />);

    expect(screen.getByText('Key items')).toBeInTheDocument();
    expect(screen.getByText('TBD')).toBeInTheDocument();
  });

  it('renders custom message when provided', () => {
    render(<PlaceholderSection title="Key items" message="Coming soon" />);

    expect(screen.getByText('Coming soon')).toBeInTheDocument();
  });
});
