import React from 'react';
import { render, screen } from '@testing-library/react';

import { StandardOverview } from '../../../../components/standards/detail/StandardOverview';
import type { StandardDetailData } from '../../../../hooks/useStandardDetail';

const mockStandard: StandardDetailData = {
  id: 'std-1',
  name: 'Standard X',
  description: 'Test standard',
  accProjectId: 'b.test-project-id',
  createdAt: new Date('2024-01-01'),
  updatedAt: new Date('2024-01-15'),
  latestVersion: {
    id: 'ver-1',
    version: 'V1.0',
    isLatest: true,
    accFolderId: 'urn:adsk.wipprod:fs.folder:co.test',
    accFileId: null,
    accCreatedAt: new Date('2024-01-01'),
    accCreatedBy: 'testuser',
    accUpdatedAt: new Date('2024-01-15'),
    accUpdatedBy: 'testuser2',
    publishedOn: null,
    firstPublishedOn: null,
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-15'),
    attributes: {
      region: 'NA',
    },
    kits: [],
  },
  versions: [],
};

const mockDocumentState = {
  viewerUrl: null,
  downloadUrl: null,
  loading: false,
  error: null,
};

describe('StandardOverview', () => {
  it('renders metadata and document preview', () => {
    render(
      <StandardOverview
        standard={mockStandard}
        standardName="Standard X"
        documentState={mockDocumentState}
      />
    );

    expect(screen.getByText('Region')).toBeInTheDocument();
    expect(screen.getByText('PDF preview unavailable')).toBeInTheDocument();
  });
});
