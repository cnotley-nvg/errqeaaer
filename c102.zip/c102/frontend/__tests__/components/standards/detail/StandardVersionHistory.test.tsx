import React from 'react';
import { render, screen } from '@testing-library/react';

import { StandardVersionHistory } from '../../../../components/standards/detail/StandardVersionHistory';

jest.mock('../../../../components/standards/hooks/useStandardVersionChanges', () => ({
  useStandardVersionChangesMap: () => ({
    changesByVersionId: {
      v3: [
        {
          id: 'c1',
          standardVersionId: 'v3',
          details: 'Added provisions for autonomous yard tractor lanes.',
          releasedBy: 'A Johnson',
          approveUrl: 'https://example.com/approval',
        },
      ],
    },
    loading: false,
    error: null,
  }),
}));

const baseVersion = {
  id: 'v1',
  version: '1.0',
  isLatest: false,
  accFolderId: 'folder-1',
  accFileId: 'file-1',
  createdAt: new Date('2025-04-03T00:00:00.000Z'),
  updatedAt: new Date('2025-04-03T00:00:00.000Z'),
  attributes: {},
  kits: [],
};

describe('StandardVersionHistory', () => {
  it('renders expandable sections with version header and details', () => {
    const versions = [
      {
        ...baseVersion,
        id: 'v3',
        version: '3.0',
        attributes: {},
      },
    ];

    render(<StandardVersionHistory versions={versions} />);

    // Header text now combines version and date with pipe separator
    const expectedDateLabel = new Date(versions[0].createdAt).toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      timeZone: 'UTC',
    });
    expect(
      screen.getByText((content) => content.includes('V3.0') && content.includes(expectedDateLabel))
    ).toBeInTheDocument();

    expect(
      screen.getByText(/Added provisions for autonomous yard tractor lanes/)
    ).toBeInTheDocument();

    expect(screen.getByText('A Johnson')).toBeInTheDocument();

    const approvalLinks = screen.getAllByRole('link', { name: /Approval link/i });
    expect(approvalLinks.length).toBeGreaterThan(0);
  });
});
