import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import { BimLink } from '../../../../components/standards/common/BimLink';

describe('BimLink', () => {
  const validProjectId = '8e8a9dbb-8c39-4c76-9b81-0d8567ccd32d';
  const validFolderId = 'urn:adsk.wipprod:fs.folder:co.B3Q_kRZnR82EZyKOfkFu5A';

  it('renders a link when valid IDs are provided', () => {
    render(<BimLink accProjectId={validProjectId} accFolderId={validFolderId} />);

    const link = screen.getByRole('link', { name: /view bim/i });
    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute('href');
    expect(link.getAttribute('href')).toContain('docs.b360.autodesk.com');
  });

  it('renders "–" when accProjectId is missing', () => {
    const { container } = render(<BimLink accProjectId={null} accFolderId={validFolderId} />);

    expect(screen.queryByRole('link')).not.toBeInTheDocument();
    expect(container.textContent).toBe('–');
  });

  it('renders "–" when accFolderId is missing', () => {
    const { container } = render(<BimLink accProjectId={validProjectId} accFolderId={null} />);

    expect(screen.queryByRole('link')).not.toBeInTheDocument();
    expect(container.textContent).toBe('–');
  });

  it('renders "–" when both IDs are missing', () => {
    const { container } = render(<BimLink accProjectId={null} accFolderId={null} />);

    expect(screen.queryByRole('link')).not.toBeInTheDocument();
    expect(container.textContent).toBe('–');
  });

  it('renders "–" when accProjectId is invalid', () => {
    const { container } = render(<BimLink accProjectId="invalid-id" accFolderId={validFolderId} />);

    expect(screen.queryByRole('link')).not.toBeInTheDocument();
    expect(container.textContent).toBe('–');
  });

  it('renders "–" when accFolderId is invalid', () => {
    const { container } = render(<BimLink accProjectId={validProjectId} accFolderId="invalid" />);

    expect(screen.queryByRole('link')).not.toBeInTheDocument();
    expect(container.textContent).toBe('–');
  });

  it('renders custom label when provided', () => {
    render(
      <BimLink accProjectId={validProjectId} accFolderId={validFolderId} label="Open in ACC" />
    );

    const link = screen.getByRole('link', { name: /open in acc/i });
    expect(link).toBeInTheDocument();
  });

  it('renders link with external attribute', () => {
    render(<BimLink accProjectId={validProjectId} accFolderId={validFolderId} />);

    const link = screen.getByRole('link', { name: /view bim/i });
    expect(link).toHaveAttribute('target', '_blank');
    expect(link).toHaveAttribute('rel', 'noopener noreferrer');
  });
});
