import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import { ApprovalLink } from '../../../../components/standards/common/ApprovalLink';

describe('ApprovalLink', () => {
  it('renders a link when valid URL is provided', () => {
    const url = 'https://docs.example.com/approval/123';
    render(<ApprovalLink approvalUrl={url} />);

    const link = screen.getByRole('link', { name: 'View approval' });
    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute('href', url);
  });

  it('renders a link with custom label', () => {
    const url = 'https://docs.example.com/approval/123';
    render(<ApprovalLink approvalUrl={url} label="View documentation" />);

    const link = screen.getByRole('link', { name: 'View documentation' });
    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute('href', url);
  });

  it('renders "–" when URL is null', () => {
    render(<ApprovalLink approvalUrl={null} />);
    expect(screen.getByText('–')).toBeInTheDocument();
    expect(screen.queryByRole('link')).not.toBeInTheDocument();
  });

  it('renders "–" when URL is undefined', () => {
    render(<ApprovalLink approvalUrl={undefined} />);
    expect(screen.getByText('–')).toBeInTheDocument();
    expect(screen.queryByRole('link')).not.toBeInTheDocument();
  });

  it('renders "–" when URL is empty string', () => {
    render(<ApprovalLink approvalUrl="" />);
    expect(screen.getByText('–')).toBeInTheDocument();
    expect(screen.queryByRole('link')).not.toBeInTheDocument();
  });

  it('renders "–" when URL does not start with http:// or https://', () => {
    render(<ApprovalLink approvalUrl="ftp://example.com/file" />);
    expect(screen.getByText('–')).toBeInTheDocument();
    expect(screen.queryByRole('link')).not.toBeInTheDocument();
  });

  it('renders link for http:// URL', () => {
    const url = 'http://example.com/approval';
    render(<ApprovalLink approvalUrl={url} />);

    const link = screen.getByRole('link', { name: 'View approval' });
    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute('href', url);
  });

  it('renders link for https:// URL', () => {
    const url = 'https://example.com/approval';
    render(<ApprovalLink approvalUrl={url} />);

    const link = screen.getByRole('link', { name: 'View approval' });
    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute('href', url);
  });
});
