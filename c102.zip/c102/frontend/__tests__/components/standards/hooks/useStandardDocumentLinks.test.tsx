import React from 'react';
import { renderHook } from '@testing-library/react';

import { useStandardDocumentLinks } from '../../../../components/standards/hooks/useStandardDocumentLinks';

jest.mock('../../../../api/graphqlClient', () => ({
  graphqlClient: {
    request: jest.fn(),
  },
}));

describe('useStandardDocumentLinks', () => {
  it('returns initial state when no version id provided', () => {
    const { result } = renderHook(() => useStandardDocumentLinks(null));

    expect(result.current).toEqual({
      viewerUrl: null,
      downloadUrl: null,
      loading: false,
      error: null,
    });
  });
});
