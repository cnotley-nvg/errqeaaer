import { beforeEach, describe, expect, it, jest } from '@jest/globals';
import { renderHook, waitFor } from '@testing-library/react';

import { useStandardVersionKeyItemsConnection } from '../../../../components/standards/hooks/useStandardVersionKeyItemsConnection';
import type { StandardVersionKeyItem } from '../../../../components/standards/hooks/useStandardVersionKeyItems';

type RequestArgs = [unknown, Record<string, unknown>?];
type RequestMock = (...args: RequestArgs) => Promise<{
  standardVersionKeyItemsConnection: {
    items: StandardVersionKeyItem[];
    total: number;
    pageIdx: number;
    limit: number;
    hasNext: boolean;
  };
}>;

jest.mock('../../../../api/graphqlClient', () => ({
  graphqlClient: {
    request: jest.fn<RequestMock>(),
  },
}));

const { graphqlClient } = require('../../../../api/graphqlClient') as {
  graphqlClient: {
    request: jest.MockedFunction<RequestMock>;
  };
};

const requestMock = graphqlClient.request;

// Stable options reference (critical for avoiding render->effect->state loops in hooks
// that depend on options.sort identity)
const stableOptions = {
  pageIdx: 0,
  pageSize: 5,
  sort: [{ field: 'category' as const, desc: false }],
  categoryFilter: '',
};

describe('useStandardVersionKeyItemsConnection', () => {
  beforeEach(() => {
    requestMock.mockReset();
  });

  it('returns empty state when no standardVersionId is provided', async () => {
    const options = stableOptions;

    const { result } = renderHook(() => useStandardVersionKeyItemsConnection(null, options));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.items).toEqual([]);
    expect(result.current.total).toBe(0);
    expect(result.current.pageIdx).toBe(0);
    expect(result.current.pageSize).toBe(5);
    expect(result.current.hasNext).toBe(false);
    expect(requestMock).not.toHaveBeenCalled();
  });

  it('fetches key items with pagination and sorting', async () => {
    requestMock.mockResolvedValue({
      standardVersionKeyItemsConnection: {
        items: [
          {
            id: 'item-1',
            standardVersionId: 'ver-1',
            category: 'Cat A',
            sheet: 'S1',
            cell: 'http://example.com/a.pdf',
          },
        ],
        total: 3,
        pageIdx: 1,
        limit: 5,
        hasNext: true,
      },
    });

    const options = stableOptions;

    const { result } = renderHook(() => useStandardVersionKeyItemsConnection('ver-1', options));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(requestMock).toHaveBeenCalledTimes(1);
    expect(requestMock).toHaveBeenCalledWith(expect.anything(), {
      standardVersionId: 'ver-1',
      pageIdx: 0,
      limit: 5,
      sort: [{ field: 'category', desc: false }],
      categoryContains: null,
    });

    expect(result.current.items).toHaveLength(1);
    expect(result.current.items[0]?.category).toBe('Cat A');
    expect(result.current.total).toBe(3);
    expect(result.current.pageIdx).toBe(1);
    expect(result.current.pageSize).toBe(5);
    expect(result.current.hasNext).toBe(true);
  });

  it('passes category filter to the query', async () => {
    requestMock.mockResolvedValue({
      standardVersionKeyItemsConnection: {
        items: [],
        total: 0,
        pageIdx: 0,
        limit: 5,
        hasNext: false,
      },
    });

    const options = {
      ...stableOptions,
      categoryFilter: ' Access ',
    };

    const { result } = renderHook(() => useStandardVersionKeyItemsConnection('ver-1', options));

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(requestMock).toHaveBeenCalledWith(expect.anything(), {
      standardVersionId: 'ver-1',
      pageIdx: 0,
      limit: 5,
      sort: [{ field: 'category', desc: false }],
      categoryContains: 'Access',
    });
  });
});
