import React, { useEffect } from 'react';
import { act, render } from '@testing-library/react';

import { useStandardSorting } from '../../../../components/standards/hooks/useStandardSorting';

const sortingEvent = {
  detail: {
    sortingColumn: { sortingField: 'name' },
    isDescending: true,
  },
} as const;

describe('useStandardSorting', () => {
  it('bubbles sorting details to consumer', () => {
    const handleSort = jest.fn();
    let trigger: ((event: typeof sortingEvent) => void) | undefined;

    const TestComponent: React.FC = () => {
      const { handleSortingChange } = useStandardSorting({ onSortChange: handleSort });

      useEffect(() => {
        trigger = handleSortingChange;
      }, [handleSortingChange]);

      return null;
    };

    render(<TestComponent />);

    act(() => {
      trigger?.(sortingEvent);
    });

    expect(handleSort).toHaveBeenCalledWith('name', true);
  });
});
