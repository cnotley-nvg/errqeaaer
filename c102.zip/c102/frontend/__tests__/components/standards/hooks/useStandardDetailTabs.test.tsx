import { renderHook, act } from '@testing-library/react';

import { useStandardDetailTabs } from '../../../../components/standards/hooks/useStandardDetailTabs';

describe('useStandardDetailTabs', () => {
  beforeEach(() => {
    window.sessionStorage.clear();
  });

  it('defaults to provided tab when nothing stored', () => {
    const { result } = renderHook(() => useStandardDetailTabs({ defaultTab: 'overview' }));

    expect(result.current.activeTabId).toBe('overview');
  });

  it('persists selected tab to session storage', () => {
    const { result } = renderHook(() => useStandardDetailTabs({ defaultTab: 'overview' }));

    act(() => {
      result.current.handleTabChange('versions');
    });

    expect(window.sessionStorage.getItem('standard-detail-active-tab')).toBe('versions');
  });
});
