import {
  getLocalStorageItem,
  setLocalStorageItem,
  removeLocalStorageItem,
  getPageSizeFallback,
  savePageSizeFallback,
  getViewTypePreference,
  saveViewTypePreference,
} from '../../../../../components/shared/catalog/utils/localStorageHelpers';

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {};
  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value;
    },
    removeItem: (key: string) => {
      delete store[key];
    },
    clear: () => {
      store = {};
    },
  };
})();

Object.defineProperty(window, 'localStorage', { value: localStorageMock });

// Mock console.warn to avoid noise in tests
const originalWarn = console.warn;
beforeAll(() => {
  console.warn = jest.fn();
});
afterAll(() => {
  console.warn = originalWarn;
});

describe('localStorageHelpers', () => {
  beforeEach(() => {
    localStorageMock.clear();
    jest.clearAllMocks();
  });

  describe('getLocalStorageItem', () => {
    it('should retrieve and parse stored values', () => {
      localStorage.setItem('test-key', '42');
      const result = getLocalStorageItem('test-key', (s) => parseInt(s, 10), 0);
      expect(result).toBe(42);
    });

    it('should return fallback when key does not exist', () => {
      const result = getLocalStorageItem('missing-key', (s) => s, 'default');
      expect(result).toBe('default');
    });

    it('should return fallback on parse error', () => {
      localStorage.setItem('test-key', 'invalid');
      const result = getLocalStorageItem(
        'test-key',
        (s) => {
          throw new Error('Parse error');
        },
        'fallback'
      );
      expect(result).toBe('fallback');
      expect(console.warn).toHaveBeenCalled();
    });
  });

  describe('setLocalStorageItem', () => {
    it('should store serialized values', () => {
      const success = setLocalStorageItem('test-key', 123, String);
      expect(success).toBe(true);
      expect(localStorage.getItem('test-key')).toBe('123');
    });

    it('should use default serializer', () => {
      const success = setLocalStorageItem('test-key', 'value');
      expect(success).toBe(true);
      expect(localStorage.getItem('test-key')).toBe('value');
    });

    it('should handle serialization errors', () => {
      const success = setLocalStorageItem('test-key', { circular: null as any }, () => {
        throw new Error('Serialization error');
      });
      expect(success).toBe(false);
      expect(console.warn).toHaveBeenCalled();
    });
  });

  describe('removeLocalStorageItem', () => {
    it('should remove items', () => {
      localStorage.setItem('test-key', 'value');
      removeLocalStorageItem('test-key');
      expect(localStorage.getItem('test-key')).toBeNull();
    });

    it('should handle removal errors gracefully', () => {
      // Can't easily trigger an error with the mock, but verify it doesn't throw
      expect(() => removeLocalStorageItem('any-key')).not.toThrow();
    });
  });

  describe('getPageSizeFallback', () => {
    it('should retrieve stored page size', () => {
      localStorage.setItem('pagesize-key', '30');
      const result = getPageSizeFallback('pagesize-key', 20);
      expect(result).toBe(30);
    });

    it('should return default for missing key', () => {
      const result = getPageSizeFallback('missing-key', 20);
      expect(result).toBe(20);
    });

    it('should return default for invalid value', () => {
      localStorage.setItem('pagesize-key', 'invalid');
      const result = getPageSizeFallback('pagesize-key', 20);
      expect(result).toBe(20);
    });

    it('should return default for negative values', () => {
      localStorage.setItem('pagesize-key', '-10');
      const result = getPageSizeFallback('pagesize-key', 20);
      expect(result).toBe(20);
    });
  });

  describe('savePageSizeFallback', () => {
    it('should save page size', () => {
      savePageSizeFallback('pagesize-key', 40);
      expect(localStorage.getItem('pagesize-key')).toBe('40');
    });
  });

  describe('getViewTypePreference', () => {
    it('should retrieve card view type', () => {
      localStorage.setItem('view-key', JSON.stringify({ viewType: 'card' }));
      const result = getViewTypePreference('view-key', 'table');
      expect(result).toBe('card');
    });

    it('should retrieve table view type', () => {
      localStorage.setItem('view-key', JSON.stringify({ viewType: 'table' }));
      const result = getViewTypePreference('view-key', 'card');
      expect(result).toBe('table');
    });

    it('should return default for missing key', () => {
      const result = getViewTypePreference('missing-key', 'card');
      expect(result).toBe('card');
    });

    it('should return default for invalid JSON', () => {
      localStorage.setItem('view-key', 'invalid json');
      const result = getViewTypePreference('view-key', 'table');
      expect(result).toBe('table');
    });

    it('should return default for invalid view type', () => {
      localStorage.setItem('view-key', JSON.stringify({ viewType: 'invalid' }));
      const result = getViewTypePreference('view-key', 'card');
      expect(result).toBe('card');
    });
  });

  describe('saveViewTypePreference', () => {
    it('should save card view preference', () => {
      saveViewTypePreference('view-key', 'card');
      const stored = JSON.parse(localStorage.getItem('view-key')!);
      expect(stored).toEqual({ viewType: 'card' });
    });

    it('should save table view preference', () => {
      saveViewTypePreference('view-key', 'table');
      const stored = JSON.parse(localStorage.getItem('view-key')!);
      expect(stored).toEqual({ viewType: 'table' });
    });
  });
});
