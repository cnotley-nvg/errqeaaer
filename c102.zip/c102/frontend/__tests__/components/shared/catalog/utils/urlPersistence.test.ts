import {
  serializeError,
  coerceViewType,
  coercePageIndex,
  coercePageSize,
  normalizeBoolean,
  clonePropertyFilterQuery,
  coercePropertyFilterQuery,
  hasFilterTokens,
  parseFilterFromParams,
  encodeFilterQuery,
  applySnapshotToSearchParams,
  DEFAULT_QUERY_KEYS,
  VALID_PAGE_SIZES,
} from '../../../../../components/shared/catalog/utils/urlPersistence';
import type { PropertyFilterQuery } from '@amzn/awsui-collection-hooks';
import type { CatalogStateSnapshot } from '../../../../../components/shared/catalog/utils/urlPersistence';

// Mock logger
jest.mock('../../../../../utils/logger', () => ({
  getScopedLogger: () => ({
    warn: jest.fn(),
    error: jest.fn(),
  }),
}));

describe('urlPersistence utilities', () => {
  describe('serializeError', () => {
    it('should serialize Error instances', () => {
      const error = new Error('Test error');
      error.name = 'TestError';
      const result = serializeError(error);
      expect(result).toEqual({ message: 'Test error', name: 'TestError' });
    });

    it('should serialize unknown errors', () => {
      const result = serializeError('string error');
      expect(result).toEqual({ message: 'Unknown error', value: 'string error' });
    });
  });

  describe('coerceViewType', () => {
    it('should return valid view types', () => {
      expect(coerceViewType('card', 'table')).toBe('card');
      expect(coerceViewType('table', 'card')).toBe('table');
    });

    it('should return fallback for invalid values', () => {
      expect(coerceViewType('invalid', 'card')).toBe('card');
      expect(coerceViewType(null, 'table')).toBe('table');
      expect(coerceViewType(undefined, 'card')).toBe('card');
    });
  });

  describe('coercePageIndex', () => {
    it('should return valid page indices', () => {
      expect(coercePageIndex(1, 1)).toBe(1);
      expect(coercePageIndex(5, 1)).toBe(5);
      expect(coercePageIndex('10', 1)).toBe(10);
    });

    it('should floor decimal values', () => {
      expect(coercePageIndex(5.7, 1)).toBe(5);
    });

    it('should return fallback for invalid values', () => {
      expect(coercePageIndex(0, 1)).toBe(1);
      expect(coercePageIndex(-5, 1)).toBe(1);
      expect(coercePageIndex('invalid', 1)).toBe(1);
      expect(coercePageIndex(NaN, 1)).toBe(1);
    });
  });

  describe('coercePageSize', () => {
    it('should return valid page sizes', () => {
      expect(coercePageSize(10, 20)).toBe(10);
      expect(coercePageSize(20, 10)).toBe(20);
      expect(coercePageSize('30', 20)).toBe(30);
      expect(coercePageSize('40', 20)).toBe(40);
    });

    it('should return fallback for invalid page sizes', () => {
      expect(coercePageSize(15, 20)).toBe(20);
      expect(coercePageSize('50', 20)).toBe(20);
      expect(coercePageSize('invalid', 20)).toBe(20);
    });

    it('should use custom valid page sizes', () => {
      expect(coercePageSize(50, 20, [10, 50, 100])).toBe(50);
      expect(coercePageSize(20, 20, [10, 50, 100])).toBe(20);
    });
  });

  describe('normalizeBoolean', () => {
    it('should parse truthy strings', () => {
      expect(normalizeBoolean('1', false)).toBe(true);
      expect(normalizeBoolean('true', false)).toBe(true);
      expect(normalizeBoolean('TRUE', false)).toBe(true);
    });

    it('should parse falsy strings', () => {
      expect(normalizeBoolean('0', true)).toBe(false);
      expect(normalizeBoolean('false', true)).toBe(false);
      expect(normalizeBoolean('FALSE', true)).toBe(false);
    });

    it('should return fallback for null', () => {
      expect(normalizeBoolean(null, true)).toBe(true);
      expect(normalizeBoolean(null, false)).toBe(false);
    });

    it('should return fallback for invalid strings', () => {
      expect(normalizeBoolean('invalid', true)).toBe(true);
      expect(normalizeBoolean('yes', false)).toBe(false);
    });
  });

  describe('clonePropertyFilterQuery', () => {
    it('should deep clone query', () => {
      const query: PropertyFilterQuery = {
        operation: 'and',
        tokens: [{ propertyKey: 'name', operator: '=', value: 'test' }],
        tokenGroups: [],
      };
      const cloned = clonePropertyFilterQuery(query);

      expect(cloned).toEqual(query);
      expect(cloned).not.toBe(query);
      expect(cloned.tokens).not.toBe(query.tokens);
    });

    it('should normalize operation to and/or', () => {
      const query: PropertyFilterQuery = {
        operation: 'or',
        tokens: [],
        tokenGroups: [],
      };
      const cloned = clonePropertyFilterQuery(query);
      expect(cloned.operation).toBe('or');
    });
  });

  describe('coercePropertyFilterQuery', () => {
    it('should return valid query', () => {
      const query: PropertyFilterQuery = {
        operation: 'and',
        tokens: [{ propertyKey: 'name', operator: '=', value: 'test' }],
        tokenGroups: [],
      };
      const coerced = coercePropertyFilterQuery(query, {
        operation: 'and',
        tokens: [],
        tokenGroups: [],
      });
      expect(coerced.tokens).toHaveLength(1);
    });

    it('should return fallback for invalid values', () => {
      const fallback: PropertyFilterQuery = { operation: 'and', tokens: [], tokenGroups: [] };
      expect(coercePropertyFilterQuery(null, fallback)).toEqual(fallback);
      expect(coercePropertyFilterQuery('invalid', fallback)).toEqual(fallback);
    });

    it('should handle missing tokens/tokenGroups', () => {
      const result = coercePropertyFilterQuery(
        { operation: 'and' },
        { operation: 'and', tokens: [], tokenGroups: [] }
      );
      expect(result.tokens).toEqual([]);
      expect(result.tokenGroups).toEqual([]);
    });
  });

  describe('hasFilterTokens', () => {
    it('should return true for queries with tokens', () => {
      expect(
        hasFilterTokens({
          operation: 'and',
          tokens: [{ propertyKey: 'name', operator: '=', value: 'test' }],
        })
      ).toBe(true);
    });

    it('should return true for queries with tokenGroups', () => {
      expect(
        hasFilterTokens({
          operation: 'and',
          tokens: [],
          tokenGroups: [{ propertyKey: 'region', operator: '=', value: 'US' }],
        })
      ).toBe(true);
    });

    it('should return false for empty queries', () => {
      expect(hasFilterTokens({ operation: 'and', tokens: [], tokenGroups: [] })).toBe(false);
      expect(hasFilterTokens({ operation: 'and', tokens: [], tokenGroups: [] })).toBe(false);
    });
  });

  describe('parseFilterFromParams', () => {
    it('should parse valid JSON', () => {
      const json = JSON.stringify({
        operation: 'and',
        tokens: [{ propertyKey: 'name', operator: '=', value: 'test' }],
      });
      const result = parseFilterFromParams(
        json,
        { operation: 'and', tokens: [], tokenGroups: [] },
        'test'
      );
      expect(result.tokens).toHaveLength(1);
    });

    it('should return fallback for null', () => {
      const fallback: PropertyFilterQuery = { operation: 'or', tokens: [], tokenGroups: [] };
      const result = parseFilterFromParams(null, fallback, 'test');
      expect(result).toEqual(fallback);
    });

    it('should return fallback for invalid JSON', () => {
      const fallback: PropertyFilterQuery = { operation: 'and', tokens: [], tokenGroups: [] };
      const result = parseFilterFromParams('invalid json', fallback, 'test');
      expect(result).toEqual(fallback);
    });
  });

  describe('encodeFilterQuery', () => {
    it('should encode non-empty queries', () => {
      const query: PropertyFilterQuery = {
        operation: 'and',
        tokens: [{ propertyKey: 'name', operator: '=', value: 'test' }],
        tokenGroups: [],
      };
      const result = encodeFilterQuery(
        query,
        { operation: 'and', tokens: [], tokenGroups: [] },
        'test'
      );
      expect(result).toBeTruthy();
      expect(JSON.parse(result!)).toMatchObject({
        operation: 'and',
        tokens: [{ propertyKey: 'name', operator: '=', value: 'test' }],
      });
    });

    it('should return null for empty queries', () => {
      const query: PropertyFilterQuery = { operation: 'and', tokens: [], tokenGroups: [] };
      const result = encodeFilterQuery(
        query,
        { operation: 'and', tokens: [], tokenGroups: [] },
        'test'
      );
      expect(result).toBeNull();
    });
  });

  describe('applySnapshotToSearchParams', () => {
    type TestSort = 'name' | 'region';

    it('should set non-default parameters', () => {
      const params = new URLSearchParams();
      const snapshot: CatalogStateSnapshot<TestSort> = {
        viewType: 'table',
        sortingField: 'region',
        sortingDescending: true,
        pageIndex: 2,
        pageSize: 30,
        propertyFilterQuery: { operation: 'and', tokens: [], tokenGroups: [] },
      };
      const fallback: CatalogStateSnapshot<TestSort> = {
        viewType: 'card',
        sortingField: 'name',
        sortingDescending: false,
        pageIndex: 1,
        pageSize: 20,
        propertyFilterQuery: { operation: 'and', tokens: [], tokenGroups: [] },
      };

      applySnapshotToSearchParams({
        params,
        snapshot,
        fallback,
        urlComparisonDefaults: fallback,
        queryKeys: DEFAULT_QUERY_KEYS,
      });

      expect(params.get('view')).toBe('table');
      expect(params.get('sort')).toBe('region');
      expect(params.get('desc')).toBe('1');
      expect(params.get('page')).toBe('2');
      expect(params.get('pageSize')).toBe('30');
    });

    it('should delete default parameters', () => {
      const params = new URLSearchParams('view=card&sort=name&page=1');
      const snapshot: CatalogStateSnapshot<TestSort> = {
        viewType: 'card',
        sortingField: 'name',
        sortingDescending: false,
        pageIndex: 1,
        pageSize: 20,
        propertyFilterQuery: { operation: 'and', tokens: [], tokenGroups: [] },
      };
      const fallback = snapshot;

      applySnapshotToSearchParams({
        params,
        snapshot,
        fallback,
        urlComparisonDefaults: fallback,
        queryKeys: DEFAULT_QUERY_KEYS,
      });

      expect(params.get('view')).toBeNull();
      expect(params.get('sort')).toBeNull();
      expect(params.get('page')).toBeNull();
    });

    it('should encode non-empty filters', () => {
      const params = new URLSearchParams();
      const snapshot: CatalogStateSnapshot<TestSort> = {
        viewType: 'card',
        sortingField: 'name',
        sortingDescending: false,
        pageIndex: 1,
        pageSize: 20,
        propertyFilterQuery: {
          operation: 'and',
          tokens: [{ propertyKey: 'region', operator: '=', value: 'US' }],
        },
      };
      const fallback: CatalogStateSnapshot<TestSort> = {
        ...snapshot,
        propertyFilterQuery: { operation: 'and', tokens: [], tokenGroups: [] },
      };

      applySnapshotToSearchParams({
        params,
        snapshot,
        fallback,
        urlComparisonDefaults: fallback,
        queryKeys: DEFAULT_QUERY_KEYS,
      });

      expect(params.get('filter')).toBeTruthy();
    });
  });
});
