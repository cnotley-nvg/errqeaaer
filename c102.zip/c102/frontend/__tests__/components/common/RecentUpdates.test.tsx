import React from 'react';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import { graphqlClient } from '../../../api/graphqlClient';
import RecentUpdates from '../../../components/common/RecentUpdates';

// Mock the graphql client
jest.mock('../../../api/graphqlClient');
const mockGraphqlClient = graphqlClient as jest.Mocked<typeof graphqlClient>;

// Mock the versioned preferences hook
jest.mock('../../../storage/recent-updates-preferences', () => ({
  useVersionedRecentUpdatesPreferences: () => ({
    preferences: {
      pageSize: 10,
      wrapLines: true,
      stripedRows: false,
      contentDisplay: [
        { id: 'details', visible: true },
        { id: 'message', visible: true },
        { id: 'createdBy', visible: true },
        { id: 'createdAt', visible: true },
        { id: 'status', visible: true },
      ],
      stickyColumns: { first: 0, last: 0 },
    },
    updatePreferences: jest.fn(),
    resetPreferences: jest.fn(),
  }),
  PAGE_SIZE_OPTIONS: [
    { value: 10, label: '10 updates' },
    { value: 20, label: '20 updates' },
  ],
  CONTENT_DISPLAY_OPTIONS: [
    { id: 'details', label: 'Item', alwaysVisible: true },
    { id: 'message', label: 'Action' },
    { id: 'createdBy', label: 'Updated by' },
    { id: 'createdAt', label: 'Date' },
    { id: 'status', label: 'Status' },
  ],
  STICKY_COLUMNS_PREFERENCE: {
    firstColumns: {
      title: 'Stick first column(s)',
      description:
        'Keep the first column(s) visible while horizontally scrolling the table content.',
      options: [
        { label: 'None', value: 0 },
        { label: 'First column', value: 1 },
        { label: 'First two columns', value: 2 },
      ],
    },
    lastColumns: {
      title: 'Stick last column',
      description: 'Keep the last column visible while horizontally scrolling the table content.',
      options: [
        { label: 'None', value: 0 },
        { label: 'Last column', value: 1 },
      ],
    },
  },
}));

// Mock moment
jest.mock('moment', () => {
  const actualMoment = jest.requireActual('moment');
  return (date: string) => ({
    ...actualMoment(date),
    fromNow: () => '2 hours ago',
  });
});

// Mock AWS UI components
jest.mock('@amzn/awsui-components-console', () => ({
  Table: ({ items, loading, empty, header, filter, preferences }: any) => (
    <div data-testid="table">
      {header}
      {filter}
      {preferences}
      {loading ? <div>Loading...</div> : items.length === 0 ? empty : <div>Table content</div>}
    </div>
  ),
  Box: ({ children }: any) => <div>{children}</div>,
  SpaceBetween: ({ children }: any) => <div>{children}</div>,
  TextFilter: ({ filteringText, onChange, filteringPlaceholder }: any) => (
    <input
      data-testid="text-filter"
      value={filteringText}
      onChange={(e) => onChange({ detail: { filteringText: e.target.value } })}
      placeholder={filteringPlaceholder}
    />
  ),
  Header: ({ children, counter, description }: any) => (
    <div data-testid="header">
      {children} {counter}
      <div>{description}</div>
    </div>
  ),
  Link: ({ children, href }: any) => <a href={href}>{children}</a>,
  Icon: ({ name }: any) => <span data-testid={`icon-${name}`} />,
  Pagination: ({ currentPageIndex, pagesCount, onChange }: any) => (
    <div data-testid="pagination">
      <button onClick={() => onChange({ detail: { currentPageIndex: currentPageIndex + 1 } })}>
        Next
      </button>
    </div>
  ),
  CollectionPreferences: ({ children }: any) => <div data-testid="preferences">{children}</div>,
  Button: ({ children, onClick }: any) => (
    <button onClick={onClick} data-testid="button">
      {children}
    </button>
  ),
}));

const mockSystemEvents = {
  searchSystemEvents: {
    items: [
      {
        id: '1',
        type: 'STANDARD',
        details: { id: 'std-1', name: 'Test Standard' },
        message: 'Updated standard',
        status: 'UPDATED',
        createdBy: 'testuser',
        createdAt: '2024-01-01T10:00:00Z',
      },
      {
        id: '2',
        type: 'TEMPLATE',
        details: { id: 'tpl-1', name: 'Test Template' },
        message: 'Published template',
        status: 'PUBLISHED',
        createdBy: 'anotheruser',
        createdAt: '2024-01-01T09:00:00Z',
      },
    ],
    total: 2,
  },
};

describe('RecentUpdates', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockGraphqlClient.request.mockResolvedValue(mockSystemEvents);
  });

  it('renders loading state initially', () => {
    render(<RecentUpdates />);
    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  it('renders table with data after loading', async () => {
    render(<RecentUpdates />);

    await waitFor(() => {
      expect(screen.getByText('Table content')).toBeInTheDocument();
    });

    expect(screen.getByText('Recent updates (2)')).toBeInTheDocument();
    expect(
      screen.getByText('Latest activities and changes across your design assets.')
    ).toBeInTheDocument();
  });

  it('renders empty state when no data', async () => {
    mockGraphqlClient.request.mockResolvedValue({
      searchSystemEvents: { items: [], total: 0 },
    });

    render(<RecentUpdates />);

    await waitFor(() => {
      expect(screen.getByText('No events')).toBeInTheDocument();
    });

    expect(screen.getByText('No system events found.')).toBeInTheDocument();
  });

  it('handles search filtering', async () => {
    render(<RecentUpdates />);

    const searchInput = screen.getByTestId('text-filter');
    fireEvent.change(searchInput, { target: { value: 'test search' } });

    await waitFor(() => {
      expect(mockGraphqlClient.request).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          filter: expect.objectContaining({
            searchTerm: 'test search',
          }),
        })
      );
    });
  });

  it('handles pagination', async () => {
    render(<RecentUpdates />);

    await waitFor(() => {
      expect(screen.getByTestId('pagination')).toBeInTheDocument();
    });

    const nextButton = screen.getByText('Next');
    fireEvent.click(nextButton);

    await waitFor(() => {
      expect(mockGraphqlClient.request).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          filter: expect.objectContaining({
            pageIdx: 1, // Second page (0-indexed)
          }),
        })
      );
    });
  });

  it('handles sorting changes', async () => {
    render(<RecentUpdates />);

    // Wait for initial load
    await waitFor(() => {
      expect(mockGraphqlClient.request).toHaveBeenCalled();
    });

    // Clear previous calls
    mockGraphqlClient.request.mockClear();

    // Simulate sorting change (this would normally come from Table component)
    // Since we're mocking the Table component, we can't easily test this interaction
    // In a real test, you'd need to render the actual Table component or use integration tests
  });

  it('handles GraphQL errors gracefully', async () => {
    const consoleError = jest.spyOn(console, 'error').mockImplementation(() => {});
    mockGraphqlClient.request.mockRejectedValue(new Error('GraphQL Error'));

    render(<RecentUpdates />);

    await waitFor(() => {
      expect(screen.getByText('No events')).toBeInTheDocument();
    });

    expect(consoleError).toHaveBeenCalledWith('Failed to fetch system events:', expect.any(Error));
    consoleError.mockRestore();
  });

  it('renders preferences component', () => {
    render(<RecentUpdates />);
    expect(screen.getByTestId('preferences')).toBeInTheDocument();
  });

  it('makes correct GraphQL request with default parameters', async () => {
    render(<RecentUpdates />);

    await waitFor(() => {
      expect(mockGraphqlClient.request).toHaveBeenCalledWith(
        expect.stringContaining('SearchSystemEvents'),
        {
          filter: {
            searchTerm: undefined,
            pageIdx: 0,
            limit: 10,
            orderBy: 'createdAt',
            orderDesc: true,
          },
        }
      );
    });
  });

  it('resets page index when search term changes', async () => {
    render(<RecentUpdates />);

    // Wait for initial load
    await waitFor(() => {
      expect(mockGraphqlClient.request).toHaveBeenCalled();
    });

    // Navigate to page 2 first
    const nextButton = screen.getByText('Next');
    fireEvent.click(nextButton);

    await waitFor(() => {
      expect(mockGraphqlClient.request).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          filter: expect.objectContaining({
            pageIdx: 1,
          }),
        })
      );
    });

    // Clear previous calls
    mockGraphqlClient.request.mockClear();

    // Change search term
    const searchInput = screen.getByTestId('text-filter');
    fireEvent.change(searchInput, { target: { value: 'new search' } });

    // Should reset to page 1 (pageIdx: 0)
    await waitFor(() => {
      expect(mockGraphqlClient.request).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          filter: expect.objectContaining({
            pageIdx: 0,
            searchTerm: 'new search',
          }),
        })
      );
    });
  });
});
