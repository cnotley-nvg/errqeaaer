import React from 'react';
import { render, screen } from '@testing-library/react';
import { MetadataField } from '../../../components/common/MetadataField';

describe('MetadataField', () => {
  it('renders label and value', () => {
    render(
      <MetadataField label="Test Label">
        <span>Test Value</span>
      </MetadataField>
    );

    expect(screen.getByText('Test Label')).toBeDefined();
    expect(screen.getByText('Test Value')).toBeDefined();
  });

  it('renders with React components as children', () => {
    render(
      <MetadataField label="Region">
        <a href="https://example.com">NA</a>
      </MetadataField>
    );

    expect(screen.getByText('Region')).toBeDefined();
    const link = screen.getByRole('link', { name: 'NA' });
    expect(link).toBeDefined();
    expect(link.getAttribute('href')).toBe('https://example.com');
  });

  it('renders with multiple child elements', () => {
    render(
      <MetadataField label="Status">
        <div>
          <span>Active</span>
          <span> - Verified</span>
        </div>
      </MetadataField>
    );

    expect(screen.getByText('Status')).toBeDefined();
    expect(screen.getByText('Active')).toBeDefined();
    expect(screen.getByText('- Verified', { exact: false })).toBeDefined();
  });

  it('renders with fallback dash when value is missing', () => {
    render(
      <MetadataField label="Empty Field">
        <span>—</span>
      </MetadataField>
    );

    expect(screen.getByText('Empty Field')).toBeDefined();
    expect(screen.getByText('—')).toBeDefined();
  });

  it('renders empty children', () => {
    render(
      <MetadataField label="Empty">
        <span></span>
      </MetadataField>
    );

    expect(screen.getByText('Empty')).toBeDefined();
  });
});
