import React from 'react';
import { render, screen } from '@testing-library/react';

import { EmptyState } from '../../../components/common/EmptyState';

jest.mock('@amzn/awsui-components-console', () => ({
  Box: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  SpaceBetween: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
  Icon: () => <span>icon</span>,
}));

describe('EmptyState', () => {
  it('renders title and subtitle', () => {
    render(<EmptyState title="No data" subtitle="Nothing to show" />);

    expect(screen.getByText('No data')).toBeInTheDocument();
    expect(screen.getByText('Nothing to show')).toBeInTheDocument();
  });
});
