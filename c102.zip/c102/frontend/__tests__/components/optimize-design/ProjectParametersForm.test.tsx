import { render } from '@testing-library/react';
import createWrapper from '@amzn/awsui-components-console/test-utils/dom';
import { ProjectParametersForm } from '../../../components/optimize-design/ProjectParametersForm';
import type { ProjectParams } from '../../../components/optimize-design/ProjectParametersForm';
import * as addressAutosuggest from '../../../api/addressAutosuggest';

jest.mock('../../../api/addressAutosuggest');

jest.mock('../../../hooks/useDesignTemplatesOptimized', () => ({
  useDesignTemplatesOptimized: () => ({
    templates: [
      {
        id: 'ars-na-gen12',
        name: 'ARS NA Gen12',
        description: 'Second template',
        facilityTypes: ['ARS', 'BTS'],
      },
      {
        id: 'template1',
        name: 'Template 1',
        description: 'First template',
        facilityTypes: ['IXD', 'RSR'],
      },
    ],
    loading: false,
    error: null,
  }),
}));

jest.mock('../../../hooks/useLatestTemplateVersionsSearch', () => ({
  useLatestTemplateVersionsSearch: () => ({
    items: [
      {
        id: 'version-1',
        version: 'v1',
        isLatest: true,
        accFolderId: 'folder-1',
        brsId: null,
        createdAt: '2024-01-01T00:00:00Z',
        updatedAt: '2024-01-01T00:00:00Z',
        attributes: {
          facilityType: 'ARS',
          grossSquareFootage: 652000,
          buildingLength: 750,
          buildingWidth: 375,
          buildingHeight: 38,
        },
        files: [],
        template: {
          id: 'ars-na-gen12',
          name: 'ARS NA Gen12',
          description: 'Second template',
          accProjectId: 'project-1',
        },
      },
      {
        id: 'version-2',
        version: 'v1',
        isLatest: true,
        accFolderId: 'folder-2',
        brsId: null,
        createdAt: '2024-01-02T00:00:00Z',
        updatedAt: '2024-01-02T00:00:00Z',
        attributes: {
          facilityType: 'IXD',
          grossSquareFootage: 450000,
          buildingLength: 550,
          buildingWidth: 275,
          buildingHeight: 35,
        },
        files: [],
        template: {
          id: 'template1',
          name: 'Template 1',
          description: 'First template',
          accProjectId: 'project-2',
        },
      },
    ],
    totalCount: 2,
    totalPages: 1,
    pageIdx: 0,
    limit: 1000,
    loading: false,
    error: null,
    refetch: jest.fn(),
  }),
}));

describe('ProjectParametersForm', () => {
  const mockParams: ProjectParams = {
    locationType: 'coordinates',
    streetAddress: '',
    country: '',
    city: '',
    zipcode: '',
    latitude: '47.6062',
    longitude: '-122.3321',
    facilityType: '',
    designTemplate: 'ars-na-gen12',
    designTemplateName: 'ARS NA Gen12',
    squareFootage: '652000',
    length: '750',
    width: '375',
    height: '38',
  };

  const mockOnChange = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render form with coordinates fields when locationType is coordinates', () => {
    const { container } = render(
      <ProjectParametersForm params={mockParams} onChange={mockOnChange} />
    );
    const wrapper = createWrapper(container);
    const inputs = wrapper.findAllInputs();
    expect(inputs).toHaveLength(6);
  });

  it('should render form with address fields when locationType is address', () => {
    const { container } = render(
      <ProjectParametersForm
        params={{ ...mockParams, locationType: 'address' }}
        onChange={mockOnChange}
      />
    );
    const wrapper = createWrapper(container);
    const inputs = wrapper.findAllInputs();
    expect(inputs).toHaveLength(7);
  });

  it('should call onChange when latitude input changes', () => {
    const { container } = render(
      <ProjectParametersForm params={mockParams} onChange={mockOnChange} />
    );
    const wrapper = createWrapper(container);
    const inputs = wrapper.findAllInputs();
    inputs[0]?.setInputValue('48.0');
    expect(mockOnChange).toHaveBeenCalledWith('latitude', '48.0');
  });

  it('should call onChange when longitude input changes', () => {
    const { container } = render(
      <ProjectParametersForm params={mockParams} onChange={mockOnChange} />
    );
    const wrapper = createWrapper(container);
    const inputs = wrapper.findAllInputs();
    inputs[1]?.setInputValue('-123.0');
    expect(mockOnChange).toHaveBeenCalledWith('longitude', '-123.0');
  });

  it('should call onChange when square footage input changes', () => {
    const { container } = render(
      <ProjectParametersForm params={mockParams} onChange={mockOnChange} />
    );
    const wrapper = createWrapper(container);
    const inputs = wrapper.findAllInputs();
    inputs[2]?.setInputValue('700000');
    expect(mockOnChange).toHaveBeenCalledWith('squareFootage', '700000');
  });

  it('should accept non-numeric input in square footage field', () => {
    const { container } = render(
      <ProjectParametersForm params={mockParams} onChange={mockOnChange} />
    );
    const wrapper = createWrapper(container);
    const inputs = wrapper.findAllInputs();
    inputs[2]?.setInputValue('abc');
    expect(mockOnChange).toHaveBeenCalledWith('squareFootage', 'abc');
  });

  it('should accept non-numeric input in length field', () => {
    const { container } = render(
      <ProjectParametersForm params={mockParams} onChange={mockOnChange} />
    );
    const wrapper = createWrapper(container);
    const inputs = wrapper.findAllInputs();
    inputs[3]?.setInputValue('xyz');
    expect(mockOnChange).toHaveBeenCalledWith('length', 'xyz');
  });

  it('should accept non-numeric input in width field', () => {
    const { container } = render(
      <ProjectParametersForm params={mockParams} onChange={mockOnChange} />
    );
    const wrapper = createWrapper(container);
    const inputs = wrapper.findAllInputs();
    inputs[4]?.setInputValue('xyz');
    expect(mockOnChange).toHaveBeenCalledWith('width', 'xyz');
  });

  it('should accept non-numeric input in height field', () => {
    const { container } = render(
      <ProjectParametersForm params={mockParams} onChange={mockOnChange} />
    );
    const wrapper = createWrapper(container);
    const inputs = wrapper.findAllInputs();
    inputs[5]?.setInputValue('xyz');
    expect(mockOnChange).toHaveBeenCalledWith('height', 'xyz');
  });

  it('should call onChange when location type select changes', () => {
    const { container } = render(
      <ProjectParametersForm params={mockParams} onChange={mockOnChange} />
    );
    const wrapper = createWrapper(container);
    const select = wrapper.findAllSelects()[0];
    select?.openDropdown();
    select?.selectOption(1);
    expect(mockOnChange).toHaveBeenCalledWith('locationType', 'address');
  });

  it('should call onChange when facility type select changes', () => {
    const { container } = render(
      <ProjectParametersForm params={mockParams} onChange={mockOnChange} />
    );
    const wrapper = createWrapper(container);
    const selects = wrapper.findAllSelects();
    const facilityTypeSelect = selects[1];
    facilityTypeSelect?.openDropdown();
    facilityTypeSelect?.selectOptionByValue('ARS');
    expect(mockOnChange).toHaveBeenCalledWith('facilityType', 'ARS');
  });

  it('should call onChange when design template select changes', () => {
    const { container } = render(
      <ProjectParametersForm params={mockParams} onChange={mockOnChange} />
    );
    const wrapper = createWrapper(container);
    const selects = wrapper.findAllSelects();
    const templateSelect = selects[2];
    templateSelect?.openDropdown();
    templateSelect?.selectOption(1);
    expect(mockOnChange).toHaveBeenCalledWith('designTemplate', 'ars-na-gen12');
  });

  it('should filter templates when facility type is selected', () => {
    const paramsWithFacilityType = { ...mockParams, facilityType: 'ARS', designTemplate: '' };
    const { container } = render(
      <ProjectParametersForm params={paramsWithFacilityType} onChange={mockOnChange} />
    );
    const wrapper = createWrapper(container);
    const selects = wrapper.findAllSelects();
    const templateSelect = selects[2];
    templateSelect?.openDropdown();
    const options = templateSelect?.findDropdown()?.findOptions();
    expect(options?.length).toBe(1);
  });

  it('should show all facility types when no design template is selected', () => {
    const paramsNoTemplate = { ...mockParams, designTemplate: '', facilityType: '' };
    const { container } = render(
      <ProjectParametersForm params={paramsNoTemplate} onChange={mockOnChange} />
    );
    const wrapper = createWrapper(container);
    const selects = wrapper.findAllSelects();
    const facilityTypeSelect = selects[1];
    facilityTypeSelect?.openDropdown();
    const options = facilityTypeSelect?.findDropdown()?.findOptions();
    expect(options?.length).toBeGreaterThan(0);
    expect(options?.some((opt) => opt.getElement().textContent?.includes('ARS'))).toBe(true);
    expect(options?.some((opt) => opt.getElement().textContent?.includes('BTS'))).toBe(true);
    expect(options?.some((opt) => opt.getElement().textContent?.includes('IXD'))).toBe(true);
    expect(options?.some((opt) => opt.getElement().textContent?.includes('RSR'))).toBe(true);
  });

  it('should auto-populate square footage when design template is selected', () => {
    const paramsWithTemplate = { ...mockParams, designTemplate: 'ars-na-gen12', squareFootage: '' };
    render(<ProjectParametersForm params={paramsWithTemplate} onChange={mockOnChange} />);
    expect(mockOnChange).toHaveBeenCalledWith('squareFootage', '652000');
  });

  it('should auto-populate with different square footage for different template', () => {
    const paramsWithDifferentTemplate = {
      ...mockParams,
      designTemplate: 'template1',
      squareFootage: '',
    };
    render(<ProjectParametersForm params={paramsWithDifferentTemplate} onChange={mockOnChange} />);
    expect(mockOnChange).toHaveBeenCalledWith('squareFootage', '450000');
  });

  it('should not auto-populate square footage when no template is selected', () => {
    const paramsNoTemplate = { ...mockParams, designTemplate: '', squareFootage: '' };
    render(<ProjectParametersForm params={paramsNoTemplate} onChange={mockOnChange} />);
    expect(mockOnChange).not.toHaveBeenCalledWith('squareFootage', expect.anything());
  });

  it('should auto-populate facility type when design template is selected and facility type is empty', () => {
    const paramsWithTemplateNoFacility = {
      ...mockParams,
      designTemplate: 'ars-na-gen12',
      facilityType: '',
    };
    render(<ProjectParametersForm params={paramsWithTemplateNoFacility} onChange={mockOnChange} />);
    expect(mockOnChange).toHaveBeenCalledWith('facilityType', 'ARS');
  });

  it('should not auto-populate facility type when facility type is already set', () => {
    const paramsWithBoth = { ...mockParams, designTemplate: 'ars-na-gen12', facilityType: 'BTS' };
    render(<ProjectParametersForm params={paramsWithBoth} onChange={mockOnChange} />);
    expect(mockOnChange).not.toHaveBeenCalledWith('facilityType', expect.anything());
  });

  it('should not auto-populate facility type when no template is selected', () => {
    const paramsNoTemplate = { ...mockParams, designTemplate: '', facilityType: '' };
    render(<ProjectParametersForm params={paramsNoTemplate} onChange={mockOnChange} />);
    expect(mockOnChange).not.toHaveBeenCalledWith('facilityType', expect.anything());
  });

  it('should display error text for latitude field', () => {
    const { container } = render(
      <ProjectParametersForm
        params={mockParams}
        onChange={mockOnChange}
        errors={{ latitude: 'Invalid latitude' }}
      />
    );
    expect(container.textContent).toContain('Invalid latitude');
  });

  it('should display error text for longitude field', () => {
    const { container } = render(
      <ProjectParametersForm
        params={mockParams}
        onChange={mockOnChange}
        errors={{ longitude: 'Invalid longitude' }}
      />
    );
    expect(container.textContent).toContain('Invalid longitude');
  });

  it('should display error text for street address field', () => {
    const { container } = render(
      <ProjectParametersForm
        params={{ ...mockParams, locationType: 'address' }}
        onChange={mockOnChange}
        errors={{ streetAddress: 'Address required' }}
      />
    );
    expect(container.textContent).toContain('Address required');
  });

  it('should display error text for zipcode field', () => {
    const { container } = render(
      <ProjectParametersForm
        params={{ ...mockParams, locationType: 'address' }}
        onChange={mockOnChange}
        errors={{ zipcode: 'Invalid zipcode' }}
      />
    );
    expect(container.textContent).toContain('Invalid zipcode');
  });

  it('should display error text for design template field', () => {
    const { container } = render(
      <ProjectParametersForm
        params={mockParams}
        onChange={mockOnChange}
        errors={{ designTemplate: 'Template required' }}
      />
    );
    expect(container.textContent).toContain('Template required');
  });

  it('should display error text for square footage field', () => {
    const { container } = render(
      <ProjectParametersForm
        params={mockParams}
        onChange={mockOnChange}
        errors={{ squareFootage: 'Invalid square footage' }}
      />
    );
    expect(container.textContent).toContain('Invalid square footage');
  });

  it('should display error text for length field', () => {
    const { container } = render(
      <ProjectParametersForm
        params={mockParams}
        onChange={mockOnChange}
        errors={{ length: 'Invalid length' }}
      />
    );
    expect(container.textContent).toContain('Invalid length');
  });

  it('should display error text for width field', () => {
    const { container } = render(
      <ProjectParametersForm
        params={mockParams}
        onChange={mockOnChange}
        errors={{ width: 'Invalid width' }}
      />
    );
    expect(container.textContent).toContain('Invalid width');
  });

  it('should display error text for height field', () => {
    const { container } = render(
      <ProjectParametersForm
        params={mockParams}
        onChange={mockOnChange}
        errors={{ height: 'Invalid height' }}
      />
    );
    expect(container.textContent).toContain('Invalid height');
  });

  it('should render address fields when locationType is address', () => {
    const { container } = render(
      <ProjectParametersForm
        params={{ ...mockParams, locationType: 'address' }}
        onChange={mockOnChange}
      />
    );
    expect(container.textContent).toContain('Street address');
    expect(container.textContent).toContain('Country');
    expect(container.textContent).toContain('City');
    expect(container.textContent).toContain('Zip/Postal code');
  });

  it('should render coordinates fields when locationType is coordinates', () => {
    const { container } = render(
      <ProjectParametersForm params={mockParams} onChange={mockOnChange} />
    );
    expect(container.textContent).toContain('Latitude');
    expect(container.textContent).toContain('Longitude');
  });

  it('should not render address fields when locationType is coordinates', () => {
    const { container } = render(
      <ProjectParametersForm params={mockParams} onChange={mockOnChange} />
    );
    expect(container.textContent).not.toContain('Street address');
  });

  it('should not render coordinates fields when locationType is address', () => {
    const { container } = render(
      <ProjectParametersForm
        params={{ ...mockParams, locationType: 'address' }}
        onChange={mockOnChange}
      />
    );
    const latitudeElements = Array.from(container.querySelectorAll('*')).filter((el) =>
      el.textContent?.includes('Latitude')
    );
    expect(latitudeElements.length).toBe(0);
  });

  it('should render all form fields', () => {
    const { container } = render(
      <ProjectParametersForm params={mockParams} onChange={mockOnChange} />
    );
    expect(container.textContent).toContain('Project parameters');
    expect(container.textContent).toContain('Location type');
    expect(container.textContent).toContain('Facility type');
    expect(container.textContent).toContain('Design template');
    expect(container.textContent).toContain('Total square footage');
    expect(container.textContent).toContain('Building length');
    expect(container.textContent).toContain('Building width');
    expect(container.textContent).toContain('Building height');
  });

  it('should auto-populate all dimensions when design template is selected', () => {
    const paramsWithTemplate = {
      ...mockParams,
      designTemplate: 'ars-na-gen12',
      squareFootage: '',
      length: '',
      width: '',
      height: '',
    };
    render(<ProjectParametersForm params={paramsWithTemplate} onChange={mockOnChange} />);
    expect(mockOnChange).toHaveBeenCalledWith('squareFootage', '652000');
    expect(mockOnChange).toHaveBeenCalledWith('length', '750');
    expect(mockOnChange).toHaveBeenCalledWith('width', '375');
    expect(mockOnChange).toHaveBeenCalledWith('height', '38');
  });

  it('should not auto-populate dimensions when already partially set', () => {
    const mockOnChangeLocal = jest.fn();
    const paramsWithPartialDimensions = {
      ...mockParams,
      designTemplate: 'ars-na-gen12',
      squareFootage: '652000',
      length: '',
      width: '',
      height: '',
    };
    render(
      <ProjectParametersForm params={paramsWithPartialDimensions} onChange={mockOnChangeLocal} />
    );
    expect(mockOnChangeLocal).not.toHaveBeenCalledWith('squareFootage', '652000');
  });
});
