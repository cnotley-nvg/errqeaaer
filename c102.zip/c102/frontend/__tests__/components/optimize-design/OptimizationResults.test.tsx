import { render, screen } from '@testing-library/react';
import { OptimizationResults } from '../../../components/optimize-design/OptimizationResults';
import type { AnalysisResult } from '../../../components/optimize-design/AnalysisResultCard';

describe('OptimizationResults', () => {
  const mockParams = {
    streetAddress: '123 Main St',
    city: 'Seattle',
    zipcode: '98101',
    country: 'USA',
    facilityType: 'Warehouse',
    designTemplate: 'template-a',
    designTemplateName: 'Template A',
    squareFootage: '50000',
    height: '40',
    width: '100',
    length: '150',
  };

  const mockAnalyses: AnalysisResult[] = [
    {
      title: 'Lightning Protection',
      description: 'Analysis complete',
      recommendation: 'required',
      downloadable: true,
    },
    {
      title: 'Seismic Analysis',
      description: 'No issues found',
      recommendation: 'not-required',
    },
  ];

  const mockOnBack = jest.fn();
  const mockOnDone = jest.fn();

  it('should render project parameters', () => {
    render(
      <OptimizationResults
        params={mockParams}
        analyses={mockAnalyses}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    expect(screen.getByText('123 Main St')).toBeInTheDocument();
    expect(screen.getByText('Seattle')).toBeInTheDocument();
    expect(screen.getByText('98101')).toBeInTheDocument();
    expect(screen.getByText('USA')).toBeInTheDocument();
    expect(screen.getByText('Warehouse')).toBeInTheDocument();
    expect(screen.getByText('Template A')).toBeInTheDocument();
    expect(screen.getByText('50,000')).toBeInTheDocument();
    expect(screen.getByText('40')).toBeInTheDocument();
    expect(screen.getByText('100')).toBeInTheDocument();
    expect(screen.getByText('150')).toBeInTheDocument();
  });

  it('should render all analyses', () => {
    render(
      <OptimizationResults
        params={mockParams}
        analyses={mockAnalyses}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    expect(screen.getByText('Lightning Protection')).toBeInTheDocument();
    expect(screen.getByText('Seismic Analysis')).toBeInTheDocument();
  });

  it('should show recommended badge for required recommendation', () => {
    const analysesWithRequired: AnalysisResult[] = [
      {
        title: 'Lightning protection',
        description: 'Analysis complete',
        recommendation: 'required',
        downloadable: true,
      },
    ];

    render(
      <OptimizationResults
        params={mockParams}
        analyses={analysesWithRequired}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    expect(screen.getByText('Recommended')).toBeInTheDocument();
  });

  it('should show not required badge for not-required recommendation', () => {
    const analysesWithNotRequired: AnalysisResult[] = [
      {
        title: 'Wind loading',
        description: 'No issues found',
        recommendation: 'not-required',
      },
    ];

    render(
      <OptimizationResults
        params={mockParams}
        analyses={analysesWithNotRequired}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    expect(screen.getByText('Not required')).toBeInTheDocument();
  });

  it('should show download button for downloadable analyses', () => {
    render(
      <OptimizationResults
        params={mockParams}
        analyses={mockAnalyses}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    const downloadButtons = screen.getAllByText('Download report');
    expect(downloadButtons).toHaveLength(1);
  });

  it('should render back and done buttons', () => {
    render(
      <OptimizationResults
        params={mockParams}
        analyses={mockAnalyses}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    expect(screen.getByText('Back')).toBeInTheDocument();
    expect(screen.getByText('Done')).toBeInTheDocument();
  });

  it('should not show badge for electrical benchmarking', () => {
    const analysesWithElectrical: AnalysisResult[] = [
      {
        title: 'Electrical benchmarking',
        description: 'Electrical analysis',
        recommendation: 'optional',
        electricalData: {
          categoryLoads: [],
          total: {
            connectedLoad: { kVA: 0, amps: 0 },
            diversifiedLoad: { kVA: 0, amps: 0 },
            utilityPowerDemand: { kVA: 0, amps: 0 },
          },
          o1: { kVA: 0, amps: 0 },
          o2: { kVA: 0, amps: 0 },
          o3: { kVA: 0, amps: 0 },
          o4: 0,
          state: 'Washington',
        },
      },
    ];

    render(
      <OptimizationResults
        params={mockParams}
        analyses={analysesWithElectrical}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    // Electrical benchmarking should not have a badge
    expect(screen.queryByText('Recommended')).not.toBeInTheDocument();
    expect(screen.queryByText('Not required')).not.toBeInTheDocument();
  });

  it('should not show badge for optional recommendation', () => {
    const analysesWithOptional: AnalysisResult[] = [
      {
        title: 'Optional Analysis',
        description: 'Optional check',
        recommendation: 'optional',
      },
    ];

    render(
      <OptimizationResults
        params={mockParams}
        analyses={analysesWithOptional}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    // Optional recommendation should not have a badge
    expect(screen.queryByText('Recommended')).not.toBeInTheDocument();
    expect(screen.queryByText('Not required')).not.toBeInTheDocument();
  });

  it('should display state when available', () => {
    const analysesWithState: AnalysisResult[] = [
      {
        title: 'Electrical benchmarking',
        description: 'Electrical analysis',
        recommendation: 'optional',
        state: 'California',
        electricalData: {
          categoryLoads: [],
          total: {
            connectedLoad: { kVA: 0, amps: 0 },
            diversifiedLoad: { kVA: 0, amps: 0 },
            utilityPowerDemand: { kVA: 0, amps: 0 },
          },
          o1: { kVA: 0, amps: 0 },
          o2: { kVA: 0, amps: 0 },
          o3: { kVA: 0, amps: 0 },
          o4: 0,
          state: 'California',
        },
      },
    ];

    render(
      <OptimizationResults
        params={mockParams}
        analyses={analysesWithState}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    expect(screen.getByText('California')).toBeInTheDocument();
  });

  it('should display dash when state is not available', () => {
    const analysesWithoutState: AnalysisResult[] = [
      {
        title: 'Lightning Protection',
        description: 'Analysis complete',
        recommendation: 'required',
      },
    ];

    render(
      <OptimizationResults
        params={mockParams}
        analyses={analysesWithoutState}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    // State field should show dash when no electrical analysis
    const stateElements = screen.getAllByText('-');
    expect(stateElements.length).toBeGreaterThan(0);
  });

  it('should render design template as a link', () => {
    render(
      <OptimizationResults
        params={mockParams}
        analyses={mockAnalyses}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    const link = screen.getByRole('link', { name: 'Template A' });
    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute('href', '/templates/template-a');
  });

  it('should format numeric fields with commas', () => {
    const paramsWithLargeNumbers = {
      ...mockParams,
      squareFootage: '652000',
      height: '250',
      width: '500',
      length: '1000',
    };

    render(
      <OptimizationResults
        params={paramsWithLargeNumbers}
        analyses={mockAnalyses}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    expect(screen.getByText('652,000')).toBeInTheDocument();
    expect(screen.getByText('250')).toBeInTheDocument();
    expect(screen.getByText('500')).toBeInTheDocument();
    expect(screen.getByText('1,000')).toBeInTheDocument();
  });

  it('should not show edited badge when no edits have been made', () => {
    const analysesWithElectrical: AnalysisResult[] = [
      {
        title: 'Electrical benchmarking',
        description: 'Electrical analysis',
        recommendation: 'optional',
        electricalData: {
          categoryLoads: [],
          total: {
            connectedLoad: { kVA: 0, amps: 0 },
            diversifiedLoad: { kVA: 0, amps: 0 },
            utilityPowerDemand: { kVA: 0, amps: 0 },
          },
          o1: { kVA: 0, amps: 0 },
          o2: { kVA: 0, amps: 0 },
          o3: { kVA: 0, amps: 0 },
          o4: 0,
          state: 'Washington',
        },
      },
    ];

    render(
      <OptimizationResults
        params={mockParams}
        analyses={analysesWithElectrical}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    expect(screen.queryByText('Edited')).not.toBeInTheDocument();
    expect(screen.queryByText('Reset to Original')).not.toBeInTheDocument();
  });

  it('should pass editable prop to ElectricalPowerDemand', () => {
    const analysesWithElectrical: AnalysisResult[] = [
      {
        title: 'Electrical benchmarking',
        description: 'Electrical analysis',
        recommendation: 'optional',
        electricalData: {
          categoryLoads: [],
          total: {
            connectedLoad: { kVA: 0, amps: 0 },
            diversifiedLoad: { kVA: 0, amps: 0 },
            utilityPowerDemand: { kVA: 0, amps: 0 },
          },
          o1: { kVA: 0, amps: 0 },
          o2: { kVA: 0, amps: 0 },
          o3: { kVA: 0, amps: 0 },
          o4: 0,
          state: 'Washington',
        },
      },
    ];

    render(
      <OptimizationResults
        params={mockParams}
        analyses={analysesWithElectrical}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    // Component should render successfully with editing enabled
    expect(screen.getByText('Electrical benchmarking')).toBeInTheDocument();
  });

  it('should show solar recommendation badge when o2.kVA is greater than 0', () => {
    const analysesWithSolar: AnalysisResult[] = [
      {
        title: 'Electrical benchmarking',
        description: 'Electrical analysis with solar',
        recommendation: 'optional',
        electricalData: {
          categoryLoads: [],
          total: {
            connectedLoad: { kVA: 0, amps: 0 },
            diversifiedLoad: { kVA: 0, amps: 0 },
            utilityPowerDemand: { kVA: 0, amps: 0 },
          },
          o1: { kVA: 1000, amps: 1200 },
          o2: { kVA: 150, amps: 180 }, // Solar power available
          o3: { kVA: 850, amps: 1020 },
          o4: 2,
          state: 'California',
        },
      },
    ];

    render(
      <OptimizationResults
        params={mockParams}
        analyses={analysesWithSolar}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    expect(screen.getByText('Solar Recommendation Available')).toBeInTheDocument();
  });

  it('should not show solar recommendation badge when o2.kVA is 0', () => {
    const analysesWithoutSolar: AnalysisResult[] = [
      {
        title: 'Electrical benchmarking',
        description: 'Electrical analysis without solar',
        recommendation: 'optional',
        electricalData: {
          categoryLoads: [],
          total: {
            connectedLoad: { kVA: 0, amps: 0 },
            diversifiedLoad: { kVA: 0, amps: 0 },
            utilityPowerDemand: { kVA: 0, amps: 0 },
          },
          o1: { kVA: 1000, amps: 1200 },
          o2: { kVA: 0, amps: 0 }, // No solar power
          o3: { kVA: 1000, amps: 1200 },
          o4: 2,
          state: 'Washington',
        },
      },
    ];

    render(
      <OptimizationResults
        params={mockParams}
        analyses={analysesWithoutSolar}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    expect(screen.queryByText('Solar Recommendation Available')).not.toBeInTheDocument();
  });

  it('should show both edited and solar badges when both conditions are met', () => {
    const analysesWithSolar: AnalysisResult[] = [
      {
        title: 'Electrical benchmarking',
        description: 'Electrical analysis with solar',
        recommendation: 'optional',
        electricalData: {
          categoryLoads: [],
          total: {
            connectedLoad: { kVA: 0, amps: 0 },
            diversifiedLoad: { kVA: 0, amps: 0 },
            utilityPowerDemand: { kVA: 0, amps: 0 },
          },
          o1: { kVA: 1000, amps: 1200 },
          o2: { kVA: 150, amps: 180 },
          o3: { kVA: 850, amps: 1020 },
          o4: 2,
          state: 'California',
        },
      },
    ];

    const { rerender } = render(
      <OptimizationResults
        params={mockParams}
        analyses={analysesWithSolar}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    // Initially only solar badge should be visible
    expect(screen.getByText('Solar Recommendation Available')).toBeInTheDocument();
    expect(screen.queryByText('Edited')).not.toBeInTheDocument();

    // Note: Testing the "Edited" badge would require simulating user interaction
    // which would trigger the handleElectricalEdit callback and set hasEdits to true.
    // This is covered by integration tests.
  });

  it('should render heat index analysis with HeatIndexOptions', () => {
    const analysesWithHeatIndex: AnalysisResult[] = [
      {
        title: 'Mechanical/Heat index',
        description: 'Heat index analysis',
        recommendation: 'recommended',
        downloadable: true,
        heatIndexData: {
          levels: [
            { level: 0, hours: 7000, percentage: 80 },
            { level: 1, hours: 1000, percentage: 11.4 },
            { level: 2, hours: 500, percentage: 5.7 },
            { level: 3, hours: 200, percentage: 2.3 },
            { level: 4, hours: 60, percentage: 0.7 },
          ],
          hvacRecommendation: 'Option 3 - Permanent HVAC System',
          recommendation: 'recommended',
        },
      },
    ];

    render(
      <OptimizationResults
        params={mockParams}
        analyses={analysesWithHeatIndex}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    expect(screen.getByText('Mechanical/Heat index')).toBeInTheDocument();
    expect(screen.getByText('Option 1 - Natural Ventilation')).toBeInTheDocument();
  });

  it('should show not-provided alert for lightning protection without dimensions', () => {
    const analysesWithNotProvided: AnalysisResult[] = [
      {
        title: 'Lightning protection',
        description: 'Building dimensions required',
        recommendation: 'not-provided',
      },
    ];

    render(
      <OptimizationResults
        params={mockParams}
        analyses={analysesWithNotProvided}
        onBack={mockOnBack}
        onDone={mockOnDone}
      />
    );

    expect(screen.getByText(/Building dimensions required/)).toBeInTheDocument();
  });
});
