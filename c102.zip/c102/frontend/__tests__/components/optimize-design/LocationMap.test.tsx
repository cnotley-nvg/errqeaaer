import { render, waitFor } from '@testing-library/react';
import { LocationMap } from '../../../components/optimize-design/LocationMap';
import * as locationServices from '../../../api/locationServices';

jest.mock('@amzn/global-realty-mosaic-arcgis-client', () => ({
  Map: jest.fn(() => <div data-testid="map" />),
}));

jest.mock('../../../api/locationServices');

describe('LocationMap', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render map with coordinates', () => {
    const { getByTestId } = render(
      <LocationMap address="" zipcode="" latitude="47.6062" longitude="-122.3321" />
    );
    expect(getByTestId('map')).toBeInTheDocument();
  });

  it('should call reverseGeocodeCoordinates when coordinates provided', async () => {
    const mockOnAddressUpdate = jest.fn();
    (locationServices.reverseGeocodeCoordinates as jest.Mock).mockResolvedValue({
      latitude: 47.6062,
      longitude: -122.3321,
      address: '123 Main St',
      city: 'Seattle',
      zipcode: '98101',
      country: 'US',
    });

    render(
      <LocationMap
        address=""
        zipcode=""
        latitude="47.6062"
        longitude="-122.3321"
        onAddressUpdate={mockOnAddressUpdate}
      />
    );

    await waitFor(() => {
      expect(locationServices.reverseGeocodeCoordinates).toHaveBeenCalledWith(47.6062, -122.3321);
    });
  });

  it('should call geocodeAddress when address provided', async () => {
    const mockOnCoordinatesUpdate = jest.fn();
    (locationServices.geocodeAddress as jest.Mock).mockResolvedValue({
      latitude: 47.6062,
      longitude: -122.3321,
      address: '123 Main St',
      city: 'Seattle',
      zipcode: '98101',
      country: 'US',
    });

    render(
      <LocationMap
        address="123 Main St"
        zipcode="98101"
        onCoordinatesUpdate={mockOnCoordinatesUpdate}
      />
    );

    await waitFor(() => {
      expect(locationServices.geocodeAddress).toHaveBeenCalledWith('123 Main St', '98101');
    });
  });

  it('should not render markers when no location provided', () => {
    render(<LocationMap address="" zipcode="" />);
    expect(require('@amzn/global-realty-mosaic-arcgis-client').Map).toHaveBeenCalledWith(
      expect.objectContaining({ markers: [] }),
      expect.anything()
    );
  });

  it('should handle invalid coordinates gracefully', () => {
    render(<LocationMap address="" zipcode="" latitude="invalid" longitude="invalid" />);
    expect(require('@amzn/global-realty-mosaic-arcgis-client').Map).toHaveBeenCalledWith(
      expect.objectContaining({ markers: [] }),
      expect.anything()
    );
  });

  it('should call onCoordinatesUpdate when geocoding address succeeds', async () => {
    const mockOnCoordinatesUpdate = jest.fn();
    (locationServices.geocodeAddress as jest.Mock).mockResolvedValue({
      latitude: 47.6062,
      longitude: -122.3321,
      address: '123 Main St',
      city: 'Seattle',
      zipcode: '98101',
      country: 'US',
    });

    render(
      <LocationMap
        address="123 Main St"
        zipcode="98101"
        onCoordinatesUpdate={mockOnCoordinatesUpdate}
      />
    );

    await waitFor(() => {
      expect(mockOnCoordinatesUpdate).toHaveBeenCalledWith(47.6062, -122.3321);
    });
  });

  it('should call onAddressUpdate when geocoding coordinates succeeds', async () => {
    const mockOnAddressUpdate = jest.fn();
    (locationServices.reverseGeocodeCoordinates as jest.Mock).mockResolvedValue({
      latitude: 47.6062,
      longitude: -122.3321,
      address: '123 Main St',
      city: 'Seattle',
      zipcode: '98101',
      country: 'US',
    });

    render(
      <LocationMap
        address=""
        zipcode=""
        latitude="47.6062"
        longitude="-122.3321"
        onAddressUpdate={mockOnAddressUpdate}
      />
    );

    await waitFor(() => {
      expect(mockOnAddressUpdate).toHaveBeenCalledWith('123 Main St', 'Seattle', '98101', 'US');
    });
  });

  it('should handle geocodeAddress returning null', async () => {
    (locationServices.geocodeAddress as jest.Mock).mockResolvedValue(null);

    render(<LocationMap address="Invalid Address" zipcode="00000" />);

    await waitFor(() => {
      expect(require('@amzn/global-realty-mosaic-arcgis-client').Map).toHaveBeenCalled();
    });
    expect(require('@amzn/global-realty-mosaic-arcgis-client').Map).toHaveBeenCalledWith(
      expect.objectContaining({ markers: [] }),
      expect.anything()
    );
  });
});
