import { render, screen } from '@testing-library/react';
import {
  AnalysisResultCard,
  type AnalysisResult,
} from '../../../components/optimize-design/AnalysisResultCard';

jest.mock('../../../utils/analysisReportGenerator', () => ({
  downloadLightningProtectionReport: jest.fn(),
}));

describe('AnalysisResultCard', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  const mockAnalysis: AnalysisResult = {
    title: 'Test Analysis',
    description: 'Test description',
    riskLevel: 'High',
    costImpact: '$100000',
    timelineImpact: '+2 Weeks',
    project: 'Test Project',
    reportId: 'TEST-001',
    recommendation: 'required',
  };

  it('should render analysis card with all fields', () => {
    render(<AnalysisResultCard analysis={mockAnalysis} />);

    expect(screen.getByText('Test Analysis')).toBeInTheDocument();
    expect(screen.getByText('Test description')).toBeInTheDocument();
    expect(screen.getByText('High')).toBeInTheDocument();
    expect(screen.getByText('$100000')).toBeInTheDocument();
    expect(screen.getByText('+2 Weeks')).toBeInTheDocument();
    expect(screen.getByText('Test Project')).toBeInTheDocument();
    expect(screen.getByText('TEST-001')).toBeInTheDocument();
  });

  it('should show required recommendation', () => {
    render(<AnalysisResultCard analysis={{ ...mockAnalysis, recommendation: 'required' }} />);
    expect(screen.getByText('ACLW Design Guideline Required')).toBeInTheDocument();
  });

  it('should show optional recommendation', () => {
    render(<AnalysisResultCard analysis={{ ...mockAnalysis, recommendation: 'optional' }} />);
    expect(screen.getByText('Optional')).toBeInTheDocument();
  });

  it('should show not-recommended recommendation', () => {
    render(
      <AnalysisResultCard analysis={{ ...mockAnalysis, recommendation: 'not-recommended' }} />
    );
    expect(screen.getByText('Not recommended')).toBeInTheDocument();
  });

  it('should show error state without other fields', () => {
    const errorAnalysis: AnalysisResult = {
      title: 'Lightning Protection',
      description: 'Network error occurred',
      recommendation: 'optional',
      error: true,
    };

    render(<AnalysisResultCard analysis={errorAnalysis} />);

    expect(screen.getByText('Lightning Protection')).toBeInTheDocument();
    expect(screen.getByText('Network error occurred')).toBeInTheDocument();
    expect(screen.queryByText('Risk level')).not.toBeInTheDocument();
    expect(screen.queryByText('Cost impact')).not.toBeInTheDocument();
  });

  it('should show download button when downloadable is true', () => {
    render(<AnalysisResultCard analysis={{ ...mockAnalysis, downloadable: true }} />);
    expect(screen.getByText('Download')).toBeInTheDocument();
  });

  it('should not show download button when downloadable is false', () => {
    render(<AnalysisResultCard analysis={{ ...mockAnalysis, downloadable: false }} />);
    expect(screen.queryByText('Download')).not.toBeInTheDocument();
  });

  it('should not show download button by default', () => {
    render(<AnalysisResultCard analysis={mockAnalysis} />);
    expect(screen.queryByText('Download')).not.toBeInTheDocument();
  });

  it('should show not-required recommendation', () => {
    render(<AnalysisResultCard analysis={{ ...mockAnalysis, recommendation: 'not-required' }} />);
    expect(screen.getByText('ACLW Design Guideline NOT Required')).toBeInTheDocument();
  });

  it('should show guideline link when guidelineUrl is provided', () => {
    render(
      <AnalysisResultCard analysis={{ ...mockAnalysis, guidelineUrl: 'https://example.com' }} />
    );
    expect(screen.getByText('View ACLW Design Guideline')).toBeInTheDocument();
  });

  it('should call downloadLightningProtectionReport when download button is clicked', async () => {
    const { downloadLightningProtectionReport } = require('../../../utils/analysisReportGenerator');
    const lightningAnalysis: AnalysisResult = {
      title: 'Lightning Protection',
      description: 'Test description',
      riskLevel: 'High',
      costImpact: '$50000',
      timelineImpact: '+1 Week',
      project: 'Test Project',
      reportId: 'LP-001',
      recommendation: 'required',
      downloadable: true,
    };

    render(<AnalysisResultCard analysis={lightningAnalysis} />);

    const downloadButton = screen.getByText('Download');
    downloadButton.click();

    expect(downloadLightningProtectionReport).toHaveBeenCalledWith({
      recommendation: 'required',
      riskLevel: 'High',
      costImpact: '$50000',
      timelineImpact: '+1 Week',
      project: 'Test Project',
      reportId: 'LP-001',
    });
  });

  it('should not call download function for non-Lightning Protection analysis', async () => {
    const { downloadLightningProtectionReport } = require('../../../utils/analysisReportGenerator');
    const otherAnalysis: AnalysisResult = {
      title: 'Other Analysis',
      description: 'Test description',
      recommendation: 'required',
      downloadable: true,
    };

    render(<AnalysisResultCard analysis={otherAnalysis} />);

    const downloadButton = screen.getByText('Download');
    downloadButton.click();

    // Should not be called for non-Lightning Protection analyses
    expect(downloadLightningProtectionReport).not.toHaveBeenCalled();
  });

  it('should open guideline URL in new tab when clicked', () => {
    const mockOpen = jest.fn();
    global.window.open = mockOpen;

    render(
      <AnalysisResultCard
        analysis={{ ...mockAnalysis, guidelineUrl: 'https://example.com/guideline' }}
      />
    );

    const guidelineButton = screen.getByText('View ACLW Design Guideline');
    guidelineButton.click();

    expect(mockOpen).toHaveBeenCalledWith('https://example.com/guideline', '_blank');
  });

  it('should not call window.open when guidelineUrl is not provided', () => {
    const mockOpen = jest.fn();
    global.window.open = mockOpen;

    render(<AnalysisResultCard analysis={mockAnalysis} />);

    // No guideline button should exist
    expect(screen.queryByText('View ACLW Design Guideline')).not.toBeInTheDocument();
    expect(mockOpen).not.toHaveBeenCalled();
  });
});
