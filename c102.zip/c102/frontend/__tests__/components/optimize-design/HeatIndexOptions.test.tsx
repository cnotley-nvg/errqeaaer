import { render, screen } from '@testing-library/react';
import { HeatIndexOptions } from '../../../components/optimize-design/HeatIndexOptions';
import type { HeatIndexResult } from '../../../api/lightningProtection';

describe('HeatIndexOptions', () => {
  const mockLevels = [
    { level: 0, hours: 7090, percentage: 80.93 },
    { level: 1, hours: 1119, percentage: 12.77 },
    { level: 2, hours: 342, percentage: 3.9 },
    { level: 3, hours: 197, percentage: 2.25 },
    { level: 4, hours: 12, percentage: 0.14 },
  ];

  it('should recommend Option 1 when hvacRecommendation contains Option 1', () => {
    const heatIndexData: HeatIndexResult = {
      recommendation: 'recommended',
      hvacRecommendation:
        'Option 1 - Natural Ventilation: Basic ventilation and passive cooling are sufficient.',
      riskWithoutMitigation: 'Low risk',
      levels: [
        { level: 0, hours: 8650, percentage: 98.7 },
        { level: 1, hours: 110, percentage: 1.3 },
        { level: 2, hours: 0, percentage: 0 },
        { level: 3, hours: 0, percentage: 0 },
        { level: 4, hours: 0, percentage: 0 },
      ],
      elevation: null,
      operatingHours: null,
      dataAvailable: true,
      error: null,
    };

    render(<HeatIndexOptions heatIndexData={heatIndexData} />);

    const option1Headers = screen.getAllByText(/Option 1 - Natural Ventilation/);
    expect(option1Headers.length).toBeGreaterThan(0);
    expect(screen.getByText('Recommended')).toBeInTheDocument();
  });

  it('should recommend Option 2 when hvacRecommendation contains Option 2', () => {
    const heatIndexData: HeatIndexResult = {
      recommendation: 'recommended',
      hvacRecommendation:
        'Option 2 - Partial Mechanical Cooling: Seasonal rental or targeted cooling in high-heat areas.',
      riskWithoutMitigation: 'Medium risk',
      levels: [
        { level: 0, hours: 7409, percentage: 84.58 },
        { level: 1, hours: 1034, percentage: 11.8 },
        { level: 2, hours: 285, percentage: 3.25 },
        { level: 3, hours: 32, percentage: 0.37 },
        { level: 4, hours: 0, percentage: 0 },
      ],
      elevation: null,
      operatingHours: null,
      dataAvailable: true,
      error: null,
    };

    render(<HeatIndexOptions heatIndexData={heatIndexData} />);

    const option2Headers = screen.getAllByText(/Option 2 - Partial Mechanical Cooling/);
    expect(option2Headers.length).toBeGreaterThan(0);
    expect(screen.getByText('Recommended')).toBeInTheDocument();
  });

  it('should recommend Option 3 when hvacRecommendation contains Option 3', () => {
    const heatIndexData: HeatIndexResult = {
      recommendation: 'recommended',
      hvacRecommendation:
        'Option 3 - Permanent HVAC System: Install mechanical equipment to maintain <85°F during peaks.',
      riskWithoutMitigation: 'High risk',
      levels: mockLevels,
      elevation: null,
      operatingHours: null,
      dataAvailable: true,
      error: null,
    };

    render(<HeatIndexOptions heatIndexData={heatIndexData} />);

    const option3Headers = screen.getAllByText(/Option 3 - Permanent HVAC System/);
    expect(option3Headers.length).toBeGreaterThan(0);
    expect(screen.getByText('Recommended')).toBeInTheDocument();
  });

  it('should display all 3 options', () => {
    const heatIndexData: HeatIndexResult = {
      recommendation: 'recommended',
      hvacRecommendation:
        'Option 1 - Natural Ventilation: Basic ventilation and passive cooling are sufficient.',
      riskWithoutMitigation: 'Low risk',
      levels: mockLevels,
      elevation: null,
      operatingHours: null,
      dataAvailable: true,
      error: null,
    };

    render(<HeatIndexOptions heatIndexData={heatIndexData} />);

    expect(screen.getByText(/Option 1 - Natural Ventilation/)).toBeInTheDocument();
    expect(screen.getByText(/Option 2 - Partial Mechanical Cooling/)).toBeInTheDocument();
    expect(screen.getByText(/Option 3 - Permanent HVAC System/)).toBeInTheDocument();
  });

  it('should highlight Option 1 as recommended', () => {
    const heatIndexData: HeatIndexResult = {
      recommendation: 'recommended',
      hvacRecommendation:
        'Option 1 - Natural Ventilation: Basic ventilation and passive cooling are sufficient.',
      riskWithoutMitigation: 'Low risk',
      levels: mockLevels,
      elevation: null,
      operatingHours: null,
      dataAvailable: true,
      error: null,
    };

    render(<HeatIndexOptions heatIndexData={heatIndexData} />);

    const badges = screen.getAllByText('Recommended');
    expect(badges.length).toBe(1);
  });

  it('should highlight Option 2 as recommended', () => {
    const heatIndexData: HeatIndexResult = {
      recommendation: 'recommended',
      hvacRecommendation:
        'Option 2 - Partial Mechanical Cooling: Seasonal rental or targeted cooling in high-heat areas.',
      riskWithoutMitigation: 'Medium risk',
      levels: mockLevels,
      elevation: null,
      operatingHours: null,
      dataAvailable: true,
      error: null,
    };

    render(<HeatIndexOptions heatIndexData={heatIndexData} />);

    const badges = screen.getAllByText('Recommended');
    expect(badges.length).toBe(1);
  });

  it('should highlight Option 3 as recommended', () => {
    const heatIndexData: HeatIndexResult = {
      recommendation: 'recommended',
      hvacRecommendation:
        'Option 3 - Permanent HVAC System: Install mechanical equipment to maintain <85°F during peaks.',
      riskWithoutMitigation: 'High risk',
      levels: mockLevels,
      elevation: null,
      operatingHours: null,
      dataAvailable: true,
      error: null,
    };

    render(<HeatIndexOptions heatIndexData={heatIndexData} />);

    const badges = screen.getAllByText('Recommended');
    expect(badges.length).toBe(1);
  });
});
