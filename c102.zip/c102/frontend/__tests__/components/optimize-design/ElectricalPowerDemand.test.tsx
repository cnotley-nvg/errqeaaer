import { render, screen, waitFor } from '@testing-library/react';
import { ElectricalPowerDemand } from '../../../components/optimize-design/ElectricalPowerDemand';
import type { ElectricalCalculatorResult } from '../../../api/electricalBenchmark';

const mockElectricalResult: ElectricalCalculatorResult = {
  categoryLoads: [
    {
      category: 'IT Equipment',
      connectedLoad: { kVA: 500, amps: 601 },
      demandDiversityFactor: 0.8,
      diversifiedLoad: { kVA: 400, amps: 481 },
      utilityDemandFactor: 0.9,
      utilityPowerDemand: { kVA: 450, amps: 541 },
    },
  ],
  total: {
    connectedLoad: { kVA: 1000, amps: 1202 },
    diversifiedLoad: { kVA: 800, amps: 962 },
    utilityPowerDemand: { kVA: 900, amps: 1082 },
  },
  o1: { kVA: 1240, amps: 1495 },
  o2: { kVA: 485, amps: 585 },
  o3: { kVA: 755, amps: 910 },
  o4: 800,
  state: 'Washington',
};

describe('ElectricalPowerDemand', () => {
  it('renders error message when error prop is provided', () => {
    render(<ElectricalPowerDemand result={null} error="Lookup table not found" />);

    expect(screen.getByText('Lookup table not found')).toBeInTheDocument();
  });

  it('renders info message when no result is provided', () => {
    render(<ElectricalPowerDemand result={null} />);

    expect(screen.getByText('No electrical data available')).toBeInTheDocument();
  });

  it('renders table with O1, O2, O3 data without units', () => {
    render(<ElectricalPowerDemand result={mockElectricalResult} />);

    // Check headers - kVA and Amps headers exist
    const kvaHeaders = screen.getAllByText('kVA');
    expect(kvaHeaders.length).toBeGreaterThan(0);
    const ampsHeaders = screen.getAllByText(/Amps/);
    expect(ampsHeaders.length).toBeGreaterThan(0);

    // Check O1 row - no units
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
    expect(screen.getAllByText('1,240').length).toBeGreaterThan(0);
    expect(screen.getAllByText('1,495').length).toBeGreaterThan(0);

    // Check O2 row - updated text
    expect(screen.getByText('Estimated rooftop solar size (potential)')).toBeInTheDocument();
    expect(screen.getAllByText('485').length).toBeGreaterThan(0);
    expect(screen.getAllByText('585').length).toBeGreaterThan(0);

    // Check O3 row - updated text
    expect(
      screen.getByText('Utility power demand request (with rooftop solar)')
    ).toBeInTheDocument();
    expect(screen.getAllByText('755').length).toBeGreaterThan(0);
    expect(screen.getAllByText('910').length).toBeGreaterThan(0);
  });

  it('renders O4 switchboard count in single cell with unit label', () => {
    render(<ElectricalPowerDemand result={mockElectricalResult} />);

    // Check O4 row
    expect(
      screen.getByText('Service ratings: number of 480VAC switchboards and their ratings')
    ).toBeInTheDocument();
    expect(screen.getAllByText('755').length).toBeGreaterThan(0);
    expect(screen.getAllByText('910').length).toBeGreaterThan(0);
  });

  it('renders O4 switchboard count in single cell with unit label', () => {
    render(<ElectricalPowerDemand result={mockElectricalResult} />);

    // Check O4 row
    expect(
      screen.getByText('Service ratings: number of 480VAC switchboards and their ratings')
    ).toBeInTheDocument();
    expect(screen.getAllByText('800 Units').length).toBeGreaterThan(0);
  });

  it('formats numbers with thousand separators', () => {
    const largeResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      o1: { kVA: 12400, amps: 14950 },
      o4: 8000,
    };

    render(<ElectricalPowerDemand result={largeResult} />);

    // O1, O2, O3 should not have units
    expect(screen.getAllByText('12,400').length).toBeGreaterThan(0);
    expect(screen.getAllByText('14,950').length).toBeGreaterThan(0);
    // O4 should still have "Units"
    expect(screen.getAllByText('8,000 Units').length).toBeGreaterThan(0);
  });

  it('renders zero values correctly', () => {
    const zeroResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      o2: { kVA: 0, amps: 0 },
      o4: 0,
    };

    render(<ElectricalPowerDemand result={zeroResult} />);

    // Should display 0 for O2 without units
    // Note: screen.getByText('0') will find multiple matches, so we check the structure
    const rows = screen.getAllByText('0');
    expect(rows.length).toBeGreaterThanOrEqual(2); // At least O2 kVA and Amps
    // O4 should have "Units"
    const unitsElements = screen.getAllByText('0 Units');
    expect(unitsElements.length).toBeGreaterThan(0);
  });

  it('renders introductory text', () => {
    render(<ElectricalPowerDemand result={mockElectricalResult} />);

    // Check for the introductory text about electrical utility power demand
    expect(
      screen.getByText(
        /Electrical utility power demand shown below shall be used for site selection/
      )
    ).toBeInTheDocument();
  });

  it('renders the component without crashing when result changes', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    // Update result with changed values
    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      o1: { kVA: 1364, amps: 1644 },
      o3: { kVA: 830, amps: 1001 },
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);

    // Component should render successfully with updated values
    expect(screen.getByText('1,364')).toBeInTheDocument();
    expect(screen.getByText('1,644')).toBeInTheDocument();
  });

  it('renders custom message when error with templateVersionId is provided', () => {
    render(
      <ElectricalPowerDemand
        result={null}
        error="Template not found"
        templateVersionId="template-123"
      />
    );

    expect(
      screen.getByText(/Electrical utility power demand shell be right-sized by Engineer-of-Record/)
    ).toBeInTheDocument();
  });

  it('detects changes in categoryLoads connectedLoad.kVA', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      categoryLoads: [
        {
          ...mockElectricalResult.categoryLoads[0],
          connectedLoad: { kVA: 600, amps: 601 }, // Changed kVA
        },
      ],
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);

    // Component should render without crashing
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in categoryLoads connectedLoad.amps', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      categoryLoads: [
        {
          ...mockElectricalResult.categoryLoads[0],
          connectedLoad: { kVA: 500, amps: 700 }, // Changed amps
        },
      ],
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in categoryLoads demandDiversityFactor', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      categoryLoads: [
        {
          ...mockElectricalResult.categoryLoads[0],
          demandDiversityFactor: 0.9, // Changed from 0.8
        },
      ],
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in categoryLoads diversifiedLoad.kVA', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      categoryLoads: [
        {
          ...mockElectricalResult.categoryLoads[0],
          diversifiedLoad: { kVA: 450, amps: 481 }, // Changed kVA
        },
      ],
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in categoryLoads diversifiedLoad.amps', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      categoryLoads: [
        {
          ...mockElectricalResult.categoryLoads[0],
          diversifiedLoad: { kVA: 400, amps: 500 }, // Changed amps
        },
      ],
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in categoryLoads utilityDemandFactor', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      categoryLoads: [
        {
          ...mockElectricalResult.categoryLoads[0],
          utilityDemandFactor: 0.95, // Changed from 0.9
        },
      ],
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in categoryLoads utilityPowerDemand.kVA', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      categoryLoads: [
        {
          ...mockElectricalResult.categoryLoads[0],
          utilityPowerDemand: { kVA: 500, amps: 541 }, // Changed kVA
        },
      ],
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in categoryLoads utilityPowerDemand.amps', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      categoryLoads: [
        {
          ...mockElectricalResult.categoryLoads[0],
          utilityPowerDemand: { kVA: 450, amps: 600 }, // Changed amps
        },
      ],
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in total.connectedLoad.kVA', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      total: {
        ...mockElectricalResult.total,
        connectedLoad: { kVA: 1100, amps: 1202 }, // Changed kVA
      },
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in total.connectedLoad.amps', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      total: {
        ...mockElectricalResult.total,
        connectedLoad: { kVA: 1000, amps: 1300 }, // Changed amps
      },
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in total.diversifiedLoad.kVA', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      total: {
        ...mockElectricalResult.total,
        diversifiedLoad: { kVA: 850, amps: 962 }, // Changed kVA
      },
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in total.diversifiedLoad.amps', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      total: {
        ...mockElectricalResult.total,
        diversifiedLoad: { kVA: 800, amps: 1000 }, // Changed amps
      },
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in total.utilityPowerDemand.kVA', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      total: {
        ...mockElectricalResult.total,
        utilityPowerDemand: { kVA: 950, amps: 1082 }, // Changed kVA
      },
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in total.utilityPowerDemand.amps', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      total: {
        ...mockElectricalResult.total,
        utilityPowerDemand: { kVA: 900, amps: 1150 }, // Changed amps
      },
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in o2.kVA', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      o2: { kVA: 500, amps: 585 }, // Changed kVA
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in o2.amps', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      o2: { kVA: 485, amps: 600 }, // Changed amps
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('detects changes in o4', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      o4: 850, // Changed from 800
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('handles missing previous category load when detecting changes', () => {
    const { rerender } = render(<ElectricalPowerDemand result={mockElectricalResult} />);

    // Add a new category load that didn't exist before
    const updatedResult: ElectricalCalculatorResult = {
      ...mockElectricalResult,
      categoryLoads: [
        ...mockElectricalResult.categoryLoads,
        {
          category: 'HVAC',
          connectedLoad: { kVA: 200, amps: 240 },
          demandDiversityFactor: 0.7,
          diversifiedLoad: { kVA: 140, amps: 168 },
          utilityDemandFactor: 0.85,
          utilityPowerDemand: { kVA: 170, amps: 204 },
        },
      ],
    };

    rerender(<ElectricalPowerDemand result={updatedResult} />);
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('renders with editable prop', () => {
    const mockOnEditComplete = jest.fn();
    render(
      <ElectricalPowerDemand
        result={mockElectricalResult}
        editable={true}
        onEditComplete={mockOnEditComplete}
      />
    );
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });

  it('renders with roofFactor and solarPowerDensity props', () => {
    render(
      <ElectricalPowerDemand
        result={mockElectricalResult}
        roofFactor={0.75}
        solarPowerDensity={15}
      />
    );
    expect(screen.getByText('Estimate total power demand for the site')).toBeInTheDocument();
  });
});
