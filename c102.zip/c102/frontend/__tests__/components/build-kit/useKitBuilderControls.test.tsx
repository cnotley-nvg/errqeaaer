import { act, renderHook } from '@testing-library/react';

import { useKitBuilderControls } from '../../../components/build-kit/hooks/useKitBuilderControls';

describe('useKitBuilderControls', () => {
  it('updates kit name and invokes interaction callback', () => {
    const onInteraction = jest.fn();
    const { result } = renderHook(() => useKitBuilderControls({ onInteraction }));

    act(() => {
      result.current.handlers.onKitNameChange('Lighting Kit');
    });

    expect(result.current.kitName).toBe('Lighting Kit');
    expect(onInteraction).toHaveBeenCalled();
  });

  it('resets form state', () => {
    const { result } = renderHook(() => useKitBuilderControls());

    act(() => {
      result.current.handlers.onKitNameChange('Example');
      result.current.handlers.onRegionsChange(['NA']);
      result.current.resetForm();
    });

    expect(result.current.kitName).toBe('');
    expect(result.current.selections.regions).toHaveLength(0);
  });
});
