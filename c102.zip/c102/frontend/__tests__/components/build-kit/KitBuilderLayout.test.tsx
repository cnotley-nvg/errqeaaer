import React from 'react';
import { render, screen } from '@testing-library/react';

import { KitBuilderLayout } from '../../../components/build-kit/KitBuilderLayout';

jest.mock('@amzn/awsui-components-console', () => ({
  Link: ({ children }: { children: React.ReactNode }) => <a>{children}</a>,
  SpaceBetween: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));

jest.mock('../../../components/PageLayout', () => ({
  PageLayout: ({ header, children }: { header?: any; children: React.ReactNode }) => (
    <div data-testid="page-layout" data-header-title={header?.title}>
      {header?.actions}
      {children}
    </div>
  ),
}));

describe('KitBuilderLayout', () => {
  it('renders header content and children', () => {
    render(
      <KitBuilderLayout headerActions={<div>Actions</div>}>
        <div>Kit content</div>
      </KitBuilderLayout>
    );

    expect(screen.getByTestId('page-layout')).toHaveAttribute(
      'data-header-title',
      'Build your custom kit'
    );
    expect(screen.getByText('Kit content')).toBeInTheDocument();
    expect(screen.getByText('Actions')).toBeInTheDocument();
  });
});
