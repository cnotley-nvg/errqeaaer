import { act, renderHook } from '@testing-library/react';

import type { KitCompatibleStandard } from '../../../hooks/useKitBuilder';
import { useKitFilters } from '../../../components/build-kit/hooks/useKitFilters';

const mockStandard: KitCompatibleStandard = {
  id: 'standard-1',
  standardId: 'std-001',
  standardName: 'Lighting Standard',
  version: '1.0.0',
  region: 'NA',
  program: ['Prime'],
  useCase: 'Lighting',
  roomFeatureZone: ['Zone A'],
  dataType: 'Electrical',
};

describe('useKitFilters', () => {
  it('normalizes selections and updates selected standards', () => {
    const onInteraction = jest.fn();
    const { result } = renderHook(() =>
      useKitFilters({
        selections: {
          regions: [' NA '],
          programs: ['Prime'],
          projectTypes: ['Lighting'],
          roomFeatureZones: [],
          dataTypes: [],
        },
        onInteraction,
      })
    );

    expect(result.current.filters).toEqual({
      regions: ['NA'],
      programs: ['Prime'],
      projectTypes: ['Lighting'],
    });

    act(() => {
      result.current.registerStandards([mockStandard]);
      result.current.handleSelectionChange([mockStandard]);
    });

    expect(result.current.selectedStandardIds).toEqual(['standard-1']);
    expect(onInteraction).toHaveBeenCalled();

    act(() => {
      result.current.resetSelectedStandards();
    });

    expect(result.current.selectedStandardIds).toHaveLength(0);
  });

  it('clears selections when filters change', () => {
    const { result, rerender } = renderHook(
      ({ regions }: { regions: string[] }) =>
        useKitFilters({
          selections: {
            regions,
            programs: [],
            projectTypes: ['Lighting'],
            roomFeatureZones: [],
            dataTypes: [],
          },
        }),
      { initialProps: { regions: ['NA'] } }
    );

    act(() => {
      result.current.registerStandards([mockStandard]);
      result.current.handleSelectionChange([mockStandard]);
    });

    expect(result.current.selectedStandardIds).toEqual([mockStandard.id]);

    // Change filters -> selections should reset.
    rerender({ regions: ['EU'] });
    expect(result.current.selectedStandardIds).toHaveLength(0);
  });

  it('re-auto-selects compatible standards after filters change (even if previously seen)', () => {
    const { result, rerender } = renderHook(
      ({ projectTypes }: { projectTypes: string[] }) =>
        useKitFilters({
          selections: {
            regions: ['NA'],
            programs: [],
            projectTypes,
            roomFeatureZones: [],
            dataTypes: [],
          },
        }),
      { initialProps: { projectTypes: ['BTS'] } }
    );

    // Initial compatible standards arrive -> auto-selected via registerStandards(newlySeen)
    act(() => {
      result.current.registerStandards([mockStandard]);
    });
    expect(result.current.selectedStandardIds).toEqual([mockStandard.id]);

    // User adds another project type (filters change) -> selection resets
    rerender({ projectTypes: ['BTS', 'Retrofit'] });
    expect(result.current.selectedStandardIds).toHaveLength(0);

    // Compatible standards refresh returns the same standard -> should be auto-selected again
    act(() => {
      result.current.registerStandards([mockStandard]);
    });
    expect(result.current.selectedStandardIds).toEqual([mockStandard.id]);
  });

  it('auto-selects newly seen standards and keeps locked ones on selection change', () => {
    const locked: KitCompatibleStandard = { ...mockStandard, id: 'locked-1' };
    const newlySeen: KitCompatibleStandard = { ...mockStandard, id: 'new-1' };

    const { result } = renderHook(() =>
      useKitFilters({
        selections: {
          regions: ['NA'],
          programs: [],
          projectTypes: ['Lighting'],
          roomFeatureZones: [],
          dataTypes: [],
        },
      })
    );

    act(() => {
      result.current.registerStandards([locked, newlySeen], {
        lockedStandardIds: [locked.id],
      });
    });

    // Newly seen are auto-selected; locked is always selected.
    expect(result.current.selectedStandardIds).toEqual(
      expect.arrayContaining([locked.id, newlySeen.id])
    );

    act(() => {
      // Attempt to drop locked by omitting it from selection change.
      result.current.handleSelectionChange([newlySeen]);
    });

    // Locked stays selected.
    expect(result.current.selectedStandardIds).toEqual(
      expect.arrayContaining([locked.id, newlySeen.id])
    );
  });

  it('drops selections for standards that disappear on refresh', () => {
    const locked: KitCompatibleStandard = { ...mockStandard, id: 'locked-2' };
    const removed: KitCompatibleStandard = { ...mockStandard, id: 'removed-1' };

    const { result } = renderHook(() =>
      useKitFilters({
        selections: {
          regions: ['NA'],
          programs: [],
          projectTypes: ['Lighting'],
          roomFeatureZones: [],
          dataTypes: [],
        },
      })
    );

    act(() => {
      result.current.registerStandards([locked, removed], { lockedStandardIds: [locked.id] });
      result.current.handleSelectionChange([locked, removed]);
    });
    expect(result.current.selectedStandardIds).toEqual([locked.id, removed.id]);

    act(() => {
      result.current.registerStandards([locked], { lockedStandardIds: [locked.id] });
    });

    expect(result.current.selectedStandardIds).toEqual([locked.id]);
  });
});
