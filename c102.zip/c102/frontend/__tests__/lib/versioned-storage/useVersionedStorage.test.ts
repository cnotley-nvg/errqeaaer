/**
 * Tests for useVersionedStorage React hook
 */

import { renderHook, act } from '@testing-library/react';
import { useVersionedStorage } from '../../../lib/versioned-storage/react/useVersionedStorage';

// Mock localStorage
const createMockLocalStorage = () => {
  let store: Record<string, string> = {};

  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value;
    },
    removeItem: (key: string) => {
      delete store[key];
    },
    clear: () => {
      store = {};
    },
    get length() {
      return Object.keys(store).length;
    },
    key: (index: number) => Object.keys(store)[index] || null,
  };
};

describe('useVersionedStorage', () => {
  let mockLocalStorage: ReturnType<typeof createMockLocalStorage>;

  beforeEach(() => {
    mockLocalStorage = createMockLocalStorage();
    Object.defineProperty(global, 'localStorage', {
      value: mockLocalStorage,
      writable: true,
      configurable: true,
    });
  });

  it('should initialize with defaults when no stored data', () => {
    const { result } = renderHook(() =>
      useVersionedStorage({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: { count: 0 },
      })
    );

    const [data] = result.current;
    expect(data).toEqual({ count: 0 });
  });

  it('should load existing data from localStorage', () => {
    mockLocalStorage.setItem(
      'test',
      JSON.stringify({
        version: 1,
        data: { count: 5 },
      })
    );

    const { result } = renderHook(() =>
      useVersionedStorage({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: { count: 0 },
      })
    );

    const [data] = result.current;
    expect(data).toEqual({ count: 5 });
  });

  it('should set data and persist to localStorage', () => {
    const { result } = renderHook(() =>
      useVersionedStorage({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: { value: 'initial' },
      })
    );

    act(() => {
      const [, setData] = result.current;
      setData({ value: 'updated' });
    });

    const [data] = result.current;
    expect(data).toEqual({ value: 'updated' });

    // Check localStorage
    const stored = JSON.parse(mockLocalStorage.getItem('test')!);
    expect(stored.data).toEqual({ value: 'updated' });
  });

  it('should update partial data', () => {
    const { result } = renderHook(() =>
      useVersionedStorage({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: { a: 1, b: 2, c: 3 },
      })
    );

    act(() => {
      const [, , updateData] = result.current;
      updateData({ b: 20 });
    });

    const [data] = result.current;
    expect(data).toEqual({ a: 1, b: 20, c: 3 });
  });

  it('should reset to defaults and clear localStorage', () => {
    // Set some data first
    mockLocalStorage.setItem(
      'test',
      JSON.stringify({
        version: 1,
        data: { value: 'stored' },
      })
    );

    const { result } = renderHook(() =>
      useVersionedStorage({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: { value: 'default' },
      })
    );

    // Should load stored data initially
    expect(result.current[0]).toEqual({ value: 'stored' });

    act(() => {
      const [, , , resetData] = result.current;
      resetData();
    });

    const [data] = result.current;
    expect(data).toEqual({ value: 'default' });
    expect(mockLocalStorage.getItem('test')).toBeNull();
  });

  it('should handle migrations on load', () => {
    mockLocalStorage.setItem(
      'test',
      JSON.stringify({
        version: 0,
        data: { oldField: 'value' },
      })
    );

    const { result } = renderHook(() =>
      useVersionedStorage({
        key: 'test',
        version: 1,
        migrations: [
          {
            from: 0,
            to: 1,
            description: 'Rename field',
            migrate: (old: any) => ({ newField: old.oldField }),
          },
        ],
        defaults: { newField: 'default' },
      })
    );

    const [data] = result.current;
    expect(data).toEqual({ newField: 'value' });
  });

  it('should maintain stable references for setter functions', () => {
    const { result, rerender } = renderHook(() =>
      useVersionedStorage({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: { value: 1 },
      })
    );

    const [, setData1, updateData1, resetData1] = result.current;

    rerender();

    const [, setData2, updateData2, resetData2] = result.current;

    // Functions should be stable across re-renders
    expect(setData1).toBe(setData2);
    expect(updateData1).toBe(updateData2);
    expect(resetData1).toBe(resetData2);
  });
});
