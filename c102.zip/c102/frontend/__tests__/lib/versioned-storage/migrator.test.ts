/**
 * Tests for migration engine
 */

import {
  runMigrations,
  applyTransforms,
  applyTransform,
} from '../../../lib/versioned-storage/core/migrator';
import { MigrationError } from '../../../lib/versioned-storage/core/errors';
import type { Migration } from '../../../lib/versioned-storage/core/types';

describe('migrator', () => {
  describe('runMigrations', () => {
    it('should return data unchanged if already at target version', () => {
      const data = { foo: 'bar' };
      const result = runMigrations(data, 1, [], 1);
      expect(result).toEqual(data);
    });

    it('should apply single migration', () => {
      const data = { old: 'value' };
      const migrations: Migration[] = [
        {
          from: 0,
          to: 1,
          description: 'Test migration',
          migrate: (old: any) => ({ new: old.old }),
        },
      ];

      const result = runMigrations(data, 0, migrations, 1);
      expect(result).toEqual({ new: 'value' });
    });

    it('should apply migration chain (v0→v1→v2)', () => {
      const data = { count: 5 };
      const migrations: Migration[] = [
        {
          from: 0,
          to: 1,
          description: 'Double count',
          migrate: (old: any) => ({ count: old.count * 2 }),
        },
        {
          from: 1,
          to: 2,
          description: 'Add 10',
          migrate: (old: any) => ({ count: old.count + 10 }),
        },
      ];

      const result = runMigrations(data, 0, migrations, 2);
      expect(result).toEqual({ count: 20 }); // 5 * 2 + 10
    });

    it('should throw if migration chain is broken', () => {
      const migrations: Migration[] = [
        { from: 0, to: 1, description: 'v0→v1', migrate: (x) => x },
        { from: 2, to: 3, description: 'v2→v3', migrate: (x) => x }, // Gap!
      ];

      expect(() => runMigrations({}, 0, migrations, 3)).toThrow(MigrationError);
    });

    it('should throw if migration does not increment by 1', () => {
      const migrations: Migration[] = [
        { from: 0, to: 2, description: 'Invalid jump', migrate: (x) => x },
      ];

      expect(() => runMigrations({}, 0, migrations, 2)).toThrow(MigrationError);
    });
  });

  describe('applyTransforms', () => {
    it('should apply function transform', () => {
      const data = { count: 5 };
      const result = applyTransforms(data, {
        count: (val: number) => val * 2,
      });
      expect(result).toEqual({ count: 10 });
    });

    it('should apply rename transform', () => {
      const data = { oldName: 'value' };
      const result = applyTransforms(data, {
        oldName: { rename: 'newName' },
      });
      expect(result).toEqual({ newName: 'value' });
    });

    it('should apply delete transform', () => {
      const data = { keep: 'yes', remove: 'no' };
      const result = applyTransforms(data, {
        remove: { delete: true },
      });
      expect(result).toEqual({ keep: 'yes' });
    });

    it('should apply default transform when field missing', () => {
      const data = { existing: 'value' };
      const result = applyTransforms(data, {
        newField: { default: 'defaultValue' },
      });
      expect(result).toEqual({ existing: 'value', newField: 'defaultValue' });
    });

    it('should not override existing value with default', () => {
      const data = { field: 'existing' };
      const result = applyTransforms(data, {
        field: { default: 'default' },
      });
      expect(result).toEqual({ field: 'existing' });
    });

    it('should apply map transform', () => {
      const data = { status: 'active' };
      const result = applyTransforms(data, {
        status: { map: { active: 'enabled', inactive: 'disabled' } },
      });
      expect(result).toEqual({ status: 'enabled' });
    });

    it('should apply nested transforms', () => {
      const data = { user: { name: 'john', age: 25 } };
      const result = applyTransforms(data, {
        user: {
          nested: {
            age: (val: number) => val + 1,
          },
        },
      });
      expect(result).toEqual({ user: { name: 'john', age: 26 } });
    });
  });

  describe('applyTransform - array notation', () => {
    it('should transform all array items', () => {
      const data = {
        items: [{ value: 10 }, { value: 20 }, { value: 30 }],
      };

      const result = applyTransform(data, 'items[].value', (val: number) => val * 2);

      expect(result).toEqual({
        items: [{ value: 20 }, { value: 40 }, { value: 60 }],
      });
    });

    it('should handle nested array paths', () => {
      const data = {
        cards: {
          breakpoints: [
            { minWidth: 1920, cards: 5 },
            { minWidth: 2560, cards: 6 },
          ],
        },
      };

      const result = applyTransform(data, 'cards.breakpoints[].minWidth', (val: number) => val + 1);

      expect(result).toEqual({
        cards: {
          breakpoints: [
            { minWidth: 1921, cards: 5 },
            { minWidth: 2561, cards: 6 },
          ],
        },
      });
    });

    it('should handle real catalog migration scenario', () => {
      const data = {
        cards: {
          cardsPerRowBreakpoints: [
            { minWidth: 0, cards: 1 },
            { minWidth: 768, cards: 2 },
            { minWidth: 1366, cards: 3 },
            { minWidth: 1920, cards: 5 },
            { minWidth: 2560, cards: 6 },
          ],
        },
      };

      // This is the actual catalog migration: 1920→1921, 2560→2561
      const result = applyTransform(
        data,
        'cards.cardsPerRowBreakpoints[].minWidth',
        (val: number) => {
          if (val === 1920) return 1921;
          if (val === 2560) return 2561;
          return val;
        }
      );

      expect(result.cards.cardsPerRowBreakpoints).toEqual([
        { minWidth: 0, cards: 1 },
        { minWidth: 768, cards: 2 },
        { minWidth: 1366, cards: 3 },
        { minWidth: 1921, cards: 5 }, // ✅ Updated!
        { minWidth: 2561, cards: 6 }, // ✅ Updated!
      ]);
    });
  });
});
