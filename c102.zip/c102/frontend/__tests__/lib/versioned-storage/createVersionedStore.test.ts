/**
 * Tests for createVersionedStore factory function
 */

import { createVersionedStore } from '../../../lib/versioned-storage/factories/createVersionedStore';
import { VersionedStore } from '../../../lib/versioned-storage/core/VersionedStore';

describe('createVersionedStore', () => {
  it('should create a VersionedStore instance', () => {
    const store = createVersionedStore({
      key: 'test',
      version: 1,
      migrations: [],
      defaults: { foo: 'bar' },
    });

    expect(store).toBeInstanceOf(VersionedStore);
  });

  it('should create functional store with all methods', () => {
    const store = createVersionedStore({
      key: 'test-functional',
      version: 1,
      migrations: [],
      defaults: { value: 42 },
    });

    // Check that all expected methods exist
    expect(typeof store.load).toBe('function');
    expect(typeof store.save).toBe('function');
    expect(typeof store.remove).toBe('function');
  });

  it('should create stores with different configurations', () => {
    const store1 = createVersionedStore({
      key: 'store1',
      version: 1,
      migrations: [],
      defaults: { a: 1 },
    });

    const store2 = createVersionedStore({
      key: 'store2',
      version: 2,
      migrations: [],
      defaults: { b: 2 },
    });

    expect(store1).toBeInstanceOf(VersionedStore);
    expect(store2).toBeInstanceOf(VersionedStore);
    // Different instances
    expect(store1).not.toBe(store2);
  });
});
