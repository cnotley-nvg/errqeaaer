/**
 * Tests for VersionedStore class
 */

import { VersionedStore } from '../../../lib/versioned-storage/core/VersionedStore';
import type { Migration, VersionedStoreConfig } from '../../../lib/versioned-storage/core/types';
import {
  validators,
  createStructuralValidator,
} from '../../../lib/versioned-storage/core/validator';

// Mock localStorage
const createMockLocalStorage = () => {
  let store: Record<string, string> = {};

  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value;
    },
    removeItem: (key: string) => {
      delete store[key];
    },
    clear: () => {
      store = {};
    },
    get length() {
      return Object.keys(store).length;
    },
    key: (index: number) => Object.keys(store)[index] || null,
  };
};

describe('VersionedStore', () => {
  let mockLocalStorage: ReturnType<typeof createMockLocalStorage>;

  beforeEach(() => {
    mockLocalStorage = createMockLocalStorage();
    // Properly mock localStorage for Jest environment
    Object.defineProperty(global, 'localStorage', {
      value: mockLocalStorage,
      writable: true,
      configurable: true,
    });
  });

  describe('load()', () => {
    it('should return defaults when no stored data', () => {
      const store = new VersionedStore({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: { foo: 'bar' },
      });

      const result = store.load();

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).toEqual({ foo: 'bar' });
        expect(result.migrated).toBe(false);
      }
    });

    it('should load current version without migration', () => {
      mockLocalStorage.setItem(
        'test',
        JSON.stringify({
          version: 1,
          data: { foo: 'baz' },
        })
      );

      const store = new VersionedStore({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: { foo: 'bar' },
      });

      const result = store.load();

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).toEqual({ foo: 'baz' });
        expect(result.migrated).toBe(false);
      }
    });

    it('should migrate from v0 to v1', () => {
      mockLocalStorage.setItem(
        'test',
        JSON.stringify({
          version: 0,
          data: { oldField: 'value' },
        })
      );

      const migrations: Migration[] = [
        {
          from: 0,
          to: 1,
          description: 'Rename oldField to newField',
          migrate: (old: any) => ({ newField: old.oldField }),
        },
      ];

      const store = new VersionedStore({
        key: 'test',
        version: 1,
        migrations,
        defaults: { newField: 'default' },
      });

      const result = store.load();

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).toEqual({ newField: 'value' });
        expect(result.migrated).toBe(true);

        // Should save migrated data
        const saved = JSON.parse(mockLocalStorage.getItem('test')!);
        expect(saved.version).toBe(1);
        expect(saved.data).toEqual({ newField: 'value' });
      }
    });

    it('should migrate through chain (v0→v1→v2)', () => {
      mockLocalStorage.setItem(
        'test',
        JSON.stringify({
          version: 0,
          data: { count: 5 },
        })
      );

      const migrations: Migration[] = [
        {
          from: 0,
          to: 1,
          description: 'Double count',
          migrate: (old: any) => ({ count: old.count * 2 }),
        },
        {
          from: 1,
          to: 2,
          description: 'Add 10',
          migrate: (old: any) => ({ count: old.count + 10 }),
        },
      ];

      const store = new VersionedStore({
        key: 'test',
        version: 2,
        migrations,
        defaults: { count: 0 },
      });

      const result = store.load();

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).toEqual({ count: 20 }); // 5 * 2 + 10
        expect(result.migrated).toBe(true);
      }
    });

    it('should handle legacy unversioned data as v0', () => {
      // Old data without version wrapper
      mockLocalStorage.setItem('test', JSON.stringify({ oldField: 'value' }));

      const migrations: Migration[] = [
        {
          from: 0,
          to: 1,
          description: 'Add version',
          migrate: (old: any) => ({ newField: old.oldField }),
        },
      ];

      const store = new VersionedStore({
        key: 'test',
        version: 1,
        migrations,
        defaults: { newField: 'default' },
      });

      const result = store.load();

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).toEqual({ newField: 'value' });
        expect(result.migrated).toBe(true);
      }
    });

    it('should fallback to defaults on parse error', () => {
      mockLocalStorage.setItem('test', 'invalid json{');

      const store = new VersionedStore({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: { foo: 'bar' },
      });

      const result = store.load();

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.fallback).toEqual({ foo: 'bar' });
        expect(result.error).toBeDefined();
      }
    });

    it('should deep merge with defaults', () => {
      mockLocalStorage.setItem(
        'test',
        JSON.stringify({
          version: 1,
          data: { nested: { field1: 'value1' } },
        })
      );

      const store = new VersionedStore({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: {
          nested: { field1: 'default1', field2: 'default2' },
          other: 'value',
        },
      });

      const result = store.load();

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).toEqual({
          nested: { field1: 'value1', field2: 'default2' },
          other: 'value',
        });
      }
    });

    it('should call onMigrationSuccess callback', () => {
      mockLocalStorage.setItem(
        'test',
        JSON.stringify({
          version: 0,
          data: { foo: 'bar' },
        })
      );

      const onMigrationSuccess = jest.fn();

      const store = new VersionedStore({
        key: 'test',
        version: 1,
        migrations: [
          {
            from: 0,
            to: 1,
            description: 'Test',
            migrate: (old) => old,
          },
        ],
        defaults: { foo: 'default' },
        onMigrationSuccess,
      });

      store.load();

      expect(onMigrationSuccess).toHaveBeenCalledWith(0, 1);
    });

    it('should call onMigrationError callback on migration failure', () => {
      mockLocalStorage.setItem(
        'test',
        JSON.stringify({
          version: 0,
          data: { foo: 'bar' },
        })
      );

      const onMigrationError = jest.fn();

      const store = new VersionedStore({
        key: 'test',
        version: 1,
        migrations: [
          {
            from: 0,
            to: 1,
            description: 'Test',
            migrate: () => {
              throw new Error('Migration failed');
            },
          },
        ],
        defaults: { foo: 'default' },
        onMigrationError,
      });

      const result = store.load();

      expect(result.success).toBe(false);
      expect(onMigrationError).toHaveBeenCalled();
    });

    it('should use validator if provided', () => {
      interface TestData {
        name: string;
        age: number;
      }

      const validator = createStructuralValidator<TestData>(
        validators.object(
          {
            name: validators.string(true),
            age: validators.number(true),
          },
          true
        )
      );

      mockLocalStorage.setItem(
        'test',
        JSON.stringify({
          version: 1,
          data: { name: 'John', age: 30 },
        })
      );

      const store = new VersionedStore<TestData>({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: { name: 'Unknown', age: 0 },
        validator,
      });

      const result = store.load();

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data.name).toBe('John');
        expect(result.data.age).toBe(30);
      }
    });

    it('should merge with defaults on validation failure', () => {
      interface TestData {
        name: string;
        age: number;
      }

      const validator = createStructuralValidator<TestData>(
        validators.object(
          {
            name: validators.string(true),
            age: validators.number(true),
          },
          true
        )
      );

      // Invalid data - missing age
      mockLocalStorage.setItem(
        'test',
        JSON.stringify({
          version: 1,
          data: { name: 'John' },
        })
      );

      const store = new VersionedStore<TestData>({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: { name: 'Unknown', age: 0 },
        validator,
      });

      const result = store.load();

      expect(result.success).toBe(true);
      if (result.success) {
        // Should merge invalid data with defaults
        expect(result.data.name).toBe('John');
        expect(result.data.age).toBe(0); // From defaults
      }
    });
  });

  describe('save()', () => {
    it('should save data with version wrapper', () => {
      const store = new VersionedStore({
        key: 'test',
        version: 2,
        migrations: [],
        defaults: { foo: 'bar' },
      });

      const success = store.save({ foo: 'baz' });

      expect(success).toBe(true);

      const saved = JSON.parse(mockLocalStorage.getItem('test')!);
      expect(saved).toEqual({
        version: 2,
        data: { foo: 'baz' },
      });
    });

    it('should return false on quota exceeded', () => {
      // Mock setItem to throw quota error
      mockLocalStorage.setItem = jest.fn(() => {
        throw new Error('QuotaExceededError');
      });

      const store = new VersionedStore({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: { foo: 'bar' },
      });

      const success = store.save({ foo: 'baz' });

      expect(success).toBe(false);
    });
  });

  describe('remove()', () => {
    it('should remove data from localStorage', () => {
      mockLocalStorage.setItem('test', 'some data');

      const store = new VersionedStore({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: { foo: 'bar' },
      });

      store.remove();

      expect(mockLocalStorage.getItem('test')).toBeNull();
    });

    it('should not throw on remove error', () => {
      // Mock removeItem to throw
      mockLocalStorage.removeItem = jest.fn(() => {
        throw new Error('Remove failed');
      });

      const store = new VersionedStore({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: { foo: 'bar' },
      });

      expect(() => store.remove()).not.toThrow();
    });
  });

  describe('deep merge', () => {
    it('should merge nested objects correctly', () => {
      const store = new VersionedStore({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: {
          level1: {
            level2: {
              field1: 'default1',
              field2: 'default2',
            },
            other: 'value',
          },
        },
      });

      mockLocalStorage.setItem(
        'test',
        JSON.stringify({
          version: 1,
          data: {
            level1: {
              level2: {
                field1: 'custom',
              },
            },
          },
        })
      );

      const result = store.load();

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).toEqual({
          level1: {
            level2: {
              field1: 'custom',
              field2: 'default2',
            },
            other: 'value',
          },
        });
      }
    });

    it('should replace arrays (not merge)', () => {
      const store = new VersionedStore({
        key: 'test',
        version: 1,
        migrations: [],
        defaults: {
          items: [1, 2, 3],
        },
      });

      mockLocalStorage.setItem(
        'test',
        JSON.stringify({
          version: 1,
          data: {
            items: [4, 5],
          },
        })
      );

      const result = store.load();

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data.items).toEqual([4, 5]); // Replaced, not merged
      }
    });
  });
});
