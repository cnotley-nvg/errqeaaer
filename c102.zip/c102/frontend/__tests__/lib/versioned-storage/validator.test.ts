/**
 * Tests for validation system
 */

import {
  createStructuralValidator,
  passThroughValidator,
  validators,
} from '../../../lib/versioned-storage/core/validator';
import type { ValidationSchema } from '../../../lib/versioned-storage/core/types';

describe('validator', () => {
  describe('passThroughValidator', () => {
    it('should always return true', () => {
      expect(passThroughValidator(null)).toBe(true);
      expect(passThroughValidator(undefined)).toBe(true);
      expect(passThroughValidator(123)).toBe(true);
      expect(passThroughValidator('string')).toBe(true);
      expect(passThroughValidator({})).toBe(true);
      expect(passThroughValidator([])).toBe(true);
    });
  });

  describe('validators helpers', () => {
    it('should create string schema', () => {
      expect(validators.string()).toEqual({ type: 'string', required: false });
      expect(validators.string(true)).toEqual({ type: 'string', required: true });
    });

    it('should create number schema', () => {
      expect(validators.number()).toEqual({ type: 'number', required: false });
      expect(validators.number(true)).toEqual({ type: 'number', required: true });
    });

    it('should create boolean schema', () => {
      expect(validators.boolean()).toEqual({ type: 'boolean', required: false });
      expect(validators.boolean(true)).toEqual({ type: 'boolean', required: true });
    });

    it('should create array schema', () => {
      const itemSchema = validators.string();
      const result = validators.array(itemSchema);
      expect(result).toEqual({
        type: 'array',
        items: itemSchema,
        required: false,
      });
    });

    it('should create object schema', () => {
      const properties = {
        name: validators.string(true),
        age: validators.number(),
      };
      const result = validators.object(properties);
      expect(result).toEqual({
        type: 'object',
        properties,
        required: false,
      });
    });

    it('should create any schema', () => {
      expect(validators.any()).toEqual({ type: 'any', required: false });
      expect(validators.any(true)).toEqual({ type: 'any', required: true });
    });
  });

  describe('createStructuralValidator', () => {
    describe('primitive types', () => {
      it('should validate string', () => {
        const validate = createStructuralValidator<string>(validators.string(true));
        expect(validate('hello')).toBe(true);
        expect(validate(123)).toBe(false);
        expect(validate(null)).toBe(false);
      });

      it('should validate number', () => {
        const validate = createStructuralValidator<number>(validators.number(true));
        expect(validate(123)).toBe(true);
        expect(validate(0)).toBe(true);
        expect(validate('123')).toBe(false);
        expect(validate(NaN)).toBe(false);
      });

      it('should validate boolean', () => {
        const validate = createStructuralValidator<boolean>(validators.boolean(true));
        expect(validate(true)).toBe(true);
        expect(validate(false)).toBe(true);
        expect(validate(0)).toBe(false);
        expect(validate('true')).toBe(false);
      });
    });

    describe('required vs optional', () => {
      it('should require field when required=true', () => {
        const schema: ValidationSchema = { type: 'string', required: true };
        const validate = createStructuralValidator<string>(schema);
        expect(validate(undefined)).toBe(false);
        expect(validate(null)).toBe(false);
        expect(validate('value')).toBe(true);
      });

      it('should allow undefined/null when required=false', () => {
        const schema: ValidationSchema = { type: 'string', required: false };
        const validate = createStructuralValidator<string | undefined>(schema);
        expect(validate(undefined)).toBe(true);
        expect(validate(null)).toBe(true);
        expect(validate('value')).toBe(true);
      });
    });

    describe('arrays', () => {
      it('should validate array of strings', () => {
        const validate = createStructuralValidator<string[]>(
          validators.array(validators.string(true), true)
        );
        expect(validate(['a', 'b', 'c'])).toBe(true);
        expect(validate([])).toBe(true);
        expect(validate(['a', 123])).toBe(false); // Mixed types
        expect(validate('not array')).toBe(false);
      });

      it('should validate array of objects', () => {
        const validate = createStructuralValidator<Array<{ id: string; count: number }>>(
          validators.array(
            validators.object(
              {
                id: validators.string(true),
                count: validators.number(true),
              },
              true
            ),
            true
          )
        );

        expect(
          validate([
            { id: 'a', count: 1 },
            { id: 'b', count: 2 },
          ])
        ).toBe(true);

        expect(
          validate([
            { id: 'a', count: 1 },
            { id: 'b' }, // Missing count
          ])
        ).toBe(false);
      });
    });

    describe('objects', () => {
      it('should validate simple object', () => {
        interface User {
          name: string;
          age: number;
        }

        const validate = createStructuralValidator<User>(
          validators.object(
            {
              name: validators.string(true),
              age: validators.number(true),
            },
            true
          )
        );

        expect(validate({ name: 'John', age: 30 })).toBe(true);
        expect(validate({ name: 'John' })).toBe(false); // Missing age
        expect(validate({ name: 123, age: 30 })).toBe(false); // Wrong type
      });

      it('should validate nested objects', () => {
        interface User {
          profile: {
            name: string;
            age: number;
          };
        }

        const validate = createStructuralValidator<User>(
          validators.object(
            {
              profile: validators.object(
                {
                  name: validators.string(true),
                  age: validators.number(true),
                },
                true
              ),
            },
            true
          )
        );

        expect(
          validate({
            profile: { name: 'John', age: 30 },
          })
        ).toBe(true);

        expect(
          validate({
            profile: { name: 'John' },
          })
        ).toBe(false); // Missing age in nested object
      });

      it('should allow extra properties', () => {
        const validate = createStructuralValidator<{ name: string }>(
          validators.object(
            {
              name: validators.string(true),
            },
            true
          )
        );

        // Extra properties are allowed (structural validation only)
        expect(
          validate({
            name: 'John',
            extra: 'property',
          })
        ).toBe(true);
      });
    });

    describe('complex real-world scenario', () => {
      it('should validate catalog preferences structure', () => {
        interface CatalogPreferences {
          table: {
            contentDisplay: Array<{ id: string; visible: boolean }>;
            wrapLines: boolean;
          };
          cards: {
            cardsPerRowBreakpoints: Array<{ minWidth: number; cards: number }>;
          };
        }

        const schema = validators.object(
          {
            table: validators.object(
              {
                contentDisplay: validators.array(
                  validators.object(
                    {
                      id: validators.string(true),
                      visible: validators.boolean(true),
                    },
                    true
                  ),
                  true
                ),
                wrapLines: validators.boolean(true),
              },
              true
            ),
            cards: validators.object(
              {
                cardsPerRowBreakpoints: validators.array(
                  validators.object(
                    {
                      minWidth: validators.number(true),
                      cards: validators.number(true),
                    },
                    true
                  ),
                  true
                ),
              },
              true
            ),
          },
          true
        );

        const validate = createStructuralValidator<CatalogPreferences>(schema);

        // Valid data
        expect(
          validate({
            table: {
              contentDisplay: [
                { id: 'name', visible: true },
                { id: 'region', visible: false },
              ],
              wrapLines: false,
            },
            cards: {
              cardsPerRowBreakpoints: [
                { minWidth: 0, cards: 1 },
                { minWidth: 1920, cards: 5 },
              ],
            },
          })
        ).toBe(true);

        // Invalid: missing table.wrapLines
        expect(
          validate({
            table: {
              contentDisplay: [],
            },
            cards: {
              cardsPerRowBreakpoints: [],
            },
          })
        ).toBe(false);

        // Invalid: wrong type in nested array
        expect(
          validate({
            table: {
              contentDisplay: [
                { id: 'name', visible: 'yes' }, // Wrong type
              ],
              wrapLines: false,
            },
            cards: {
              cardsPerRowBreakpoints: [],
            },
          })
        ).toBe(false);
      });
    });

    describe('any type', () => {
      it('should accept any value', () => {
        const validate = createStructuralValidator<any>(validators.any(true));
        expect(validate('string')).toBe(true);
        expect(validate(123)).toBe(true);
        expect(validate(true)).toBe(true);
        expect(validate({})).toBe(true);
        expect(validate([])).toBe(true);
        expect(validate(null)).toBe(false); // Still requires non-null if required=true
      });
    });
  });
});
