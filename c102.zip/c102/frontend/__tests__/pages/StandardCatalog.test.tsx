import React from 'react';
import { MemoryRouter } from 'react-router-dom';
import { render } from '@testing-library/react';
jest.mock('../../components/PageLayout', () => ({
  PageLayout: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));

jest.mock('../../components/standards/catalog/StandardCardList', () => ({
  StandardCardList: () => <div data-testid="standard-card-list" />,
}));

jest.mock('../../components/standards/catalog/StandardTable', () => ({
  StandardTable: () => <div data-testid="standard-table" />,
}));

import { StandardCatalog } from '../../pages/StandardCatalog';

const catalogSearchBarMock = jest.fn((_props: unknown) => <div data-testid="catalog-search-bar" />);

jest.mock('../../components/shared/CatalogSearchBar', () => ({
  CatalogSearchBar: (props: unknown) => catalogSearchBarMock(props),
}));

jest.mock('../../hooks/useLatestStandardVersionsSearch', () => ({
  useLatestStandardVersionsSearch: () => ({
    items: [
      {
        id: 'std-1',
        name: 'Standard 1',
        description: null,
        accProjectId: 'proj-1',
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        latestVersion: {
          id: 'std-1-v1',
          version: '1.0',
          isLatest: true,
          createdAt: '2025-01-01T00:00:00.000Z',
          updatedAt: '2025-01-01T00:00:00.000Z',
          attributes: {
            region: 'NA',
            projectType: 'Operations',
            program: ['ARS', 'AMZL', 'DSC'],
          },
        },
      },
    ],
    loading: false,
    error: null,
    totalCount: 1,
    totalPages: 1,
    pageIdx: 0,
    refetch: jest.fn(),
  }),
}));

jest.mock('../../hooks/useStandardCatalogControls', () => {
  const actual = jest.requireActual('../../hooks/useStandardCatalogControls');
  return {
    ...actual,
    useStandardCatalogControls: () => ({
      viewType: 'card',
      propertyFilterQuery: { operation: 'and', tokens: [], tokenGroups: [] },
      sortingField: 'name',
      sortingDescending: false,
      pageIndex: 1,
      pageSize: 20,
      filterInput: {
        pageIdx: 0,
        limit: 25,
        orderBy: 'name',
        orderDesc: false,
        query: undefined,
      },
      handleViewTypeChange: jest.fn(),
      handlePropertyFilterChange: jest.fn(),
      handleSortingChange: jest.fn(),
      handlePageChange: jest.fn(),
      handlePageSizeChange: jest.fn(),
    }),
  };
});

jest.mock('../../hooks/useStandardFilterOptionsFromBackend', () => ({
  useStandardFilterOptionsFromBackend: () => ({
    filteringOptions: [
      { propertyKey: 'name', value: 'Standard 1', label: 'Standard 1' },
      { propertyKey: 'region', value: 'NA', label: 'NA' },
      { propertyKey: 'projectType', value: 'Operations', label: 'Operations' },
      { propertyKey: 'program', value: 'ARS', label: 'ARS' },
      { propertyKey: 'program', value: 'AMZL', label: 'AMZL' },
      { propertyKey: 'program', value: 'DSC', label: 'DSC' },
    ],
    loading: false,
    error: null,
  }),
}));

describe('StandardCatalog page', () => {
  it('passes dynamic filtering options to CatalogSearchBar', () => {
    render(
      <MemoryRouter
        initialEntries={['/standards']}
        future={{
          v7_startTransition: true,
          v7_relativeSplatPath: true,
        }}
      >
        <StandardCatalog />
      </MemoryRouter>
    );

    expect(catalogSearchBarMock).toHaveBeenCalledWith(
      expect.objectContaining({
        filteringOptions: expect.arrayContaining([
          expect.objectContaining({ propertyKey: 'name', value: 'Standard 1' }),
          expect.objectContaining({ propertyKey: 'region', value: 'NA' }),
          expect.objectContaining({ propertyKey: 'projectType', value: 'Operations' }),
          expect.objectContaining({ propertyKey: 'program', value: 'ARS' }),
          expect.objectContaining({ propertyKey: 'program', value: 'AMZL' }),
          expect.objectContaining({ propertyKey: 'program', value: 'DSC' }),
        ]),
      })
    );
  });
});
