import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import HomePage from '../../pages/HomePage';

const mockNavigate = jest.fn();

jest.mock('react-router-dom', () => ({
  useNavigate: () => mockNavigate,
}));

jest.mock('../../components/PageLayout', () => ({
  PageLayout: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));

describe('HomePage', () => {
  beforeEach(() => {
    mockNavigate.mockClear();
  });

  it('navigates to templates when Design Managers button is clicked', () => {
    render(<HomePage />);

    const button = screen.getByText('Explore design templates');
    fireEvent.click(button);

    expect(mockNavigate).toHaveBeenCalledWith('/templates');
  });

  it('navigates to generator when Transaction Managers button is clicked', () => {
    render(<HomePage />);

    const button = screen.getByText('Explore design generator');
    fireEvent.click(button);

    expect(mockNavigate).toHaveBeenCalledWith('/design-generator');
  });

  it('navigates to build when Pre-Construction & Construction button is clicked', () => {
    render(<HomePage />);

    const button = screen.getByText('Explore build a kit');
    fireEvent.click(button);

    expect(mockNavigate).toHaveBeenCalledWith('/build-kit');
  });

  it('navigates to standards when Amazon Stakeholders button is clicked', () => {
    render(<HomePage />);

    const button = screen.getByText('Explore standards');
    fireEvent.click(button);

    expect(mockNavigate).toHaveBeenCalledWith('/standards');
  });
});
