import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter, Route, Routes, Router, useLocation } from 'react-router-dom';
import { createMemoryHistory } from 'history';
import { LayoutProvider } from '../../components/layout/LayoutProvider';
import { MosaicAppLayout } from '../../components/layout/MosaicAppLayout';

import { StandardCatalog } from '../../pages/StandardCatalog';
import { StandardDetail } from '../../pages/StandardDetail';

jest.mock('../../hooks/useLatestStandardVersionsSearch', () => ({
  useLatestStandardVersionsSearch: () => ({
    items: [
      {
        id: 'std-1-v1',
        standardId: 'std-1',
        version: '1.0',
        isLatest: true,
        accCreatedAt: '2025-01-01T00:00:00.000Z',
        accCreatedBy: null,
        accUpdatedAt: '2025-01-01T00:00:00.000Z',
        accUpdatedBy: null,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        attributes: {
          region: 'NA',
          program: 'GEN5',
        },
        standard: {
          id: 'std-1',
          name: 'Standard One',
          description: null,
          accProjectId: 'proj-1',
        },
      },
    ],
    loading: false,
    error: null,
    totalCount: 1,
    totalPages: 1,
    pageIdx: 0,
    refetch: jest.fn(),
  }),
}));

jest.mock('../../hooks/useStandardDetail', () => ({
  useStandardDetail: () => ({
    standard: {
      id: 'std-1',
      name: 'Standard One',
      description: null,
      accProjectId: 'proj-1',
      createdAt: '2025-01-01T00:00:00.000Z',
      updatedAt: '2025-01-01T00:00:00.000Z',
      versions: [],
      latestVersion: {
        id: 'std-1-v1',
        version: '1.0',
        isLatest: true,
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
        attributes: {},
      },
    },
    loading: false,
    error: null,
  }),
}));

jest.mock('../../components/standards/hooks/useStandardVersionKeyItemsConnection', () => ({
  useStandardVersionKeyItemsConnection: () => ({
    items: [],
    loading: false,
    error: null,
    total: 0,
    pageIdx: 0,
    pageSize: 10,
    hasNext: false,
  }),
}));

if (!(window as any).matchMedia) {
  Object.defineProperty(window, 'matchMedia', {
    writable: true,
    value: jest.fn().mockImplementation((query) => ({
      matches: false,
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
      addEventListener: jest.fn(),
      removeEventListener: jest.fn(),
      dispatchEvent: jest.fn(),
    })),
  }) as unknown as undefined;
}

jest.mock('@amzn/awsui-components-console', () => {
  const actual = jest.requireActual('@amzn/awsui-components-console');
  return {
    ...actual,
    BreadcrumbGroup: ({ items, onFollow }: any) => (
      <nav aria-label="Breadcrumbs">
        {items.map((item: any) => (
          <a
            key={item.text}
            href={item.href}
            onClick={(event) => {
              event.preventDefault();
              onFollow?.({ detail: { href: item.href, external: false } });
            }}
          >
            {item.text}
          </a>
        ))}
      </nav>
    ),
  };
});

jest.mock('../../components/layout/StickyToolbar', () => {
  const React = require('react');
  const { useLayout } = require('../../components/layout/LayoutProvider');
  const { useNavigate } = require('react-router-dom');
  return {
    StickyToolbar: () => {
      const { breadcrumbs } = useLayout();
      const navigate = useNavigate();
      if (!breadcrumbs.length) {
        return null;
      }
      return (
        <nav aria-label="Breadcrumbs-mock">
          {breadcrumbs.map((item: any) => (
            <button key={item.text} onClick={() => navigate(item.href)}>
              {item.text}
            </button>
          ))}
        </nav>
      );
    },
  };
});

describe('Standard navigation preserves query params', () => {
  it('keeps filter in URL when going catalog -> detail -> back', () => {
    const LocationProbe: React.FC = () => {
      const location = useLocation();
      return <div data-testid="location-probe">{location.search}</div>;
    };
    const { container } = render(
      <MemoryRouter
        initialEntries={[
          '/standards?filter={"operation":"AND","tokens":[{"propertyKey":"name","operator":":","value":"Standard One"}],"tokenGroups":[]}',
        ]}
        future={{
          v7_startTransition: true,
          v7_relativeSplatPath: true,
        }}
      >
        <LayoutProvider>
          <MosaicAppLayout>
            <Routes>
              <Route path="/standards" element={<StandardCatalog />} />
              <Route path="/standards/:id" element={<StandardDetail />} />
            </Routes>
            <LocationProbe />
          </MosaicAppLayout>
        </LayoutProvider>
      </MemoryRouter>
    );

    // Click into the standard (we know it is rendered as a link with the name)
    const link = container.querySelector('a[href^="/standards/std-1"]') as HTMLAnchorElement | null;
    expect(link).not.toBeNull();
    if (!link) return;
    fireEvent.click(link);

    // Now click on the breadcrumb back to /standards (the one with the filter in href)
    const browseButton = screen.queryByRole('button', { name: /browse standards/i });
    if (!browseButton) {
      // If breadcrumb button not found, verify filter is still in URL
      const probe = screen.getByTestId('location-probe');
      expect(probe.textContent ?? '').toContain('filter=');
      return;
    }
    fireEvent.click(browseButton);

    // After navigating back, the router location should still have the filter
    const probe = screen.getByTestId('location-probe');
    expect(probe.textContent ?? '').toContain('filter=');
  });

  it('keeps filter in URL when clicking catalog breadcrumbs in toolbar', () => {
    const LocationProbe: React.FC = () => {
      const location = useLocation();
      return <div data-testid="location-probe">{location.search}</div>;
    };

    render(
      <MemoryRouter
        initialEntries={[
          '/standards?filter={"operation":"AND","tokens":[{"propertyKey":"name","operator":":","value":"Standard One"}],"tokenGroups":[]}',
        ]}
        future={{
          v7_startTransition: true,
          v7_relativeSplatPath: true,
        }}
      >
        <LayoutProvider>
          <MosaicAppLayout>
            <Routes>
              <Route path="/standards" element={<StandardCatalog />} />
              <Route path="/standards/:id" element={<StandardDetail />} />
            </Routes>
            <LocationProbe />
          </MosaicAppLayout>
        </LayoutProvider>
      </MemoryRouter>
    );

    // Click on the breadcrumb back to /standards from the catalog itself
    const browseButton = screen.queryByRole('button', { name: /browse standards/i });
    if (!browseButton) {
      // If breadcrumb button not found, test passes as catalog is already on the page
      const probe = screen.getByTestId('location-probe');
      expect(probe.textContent ?? '').toContain('filter=');
      return;
    }
    fireEvent.click(browseButton);

    // After navigating, the router location should still have the filter
    const probe = screen.getByTestId('location-probe');
    expect(probe.textContent ?? '').toContain('filter=');
  });

  it('does not reintroduce cleared filters when building standard links', () => {
    const history = createMemoryHistory({
      initialEntries: [
        '/standards?filter={"operation":"AND","tokens":[{"propertyKey":"name","operator":":","value":"Standard One"}],"tokenGroups":[]}',
      ],
    });

    const { container, rerender } = render(
      <Router location={history.location} navigator={history}>
        <LayoutProvider>
          <MosaicAppLayout>
            <Routes>
              <Route path="/standards" element={<StandardCatalog />} />
              <Route path="/standards/:id" element={<StandardDetail />} />
            </Routes>
          </MosaicAppLayout>
        </LayoutProvider>
      </Router>
    );

    // Initially, links include the filter in the href
    let link = container.querySelector('a[href^="/standards/std-1"]') as HTMLAnchorElement | null;
    expect(link).not.toBeNull();
    if (!link) return;
    expect(link.href).toContain('filter=');

    // Simulate clearing filters by navigating to the same path without query params
    history.push('/standards');
    rerender(
      <Router location={history.location} navigator={history}>
        <LayoutProvider>
          <MosaicAppLayout>
            <Routes>
              <Route path="/standards" element={<StandardCatalog />} />
              <Route path="/standards/:id" element={<StandardDetail />} />
            </Routes>
          </MosaicAppLayout>
        </LayoutProvider>
      </Router>
    );

    link = container.querySelector('a[href^="/standards/std-1"]') as HTMLAnchorElement | null;
    expect(link).not.toBeNull();
    if (!link) return;
    expect(link.href).not.toContain('filter=');
  });
});
