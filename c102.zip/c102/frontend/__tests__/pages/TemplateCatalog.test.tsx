import React from 'react';
import { render } from '@testing-library/react';

import { TemplateCatalog } from '../../pages/TemplateCatalog';
jest.mock('react-router-dom', () => ({
  useLocation: () => ({
    pathname: '/templates',
    search: '',
    hash: '',
    state: null,
  }),
  useNavigate: () => jest.fn(),
}));

const catalogSearchBarMock = jest.fn((_props: unknown) => <div data-testid="catalog-search-bar" />);

jest.mock('../../components/shared/CatalogSearchBar', () => ({
  CatalogSearchBar: (props: unknown) => catalogSearchBarMock(props),
}));

jest.mock('../../components/PageLayout', () => ({
  PageLayout: ({ children }: { children: React.ReactNode }) => <div>{children}</div>,
}));

const templateCatalogToolbarMock = jest.fn((_props: unknown) => (
  <div data-testid="template-catalog-toolbar" />
));

jest.mock('../../components/templates', () => ({
  TemplateCardList: () => <div data-testid="template-card-list" />,
  TemplateTable: () => <div data-testid="template-table" />,
  TemplateCatalogToolbar: (props: unknown) => templateCatalogToolbarMock(props),
  useTemplateTablePreferences: () => ({
    preferences: { pageSize: 10, contentDisplay: [] },
    setPreferences: jest.fn(),
    resetPreferences: jest.fn(),
    columnOptions: [],
    pageSizeOptions: [],
    preferencesKey: 0,
  }),
  useTemplateCardPreferences: () => ({
    preferences: { pageSize: 12, contentDisplay: [] },
    setPreferences: jest.fn(),
    resetPreferences: jest.fn(),
    fieldOptions: [],
    pageSizeOptions: [],
    preferencesKey: 0,
  }),
}));

// Create stable mock objects inside factory to prevent infinite re-renders
const mockResult = {
  viewType: 'card' as const,
  sortingField: 'name' as const,
  sortingDescending: false,
  pageIndex: 1,
  filterInput: {
    pageIdx: 0,
    limit: 20,
    orderBy: 'name' as const,
    orderDesc: false,
    query: undefined,
  },
  searchValue: '',
  selectedType: undefined,
  propertyFilterQuery: { tokens: [], operation: 'and' as const },
  handleViewTypeChange: jest.fn(),
  handleSortingChange: jest.fn(),
  handlePageChange: jest.fn(),
  handlePageSizeChange: jest.fn(),
  handleSearchChange: jest.fn(),
  handlePropertyFilterTokensChange: jest.fn(),
  handleTypeChange: jest.fn(),
};

jest.mock('../../hooks/useTemplateCatalogControls', () => ({
  useTemplateCatalogControls: () => mockResult,
}));

const mockSearchResult = {
  items: [
    {
      id: 'tpl-1-v1',
      version: '1.0',
      isLatest: true,
      accFolderId: 'folder-1',
      brsId: null,
      createdAt: '2025-01-01T00:00:00.000Z',
      updatedAt: '2025-01-01T00:00:00.000Z',
      attributes: {},
      files: [],
      template: {
        id: 'tpl-1',
        name: 'Template A',
        description: null,
        accProjectId: 'proj-1',
        createdAt: '2025-01-01T00:00:00.000Z',
        updatedAt: '2025-01-01T00:00:00.000Z',
      },
    },
  ],
  loading: false,
  error: null,
  totalCount: 1,
  totalPages: 1,
  pageIdx: 0,
  limit: 20,
  refetch: jest.fn(),
};

jest.mock('../../hooks/useLatestTemplateVersionsSearch', () => ({
  useLatestTemplateVersionsSearch: () => mockSearchResult,
}));

jest.mock('../../hooks/useTemplateFilterOptions', () => ({
  useTemplateFilterOptions: jest.fn(() => ({
    filteringOptions: [],
    loading: false,
    error: null,
  })),
  ALL_TEMPLATE_FILTER_FIELDS: [
    'name',
    'region',
    'facilityType',
    'program',
    'businessUnit',
    'generation',
    'createdBy',
    'version',
  ],
}));

describe('TemplateCatalog page', () => {
  it('renders TemplateCatalogToolbar with property filter props', () => {
    render(<TemplateCatalog />);

    expect(templateCatalogToolbarMock).toHaveBeenCalledWith(
      expect.objectContaining({
        propertyFilterQuery: expect.objectContaining({
          operation: expect.any(String),
          tokens: expect.any(Array),
        }),
        onPropertyFilterTokensChange: expect.any(Function),
        onSearchChange: expect.any(Function),
        onViewChange: expect.any(Function),
      })
    );
  });

  it('renders TemplateCatalogToolbar with pagination and preferences controls', () => {
    render(<TemplateCatalog />);

    expect(templateCatalogToolbarMock).toHaveBeenCalledWith(
      expect.objectContaining({
        paginationControl: null, // null when totalPages <= 1
        preferencesControl: expect.anything(), // shown for both card and table views
      })
    );
  });
});
