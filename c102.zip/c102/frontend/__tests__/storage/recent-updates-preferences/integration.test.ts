/**
 * @jest-environment jsdom
 *
 * Integration tests for Recent Updates Preferences storage
 * Tests end-to-end flow including validation and store operations
 */

import {
  recentUpdatesPreferencesStore,
  DEFAULT_RECENT_UPDATES_PREFERENCES,
} from '../../../storage/recent-updates-preferences';

describe('Recent Updates Preferences Integration', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  describe('Recent Updates Store', () => {
    it('should initialize with defaults when no data exists', () => {
      const result = recentUpdatesPreferencesStore.load();

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).toEqual(DEFAULT_RECENT_UPDATES_PREFERENCES);
        expect(result.migrated).toBe(false);
      }
    });

    it('should persist and retrieve preferences', () => {
      const customPrefs = {
        pageSize: 20,
        wrapLines: false,
        stripedRows: true,
        contentDisplay: [
          { id: 'details', visible: true },
          { id: 'message', visible: false },
          { id: 'createdBy', visible: true },
          { id: 'createdAt', visible: true },
          { id: 'status', visible: false },
        ],
        stickyColumns: {
          first: 1,
          last: 0,
        },
      };

      // Save preferences
      recentUpdatesPreferencesStore.save(customPrefs);

      // Load and verify
      const result = recentUpdatesPreferencesStore.load();
      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).toEqual(customPrefs);
        expect(result.migrated).toBe(false);
      }
    });

    it('should handle corrupted localStorage data gracefully', () => {
      // Corrupt the localStorage data
      localStorage.setItem('recent-updates-preferences', 'invalid-json{');

      const result = recentUpdatesPreferencesStore.load();

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.fallback).toEqual(DEFAULT_RECENT_UPDATES_PREFERENCES);
        expect(result.error).toBeInstanceOf(Error);
      }
    });

    it('should remove preferences from localStorage', () => {
      // First save some preferences
      const customPrefs = {
        ...DEFAULT_RECENT_UPDATES_PREFERENCES,
        pageSize: 50,
      };
      recentUpdatesPreferencesStore.save(customPrefs);

      // Verify they exist
      expect(localStorage.getItem('recent-updates-preferences')).toBeTruthy();

      // Remove them
      recentUpdatesPreferencesStore.remove();

      // Verify they're gone
      expect(localStorage.getItem('recent-updates-preferences')).toBeNull();

      // Loading should return defaults
      const result = recentUpdatesPreferencesStore.load();
      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).toEqual(DEFAULT_RECENT_UPDATES_PREFERENCES);
      }
    });

    it('should handle missing optional fields gracefully', () => {
      const partialPrefs = {
        pageSize: 15,
        wrapLines: true,
        stripedRows: false,
        contentDisplay: [
          { id: 'details', visible: true },
          { id: 'message', visible: true },
        ],
        // Missing stickyColumns
      };

      localStorage.setItem(
        'recent-updates-preferences',
        JSON.stringify({
          version: 1,
          data: partialPrefs,
        })
      );

      const result = recentUpdatesPreferencesStore.load();

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data.pageSize).toBe(15);
        expect(result.data.wrapLines).toBe(true);
        expect(result.data.stripedRows).toBe(false);
        expect(result.data.contentDisplay).toEqual([
          { id: 'details', visible: true },
          { id: 'message', visible: true },
        ]);
        // The stored data doesn't have stickyColumns, so it should use defaults
        expect(result.data.stickyColumns).toEqual({ first: 0, last: 0 });
      }
    });
  });
});
