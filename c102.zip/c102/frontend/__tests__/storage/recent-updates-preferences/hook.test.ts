/**
 * @jest-environment jsdom
 *
 * Tests for Recent Updates Preferences React hook
 */

import { renderHook, act } from '@testing-library/react';
import { useVersionedRecentUpdatesPreferences } from '../../../storage/recent-updates-preferences';

describe('useVersionedRecentUpdatesPreferences', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('should initialize with default preferences', () => {
    const { result } = renderHook(() => useVersionedRecentUpdatesPreferences());

    expect(result.current.preferences).toEqual({
      pageSize: 10,
      wrapLines: true,
      stripedRows: false,
      contentDisplay: [
        { id: 'details', visible: true },
        { id: 'message', visible: true },
        { id: 'createdBy', visible: true },
        { id: 'createdAt', visible: true },
        { id: 'status', visible: true },
      ],
      stickyColumns: {
        first: 0,
        last: 0,
      },
    });
  });

  it('should update preferences and persist to localStorage', () => {
    const { result } = renderHook(() => useVersionedRecentUpdatesPreferences());

    const newPreferences = {
      pageSize: 20,
      wrapLines: false,
      stripedRows: true,
      contentDisplay: [
        { id: 'details', visible: true },
        { id: 'message', visible: false },
      ],
      stickyColumns: {
        first: 1,
        last: 0,
      },
    };

    act(() => {
      result.current.updatePreferences(newPreferences);
    });

    expect(result.current.preferences).toEqual(newPreferences);

    // Verify localStorage persistence
    const stored = localStorage.getItem('recent-updates-preferences');
    expect(stored).toBeTruthy();
    const parsed = JSON.parse(stored!);
    expect(parsed.data).toEqual(newPreferences);
  });

  it('should reset preferences to defaults', () => {
    const { result } = renderHook(() => useVersionedRecentUpdatesPreferences());

    // First update preferences
    act(() => {
      result.current.updatePreferences({
        pageSize: 50,
        wrapLines: false,
        stripedRows: true,
        contentDisplay: [{ id: 'details', visible: true }],
      });
    });

    // Verify they changed
    expect(result.current.preferences.pageSize).toBe(50);

    // Reset to defaults
    act(() => {
      result.current.resetPreferences();
    });

    // Verify reset
    expect(result.current.preferences.pageSize).toBe(10);
    expect(result.current.preferences.wrapLines).toBe(true);
    expect(result.current.preferences.stripedRows).toBe(false);

    // Verify localStorage was cleared
    expect(localStorage.getItem('recent-updates-preferences')).toBeNull();
  });

  it('should handle partial preference updates', () => {
    const { result } = renderHook(() => useVersionedRecentUpdatesPreferences());

    act(() => {
      result.current.updatePreferences({
        pageSize: 25,
        // Other fields should remain unchanged
      });
    });

    expect(result.current.preferences.pageSize).toBe(25);
    expect(result.current.preferences.wrapLines).toBe(true); // Should keep default
    expect(result.current.preferences.stripedRows).toBe(false); // Should keep default
  });

  it('should handle contentDisplay updates', () => {
    const { result } = renderHook(() => useVersionedRecentUpdatesPreferences());

    act(() => {
      result.current.updatePreferences({
        contentDisplay: [
          { id: 'details', visible: true },
          { id: 'message', visible: false },
        ],
      });
    });

    expect(result.current.preferences.contentDisplay).toEqual([
      { id: 'details', visible: true },
      { id: 'message', visible: false },
    ]);
  });

  it('should handle missing stickyColumns in update', () => {
    const { result } = renderHook(() => useVersionedRecentUpdatesPreferences());

    act(() => {
      result.current.updatePreferences({
        pageSize: 15,
        // No stickyColumns provided
      });
    });

    expect(result.current.preferences.stickyColumns).toEqual({
      first: 0,
      last: 0,
    });
  });

  it('should load existing preferences from localStorage on mount', () => {
    const existingPrefs = {
      pageSize: 30,
      wrapLines: false,
      stripedRows: true,
      contentDisplay: [
        { id: 'details', visible: true },
        { id: 'status', visible: false },
      ],
      stickyColumns: {
        first: 2,
        last: 1,
      },
    };

    localStorage.setItem(
      'recent-updates-preferences',
      JSON.stringify({
        version: 1,
        data: existingPrefs,
      })
    );

    const { result } = renderHook(() => useVersionedRecentUpdatesPreferences());

    expect(result.current.preferences).toEqual(existingPrefs);
  });
});
