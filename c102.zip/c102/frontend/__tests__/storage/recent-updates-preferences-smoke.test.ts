/**
 * Smoke tests for Recent Updates Preferences storage system
 *
 * These tests validate critical paths:
 * 1. Basic store operations (load, save, remove)
 * 2. React hook integration
 * 3. Edge case handling (corrupted data, validation failures)
 */

import { renderHook, act } from '@testing-library/react';
import {
  useVersionedRecentUpdatesPreferences,
  recentUpdatesPreferencesStore,
  DEFAULT_RECENT_UPDATES_PREFERENCES,
} from '../../storage/recent-updates-preferences';

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {};
  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value;
    },
    removeItem: (key: string) => {
      delete store[key];
    },
    clear: () => {
      store = {};
    },
  };
})();

Object.defineProperty(window, 'localStorage', {
  value: localStorageMock,
  writable: true,
});

describe('Recent Updates Preferences - Smoke Tests', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  describe('Store Operations', () => {
    it('should load defaults when no data exists', () => {
      const result = recentUpdatesPreferencesStore.load();

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).toEqual(DEFAULT_RECENT_UPDATES_PREFERENCES);
        expect(result.migrated).toBe(false);
      }
    });

    it('should save and load preferences correctly', () => {
      const customPrefs = {
        pageSize: 25,
        wrapLines: false,
        stripedRows: true,
        contentDisplay: [
          { id: 'details', visible: true },
          { id: 'message', visible: false },
        ],
        stickyColumns: {
          first: 1,
          last: 1,
        },
      };

      recentUpdatesPreferencesStore.save(customPrefs);
      const result = recentUpdatesPreferencesStore.load();

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).toEqual(customPrefs);
      }
    });

    it('should handle corrupted data gracefully', () => {
      localStorage.setItem('recent-updates-preferences', 'corrupted-json{');

      const result = recentUpdatesPreferencesStore.load();

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.fallback).toEqual(DEFAULT_RECENT_UPDATES_PREFERENCES);
      }
    });
  });

  describe('React Hook Integration', () => {
    it('should provide working preferences state and updaters', () => {
      const { result } = renderHook(() => useVersionedRecentUpdatesPreferences());

      // Initial state should be defaults
      expect(result.current.preferences).toEqual(DEFAULT_RECENT_UPDATES_PREFERENCES);

      // Update preferences
      act(() => {
        result.current.updatePreferences({
          pageSize: 50,
          wrapLines: false,
        });
      });

      // State should update
      expect(result.current.preferences.pageSize).toBe(50);
      expect(result.current.preferences.wrapLines).toBe(false);

      // Reset preferences
      act(() => {
        result.current.resetPreferences();
      });

      // Should return to defaults
      expect(result.current.preferences).toEqual(DEFAULT_RECENT_UPDATES_PREFERENCES);
    });

    it('should persist changes across hook instances', () => {
      // First hook instance
      const { result: result1 } = renderHook(() => useVersionedRecentUpdatesPreferences());

      act(() => {
        result1.current.updatePreferences({
          pageSize: 100,
          stripedRows: true,
        });
      });

      // Second hook instance (simulates component remount)
      const { result: result2 } = renderHook(() => useVersionedRecentUpdatesPreferences());

      // Should load persisted preferences
      expect(result2.current.preferences.pageSize).toBe(100);
      expect(result2.current.preferences.stripedRows).toBe(true);
    });
  });

  describe('Edge Cases', () => {
    it('should handle corrupted data gracefully', () => {
      localStorage.setItem('recent-updates-preferences', 'corrupted-json{');

      const result = recentUpdatesPreferencesStore.load();

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.fallback).toEqual(DEFAULT_RECENT_UPDATES_PREFERENCES);
      }
    });
  });
});
