/**
 * @jest-environment jsdom
 *
 * Integration tests for Catalog Preferences storage
 * Tests end-to-end flow including migration, validation, and store operations
 */

import {
  templateCatalogPreferencesStore,
  standardCatalogPreferencesStore,
  DEFAULT_TEMPLATE_CATALOG_PREFERENCES,
} from '../../../storage/catalog-preferences';

describe('Catalog Preferences Integration', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  describe('Template Catalog Store', () => {
    it('should initialize with defaults when no data exists', () => {
      const result = templateCatalogPreferencesStore.load();

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).toEqual(DEFAULT_TEMPLATE_CATALOG_PREFERENCES);
        expect(result.migrated).toBe(false);
      }
    });

    it('should persist and retrieve preferences', () => {
      const customPrefs = {
        viewType: 'card' as const,
        pageSizeFallback: 20,
        table: {
          contentDisplay: [
            { id: 'name', visible: true },
            { id: 'region', visible: false },
          ],
          wrapLines: true,
          stripedRows: false,
        },
        cards: {
          contentDisplay: [{ id: 'region', visible: true }],
          cardsPerRowBreakpoints: [
            { minWidth: 0, cards: 1 },
            { minWidth: 768, cards: 2 },
          ],
        },
      };

      const saved = templateCatalogPreferencesStore.save(customPrefs);
      expect(saved).toBe(true);

      const result = templateCatalogPreferencesStore.load();
      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data).toEqual(customPrefs);
      }
    });

    it('should update preferences partially', () => {
      const initialResult = templateCatalogPreferencesStore.load();
      expect(initialResult.success).toBe(true);
      if (!initialResult.success) return;

      const initial = initialResult.data;

      const updated = {
        ...initial,
        table: {
          ...initial.table,
          wrapLines: true,
        },
      };

      templateCatalogPreferencesStore.save(updated);
      const result = templateCatalogPreferencesStore.load();

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.data.table.wrapLines).toBe(true);
        expect(result.data.cards).toEqual(initial.cards); // Cards unchanged
      }
    });

    it('should reset to defaults by removing data', () => {
      // Set custom preferences
      const customPrefs = {
        viewType: 'card' as const,
        pageSizeFallback: 20,
        table: {
          contentDisplay: [{ id: 'custom', visible: true }],
          wrapLines: true,
          stripedRows: false,
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [{ minWidth: 0, cards: 1 }],
        },
      };

      templateCatalogPreferencesStore.save(customPrefs);

      const loadedResult = templateCatalogPreferencesStore.load();
      expect(loadedResult.success).toBe(true);
      if (loadedResult.success) {
        expect(loadedResult.data).toEqual(customPrefs);
      }

      // Reset by removing
      templateCatalogPreferencesStore.remove();

      const resetResult = templateCatalogPreferencesStore.load();
      expect(resetResult.success).toBe(true);
      if (resetResult.success) {
        expect(resetResult.data).toEqual(DEFAULT_TEMPLATE_CATALOG_PREFERENCES);
      }
    });

    it('should handle v0 data gracefully (uses defaults)', () => {
      // Setup: Write old v0 format
      // Note: v0 migration detects old keys but since there's no version in localStorage,
      // the store treats it as fresh data and returns defaults
      const oldTablePrefs = {
        pageSize: 10,
        contentDisplay: [
          { id: 'name', visible: true },
          { id: 'region', visible: false },
        ],
        wrapLines: true,
        stripedRows: false,
      };

      const oldCardPrefs = {
        pageSize: 10,
        contentDisplay: [
          { id: 'region', visible: false },
          { id: 'program', visible: true },
        ],
        cardsPerRowBreakpoints: [
          { minWidth: 0, cards: 1 },
          { minWidth: 1920, cards: 5 }, // Old threshold
        ],
      };

      localStorage.setItem('template-catalog-table-preferences', JSON.stringify(oldTablePrefs));
      localStorage.setItem('template-catalog-card-preferences', JSON.stringify(oldCardPrefs));

      // Load - should return defaults since no versioned data exists
      const result = templateCatalogPreferencesStore.load();

      expect(result.success).toBe(true);
      if (!result.success) return;

      // Verify we got valid data (either migrated or defaults)
      const prefs = result.data;
      expect(prefs.table.contentDisplay).toBeDefined();
      expect(Array.isArray(prefs.table.contentDisplay)).toBe(true);
      expect(prefs.cards.cardsPerRowBreakpoints).toBeDefined();
      expect(Array.isArray(prefs.cards.cardsPerRowBreakpoints)).toBe(true);
    });

    it('should automatically migrate v1 to v4 (breakpoint normalization)', () => {
      // Setup: Write v1 format with old breakpoints
      const v1Data = {
        version: 1,
        data: {
          table: {
            contentDisplay: [{ id: 'name', visible: true }],
            wrapLines: false,
          },
          cards: {
            contentDisplay: [{ id: 'region', visible: true }],
            cardsPerRowBreakpoints: [
              { minWidth: 0, cards: 1 },
              { minWidth: 768, cards: 2 },
              { minWidth: 1366, cards: 3 },
            ],
          },
        },
      };

      localStorage.setItem('template-catalog-preferences', JSON.stringify(v1Data));

      // Trigger migration
      const result = templateCatalogPreferencesStore.load();

      expect(result.success).toBe(true);
      if (!result.success) return;

      const prefs = result.data;
      expect(result.migrated).toBe(true);

      // V4 normalizes to 3 fixed breakpoints: 768, 1366, 1920
      expect(prefs.cards.cardsPerRowBreakpoints).toHaveLength(3);

      const bp768 = prefs.cards.cardsPerRowBreakpoints.find((bp) => bp.minWidth === 768);
      const bp1366 = prefs.cards.cardsPerRowBreakpoints.find((bp) => bp.minWidth === 1366);
      const bp1920 = prefs.cards.cardsPerRowBreakpoints.find((bp) => bp.minWidth === 1920);

      expect(bp768).toBeDefined();
      expect(bp1366).toBeDefined();
      expect(bp1920).toBeDefined();

      // Verify version was updated to V4
      const stored = localStorage.getItem('template-catalog-preferences');
      if (stored) {
        const parsed = JSON.parse(stored);
        expect(parsed.version).toBe(4); // Now at V4
      }
    });

    it('should fallback to defaults on invalid data', () => {
      // Write invalid data
      localStorage.setItem(
        'template-catalog-preferences',
        JSON.stringify({
          version: 2,
          data: {
            invalid: 'structure',
          },
        })
      );

      const result = templateCatalogPreferencesStore.load();

      // Invalid structure returns failure with fallback defaults
      if (result.success) {
        // If validation passes (lenient), verify required fields exist
        expect(result.data.table).toBeDefined();
        expect(result.data.cards).toBeDefined();
      } else {
        // If validation fails (strict), verify fallback is provided
        expect(result.fallback).toBeDefined();
        expect(result.fallback.table).toBeDefined();
        expect(result.fallback.cards).toBeDefined();
        expect(result.fallback.table.contentDisplay).toBeDefined();
        expect(result.fallback.cards.cardsPerRowBreakpoints).toBeDefined();
      }
    });

    it('should fallback to defaults on malformed JSON', () => {
      localStorage.setItem('template-catalog-preferences', 'invalid json{');

      const result = templateCatalogPreferencesStore.load();

      expect(result.success).toBe(false);
      if (!result.success) {
        // Should return defaults via fallback
        expect(result.fallback).toEqual(DEFAULT_TEMPLATE_CATALOG_PREFERENCES);
      }
    });
  });

  describe('Standard Catalog Store', () => {
    it('should work independently from template store', () => {
      // Set template preferences
      templateCatalogPreferencesStore.save({
        viewType: 'card',
        pageSizeFallback: 20,
        table: {
          contentDisplay: [{ id: 'template-column', visible: true }],
          wrapLines: false,
          stripedRows: false,
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [{ minWidth: 0, cards: 1 }],
        },
      });

      // Set standard preferences
      standardCatalogPreferencesStore.save({
        viewType: 'card',
        pageSizeFallback: 20,
        table: {
          contentDisplay: [{ id: 'standard-column', visible: true }],
          wrapLines: false,
          stripedRows: false,
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [{ minWidth: 0, cards: 2 }],
        },
      });

      // Verify they're independent
      const templateResult = templateCatalogPreferencesStore.load();
      const standardResult = standardCatalogPreferencesStore.load();

      expect(templateResult.success).toBe(true);
      expect(standardResult.success).toBe(true);

      if (templateResult.success && standardResult.success) {
        expect(templateResult.data.table.contentDisplay[0].id).toBe('template-column');
        expect(standardResult.data.table.contentDisplay[0].id).toBe('standard-column');
        expect(templateResult.data.cards.cardsPerRowBreakpoints[0].cards).toBe(1);
        expect(standardResult.data.cards.cardsPerRowBreakpoints[0].cards).toBe(2);
      }
    });

    it('should handle v0 standard data gracefully (uses defaults)', () => {
      // Setup: Write old v0 format for standards
      const oldTablePrefs = {
        contentDisplay: [
          { id: 'name', visible: true },
          { id: 'projectType', visible: false },
        ],
        wrapLines: false,
      };

      const oldCardPrefs = {
        contentDisplay: [{ id: 'region', visible: true }],
        cardsPerRowBreakpoints: [{ minWidth: 0, cards: 1 }],
      };

      localStorage.setItem('standard-catalog-table-preferences', JSON.stringify(oldTablePrefs));
      localStorage.setItem('standard-catalog-card-preferences', JSON.stringify(oldCardPrefs));

      // Load - should return defaults since no versioned data exists
      const result = standardCatalogPreferencesStore.load();

      expect(result.success).toBe(true);
      if (!result.success) return;

      // Verify we got valid data
      const prefs = result.data;
      expect(prefs.table.contentDisplay).toBeDefined();
      expect(Array.isArray(prefs.table.contentDisplay)).toBe(true);
      expect(prefs.cards.cardsPerRowBreakpoints).toBeDefined();
      expect(Array.isArray(prefs.cards.cardsPerRowBreakpoints)).toBe(true);
    });
  });

  describe('Real-world scenarios', () => {
    it('should handle complete user workflow', () => {
      // 1. User loads page with no saved preferences
      let result = templateCatalogPreferencesStore.load();
      expect(result.success).toBe(true);
      if (!result.success) return;

      let prefs = result.data;
      expect(prefs).toEqual(DEFAULT_TEMPLATE_CATALOG_PREFERENCES);

      // 2. User shows a hidden column
      const updated1 = {
        ...prefs,
        table: {
          ...prefs.table,
          contentDisplay: prefs.table.contentDisplay.map((item) =>
            item.id === 'siteAcreage' ? { ...item, visible: true } : item
          ),
        },
      };
      templateCatalogPreferencesStore.save(updated1);

      // 3. User enables wrap lines
      result = templateCatalogPreferencesStore.load();
      expect(result.success).toBe(true);
      if (!result.success) return;

      const updated2 = {
        ...result.data,
        table: {
          ...result.data.table,
          wrapLines: true,
        },
      };
      templateCatalogPreferencesStore.save(updated2);

      // 4. User changes card fields
      result = templateCatalogPreferencesStore.load();
      expect(result.success).toBe(true);
      if (!result.success) return;

      const updated3 = {
        ...result.data,
        cards: {
          ...result.data.cards,
          contentDisplay: [
            { id: 'region', visible: true },
            { id: 'capacity', visible: true },
            { id: 'businessUnit', visible: false },
          ],
        },
      };
      templateCatalogPreferencesStore.save(updated3);

      // 5. Verify final state
      result = templateCatalogPreferencesStore.load();
      expect(result.success).toBe(true);
      if (!result.success) return;

      const final = result.data;
      expect(final.table.wrapLines).toBe(true);
      expect(final.table.contentDisplay.find((i) => i.id === 'siteAcreage')?.visible).toBe(true);
      expect(final.cards.contentDisplay).toHaveLength(3);
      expect(final.cards.contentDisplay[2].visible).toBe(false);
    });
  });
});
