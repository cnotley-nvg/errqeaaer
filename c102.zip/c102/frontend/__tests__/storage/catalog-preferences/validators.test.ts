/**
 * @jest-environment jsdom
 */

import { validateCatalogPreferences } from '../../../storage/catalog-preferences/validators';
import { DEFAULT_TEMPLATE_CATALOG_PREFERENCES } from '../../../storage/catalog-preferences/defaults';
import type { CatalogPreferences } from '../../../storage/catalog-preferences/types';

describe('Catalog Preferences Validators', () => {
  describe('validateCatalogPreferences', () => {
    it('should validate a complete valid preferences object', () => {
      const valid: CatalogPreferences = {
        viewType: 'card',
        pageSizeFallback: 20,
        table: {
          contentDisplay: [
            { id: 'name', visible: true },
            { id: 'region', visible: false },
          ],
          wrapLines: true,
          stripedRows: false,
        },
        cards: {
          contentDisplay: [
            { id: 'region', visible: true },
            { id: 'program', visible: false },
          ],
          cardsPerRowBreakpoints: [
            { minWidth: 0, cards: 1 },
            { minWidth: 768, cards: 2 },
            { minWidth: 1366, cards: 3 },
          ],
        },
      };

      expect(() => validateCatalogPreferences(valid)).not.toThrow();
      expect(validateCatalogPreferences(valid)).toBe(true);
    });

    it('should validate default preferences', () => {
      expect(() => validateCatalogPreferences(DEFAULT_TEMPLATE_CATALOG_PREFERENCES)).not.toThrow();
      expect(validateCatalogPreferences(DEFAULT_TEMPLATE_CATALOG_PREFERENCES)).toBe(true);
    });

    it('should validate preferences without optional fields', () => {
      const minimal: CatalogPreferences = {
        viewType: 'card',
        pageSizeFallback: 20,
        table: {
          contentDisplay: [],
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [],
        },
      };

      expect(() => validateCatalogPreferences(minimal)).not.toThrow();
      expect(validateCatalogPreferences(minimal)).toBe(true);
    });

    it('should reject missing table object', () => {
      const invalid = {
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should reject missing cards object', () => {
      const invalid = {
        table: {
          contentDisplay: [],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should reject missing table.contentDisplay', () => {
      const invalid = {
        table: {
          wrapLines: true,
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should reject missing cards.contentDisplay', () => {
      const invalid = {
        table: {
          contentDisplay: [],
        },
        cards: {
          cardsPerRowBreakpoints: [],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should reject missing cards.cardsPerRowBreakpoints', () => {
      const invalid = {
        table: {
          contentDisplay: [],
        },
        cards: {
          contentDisplay: [],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should reject invalid contentDisplay items (missing id)', () => {
      const invalid = {
        table: {
          contentDisplay: [
            { visible: true }, // Missing 'id'
          ],
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should reject invalid contentDisplay items (missing visible)', () => {
      const invalid = {
        table: {
          contentDisplay: [
            { id: 'name' }, // Missing 'visible'
          ],
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should reject invalid contentDisplay items (wrong type for id)', () => {
      const invalid = {
        table: {
          contentDisplay: [
            { id: 123, visible: true }, // id should be string
          ],
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should reject invalid contentDisplay items (wrong type for visible)', () => {
      const invalid = {
        table: {
          contentDisplay: [
            { id: 'name', visible: 'true' }, // visible should be boolean
          ],
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should reject invalid breakpoint items (missing minWidth)', () => {
      const invalid = {
        table: {
          contentDisplay: [],
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [
            { cards: 1 }, // Missing 'minWidth'
          ],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should reject invalid breakpoint items (missing cards)', () => {
      const invalid = {
        table: {
          contentDisplay: [],
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [
            { minWidth: 0 }, // Missing 'cards'
          ],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should reject invalid breakpoint items (wrong type for minWidth)', () => {
      const invalid = {
        table: {
          contentDisplay: [],
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [
            { minWidth: '0', cards: 1 }, // minWidth should be number
          ],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should reject invalid breakpoint items (wrong type for cards)', () => {
      const invalid = {
        table: {
          contentDisplay: [],
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [
            { minWidth: 0, cards: '1' }, // cards should be number
          ],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should reject wrong type for wrapLines', () => {
      const invalid = {
        table: {
          contentDisplay: [],
          wrapLines: 'true', // Should be boolean
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should reject wrong type for stripedRows', () => {
      const invalid = {
        table: {
          contentDisplay: [],
          stripedRows: 1, // Should be boolean
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should pass through extra fields (pass-through mode)', () => {
      const withExtra = {
        table: {
          contentDisplay: [],
          wrapLines: true,
          extraField: 'should be preserved', // Extra field
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [],
        },
        extraTopLevel: 'also preserved', // Extra top-level field
      };

      expect(() => validateCatalogPreferences(withExtra as any)).not.toThrow();
    });

    it('should accept any column id string value', () => {
      const customColumns: CatalogPreferences = {
        viewType: 'card',
        pageSizeFallback: 20,
        table: {
          contentDisplay: [
            { id: 'customColumn1', visible: true },
            { id: 'customColumn2', visible: false },
            { id: 'any-string-works', visible: true },
          ],
        },
        cards: {
          contentDisplay: [{ id: 'customCardField', visible: true }],
          cardsPerRowBreakpoints: [{ minWidth: 0, cards: 1 }],
        },
      };

      expect(() => validateCatalogPreferences(customColumns)).not.toThrow();
      expect(validateCatalogPreferences(customColumns)).toBe(true);
    });

    it('should accept empty arrays', () => {
      const empty: CatalogPreferences = {
        viewType: 'card',
        pageSizeFallback: 20,
        table: {
          contentDisplay: [],
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [],
        },
      };

      expect(() => validateCatalogPreferences(empty)).not.toThrow();
      expect(validateCatalogPreferences(empty)).toBe(true);
    });

    it('should reject non-array contentDisplay', () => {
      const invalid = {
        table: {
          contentDisplay: { id: 'name', visible: true }, // Should be array
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [],
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });

    it('should reject non-array cardsPerRowBreakpoints', () => {
      const invalid = {
        table: {
          contentDisplay: [],
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: { minWidth: 0, cards: 1 }, // Should be array
        },
      };

      expect(validateCatalogPreferences(invalid as any)).toBe(false);
    });
  });
});
