import { migrationV3toV4 } from '../../../storage/catalog-preferences/migrations';
import { normalizeBreakpoints } from '../../../storage/catalog-preferences/normalizeBreakpoints';
import type { CatalogPreferencesV3 } from '../../../storage/catalog-preferences/types';

describe('migrationV3toV4', () => {
  const createV3Data = (
    breakpoints: { minWidth: number; cards: number }[]
  ): CatalogPreferencesV3 => ({
    viewType: 'card',
    pageSizeFallback: 20,
    table: { contentDisplay: [], wrapLines: false, stripedRows: false },
    cards: {
      contentDisplay: [],
      cardsPerRowBreakpoints: breakpoints,
    },
  });

  describe('normalizeBreakpoints', () => {
    it('should convert 5 legacy breakpoints to 3 normalized breakpoints', () => {
      const legacyBreakpoints = [
        { minWidth: 0, cards: 1 },
        { minWidth: 768, cards: 2 },
        { minWidth: 1366, cards: 3 },
        { minWidth: 1921, cards: 5 },
        { minWidth: 2561, cards: 6 },
      ];

      const result = normalizeBreakpoints(legacyBreakpoints);

      expect(result).toHaveLength(3);
      expect(result).toEqual([
        { minWidth: 768, cards: 1 },
        { minWidth: 1366, cards: 3 },
        { minWidth: 1920, cards: 5 },
      ]);
    });

    it('should clamp tablet cards to max 2', () => {
      const breakpoints = [{ minWidth: 768, cards: 5 }];
      const result = normalizeBreakpoints(breakpoints);

      const tablet = result.find((bp) => bp.minWidth === 768);
      expect(tablet!.cards).toBe(2);
    });

    it('should clamp laptop cards to max 4', () => {
      const breakpoints = [{ minWidth: 1366, cards: 10 }];
      const result = normalizeBreakpoints(breakpoints);

      const laptop = result.find((bp) => bp.minWidth === 1366);
      expect(laptop!.cards).toBe(4);
    });

    it('should clamp desktop cards to max 6', () => {
      const breakpoints = [{ minWidth: 1920, cards: 10 }];
      const result = normalizeBreakpoints(breakpoints);

      const desktop = result.find((bp) => bp.minWidth === 1920);
      expect(desktop!.cards).toBe(6);
    });

    it('should fill missing breakpoints with defaults', () => {
      const result = normalizeBreakpoints([]);

      expect(result).toEqual([
        { minWidth: 768, cards: 2 },
        { minWidth: 1366, cards: 3 },
        { minWidth: 1920, cards: 4 },
      ]);
    });

    it('should map legacy minWidth 0 to 768', () => {
      const breakpoints = [{ minWidth: 0, cards: 1 }];
      const result = normalizeBreakpoints(breakpoints);

      const tablet = result.find((bp) => bp.minWidth === 768);
      expect(tablet!.cards).toBe(1);
    });

    it('should map legacy minWidth 1921 to 1920', () => {
      const breakpoints = [{ minWidth: 1921, cards: 5 }];
      const result = normalizeBreakpoints(breakpoints);

      const desktop = result.find((bp) => bp.minWidth === 1920);
      expect(desktop!.cards).toBe(5);
    });

    it('should map legacy minWidth 2561 to 1920', () => {
      const breakpoints = [{ minWidth: 2561, cards: 6 }];
      const result = normalizeBreakpoints(breakpoints);

      const desktop = result.find((bp) => bp.minWidth === 1920);
      expect(desktop!.cards).toBe(6);
    });
  });

  describe('migrationV3toV4.migrate', () => {
    it('should preserve viewType and pageSizeFallback', () => {
      const v3Data = createV3Data([
        { minWidth: 768, cards: 2 },
        { minWidth: 1366, cards: 3 },
        { minWidth: 1920, cards: 4 },
      ]);
      v3Data.viewType = 'table';
      v3Data.pageSizeFallback = 50;

      const v4Data = migrationV3toV4.migrate(v3Data);

      expect(v4Data.viewType).toBe('table');
      expect(v4Data.pageSizeFallback).toBe(50);
    });

    it('should preserve table preferences', () => {
      const v3Data = createV3Data([]);
      v3Data.table = {
        contentDisplay: [{ id: 'name', visible: true }],
        wrapLines: true,
        stripedRows: true,
      };

      const v4Data = migrationV3toV4.migrate(v3Data);

      expect(v4Data.table).toEqual(v3Data.table);
    });

    it('should preserve card contentDisplay', () => {
      const v3Data = createV3Data([]);
      v3Data.cards.contentDisplay = [
        { id: 'region', visible: true },
        { id: 'program', visible: false },
      ];

      const v4Data = migrationV3toV4.migrate(v3Data);

      expect(v4Data.cards.contentDisplay).toEqual(v3Data.cards.contentDisplay);
    });

    it('should normalize breakpoints in full migration', () => {
      const v3Data = createV3Data([
        { minWidth: 0, cards: 1 },
        { minWidth: 768, cards: 2 },
        { minWidth: 1366, cards: 3 },
        { minWidth: 1921, cards: 5 },
        { minWidth: 2561, cards: 6 },
      ]);

      const v4Data = migrationV3toV4.migrate(v3Data);

      expect(v4Data.cards.cardsPerRowBreakpoints).toHaveLength(3);
      expect(v4Data.cards.cardsPerRowBreakpoints[0].minWidth).toBe(768);
      expect(v4Data.cards.cardsPerRowBreakpoints[1].minWidth).toBe(1366);
      expect(v4Data.cards.cardsPerRowBreakpoints[2].minWidth).toBe(1920);
    });
  });

  describe('migration metadata', () => {
    it('should have correct from version', () => {
      expect(migrationV3toV4.from).toBe(3);
    });

    it('should have correct to version', () => {
      expect(migrationV3toV4.to).toBe(4);
    });

    it('should have a description', () => {
      expect(migrationV3toV4.description).toBeTruthy();
    });
  });
});
