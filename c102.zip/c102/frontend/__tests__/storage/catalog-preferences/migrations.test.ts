/**
 * @jest-environment jsdom
 */

import {
  migrationV0toV1Templates,
  migrationV0toV1Standards,
  migrationV1toV2,
} from '../../../storage/catalog-preferences/migrations';
import { DEFAULT_CARD_BREAKPOINTS } from '../../../storage/catalog-preferences/defaults';
import type {
  CatalogPreferencesV1,
  CatalogPreferencesV2,
} from '../../../storage/catalog-preferences/types';

describe('Catalog Preferences Migrations', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  describe('migrationV0toV1Templates', () => {
    it('should merge separate table and card localStorage keys', () => {
      // Setup: Write old v0 format to localStorage
      const oldTablePrefs = {
        pageSize: 10,
        contentDisplay: [
          { id: 'name', visible: true },
          { id: 'region', visible: true },
        ],
        wrapLines: true,
        stripedRows: false,
      };

      const oldCardPrefs = {
        pageSize: 10,
        contentDisplay: [
          { id: 'region', visible: true },
          { id: 'program', visible: true },
        ],
        cardsPerRowBreakpoints: [
          { minWidth: 0, cards: 1 },
          { minWidth: 768, cards: 2 },
        ],
      };

      localStorage.setItem('template-catalog-table-preferences', JSON.stringify(oldTablePrefs));
      localStorage.setItem('template-catalog-card-preferences', JSON.stringify(oldCardPrefs));

      // Execute migration (oldData is not used in this migration)
      const result = migrationV0toV1Templates.migrate!({}); // Non-null assertion - we know it exists

      // Verify unified structure
      expect(result).toEqual({
        table: {
          contentDisplay: oldTablePrefs.contentDisplay,
          wrapLines: true,
          stripedRows: false,
        },
        cards: {
          contentDisplay: oldCardPrefs.contentDisplay,
          cardsPerRowBreakpoints: oldCardPrefs.cardsPerRowBreakpoints,
        },
      });

      // Verify old keys were removed
      expect(localStorage.getItem('template-catalog-table-preferences')).toBeNull();
      expect(localStorage.getItem('template-catalog-card-preferences')).toBeNull();
    });

    it('should use defaults when old keys do not exist', () => {
      // Execute migration with no old data
      const result = migrationV0toV1Templates.migrate!({});

      // Verify defaults are used
      expect(result).toEqual({
        table: {
          contentDisplay: [],
          wrapLines: undefined,
          stripedRows: undefined,
        },
        cards: {
          contentDisplay: [],
          cardsPerRowBreakpoints: [...DEFAULT_CARD_BREAKPOINTS],
        },
      });
    });

    it('should handle malformed JSON gracefully', () => {
      // Setup: Write invalid JSON
      localStorage.setItem('template-catalog-table-preferences', 'invalid json{');
      localStorage.setItem('template-catalog-card-preferences', '{broken');

      // Spy on console.warn
      const warnSpy = jest.spyOn(console, 'warn').mockImplementation();

      // Execute migration
      const result = migrationV0toV1Templates.migrate!({});

      // Verify defaults are used
      expect(result.table.contentDisplay).toEqual([]);
      expect(result.cards.contentDisplay).toEqual([]);

      // Verify warnings were logged
      expect(warnSpy).toHaveBeenCalledWith(
        expect.stringContaining('[Migration v0→v1] Failed to parse'),
        expect.any(Error)
      );

      warnSpy.mockRestore();
    });

    it('should have correct migration metadata', () => {
      expect(migrationV0toV1Templates.from).toBe(0);
      expect(migrationV0toV1Templates.to).toBe(1);
      expect(migrationV0toV1Templates.description).toContain('Merge separate');
    });
  });

  describe('migrationV0toV1Standards', () => {
    it('should merge separate standard catalog keys', () => {
      // Setup: Write old v0 format to localStorage
      const oldTablePrefs = {
        contentDisplay: [
          { id: 'name', visible: true },
          { id: 'projectType', visible: true },
        ],
        wrapLines: false,
        stripedRows: true,
      };

      const oldCardPrefs = {
        contentDisplay: [
          { id: 'region', visible: true },
          { id: 'projectType', visible: true },
        ],
        cardsPerRowBreakpoints: [
          { minWidth: 0, cards: 1 },
          { minWidth: 1366, cards: 3 },
        ],
      };

      localStorage.setItem('standard-catalog-table-preferences', JSON.stringify(oldTablePrefs));
      localStorage.setItem('standard-catalog-card-preferences', JSON.stringify(oldCardPrefs));

      // Execute migration
      const result = migrationV0toV1Standards.migrate!({});

      // Verify unified structure
      expect(result).toEqual({
        table: {
          contentDisplay: oldTablePrefs.contentDisplay,
          wrapLines: false,
          stripedRows: true,
        },
        cards: {
          contentDisplay: oldCardPrefs.contentDisplay,
          cardsPerRowBreakpoints: oldCardPrefs.cardsPerRowBreakpoints,
        },
      });

      // Verify old keys were removed
      expect(localStorage.getItem('standard-catalog-table-preferences')).toBeNull();
      expect(localStorage.getItem('standard-catalog-card-preferences')).toBeNull();
    });
  });

  describe('migrationV1toV2', () => {
    it('should update breakpoint thresholds from 1920 to 1921', () => {
      const v1Data: CatalogPreferencesV1 = {
        table: {
          contentDisplay: [{ id: 'name', visible: true }],
          wrapLines: false,
          stripedRows: false,
        },
        cards: {
          contentDisplay: [{ id: 'region', visible: true }],
          cardsPerRowBreakpoints: [
            { minWidth: 0, cards: 1 },
            { minWidth: 768, cards: 2 },
            { minWidth: 1366, cards: 3 },
            { minWidth: 1920, cards: 5 }, // Should be updated to 1921
            { minWidth: 2560, cards: 6 }, // Should be updated to 2561
          ],
        },
      };

      // Execute migration using the transforms
      const transform = migrationV1toV2.transforms!['cards.cardsPerRowBreakpoints[].minWidth'] as (
        val: number
      ) => number;

      expect(transform(0)).toBe(0);
      expect(transform(768)).toBe(768);
      expect(transform(1366)).toBe(1366);
      expect(transform(1920)).toBe(1921); // Updated
      expect(transform(2560)).toBe(2561); // Updated
    });

    it('should preserve other breakpoint values unchanged', () => {
      const transform = migrationV1toV2.transforms!['cards.cardsPerRowBreakpoints[].minWidth'] as (
        val: number
      ) => number;

      // Test various values that should remain unchanged
      expect(transform(640)).toBe(640);
      expect(transform(1024)).toBe(1024);
      expect(transform(1440)).toBe(1440);
      expect(transform(3840)).toBe(3840);
    });

    it('should have correct migration metadata', () => {
      expect(migrationV1toV2.from).toBe(1);
      expect(migrationV1toV2.to).toBe(2);
      expect(migrationV1toV2.description).toContain('Update breakpoint thresholds');
    });

    it('should use declarative transforms', () => {
      expect(migrationV1toV2.transforms).toBeDefined();
      expect(migrationV1toV2.migrate).toBeUndefined();
    });
  });
});
