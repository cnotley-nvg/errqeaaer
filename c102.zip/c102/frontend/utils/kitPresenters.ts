import type { PropertyFilterProps } from '@amzn/awsui-components-console';

import type { AttributeMap, Kit, KitOptions } from '@amzn/global-realty-mosaic-graphql-schema';
import { formatProgramLabel } from './attributeDisplay';

const coerceArray = (value: unknown): unknown[] => {
  if (value === null || value === undefined) {
    return [];
  }

  return Array.isArray(value) ? value : [value];
};

const formatScalar = (value: unknown): string => {
  if (value === null || value === undefined) {
    return '';
  }

  if (typeof value === 'boolean') {
    return value ? 'Yes' : 'No';
  }

  if (typeof value === 'number') {
    return value.toString();
  }

  if (typeof value === 'string') {
    return value;
  }

  if (typeof value === 'object' && value && 'value' in (value as Record<string, unknown>)) {
    const numeric = (value as { value?: unknown; unit?: unknown }).value;
    if (typeof numeric === 'number' || typeof numeric === 'string') {
      const unit = (value as { unit?: unknown }).unit;
      const suffix = typeof unit === 'string' && unit.trim().length ? ` ${unit}` : '';
      return `${numeric}${suffix}`;
    }
  }

  try {
    return JSON.stringify(value);
  } catch (error) {
    return String(value);
  }
};

const listAttributeValues = (
  attributes: AttributeMap | null | undefined,
  key: string
): string[] => {
  if (!attributes) {
    return [];
  }

  const raw = attributes[key];
  return coerceArray(raw)
    .map(formatScalar)
    .map((entry) => entry.trim())
    .filter((entry) => entry.length > 0);
};

export const formatKitAttribute = (kit: Kit, key: string): string =>
  listAttributeValues(kit.latestVersion?.attributes, key).join(', ');

const buildOptions = (
  propertyKey: string,
  values: readonly string[]
): PropertyFilterProps.FilteringOption[] =>
  values
    .map((value) => value.trim())
    .filter((value) => value.length > 0)
    .map((value) => ({ propertyKey, value, label: value }));

const buildProgramOptions = (values: readonly string[]): PropertyFilterProps.FilteringOption[] =>
  values
    .map((value) => value.trim())
    .filter((value) => value.length > 0)
    .map((value) => ({ propertyKey: 'program', value, label: formatProgramLabel(value) }));

export const createKitFilteringOptions = (
  options: KitOptions
): ReadonlyArray<PropertyFilterProps.FilteringOption> => {
  const regionOptions = buildOptions('region', options.regions);
  const programOptions = buildProgramOptions(options.programs);
  const projectTypeOptions = buildOptions('projectType', options.projectTypes);

  return [...regionOptions, ...programOptions, ...projectTypeOptions];
};
