import type {
  PropertyFilterQuery,
  PropertyFilterToken,
  PropertyFilterTokenGroup,
} from '@amzn/awsui-collection-hooks';

import type { KitFilterInput } from '@amzn/global-realty-mosaic-graphql-schema';

type TokenLike = Pick<PropertyFilterToken, 'propertyKey' | 'operator' | 'value'> & {
  values?: unknown;
};

type QueryEntry = TokenLike | PropertyFilterTokenGroup;

const normalizeTokenValues = (token: TokenLike): string[] => {
  const values = new Set<string>();

  const append = (raw: unknown) => {
    if (raw === undefined || raw === null) {
      return;
    }

    if (Array.isArray(raw)) {
      raw.forEach(append);
      return;
    }

    const normalized = `${raw}`.trim();
    if (normalized.length) {
      values.add(normalized);
    }
  };

  append(token.values);
  append(token.value);

  return Array.from(values);
};

const flattenTokens = (query: PropertyFilterQuery): TokenLike[] => {
  const tokens: TokenLike[] = [];

  const visit = (entry: QueryEntry) => {
    if ('tokens' in entry) {
      entry.tokens?.forEach(visit);
      return;
    }

    tokens.push(entry as TokenLike);
  };

  query.tokenGroups?.forEach(visit);
  query.tokens?.forEach(visit);

  return tokens;
};

const appendValues = (target: string[] | undefined, values: string[]): string[] => {
  const next = target ? [...target] : [];

  values.forEach((value) => {
    if (!next.includes(value)) {
      next.push(value);
    }
  });

  return next;
};

export const buildKitFilterInput = (query: PropertyFilterQuery): KitFilterInput => {
  const tokens = flattenTokens(query);

  const filter: KitFilterInput = {};

  tokens.forEach((token) => {
    const values = normalizeTokenValues(token);
    if (!values.length) {
      return;
    }

    const operator = token.operator ?? ':';

    switch (token.propertyKey) {
      case 'name': {
        if (operator === ':' || operator === '=' || operator === '!=') {
          filter.nameContains = appendValues(filter.nameContains ?? undefined, values);
        }
        break;
      }
      case 'description': {
        if (operator === ':' || operator === '=' || operator === '!=') {
          filter.descriptionContains = appendValues(
            filter.descriptionContains ?? undefined,
            values
          );
        }
        break;
      }
      case 'region': {
        if (operator === '=' || operator === ':') {
          filter.regionIn = appendValues(filter.regionIn ?? undefined, values);
        }
        break;
      }
      case 'program': {
        if (operator === '=' || operator === ':') {
          filter.programIn = appendValues(filter.programIn ?? undefined, values);
        }
        break;
      }
      case 'useCase': {
        if (operator === '=' || operator === ':') {
          filter.useCaseIn = appendValues(filter.useCaseIn ?? undefined, values);
        }
        break;
      }
      default:
        break;
    }
  });

  return filter;
};
