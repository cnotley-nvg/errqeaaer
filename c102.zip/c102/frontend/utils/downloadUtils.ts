/**
 * Triggers a file download without opening a new tab/window.
 * Creates a temporary anchor element, clicks it programmatically, and removes it.
 *
 * @param url - The URL to download from (typically a signed URL)
 *
 * @example
 * ```typescript
 * // Download a file
 * triggerDownload('https://example.com/file.pdf');
 * ```
 */
export const triggerDownload = (url: string): void => {
  const link = document.createElement('a');
  link.href = url;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
