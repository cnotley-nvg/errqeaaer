import { createConsola } from 'consola';

export interface LogContext {
  [key: string]: unknown;
}

export interface Logger {
  info(message: string, context?: LogContext): void;
  warn(message: string, context?: LogContext): void;
  error(message: string, context?: LogContext): void;
  child(context: LogContext): Logger;
}

const level =
  typeof window !== 'undefined' &&
  window.location.host.endsWith('.amazon.dev') &&
  !window.location.host.startsWith('alpha') &&
  !window.location.host.startsWith('beta')
    ? 3
    : 999;

const consola =
  (globalThis as any).LOGGER ??
  createConsola({
    level,
    formatOptions: {
      colors: true,
      fancy: true,
    },
  });
(globalThis as any).LOGGER = consola;

class ConsolaLogger implements Logger {
  constructor(
    private scope: string,
    private context: LogContext = {}
  ) {}

  private log(level: 'info' | 'warn' | 'error', message: string, context?: LogContext) {
    const fullContext = { ...this.context, ...context, scope: this.scope };
    consola[level](message, fullContext);
  }

  info(message: string, context?: LogContext): void {
    this.log('info', message, context);
  }

  warn(message: string, context?: LogContext): void {
    this.log('warn', message, context);
  }

  error(message: string, context?: LogContext): void {
    this.log('error', message, context);
  }

  child(context: LogContext): Logger {
    return new ConsolaLogger(this.scope, { ...this.context, ...context });
  }
}

const rootLogger = new ConsolaLogger('frontend', { application: 'global-realty-mosaic' });

export const getScopedLogger = (scope: string, context: LogContext = {}): Logger =>
  rootLogger.child({ scope, ...context });

export type FrontendLogger = Logger;
