import type { PropertyFilterProps } from '@amzn/awsui-components-console';

import type { AttributeMap } from '@amzn/global-realty-mosaic-graphql-schema';
import type { Standard } from '../components/standards/catalog/types';
import { formatProgramLabel } from './attributeDisplay';

export type AttributeValue = unknown;

const ATTRIBUTE_KEYS = ['region', 'program', 'projectType'] as const;

const coerceAttributeArray = (value: AttributeValue): AttributeValue[] | null => {
  if (value === null || value === undefined) {
    return null;
  }

  if (Array.isArray(value)) {
    return value;
  }

  return [value];
};

const isNumericAttribute = (
  value: AttributeValue
): value is { value: number; unit?: string | null } => {
  return Boolean(
    value &&
      typeof value === 'object' &&
      'value' in (value as Record<string, unknown>) &&
      typeof (value as { value: unknown }).value === 'number'
  );
};

const formatScalarValue = (value: AttributeValue): string => {
  if (value === undefined || value === null) {
    return '';
  }

  if (typeof value === 'boolean') {
    return value ? 'Yes' : 'No';
  }

  if (typeof value === 'number') {
    return value.toString();
  }

  if (isNumericAttribute(value)) {
    const unit = value.unit ? ` ${value.unit}` : '';
    return `${value.value}${unit}`;
  }

  if (typeof value === 'string') {
    return value;
  }

  return JSON.stringify(value);
};

export const extractAttribute = (
  attributes: AttributeMap | null | undefined,
  key: string
): AttributeValue | null => {
  if (!attributes) {
    return null;
  }

  const value = attributes[key];
  return value ?? null;
};

export const listAttributeValues = (
  attributes: AttributeMap | null | undefined,
  key: string
): string[] => {
  const rawValue = extractAttribute(attributes, key);
  const values = coerceAttributeArray(rawValue);
  if (!values || !values.length) {
    return [];
  }

  return values.map(formatScalarValue).filter((value) => value.trim().length > 0);
};

export const formatAttributeValue = (
  attributes: AttributeMap | null | undefined,
  key: string
): string => listAttributeValues(attributes, key).join(', ');

export const formatStandardAttribute = (standard: Standard, key: string): string =>
  formatAttributeValue(standard.latestVersion?.attributes, key);

export const formatUpdatedAt = (standard: Standard): string => standard.updatedAt;

export const formatVersion = (standard: Standard): string => standard.latestVersion?.version ?? '';

export const createFilteringOptions = (
  standards: Standard[]
): ReadonlyArray<PropertyFilterProps.FilteringOption> => {
  const optionMap: Record<string, Set<string>> = {
    name: new Set(),
    region: new Set(),
    program: new Set(),
    projectType: new Set(),
  };

  standards.forEach((standard) => {
    optionMap.name.add(standard.name);

    ATTRIBUTE_KEYS.forEach((attributeKey) => {
      listAttributeValues(standard.latestVersion?.attributes, attributeKey).forEach((value) =>
        optionMap[attributeKey].add(value)
      );
    });
  });

  return Object.entries(optionMap).flatMap(([propertyKey, values]) =>
    Array.from(values)
      .sort((left, right) => left.localeCompare(right))
      .map((value) => ({
        propertyKey,
        value,
        label: propertyKey === 'program' ? formatProgramLabel(value) : value,
      }))
  );
};
