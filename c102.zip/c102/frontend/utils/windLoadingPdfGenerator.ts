import { jsPDF } from 'jspdf';

export type WindLoadingReportData = {
  recommendation: 'required' | 'not-required';
  guidelineUrl?: string | null;
};

export const generateWindLoadingPDF = (data: WindLoadingReportData): jsPDF => {
  const doc = new jsPDF();
  let y = 20;

  doc.setFontSize(16);
  doc.text('WIND LOADING ANALYSIS REPORT', 105, y, { align: 'center' });
  y += 10;
  doc.setFontSize(10);
  doc.text('ACLW Design Guideline Assessment - ASCE 7-22', 105, y, { align: 'center' });
  y += 6;
  doc.text(`Generated: ${new Date().toLocaleString()}`, 105, y, { align: 'center' });
  y += 15;

  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('RECOMMENDATION:', 20, y);
  y += 7;
  doc.setFont('helvetica', 'normal');
  const recommendation =
    data.recommendation === 'required'
      ? 'ACLW Design Guideline REQUIRED'
      : 'ACLW Design Guideline NOT REQUIRED';
  doc.text(recommendation, 20, y);
  y += 15;

  doc.setFont('helvetica', 'bold');
  doc.text('CONCLUSION:', 20, y);
  y += 7;
  doc.setFont('helvetica', 'normal');

  const conclusion =
    data.recommendation === 'required'
      ? 'Wind loading analysis indicates that ACLW (Above Code Level Wind) design guidelines are required for this location.'
      : 'Wind loading analysis indicates that ACLW (Above Code Level Wind) design guidelines are not required for this location.';

  const splitConclusion = doc.splitTextToSize(conclusion, 170);
  doc.text(splitConclusion, 20, y);
  y += splitConclusion.length * 6 + 15;

  if (data.guidelineUrl) {
    doc.setFont('helvetica', 'bold');
    doc.text('GUIDELINE REFERENCE:', 20, y);
    y += 7;
    doc.setFont('helvetica', 'normal');
    doc.text('ACLW Design Guideline Document:', 20, y);
    y += 6;
    doc.setTextColor(0, 0, 255);
    doc.textWithLink(data.guidelineUrl, 20, y, { url: data.guidelineUrl });
    doc.setTextColor(0, 0, 0);
    y += 10;
  }

  doc.text('This result should be communicated to the Architect of Record.', 20, y);

  return doc;
};

export const downloadWindLoadingReport = (data: WindLoadingReportData): void => {
  try {
    const doc = generateWindLoadingPDF(data);
    const filename = `wind-loading-report-${Date.now()}.pdf`;
    doc.save(filename);
  } catch (error) {
    console.error('Error generating Wind Loading PDF:', error);
  }
};
