import { jsPDF } from 'jspdf';

export type HeatIndexLevel = {
  level: number;
  hours: number;
  percentage: number;
};

export type HeatIndexReportData = {
  levels: HeatIndexLevel[];
  hvacRecommendation: string;
  recommendation: string;
};

export type ProjectParameters = {
  streetAddress: string;
  city: string;
  state?: string;
  zipcode: string;
  country: string;
  facilityType: string;
  designTemplate: string;
  squareFootage: string;
};

export type LightningProtectionReportData = {
  recommendation:
    | 'required'
    | 'not-recommended'
    | 'not-required'
    | 'optional'
    | 'recommended'
    | 'not-provided';
  riskLevel?: string;
  costImpact?: string;
  timelineImpact?: string;
  project?: string;
  reportId?: string;
  heatIndexData?: HeatIndexReportData;
  projectParams?: ProjectParameters;
};

export const generateLightningProtectionPDF = (data: LightningProtectionReportData): jsPDF => {
  const doc = new jsPDF();
  let y = 20;

  const isHeatIndex = !!data.heatIndexData;
  const title = isHeatIndex
    ? 'MECHANICAL / HEAT INDEX ANALYSIS REPORT'
    : 'LIGHTNING PROTECTION RISK ASSESSMENT REPORT';
  const subtitle = isHeatIndex ? 'HVAC System Requirements Analysis' : 'Based on NFPA 780 Annex L';

  doc.setFontSize(16);
  doc.text(title, 105, y, { align: 'center' });
  y += 10;
  doc.setFontSize(10);
  doc.text(subtitle, 105, y, { align: 'center' });
  y += 6;
  doc.text(`Generated: ${new Date().toLocaleString()}`, 105, y, { align: 'center' });
  y += 15;

  // Project Parameters Section (if provided)
  if (data.projectParams) {
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('PROJECT PARAMETERS:', 20, y);
    y += 7;
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`Street address: ${data.projectParams.streetAddress}`, 25, y);
    y += 6;
    doc.text(`City: ${data.projectParams.city}`, 25, y);
    y += 6;
    if (data.projectParams.state) {
      doc.text(`State: ${data.projectParams.state}`, 25, y);
      y += 6;
    }
    doc.text(`Zip/Postal code: ${data.projectParams.zipcode}`, 25, y);
    y += 6;
    doc.text(`Country: ${data.projectParams.country}`, 25, y);
    y += 6;
    doc.text(`Facility type: ${data.projectParams.facilityType}`, 25, y);
    y += 6;
    doc.text(`Design template: ${data.projectParams.designTemplate}`, 25, y);
    y += 6;
    doc.text(`Total square footage: ${data.projectParams.squareFootage}`, 25, y);
    y += 15;
  }

  if (!isHeatIndex) {
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('RECOMMENDATION:', 20, y);
    y += 7;
    doc.setFont('helvetica', 'normal');
    const recommendation = getRecommendationText(data.recommendation);
    doc.text(recommendation, 20, y);
    y += 15;
  }

  if (!isHeatIndex) {
    doc.setFont('helvetica', 'bold');
    doc.text('ANALYSIS DETAILS:', 20, y);
    y += 7;
    doc.setFont('helvetica', 'normal');
    if (data.riskLevel) {
      doc.text(`Risk Level: ${data.riskLevel}`, 25, y);
      y += 6;
    }
    if (data.costImpact) {
      doc.text(`Cost Impact: ${data.costImpact}`, 25, y);
      y += 6;
    }
    if (data.timelineImpact) {
      doc.text(`Timeline Impact: ${data.timelineImpact}`, 25, y);
      y += 6;
    }
    if (data.project) {
      doc.text(`Project: ${data.project}`, 25, y);
      y += 6;
    }
    if (data.reportId) {
      doc.text(`Report ID: ${data.reportId}`, 25, y);
      y += 6;
    }
    y += 15;
  }

  if (data.heatIndexData) {
    const levels = data.heatIndexData.levels;
    const level0 = levels.find((l) => l.level === 0);
    const level1 = levels.find((l) => l.level === 1);
    const level2 = levels.find((l) => l.level === 2);
    const level3 = levels.find((l) => l.level === 3);
    const level4 = levels.find((l) => l.level === 4);

    // Heat Index Levels Distribution Table
    doc.setFont('helvetica', 'bold');
    doc.text('Site Internal Heat Index Levels Distribution', 20, y);
    y += 5;
    doc.setFontSize(9);
    doc.setFont('helvetica', 'italic');
    doc.text('(Outside Heat Index + 6°F)', 20, y);
    y += 10;

    // Table headers
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text('HI Levels', 20, y);
    doc.text('Site Annual Interior Heat Index Hours', 80, y);
    doc.text('% Hours', 150, y);
    y += 6;

    // Table rows
    doc.setFont('helvetica', 'normal');
    doc.text('Level 0', 20, y);
    doc.text((level0?.hours || 0).toString(), 80, y);
    doc.text((level0?.percentage || 0).toFixed(1) + '%', 150, y);
    y += 6;
    doc.text('Level 1', 20, y);
    doc.text((level1?.hours || 0).toString(), 80, y);
    doc.text((level1?.percentage || 0).toFixed(1) + '%', 150, y);
    y += 6;
    doc.text('Level 2', 20, y);
    doc.text((level2?.hours || 0).toString(), 80, y);
    doc.text((level2?.percentage || 0).toFixed(1) + '%', 150, y);
    y += 6;
    doc.text('Level 3', 20, y);
    doc.text((level3?.hours || 0).toString(), 80, y);
    doc.text((level3?.percentage || 0).toFixed(1) + '%', 150, y);
    y += 6;
    doc.text('Level 4', 20, y);
    doc.text((level4?.hours || 0).toString(), 80, y);
    doc.text((level4?.percentage || 0).toFixed(1) + '%', 150, y);
    y += 8;

    doc.setFontSize(8);
    doc.setFont('helvetica', 'italic');
    doc.text(
      '*Heat Index is defined as "Feels Like" temperature (combination of air temperature and humidity)',
      20,
      y
    );
    y += 15;

    // WHS Heat Stress Prevention Standard Table
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('WHS Heat Stress Prevention Standard (Global)', 20, y);
    y += 10;

    // Table headers
    doc.text('HI Levels', 20, y);
    doc.text('HI (F) Range', 80, y);
    y += 6;

    // Table rows
    doc.setFont('helvetica', 'normal');
    doc.text('Level 0', 20, y);
    doc.text('HI<80°F (HI<27°C)', 80, y);
    y += 6;
    doc.text('Level 1', 20, y);
    doc.text('HI=80°F to 89°F (HI=27°C to 32°C)', 80, y);
    y += 6;
    doc.text('Level 2', 20, y);
    doc.text('HI=90°F to 99°F (HI=32°C to 37°C)', 80, y);
    y += 6;
    doc.text('Level 3', 20, y);
    doc.text('HI=100°F to 114°F (HI=38°C to 46°C)', 80, y);
    y += 6;
    doc.text('Level 4', 20, y);
    doc.text('HI>=115°F (HI>=46.1°C)', 80, y);
    y += 15;

    // HVAC Recommendation
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('MECHANICAL/HEAT INDEX:', 20, y);
    y += 7;
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    const hvacText = doc.splitTextToSize(data.heatIndexData.hvacRecommendation, 170);
    doc.text(hvacText, 20, y);
    y += hvacText.length * 6 + 5;

    // Add detailed trigger conditions based on option
    if (data.heatIndexData.hvacRecommendation.includes('Option 1')) {
      doc.setFontSize(9);
      doc.setFont('helvetica', 'italic');
      doc.text('Triggers when:', 20, y);
      y += 5;
      doc.text('  • Internal heat index <80°F for >92.5% of year (Level 0), OR', 20, y);
      y += 5;
      doc.text('  • Internal heat index <90°F for >99% of year (Levels 0-1)', 20, y);
      y += 10;
    } else if (data.heatIndexData.hvacRecommendation.includes('Option 2')) {
      doc.setFontSize(9);
      doc.setFont('helvetica', 'italic');
      doc.text('Triggers when:', 20, y);
      y += 5;
      doc.text(
        '  • Internal heat index 90-100°F for 100-500 hrs/year (1.15%-5.7%) — Level 2',
        20,
        y
      );
      y += 5;
      doc.text('Solution: Seasonal rental portable AC units during peak summer months', 20, y);
      y += 10;
    } else if (data.heatIndexData.hvacRecommendation.includes('Option 3')) {
      doc.setFontSize(9);
      doc.setFont('helvetica', 'italic');
      doc.text('Triggers when any of the following conditions occur:', 20, y);
      y += 5;
      doc.text(
        '  • Scenario A: Internal heat index 90-100°F for >500 hrs/year (5.7%) — Level 2',
        20,
        y
      );
      y += 5;
      doc.text(
        '  • Scenario B: Internal heat index 100-114°F for >300 hrs/year (3.4%) — Level 3',
        20,
        y
      );
      y += 5;
      doc.text('  • Scenario C: Internal heat index >=115°F for >=1 hr/year — Level 4', 20, y);
      y += 10;
    } else {
      y += 10;
    }
  }

  if (!data.heatIndexData) {
    doc.setFont('helvetica', 'bold');
    doc.text('CONCLUSION:', 20, y);
    y += 7;
    doc.setFont('helvetica', 'normal');
    const conclusion = getConclusionText(data.recommendation);
    const splitConclusion = doc.splitTextToSize(conclusion, 170);
    doc.text(splitConclusion, 20, y);
    y += splitConclusion.length * 6 + 10;
  }

  doc.text('This result should be communicated to the Architect of Record.', 20, y);

  return doc;
};

export const getRecommendationText = (
  recommendation:
    | 'required'
    | 'not-recommended'
    | 'not-required'
    | 'optional'
    | 'recommended'
    | 'not-provided'
): string => {
  switch (recommendation) {
    case 'required':
      return 'Lightning Protection System RECOMMENDED';
    case 'not-recommended':
      return 'Lightning Protection System NOT RECOMMENDED';
    case 'not-required':
      return 'Lightning Protection System OPTIONAL';
    case 'recommended':
      return 'HVAC System RECOMMENDED';
    case 'optional':
      return 'Lightning Protection System OPTIONAL';
    case 'not-provided':
      return 'Analysis Not Available';
  }
};

export const getConclusionText = (
  recommendation:
    | 'required'
    | 'not-recommended'
    | 'not-required'
    | 'optional'
    | 'recommended'
    | 'not-provided'
): string => {
  switch (recommendation) {
    case 'required':
      return 'A lightning protection system is recommended to be installed based on a risk assessment factoring in lighting strike data in this region and building characteristics.';
    case 'not-recommended':
      return 'A lightning protection system is not recommended for this building based on the risk assessment.';
    case 'not-required':
    case 'optional':
      return 'A lightning protection system is optional based on a risk assessment factoring in lighting strike data in this region and building characteristics.';
    case 'recommended':
      return 'Based on heat index analysis, enhanced HVAC system is recommended for this building.';
    case 'not-provided':
      return 'Building dimensions are required to perform lightning protection analysis.';
  }
};

export const downloadLightningProtectionReport = (data: LightningProtectionReportData): void => {
  try {
    const doc = generateLightningProtectionPDF(data);
    const filename = data.heatIndexData
      ? `mechanical-heat-index-report-${Date.now()}.pdf`
      : `lightning-protection-report-${Date.now()}.pdf`;
    doc.save(filename);
  } catch (error) {
    console.error('Error generating PDF:', error);
  }
};
