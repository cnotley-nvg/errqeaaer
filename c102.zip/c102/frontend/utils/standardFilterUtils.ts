import type {
  PropertyFilterQuery,
  PropertyFilterToken,
  PropertyFilterTokenGroup,
} from '@amzn/awsui-collection-hooks';

import type {
  FilterInput,
  FilterOperator,
  FilterQueryInput,
  FilterTokenGroupInput,
} from '@amzn/global-realty-mosaic-graphql-schema';

import type { SortableField } from '../hooks/useStandardCatalogPersistence';
import { DEFAULT_CATALOG_PAGE_SIZE } from '../components/standards/catalog/preferences';

type TokenLike = Pick<PropertyFilterToken, 'propertyKey' | 'operator' | 'value'> & {
  values?: unknown;
};

export type QueryEntry = PropertyFilterToken | PropertyFilterTokenGroup;

const OPERATOR_MAP: Record<string, FilterOperator | undefined> = {
  '=': 'EQUALS',
  '!=': 'NOT_EQUALS',
  ':': 'CONTAINS',
  '!:': 'NOT_CONTAINS',
  '^': 'STARTS_WITH',
  '!^': 'NOT_STARTS_WITH',
  '>': 'GREATER_THAN',
  '<': 'LESS_THAN',
  '>=': 'GREATER_OR_EQUAL',
  '<=': 'LESS_OR_EQUAL',
};

const normalizeTokenValues = (token: TokenLike): string[] => {
  const collected = new Set<string>();

  const append = (raw: unknown) => {
    if (raw === undefined || raw === null) {
      return;
    }

    if (Array.isArray(raw)) {
      raw.forEach(append);
      return;
    }

    const trimmed = `${raw}`.trim();
    if (trimmed.length) {
      collected.add(trimmed);
    }
  };

  append(token.values);
  append(token.value);

  return Array.from(collected);
};

const mapOperator = (operator: string | undefined): FilterOperator | null => {
  if (!operator) {
    return null;
  }

  const mapped = OPERATOR_MAP[operator];
  return mapped ?? null;
};

export const mapTokenToQueryGroup = (token: TokenLike): FilterTokenGroupInput | null => {
  const propertyKey = token.propertyKey?.trim();
  if (!propertyKey) {
    return null;
  }

  const operator = mapOperator(token.operator);
  if (!operator) {
    return null;
  }

  const values = normalizeTokenValues(token);
  if (!values.length) {
    return {
      propertyKey,
      operator,
    };
  }

  if (values.length === 1) {
    return {
      propertyKey,
      operator,
      value: values[0],
    };
  }

  return {
    propertyKey,
    operator,
    values,
  };
};

export const collectTokens = (entry: QueryEntry, target: FilterTokenGroupInput[]): void => {
  if ('tokens' in entry) {
    entry.tokens?.forEach((token) => collectTokens(token, target));
    return;
  }

  const converted = mapTokenToQueryGroup(entry);
  if (converted) {
    target.push(converted);
  }
};

export const toFilterQueryInput = (query: PropertyFilterQuery): FilterQueryInput | undefined => {
  const groups: FilterTokenGroupInput[] = [];

  query.tokenGroups?.forEach((group) => collectTokens(group, groups));
  query.tokens?.forEach((token) => collectTokens(token, groups));

  if (!groups.length) {
    return undefined;
  }

  return {
    operation: (query.operation ?? 'and').toUpperCase() === 'OR' ? 'OR' : 'AND',
    tokenGroups: groups,
  } satisfies FilterQueryInput;
};

export const buildFilterInput = (
  query: PropertyFilterQuery,
  pageIdx: number,
  sortingField: SortableField,
  sortingDescending: boolean,
  pageSize: number = DEFAULT_CATALOG_PAGE_SIZE
): FilterInput => {
  const filterQuery = toFilterQueryInput(query);

  const normalizedPageIdx = Number.isFinite(pageIdx) ? Math.max(0, Math.floor(pageIdx - 1)) : 0;

  const base: FilterInput = {
    pageIdx: normalizedPageIdx,
    limit: pageSize,
    orderBy: sortingField,
    orderDesc: sortingDescending,
  };

  return filterQuery ? { ...base, query: filterQuery } : base;
};
