export const formatNumber = (value: string | number | null | undefined): string => {
  if (value === '') return '';
  if (value === null || value === undefined) return 'N/A';
  const num = typeof value === 'string' ? parseFloat(value) : value;
  return isNaN(num) ? 'N/A' : num.toLocaleString('en-US', { maximumFractionDigits: 0 });
};
