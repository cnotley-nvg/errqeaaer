import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export interface LinkField {
  text: string;
  url?: string | null;
}

export interface TemplateRevisionPdfData {
  templateName: string;
  versionRange: string;
  description?: string;
  generatedDate: string;
  totalChanges: number;
  changes: Array<{
    category: string;
    title: string;
    description: string;
    dci?: LinkField | null;
    dcr?: LinkField | null;
    sheet?: string | null;
    changeInCost?: string | null;
  }>;
}

/**
 * Generates a PDF report for template revision history
 * @param data - The data to include in the PDF
 */
export const generateTemplateRevisionHistoryPdf = (data: TemplateRevisionPdfData): void => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  const marginLeft = 20;
  const marginRight = 20;
  const contentWidth = pageWidth - marginLeft - marginRight;

  let yPosition = 20;

  // ========================================
  // HEADER SECTION
  // ========================================

  // Document Title
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('Template Revision History', marginLeft, yPosition);
  yPosition += 10;

  // Horizontal line under title
  doc.setLineWidth(0.5);
  doc.line(marginLeft, yPosition, pageWidth - marginRight, yPosition);
  yPosition += 10;

  // Template metadata
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('Template Name:', marginLeft, yPosition);
  doc.setFont('helvetica', 'normal');
  doc.text(data.templateName, marginLeft + 35, yPosition);
  yPosition += 7;

  doc.setFont('helvetica', 'bold');
  doc.text('Version:', marginLeft, yPosition);
  doc.setFont('helvetica', 'normal');
  doc.text(data.versionRange, marginLeft + 35, yPosition);
  yPosition += 7;

  if (data.description) {
    doc.setFont('helvetica', 'bold');
    doc.text('Description:', marginLeft, yPosition);
    doc.setFont('helvetica', 'normal');

    // Handle long descriptions with text wrapping
    const descriptionLines = doc.splitTextToSize(data.description, contentWidth - 35);
    doc.text(descriptionLines, marginLeft + 35, yPosition);
    yPosition += descriptionLines.length * 5 + 2;
  }

  doc.setFont('helvetica', 'bold');
  doc.text('Generated:', marginLeft, yPosition);
  doc.setFont('helvetica', 'normal');
  doc.text(data.generatedDate, marginLeft + 35, yPosition);
  yPosition += 7;

  doc.setFont('helvetica', 'bold');
  doc.text('Total Changes:', marginLeft, yPosition);
  doc.setFont('helvetica', 'normal');
  doc.text(String(data.totalChanges), marginLeft + 35, yPosition);
  yPosition += 15;

  // ========================================
  // CHANGES TABLE
  // ========================================

  // Section heading
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('Change History', marginLeft, yPosition);
  yPosition += 8;

  // Prepare table data
  const tableHeaders = [
    ['Discipline', 'Change', 'Description', 'DCI #', 'DCR #', 'Sheet', 'Change in Cost'],
  ];
  const tableData = data.changes.map((change) => [
    change.category || '—',
    change.title || '—',
    change.description || '—',
    change.dci?.text || '—',
    change.dcr?.text || '—',
    change.sheet || '—',
    change.changeInCost || '—',
  ]);

  // Generate table using autoTable
  autoTable(doc, {
    head: tableHeaders,
    body: tableData,
    startY: yPosition,
    margin: { left: marginLeft, right: marginRight },
    styles: {
      fontSize: 9,
      cellPadding: 4,
      lineColor: [200, 200, 200],
      lineWidth: 0.25,
    },
    headStyles: {
      fillColor: [245, 245, 245],
      textColor: [0, 0, 0],
      fontStyle: 'bold',
      fontSize: 10,
      halign: 'left',
    },
    didDrawPage: () => {
      // Add page numbers to footer
      const pageCount = doc.getNumberOfPages();
      const currentPage = doc.getCurrentPageInfo().pageNumber;

      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.text(
        `Page ${currentPage} of ${pageCount}`,
        pageWidth / 2,
        doc.internal.pageSize.getHeight() - 10,
        { align: 'center' }
      );
    },
    theme: 'grid',
    tableLineColor: [200, 200, 200],
    tableLineWidth: 0.25,
  });

  // ========================================
  // SAVE PDF
  // ========================================

  // Generate filename with sanitized template name
  const sanitizedTemplateName = data.templateName.replace(/[^a-z0-9]/gi, '_');
  const timestamp = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
  const filename = `${sanitizedTemplateName}_Revision_History_${timestamp}.pdf`;

  doc.save(filename);
};
