import type { PropertyFilterProps } from '@amzn/awsui-components-console';
import type {
  FilterInput,
  FilterOperator,
  FilterTokenGroupInput,
} from '@amzn/global-realty-mosaic-graphql-schema';

/**
 * Sortable field names for template catalog
 */
export type SortableTemplateField =
  | 'name'
  | 'accProjectId'
  | 'updatedAt'
  | 'createdAt'
  | 'region'
  | 'program'
  | 'capacity'
  | 'stories'
  | 'facilityType'
  | 'businessUnit'
  | 'siteAcreage'
  | 'dockDoorCount'
  | 'totalTrailerParking'
  | 'maxWeeklyHeadcount'
  | 'powerKva'
  | 'createdBy'
  | 'grossSquareFootage'
  | 'peakShiftHeadcount'
  | 'clearHeightFtM'
  | 'dspParking'
  | 'generation';

/**
 * Collects and normalizes PropertyFilter tokens into GraphQL FilterTokenGroupInput format
 */
const collectPropertyFilterTokens = (query: PropertyFilterProps.Query): FilterTokenGroupInput[] => {
  const collected: FilterTokenGroupInput[] = [];

  const visit = (entry: any): void => {
    if (!entry) {
      return;
    }

    if (Array.isArray(entry.tokens)) {
      entry.tokens.forEach(visit);
      return;
    }

    if (typeof entry.propertyKey !== 'string') {
      return;
    }

    // Map AWS UI operators to GraphQL operators
    const operatorMap: Record<string, FilterOperator> = {
      '=': 'EQUALS',
      '!=': 'NOT_EQUALS',
      ':': 'CONTAINS',
      '!:': 'NOT_CONTAINS',
      '^': 'STARTS_WITH',
      '!^': 'NOT_STARTS_WITH',
      '>': 'GREATER_THAN',
      '<': 'LESS_THAN',
      '>=': 'GREATER_OR_EQUAL',
      '<=': 'LESS_OR_EQUAL',
    };

    const operator = operatorMap[entry.operator] || 'EQUALS';

    // Handle multi-value tokens (from enum tokenType with checkboxes)
    // Cloudscape PropertyFilter returns array values for multi-select
    const rawValue = entry.value;
    if (Array.isArray(rawValue)) {
      // Filter out null/undefined/empty values and normalize
      const normalizedValues = rawValue
        .filter((val) => val !== undefined && val !== null)
        .map((val) => String(val).trim())
        .filter((val) => val !== '');

      if (normalizedValues.length > 0) {
        // Use 'values' field for multi-value tokens (single token with array)
        collected.push({
          propertyKey: entry.propertyKey,
          operator,
          values: normalizedValues,
        });
      }
      return;
    }

    // Handle single-value tokens
    let normalized = '';
    if (typeof rawValue === 'string') {
      normalized = rawValue.trim();
    } else if (rawValue !== undefined && rawValue !== null) {
      normalized = String(rawValue).trim();
    }

    if (!normalized) {
      return;
    }

    collected.push({ propertyKey: entry.propertyKey, operator, value: normalized });
  };

  (query.tokenGroups ?? []).forEach(visit);
  (query.tokens ?? []).forEach(visit);

  return collected;
};

/**
 * Builds FilterInput for GraphQL query from PropertyFilter query and pagination state
 *
 * @param query - PropertyFilter query from AWS UI component
 * @param pageIndex - 1-based page index (URL state)
 * @param sortingField - Field to sort by
 * @param sortingDescending - Sort direction
 * @param pageSize - Number of items per page
 * @returns FilterInput for GraphQL query with 0-based pageIdx
 */
export const buildFilterInput = (
  query: PropertyFilterProps.Query,
  pageIndex: number,
  sortingField: SortableTemplateField,
  sortingDescending: boolean,
  pageSize: number
): FilterInput => {
  const tokens = collectPropertyFilterTokens(query);

  // Convert 1-based pageIndex to 0-based pageIdx for GraphQL
  const normalizedPageIdx = Number.isFinite(pageIndex) ? Math.max(0, Math.floor(pageIndex - 1)) : 0;

  return {
    pageIdx: normalizedPageIdx,
    limit: pageSize,
    orderBy: sortingField,
    orderDesc: sortingDescending,
    query: tokens.length
      ? {
          operation: query.operation === 'or' ? 'OR' : 'AND',
          tokenGroups: tokens,
        }
      : undefined,
  };
};
