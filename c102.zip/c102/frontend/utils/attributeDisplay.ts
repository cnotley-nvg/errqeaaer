/**
 * Helper functions for formatting multi-value attributes for display.
 */

type ReactNodePrimitive = string | number | null | undefined;

const CROSS_PROGRAM_THRESHOLD = 3;
const CROSS_PROGRAM_LABEL = 'Cross-program';
const PROGRAM_LABELS: Record<string, string> = {
  AGDC: 'Automated Grocery Distribution Center (AGDC)',
  'Air Gateway': 'Amazon Air (Air Gateway)',
  AMXL: 'Amazon Logistics Extra-Large (AMXL)',
  AMZL: 'Amazon Logistics Delivery Station (AMZL)',
  ARS: 'Amazon Robotics Sortable (ARS)',
  ARSC: 'Amazon Robotics Sort Center (ARSC)',
  ATH: 'Amazon Transportation Hub (ATH)',
  SDC: 'Storage and Distribution Center (SDC)',
  '1DC': 'Single Distribution Center (1DC)',
  DSC: 'Dedicated Service Center (DSC)',
  FSC: 'Fleet Service Center (FSC)',
  IXD: 'Inbound Cross Dock (IXD)',
  MGDC: 'Manual Grocery Distribution Center (MGDC)',
  ReLo: 'Reverse Logistics (ReLo)',
  RSR: 'Rural SuperRural (RSR)',
  SC: 'Sort Center (SC)',
  SSD: 'Sub Same Day (SSD)',
  'SSD-DC': 'Sub-Same Day Distribution Center (SSD-DC)',
  'SSD-FC': 'Sub-Same Day Fulfillment Center (SSD-FC)',
  TNS: 'Traditional Non-Sortable (TNS)',
  TS: 'Traditional Sortable (TS)',
  XLDS: 'Extra Large Delivery Station (XLDS)',
  XLFC: 'Extra Large Fulfillment Center (XLFC)',
  XLSC: 'Extra Large Sort Center (XLSC)',
};

export const formatProgramLabel = (program: string | null | undefined): string => {
  if (!program) {
    return '';
  }

  const trimmed = program.trim();
  return PROGRAM_LABELS[trimmed] ?? trimmed;
};

/**
 * Formats array values as comma-separated string.
 * - Single value: returns as-is
 * - Multiple values: returns comma-separated string (e.g., "BTS, Retrofit, STS")
 * - Empty/null: returns null
 *
 * @param values - Array of strings, single string, or null/undefined
 * @returns Formatted string or null
 */
export const formatArrayAsCommaSeparated = (
  values: string[] | string | null | undefined
): ReactNodePrimitive => {
  if (!values) {
    return null;
  }

  const valueArray = Array.isArray(values) ? values : [values];
  const filtered = valueArray.filter(Boolean);

  if (filtered.length === 0) {
    return null;
  }

  if (filtered.length === 1) {
    return filtered[0];
  }

  return filtered.join(', ');
};

/**
 * Formats program attribute for display.
 * Special logic: Shows "Cross-program" when MORE than 3 programs exist.
 * Otherwise shows comma-separated list.
 *
 * @example
 * formatProgram(['GCF']) → 'GCF'
 * formatProgram(['GCF', 'ATS']) → 'GCF, ATS'
 * formatProgram(['GCF', 'ATS', 'AMXL']) → 'GCF, ATS, AMXL'
 * formatProgram(['GCF', 'ATS', 'AMXL', 'IXD']) → 'Cross-program'
 * formatProgram(['GCF', 'ATS', 'AMXL', 'IXD', 'SC']) → 'Cross-program'
 */
export const formatProgram = (
  program: string[] | string | null | undefined
): ReactNodePrimitive => {
  if (!program) {
    return null;
  }

  const valueArray = Array.isArray(program) ? program : [program];
  const filtered = valueArray.filter(Boolean);

  if (filtered.length === 0) {
    return null;
  }

  if (filtered.length === 1) {
    return filtered[0];
  }

  // Show "Cross-program" ONLY when MORE than 3 programs (4+)
  if (filtered.length > CROSS_PROGRAM_THRESHOLD) {
    return CROSS_PROGRAM_LABEL;
  }

  // Otherwise show comma-separated list (2-3 values)
  return filtered.join(', ');
};

/**
 * Formats projectType attribute for display.
 * Always shows comma-separated list, regardless of count.
 *
 * @example
 * formatProjectType(['BTS']) → 'BTS'
 * formatProjectType(['BTS', 'Retrofit']) → 'BTS, Retrofit'
 * formatProjectType(['BTS', 'Retrofit', 'STS', 'Expansion']) → 'BTS, Retrofit, STS, Expansion'
 */
export const formatProjectType = (
  projectType: string[] | string | null | undefined
): ReactNodePrimitive => {
  return formatArrayAsCommaSeparated(projectType);
};

/**
 * Formats roomFeatureZone attribute for display.
 * Always shows comma-separated list, regardless of count.
 *
 * @example
 * formatRoomFeatureZone(['Warehouse']) → 'Warehouse'
 * formatRoomFeatureZone(['Warehouse', 'Office']) → 'Warehouse, Office'
 * formatRoomFeatureZone(['Warehouse', 'Office', 'MEP', 'Site']) → 'Warehouse, Office, MEP, Site'
 */
export const formatRoomFeatureZone = (
  roomFeatureZone: string[] | string | null | undefined
): ReactNodePrimitive => {
  return formatArrayAsCommaSeparated(roomFeatureZone);
};
