import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { ElectricalCalculatorResult } from '../api/electricalBenchmark';

export interface ProjectParameters {
  streetAddress: string;
  city: string;
  zipcode: string;
  country: string;
  state?: string;
  facilityType: string;
  designTemplate: string;
  squareFootage: string;
}

export interface ElectricalBenchmarkPdfData {
  projectParams: ProjectParameters;
  electricalData: ElectricalCalculatorResult;
  generatedDate: string;
  roofFactor?: number;
  solarPowerDensity?: number;
}

/**
 * Formats a number with specified decimal places
 */
const formatNumber = (value: number, decimals = 0): string => {
  return value.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
};

/**
 * Formats a decimal as percentage
 */
const formatPercentage = (value: number): string => {
  return `${Math.round(value * 100)}%`;
};

/**
 * Generates a PDF report for electrical benchmarking analysis
 * @param data - The project parameters and electrical calculation data
 */
export const generateElectricalBenchmarkPdf = (data: ElectricalBenchmarkPdfData): void => {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const marginLeft = 15;
  const marginRight = 15;
  const contentWidth = pageWidth - marginLeft - marginRight;

  let yPosition = 15;

  // ========================================
  // HEADER SECTION - Project Parameters
  // ========================================

  // Document Title
  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text('Electrical Benchmark Report', marginLeft, yPosition);

  // Generated date - top right corner (without "Generated:" label)
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const generatedValue = data.generatedDate;
  const generatedValueWidth = doc.getTextWidth(generatedValue);
  doc.text(generatedValue, pageWidth - marginRight - generatedValueWidth, yPosition);

  yPosition += 8;

  // Horizontal line under title
  doc.setLineWidth(0.5);
  doc.line(marginLeft, yPosition, pageWidth - marginRight, yPosition);
  yPosition += 8;

  // Project Parameters Section
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Project Parameters', marginLeft, yPosition);
  yPosition += 7;

  doc.setFontSize(10);

  // First row of parameters - Address fields in logical order
  const col1X = marginLeft;
  const col2X = marginLeft + contentWidth / 4;
  const col3X = marginLeft + (contentWidth / 4) * 2;
  const col4X = marginLeft + (contentWidth / 4) * 3;

  doc.setFont('helvetica', 'bold');
  doc.text('Street address:', col1X, yPosition);
  doc.setFont('helvetica', 'normal');
  doc.text(data.projectParams.streetAddress, col1X, yPosition + 5);

  doc.setFont('helvetica', 'bold');
  doc.text('City:', col2X, yPosition);
  doc.setFont('helvetica', 'normal');
  doc.text(data.projectParams.city, col2X, yPosition + 5);

  doc.setFont('helvetica', 'bold');
  doc.text('State:', col3X, yPosition);
  doc.setFont('helvetica', 'normal');
  doc.text(data.projectParams.state || '-', col3X, yPosition + 5);

  doc.setFont('helvetica', 'bold');
  doc.text('Zip/Postal code:', col4X, yPosition);
  doc.setFont('helvetica', 'normal');
  doc.text(data.projectParams.zipcode, col4X, yPosition + 5);

  yPosition += 12;

  // Second row of parameters - Project details
  doc.setFont('helvetica', 'bold');
  doc.text('Country:', col1X, yPosition);
  doc.setFont('helvetica', 'normal');
  doc.text(data.projectParams.country, col1X, yPosition + 5);

  doc.setFont('helvetica', 'bold');
  doc.text('Project type:', col2X, yPosition);
  doc.setFont('helvetica', 'normal');
  doc.text(data.projectParams.facilityType || '-', col2X, yPosition + 5);

  doc.setFont('helvetica', 'bold');
  doc.text('Design template:', col3X, yPosition);
  doc.setFont('helvetica', 'normal');
  doc.text(data.projectParams.designTemplate, col3X, yPosition + 5);

  doc.setFont('helvetica', 'bold');
  doc.text('Total square footage:', col4X, yPosition);
  doc.setFont('helvetica', 'normal');
  doc.text(data.projectParams.squareFootage, col4X, yPosition + 5);

  yPosition += 18;

  // ========================================
  // CATEGORY LOAD ANALYSIS TABLE
  // ========================================

  // Section heading
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Category Load Analysis', marginLeft, yPosition);
  yPosition += 4.5;

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Detailed breakdown of electrical loads by category', marginLeft, yPosition);
  yPosition += 5;

  // Prepare category loads table data
  const categoryHeaders = [
    [
      'Load Description',
      'Connected Load\nkVA',
      'Connected Load\nAmps',
      'Demand/Diversity\nFactor',
      'Diversified Load\nkVA',
      'Diversified Load\nAmps',
      'Utility Demand\nFactor',
      'Utility Power Demand\nkVA',
      'Utility Power Demand\nAmps',
    ],
  ];

  const categoryData = [
    ...data.electricalData.categoryLoads.map((load) => [
      load.category,
      formatNumber(load.connectedLoad.kVA, 1),
      formatNumber(load.connectedLoad.amps, 1),
      formatPercentage(load.demandDiversityFactor),
      formatNumber(load.diversifiedLoad.kVA, 1),
      formatNumber(load.diversifiedLoad.amps, 1),
      formatPercentage(load.utilityDemandFactor),
      formatNumber(load.utilityPowerDemand.kVA, 1),
      formatNumber(load.utilityPowerDemand.amps, 1),
    ]),
    [
      'Total',
      formatNumber(data.electricalData.total.connectedLoad.kVA),
      formatNumber(data.electricalData.total.connectedLoad.amps),
      '',
      formatNumber(data.electricalData.total.diversifiedLoad.kVA),
      formatNumber(data.electricalData.total.diversifiedLoad.amps),
      '',
      formatNumber(data.electricalData.total.utilityPowerDemand.kVA),
      formatNumber(data.electricalData.total.utilityPowerDemand.amps),
    ],
  ];

  // Generate category loads table
  autoTable(doc, {
    head: categoryHeaders,
    body: categoryData,
    startY: yPosition,
    margin: { left: marginLeft, right: marginRight },
    styles: {
      fontSize: 8,
      cellPadding: 2,
      lineColor: [0, 0, 0],
      lineWidth: 0,
      halign: 'right',
    },
    headStyles: {
      fillColor: [255, 255, 255],
      textColor: [0, 0, 0],
      fontStyle: 'bold',
      fontSize: 8,
      halign: 'right',
      valign: 'middle',
      lineWidth: { bottom: 0.05, top: 0.05, left: 0, right: 0 },
    },
    bodyStyles: {
      lineWidth: { bottom: 0.05, top: 0, left: 0, right: 0 },
    },
    columnStyles: {
      0: { halign: 'left', cellWidth: 45 }, // Load Description - left align
      1: { halign: 'right', cellWidth: 'auto' },
      2: { halign: 'right', cellWidth: 'auto' },
      3: { halign: 'right', cellWidth: 'auto' },
      4: { halign: 'right', cellWidth: 'auto' },
      5: { halign: 'right', cellWidth: 'auto' },
      6: { halign: 'right', cellWidth: 'auto' },
      7: { halign: 'right', cellWidth: 'auto' },
      8: { halign: 'right', cellWidth: 'auto' },
    },
    didParseCell: (data) => {
      // Make the Total row bold
      if (data.section === 'body' && data.row.index === categoryData.length - 1) {
        data.cell.styles.fontStyle = 'bold';
      }
      // Left align the first column header (Load Description)
      if (data.section === 'head' && data.column.index === 0) {
        data.cell.styles.halign = 'left';
      }
    },
    theme: 'plain',
  });

  // Get final Y position after table
  yPosition = (doc as any).lastAutoTable.finalY + 10;

  // Check if we need a new page for summary metrics
  if (yPosition > pageHeight - 60) {
    doc.addPage();
    yPosition = 15;
  }

  // ========================================
  // SUMMARY METRICS TABLE
  // ========================================

  // Section heading
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Summary Metrics', marginLeft, yPosition);
  yPosition += 4.5;

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Key electrical power demand metrics for design planning', marginLeft, yPosition);
  yPosition += 5;

  // Prepare summary metrics table data
  const summaryHeaders = [['Metric', 'kVA', 'Amps']];

  const summaryData = [
    [
      'Estimate total power demand for the site',
      formatNumber(data.electricalData.o1.kVA),
      formatNumber(data.electricalData.o1.amps),
    ],
    [
      'Estimated rooftop solar size (potential)',
      formatNumber(data.electricalData.o2.kVA),
      formatNumber(data.electricalData.o2.amps),
    ],
    [
      'Utility power demand request (with rooftop solar)',
      formatNumber(data.electricalData.o3.kVA),
      formatNumber(data.electricalData.o3.amps),
    ],
    [
      'Service ratings: number of 480VAC switchboards and their ratings',
      '',
      `${formatNumber(data.electricalData.o4)} Units`,
    ],
  ];

  // Generate summary metrics table
  autoTable(doc, {
    head: summaryHeaders,
    body: summaryData,
    startY: yPosition,
    margin: { left: marginLeft, right: marginRight },
    tableWidth: 'auto', // Let table stretch to fill available width
    styles: {
      fontSize: 9,
      cellPadding: 3,
      lineColor: [0, 0, 0],
      lineWidth: 0,
    },
    headStyles: {
      fillColor: [255, 255, 255],
      textColor: [0, 0, 0],
      fontStyle: 'bold',
      fontSize: 9,
      halign: 'right',
      lineWidth: { bottom: 0.05, top: 0.05, left: 0, right: 0 },
    },
    bodyStyles: {
      lineWidth: { bottom: 0.05, top: 0, left: 0, right: 0 },
    },
    columnStyles: {
      0: { halign: 'left', cellWidth: 'auto' },
      1: { halign: 'right', cellWidth: 60 },
      2: { halign: 'right', cellWidth: 60 },
    },
    didParseCell: (data) => {
      // Left align the first column header (Metric)
      if (data.section === 'head' && data.column.index === 0) {
        data.cell.styles.halign = 'left';
      }
    },
    theme: 'plain',
  });

  // Add solar calculation parameters if O2 has non-zero value
  if (
    data.electricalData.o2.kVA > 0 &&
    data.roofFactor !== undefined &&
    data.solarPowerDensity !== undefined
  ) {
    yPosition = (doc as any).lastAutoTable.finalY + 5; // Increased spacing from table
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
  }

  // ========================================
  // ADD PAGE NUMBERS TO ALL PAGES
  // ========================================

  // Ensure all pages have page numbers (in case first page doesn't have a table)
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(`Page ${i} of ${totalPages}`, pageWidth / 2, pageHeight - 8, { align: 'center' });
  }

  // ========================================
  // SAVE PDF
  // ========================================

  const timestamp = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
  const filename = `Electrical_Benchmark_Report_${timestamp}.pdf`;

  doc.save(filename);
};

/**
 * Convenience function to download the electrical benchmark report
 */
export const downloadElectricalBenchmarkReport = (
  projectParams: ProjectParameters,
  electricalData: ElectricalCalculatorResult,
  roofFactor?: number,
  solarPowerDensity?: number
): void => {
  const generatedDate = new Date().toLocaleString();

  generateElectricalBenchmarkPdf({
    projectParams,
    electricalData,
    generatedDate,
    roofFactor,
    solarPowerDensity,
  });
};
