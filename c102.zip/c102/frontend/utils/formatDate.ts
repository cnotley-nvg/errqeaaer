/**
 * Date formatting utilities
 */

/**
 * Format date as "DD Mon YYYY" (e.g., "15 Jan 2026")
 * Used in: StandardTable, StandardCardList, StandardOverviewMetadata, overviewUtils
 */
export function formatDateShort(value?: string | Date | null): string {
  if (!value) {
    return '';
  }

  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) {
    return typeof value === 'string' ? value : '';
  }

  return date.toLocaleDateString('en-US', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    timeZone: 'UTC',
  });
}

/**
 * Format date as "Month DD, YYYY" (e.g., "January 15, 2026")
 * Used in: TemplateTable, TemplateCardList
 */
export function formatDateLong(value?: string | null): string {
  if (!value) {
    return '';
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return value;
  }

  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

/**
 * Format date using browser default locale
 * Used in: TemplateFilesTable
 */
export function formatDateDefault(value?: string | null): string {
  if (!value) {
    return '';
  }

  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString();
}
