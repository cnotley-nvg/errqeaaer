/**
 * Utility functions for building Autodesk Construction Cloud (ACC), BIM360, and BRS URLs
 */

/**
 * Platform type for Autodesk projects
 */
export type AutodeskPlatform = 'ACC' | 'BIM360';

/**
 * Detects whether a project is on ACC or BIM360 based on the project ID format
 *
 * @param accProjectId - Project ID to check
 * @returns 'ACC' if project ID has "b." prefix, 'BIM360' otherwise
 *
 * @example
 * ```typescript
 * detectPlatform('b.7f89f6ea-5a3c-49ed-b024-599f9b9003cf') // 'ACC'
 * detectPlatform('a195ba78-ce59-436c-8fe4-29597d80dcb8')   // 'BIM360'
 * ```
 */
export const detectPlatform = (accProjectId: string): AutodeskPlatform => {
  return accProjectId.startsWith('b.') ? 'ACC' : 'BIM360';
};

/**
 * Builds a BIM360 project folder URL from project and folder identifiers
 *
 * @param projectId - BIM360 project ID (UUID without prefix)
 * @param folderId - Folder ID (format: "urn:adsk.wipprod:fs.folder:co.{id}")
 * @returns Complete BIM360 URL to the folder in the project
 *
 * @example
 * ```typescript
 * buildBim360FolderUrl(
 *   'a195ba78-ce59-436c-8fe4-29597d80dcb8',
 *   'urn:adsk.wipprod:fs.folder:co.8rl67c1_S82DURRIUB_rQw'
 * )
 * // Returns: "https://docs.b360.autodesk.com/projects/a195ba78-ce59-436c-8fe4-29597d80dcb8/folders/urn:adsk.wipprod:fs.folder:co.8rl67c1_S82DURRIUB_rQw"
 * ```
 */
export const buildBim360FolderUrl = (projectId: string, folderId: string): string => {
  return `https://docs.b360.autodesk.com/projects/${projectId}/folders/${folderId}`;
};

/**
 * Builds an ACC project folder URL from project and folder identifiers
 * This function automatically detects whether the project is on ACC or BIM360
 * based on the project ID format and builds the appropriate URL.
 *
 * @param accProjectId - Project ID (format: "b.{uuid}" for ACC or "{uuid}" for BIM360)
 * @param accFolderId - Folder ID (format: "urn:adsk.wipprod:fs.folder:co.{id}")
 * @returns Complete URL to the folder in the project (ACC or BIM360)
 *
 * @example
 * ```typescript
 * // ACC project (has "b." prefix)
 * buildAccFolderUrl(
 *   'b.7f89f6ea-5a3c-49ed-b024-599f9b9003cf',
 *   'urn:adsk.wipprod:fs.folder:co.vglRX7a0QiWvFEniu37PIA'
 * )
 * // Returns: "https://acc.autodesk.com/docs/files/projects/7f89f6ea-5a3c-49ed-b024-599f9b9003cf?folderUrn=urn%3Aadsk.wipprod%3Afs.folder%3Aco.vglRX7a0QiWvFEniu37PIA"
 *
 * // BIM360 project (no "b." prefix)
 * buildAccFolderUrl(
 *   'a195ba78-ce59-436c-8fe4-29597d80dcb8',
 *   'urn:adsk.wipprod:fs.folder:co.8rl67c1_S82DURRIUB_rQw'
 * )
 * // Returns: "https://docs.b360.autodesk.com/projects/a195ba78-ce59-436c-8fe4-29597d80dcb8/folders/urn:adsk.wipprod:fs.folder:co.8rl67c1_S82DURRIUB_rQw"
 * ```
 */
export const buildAccFolderUrl = (accProjectId: string, accFolderId: string): string => {
  const platform = detectPlatform(accProjectId);

  if (platform === 'BIM360') {
    // BIM360 uses plain UUID
    return buildBim360FolderUrl(accProjectId, accFolderId);
  }

  // ACC: Strip "b." prefix from project ID
  const projectId = accProjectId.substring(2);

  // URL encode the folder URN for ACC
  const encodedFolderUrn = encodeURIComponent(accFolderId);

  // Build the ACC URL
  return `https://acc.autodesk.com/docs/files/projects/${projectId}?folderUrn=${encodedFolderUrn}`;
};

/**
 * Checks if an ACC project ID is valid
 * @param accProjectId - ACC project ID to validate
 * @returns true if valid format, false otherwise
 */
export const isValidAccProjectId = (accProjectId: string | null | undefined): boolean => {
  if (!accProjectId) return false;

  // Valid formats: "b.{uuid}" or just "{uuid}"
  const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const strippedId = accProjectId.startsWith('b.') ? accProjectId.substring(2) : accProjectId;

  return uuidPattern.test(strippedId);
};

/**
 * Checks if an ACC folder ID is valid
 * @param accFolderId - ACC folder ID to validate
 * @returns true if valid format, false otherwise
 */
export const isValidAccFolderId = (accFolderId: string | null | undefined): boolean => {
  if (!accFolderId) return false;

  // Valid format: "urn:adsk.wipprod:fs.folder:co.{id}"
  return accFolderId.startsWith('urn:adsk.wipprod:fs.folder:co.');
};

/**
 * Builds a BRS (Building Requirements Specification) detail URL
 *
 * @param brsId - BRS ID (format: Salesforce ID like "a1q3t00000BmdJHAAZ")
 * @returns Complete BRS URL to the detail page
 *
 * @example
 * ```typescript
 * buildBrsUrl('a1q3t00000BmdJHAAZ')
 * // Returns: "https://amznfulfillment.my.site.com/brs/brs-detail?brsId=a1q3t00000BmdJHAAZ"
 * ```
 */
export const buildBrsUrl = (brsId: string): string => {
  return `https://amznfulfillment.my.site.com/brs/brs-detail?brsId=${brsId}`;
};

/**
 * Checks if a BRS ID is valid
 * @param brsId - BRS ID to validate (Salesforce ID format)
 * @returns true if valid format, false otherwise
 */
export const isValidBrsId = (brsId: string | null | undefined): boolean => {
  if (!brsId) return false;

  // Salesforce ID format: 15 or 18 alphanumeric characters
  const salesforceIdPattern = /^[a-zA-Z0-9]{15}([a-zA-Z0-9]{3})?$/;
  return salesforceIdPattern.test(brsId);
};

/**
 * Checks if a username is valid for Phone Tool linking
 * @param username - Username to validate
 * @returns true if valid Amazon username format (lowercase alphanumeric), false otherwise
 */
export const isValidPhoneToolUsername = (username: string | null | undefined): boolean => {
  if (!username) return false;

  // Amazon usernames are lowercase alphanumeric strings (no spaces, no special chars)
  // Examples: johsong, shaghata, tylure, abodkay
  const usernamePattern = /^[a-z][a-z0-9]*$/;
  return usernamePattern.test(username.trim().toLowerCase());
};

/**
 * Builds a Phone Tool user profile URL
 *
 * @param username - Amazon username/login (e.g., "johsong", "shaghata")
 * @returns Complete Phone Tool URL to the user's profile page
 *
 * @example
 * ```typescript
 * buildPhoneToolUrl('johsong')
 * // Returns: "https://phonetool.amazon.com/users/johsong"
 * ```
 */
export const buildPhoneToolUrl = (username: string): string => {
  return `https://phonetool.amazon.com/users/${username}`;
};
