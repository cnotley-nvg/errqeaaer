import { validators, createStructuralValidator } from '../../lib/versioned-storage';
import type { CatalogPreferences } from './types';

/**
 * Schema for card breakpoints
 * Each breakpoint defines a minimum width and number of cards per row
 */
const cardBreakpointSchema = validators.object(
  {
    minWidth: validators.number(true),
    cards: validators.number(true),
  },
  true
);

/**
 * Schema for content display items
 * Each item has an id (column/field name) and visibility flag
 */
const contentDisplayItemSchema = validators.object(
  {
    id: validators.string(true),
    visible: validators.boolean(true),
  },
  true
);

/**
 * Schema for table preferences
 * Includes content display array and optional UI settings
 */
const tablePreferencesSchema = validators.object(
  {
    contentDisplay: validators.array(contentDisplayItemSchema, true),
    wrapLines: validators.boolean(false), // Optional
    stripedRows: validators.boolean(false), // Optional
  },
  true
);

/**
 * Schema for card preferences
 * Includes content display array and breakpoints for responsive layout
 */
const cardPreferencesSchema = validators.object(
  {
    contentDisplay: validators.array(contentDisplayItemSchema, true),
    cardsPerRowBreakpoints: validators.array(cardBreakpointSchema, true),
  },
  true
);

/**
 * Complete schema for CatalogPreferences (v3)
 * Includes table and card view preferences plus viewType and pageSizeFallback
 */
const catalogPreferencesSchema = validators.object(
  {
    table: tablePreferencesSchema,
    cards: cardPreferencesSchema,
    viewType: validators.string(true), // 'table' or 'card' - validated below
    pageSizeFallback: validators.number(true),
  },
  true
);

/**
 * Validator for CatalogPreferences (v3)
 *
 * Validates:
 * - Table preferences (contentDisplay array, wrapLines, stripedRows)
 * - Card preferences (contentDisplay array, cardsPerRowBreakpoints array)
 * - View type ('table' or 'card')
 * - Page size fallback (number > 0)
 * - Required fields are present with correct types
 * - Optional fields are validated if present
 *
 * Note: This uses pass-through mode, so extra fields are preserved.
 * Column IDs are not restricted to specific values - this allows for
 * deployment-specific columns without breaking validation.
 *
 * @param data - Data to validate
 * @returns Type guard indicating if data is valid CatalogPreferences
 */
export function validateCatalogPreferences(data: unknown): data is CatalogPreferences {
  // First check basic structure
  if (!data || typeof data !== 'object') {
    return false;
  }

  const prefs = data as any;

  // Validate required fields exist
  if (
    !prefs.table ||
    !prefs.cards ||
    !prefs.viewType ||
    typeof prefs.pageSizeFallback !== 'number'
  ) {
    return false;
  }

  // Validate viewType enum
  if (prefs.viewType !== 'table' && prefs.viewType !== 'card') {
    return false;
  }

  // Validate pageSizeFallback range
  if (prefs.pageSizeFallback <= 0) {
    return false;
  }

  // Use structural validator for detailed validation
  return createStructuralValidator<CatalogPreferences>(catalogPreferencesSchema)(data);
}
