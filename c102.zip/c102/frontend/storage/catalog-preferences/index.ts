/**
 * Catalog Preferences Storage
 *
 * Provides versioned localStorage for template and standard catalog preferences.
 * Handles automatic migration from legacy v0 (separate keys) through v1, v2 to current v3 format.
 *
 * Usage:
 * ```typescript
 * import { templateCatalogPreferencesStore } from './storage/catalog-preferences';
 *
 * // Get current preferences
 * const prefs = templateCatalogPreferencesStore.get();
 *
 * // Update preferences
 * templateCatalogPreferencesStore.set({
 *   ...prefs,
 *   pageSize: 30,
 *   viewType: 'table',
 * });
 * ```
 */

import { createVersionedStore } from '../../lib/versioned-storage';
import type { CatalogPreferences } from './types';
import {
  CURRENT_VERSION,
  TEMPLATE_CATALOG_KEY,
  STANDARD_CATALOG_KEY,
  PUBLISHED_KIT_CATALOG_KEY,
} from './types';
import {
  DEFAULT_TEMPLATE_CATALOG_PREFERENCES,
  DEFAULT_STANDARD_CATALOG_PREFERENCES,
  DEFAULT_PUBLISHED_KIT_CATALOG_PREFERENCES,
} from './defaults';
import { validateCatalogPreferences } from './validators';
import {
  migrationV0toV1Templates,
  migrationV0toV1Standards,
  migrationV1toV2,
  migrationV2toV3Templates,
  migrationV2toV3Standards,
  migrationV3toV4,
} from './migrations';

/**
 * Versioned store for template catalog preferences
 *
 * Automatically migrates from:
 * - v0: Separate localStorage keys (template-catalog-table-preferences, template-catalog-card-preferences)
 * - v1: Unified structure with old breakpoint thresholds
 * - v2: Current version with updated breakpoints
 * - v3: Added pageSize and viewType
 */
export const templateCatalogPreferencesStore = createVersionedStore<CatalogPreferences>({
  key: TEMPLATE_CATALOG_KEY,
  version: CURRENT_VERSION,
  migrations: [
    migrationV0toV1Templates,
    migrationV1toV2,
    migrationV2toV3Templates,
    migrationV3toV4,
  ],
  defaults: DEFAULT_TEMPLATE_CATALOG_PREFERENCES,
  validator: validateCatalogPreferences,
  onMigrationSuccess: (from, to) => {
    if ((import.meta as any).env?.DEV) {
      console.log(
        `[CatalogPreferences] Migrated template catalog preferences from v${from} to v${to}`
      );
    }
  },
  onMigrationError: (error: Error) => {
    console.error('[CatalogPreferences] Template catalog preferences migration failed:', error);
  },
});

/**
 * Versioned store for standard catalog preferences
 *
 * Automatically migrates from:
 * - v0: Separate localStorage keys (standard-catalog-table-preferences, standard-catalog-card-preferences)
 * - v1: Unified structure with old breakpoint thresholds
 * - v2: Current version with updated breakpoints
 * - v3: Added pageSize and viewType
 */
export const standardCatalogPreferencesStore = createVersionedStore<CatalogPreferences>({
  key: STANDARD_CATALOG_KEY,
  version: CURRENT_VERSION,
  migrations: [
    migrationV0toV1Standards,
    migrationV1toV2,
    migrationV2toV3Standards,
    migrationV3toV4,
  ],
  defaults: DEFAULT_STANDARD_CATALOG_PREFERENCES,
  validator: validateCatalogPreferences,
  onMigrationSuccess: (from, to) => {
    if ((import.meta as any).env?.DEV) {
      console.log(
        `[CatalogPreferences] Migrated standard catalog preferences from v${from} to v${to}`
      );
    }
  },
  onMigrationError: (error: Error) => {
    console.error('[CatalogPreferences] Standard catalog preferences migration failed:', error);
  },
});

/**
 * Versioned store for published kits catalog preferences.
 *
 * There are no legacy migrations today (kits didn't previously store catalog preferences),
 * but we still use the same versioned store mechanism for consistency and future-proofing.
 */
export const publishedKitCatalogPreferencesStore = createVersionedStore<CatalogPreferences>({
  key: PUBLISHED_KIT_CATALOG_KEY,
  version: CURRENT_VERSION,
  migrations: [migrationV3toV4],
  defaults: DEFAULT_PUBLISHED_KIT_CATALOG_PREFERENCES,
  validator: validateCatalogPreferences,
  onMigrationError: (error: Error) => {
    console.error(
      '[CatalogPreferences] Published kit catalog preferences migration failed:',
      error
    );
  },
});

// Re-export types and defaults for convenience
export type {
  CatalogPreferences,
  CatalogPreferencesV0,
  CatalogPreferencesV1,
  CatalogPreferencesV2,
  CatalogPreferencesV3,
  CatalogPreferencesV4,
  TablePreferences,
  CardPreferences,
  ContentDisplayItem,
  CardBreakpoint,
} from './types';

export {
  DEFAULT_TEMPLATE_CATALOG_PREFERENCES,
  DEFAULT_STANDARD_CATALOG_PREFERENCES,
  DEFAULT_PUBLISHED_KIT_CATALOG_PREFERENCES,
  DEFAULT_PAGE_SIZE_FALLBACK,
} from './defaults';

export { CURRENT_VERSION } from './types';
