/**
 * React hook wrapper for versioned catalog preferences storage
 *
 * This hook wraps the VersionedStore to provide a React-friendly API
 * that maintains compatibility with the existing useCatalogPreferences interface.
 */

import { useState, useCallback, useEffect, useRef } from 'react';
import type { VersionedStore } from '../../lib/versioned-storage';
import type { CatalogPreferences } from './types';

export interface CatalogPreferencesHookResult {
  preferences: CatalogPreferences;
  updateTablePreferences: (updates: Partial<CatalogPreferences['table']>) => void;
  updateCardsPreferences: (updates: Partial<CatalogPreferences['cards']>) => void;
  updateViewType: (viewType: 'table' | 'card') => void;
  updatePageSizeFallback: (pageSizeFallback: number) => void;
  resetToDefaults: () => void;
}

/**
 * Create a React hook for catalog preferences using versioned storage
 *
 * @param store - VersionedStore instance (templateCatalogPreferencesStore or standardCatalogPreferencesStore)
 * @returns Hook function that provides preferences state and update functions
 *
 * @example
 * ```typescript
 * import { templateCatalogPreferencesStore } from '../../../storage/catalog-preferences';
 *
 * export const useCatalogPreferences = createVersionedCatalogPreferencesHook(
 *   templateCatalogPreferencesStore
 * );
 * ```
 */
export function createVersionedCatalogPreferencesHook(
  store: VersionedStore<CatalogPreferences>
): () => CatalogPreferencesHookResult {
  return function useVersionedCatalogPreferences(): CatalogPreferencesHookResult {
    // Load initial preferences on mount
    const initialPreferencesRef = useRef<CatalogPreferences | null>(null);

    if (initialPreferencesRef.current === null) {
      const result = store.load();
      initialPreferencesRef.current = result.success ? result.data : result.fallback;
    }

    const [preferences, setPreferences] = useState<CatalogPreferences>(
      initialPreferencesRef.current
    );

    // Sync with localStorage on mount (in case it changed in another tab)
    useEffect(() => {
      const result = store.load();
      const loadedPrefs = result.success ? result.data : result.fallback;
      setPreferences(loadedPrefs);
    }, []);

    /**
     * Update table-specific preferences
     * Merges updates with existing preferences and saves to storage
     */
    const updateTablePreferences = useCallback((updates: Partial<CatalogPreferences['table']>) => {
      setPreferences((prev) => {
        const updated: CatalogPreferences = {
          ...prev,
          table: { ...prev.table, ...updates },
        };

        // Save to localStorage
        store.save(updated);

        return updated;
      });
    }, []);

    /**
     * Update card-specific preferences
     * Merges updates with existing preferences and saves to storage
     */
    const updateCardsPreferences = useCallback((updates: Partial<CatalogPreferences['cards']>) => {
      setPreferences((prev) => {
        const updated: CatalogPreferences = {
          ...prev,
          cards: { ...prev.cards, ...updates },
        };

        // Save to localStorage
        store.save(updated);

        return updated;
      });
    }, []);

    /**
     * Update page size fallback
     * Saves to storage immediately
     */
    const updatePageSizeFallback = useCallback((pageSizeFallback: number) => {
      setPreferences((prev) => {
        const updated: CatalogPreferences = {
          ...prev,
          pageSizeFallback,
        };

        // Save to localStorage
        store.save(updated);

        return updated;
      });
    }, []);

    /**
     * Update view type (table or card)
     * Saves to storage immediately
     */
    const updateViewType = useCallback((viewType: 'table' | 'card') => {
      setPreferences((prev) => {
        const updated: CatalogPreferences = {
          ...prev,
          viewType,
        };

        // Save to localStorage
        store.save(updated);

        return updated;
      });
    }, []);

    /**
     * Reset preferences to defaults
     * Removes stored preferences and reverts to default values
     */
    const resetToDefaults = useCallback(() => {
      // Remove from localStorage
      store.remove();

      // Load defaults (which will be returned since no stored data exists)
      const result = store.load();
      const defaults = result.success ? result.data : result.fallback;

      setPreferences(defaults);
    }, []);

    return {
      preferences,
      updateTablePreferences,
      updateCardsPreferences,
      updateViewType,
      updatePageSizeFallback,
      resetToDefaults,
    };
  };
}
