import type { CardBreakpoint } from './types';

export const TARGET_BREAKPOINTS = [768, 1366, 1920] as const;

export const DEFAULT_CARDS_BY_BREAKPOINT: Record<number, number> = {
  768: 2,
  1366: 3,
  1920: 4,
};

const LEGACY_BREAKPOINT_MAP: Record<number, number> = {
  0: 768,
  1921: 1920,
  2561: 1920,
};

const getCardRangeForBreakpoint = (minWidth: number): { min: number; max: number } => {
  if (minWidth === 768) return { min: 1, max: 2 };
  if (minWidth === 1366) return { min: 2, max: 4 };
  if (minWidth === 1920) return { min: 3, max: 6 };
  return { min: 1, max: 6 };
};

const clamp = (value: number, min: number, max: number): number =>
  Math.max(min, Math.min(max, value));

export function normalizeBreakpoints(breakpoints: CardBreakpoint[]): CardBreakpoint[] {
  const byMinWidth = new Map<number, CardBreakpoint>();

  breakpoints.forEach((bp) => {
    const normalizedMinWidth = LEGACY_BREAKPOINT_MAP[bp.minWidth] ?? bp.minWidth;
    if (!byMinWidth.has(normalizedMinWidth)) {
      byMinWidth.set(normalizedMinWidth, { ...bp, minWidth: normalizedMinWidth });
    }
  });

  return TARGET_BREAKPOINTS.map((minWidth) => {
    const existing = byMinWidth.get(minWidth);
    const { min, max } = getCardRangeForBreakpoint(minWidth);
    const defaultCards = DEFAULT_CARDS_BY_BREAKPOINT[minWidth];
    const cards = existing ? clamp(existing.cards, min, max) : defaultCards;
    return { minWidth, cards };
  });
}
