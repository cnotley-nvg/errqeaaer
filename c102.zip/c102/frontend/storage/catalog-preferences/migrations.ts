/**
 * Migrations for catalog preferences
 *
 * Migration history:
 * - v0 → v1: Merge separate table/card localStorage keys into unified structure
 * - v1 → v2: Update breakpoint thresholds (1920→1921, 2560→2561)
 * - v2 → v3: Add pageSize and viewType to preferences
 * - v3 → v4: Normalize breakpoints from 5 to 3 fixed options (768, 1366, 1920)
 */

import type { Migration } from '../../lib/versioned-storage';
import type {
  CatalogPreferencesV1,
  CatalogPreferencesV2,
  CatalogPreferencesV3,
  CatalogPreferencesV4,
  LegacyTablePreferencesV0,
  LegacyCardPreferencesV0,
} from './types';
import { DEFAULT_CARD_BREAKPOINTS, DEFAULT_PAGE_SIZE_FALLBACK } from './defaults';
import { normalizeBreakpoints } from './normalizeBreakpoints';

/**
 * Migration from v0 to v1: Merge separate localStorage keys
 *
 * v0 had separate keys:
 * - 'template-catalog-table-preferences' → table preferences
 * - 'template-catalog-card-preferences' → card preferences
 *
 * v1 unified them into a single 'template-catalog-preferences' key
 */
export const migrationV0toV1Templates: Migration<any, CatalogPreferencesV1> = {
  from: 0,
  to: 1,
  description: 'Merge separate table/card localStorage keys into unified structure',
  migrate: (_oldData: any) => {
    // Try to load old separate keys
    let tablePrefs: LegacyTablePreferencesV0 | null = null;
    let cardPrefs: LegacyCardPreferencesV0 | null = null;

    try {
      const tableRaw = localStorage.getItem('template-catalog-table-preferences');
      if (tableRaw) {
        tablePrefs = JSON.parse(tableRaw);
        // Clean up old key
        localStorage.removeItem('template-catalog-table-preferences');
      }
    } catch (e) {
      console.warn('[Migration v0→v1] Failed to parse table preferences:', e);
    }

    try {
      const cardRaw = localStorage.getItem('template-catalog-card-preferences');
      if (cardRaw) {
        cardPrefs = JSON.parse(cardRaw);
        // Clean up old key
        localStorage.removeItem('template-catalog-card-preferences');
      }
    } catch (e) {
      console.warn('[Migration v0→v1] Failed to parse card preferences:', e);
    }

    // Build unified structure
    const unified: CatalogPreferencesV1 = {
      table: {
        contentDisplay: tablePrefs?.contentDisplay || [],
        wrapLines: tablePrefs?.wrapLines,
        stripedRows: tablePrefs?.stripedRows,
      },
      cards: {
        contentDisplay: cardPrefs?.contentDisplay || [],
        cardsPerRowBreakpoints: cardPrefs?.cardsPerRowBreakpoints || [...DEFAULT_CARD_BREAKPOINTS],
      },
    };

    return unified;
  },
};

/**
 * Migration from v0 to v1 for standards catalog
 * Same logic but different localStorage keys
 */
export const migrationV0toV1Standards: Migration<any, CatalogPreferencesV1> = {
  from: 0,
  to: 1,
  description: 'Merge separate table/card localStorage keys into unified structure',
  migrate: (_oldData: any) => {
    let tablePrefs: LegacyTablePreferencesV0 | null = null;
    let cardPrefs: LegacyCardPreferencesV0 | null = null;

    try {
      const tableRaw = localStorage.getItem('standard-catalog-table-preferences');
      if (tableRaw) {
        tablePrefs = JSON.parse(tableRaw);
        localStorage.removeItem('standard-catalog-table-preferences');
      }
    } catch (e) {
      console.warn('[Migration v0→v1] Failed to parse standards table preferences:', e);
    }

    try {
      const cardRaw = localStorage.getItem('standard-catalog-card-preferences');
      if (cardRaw) {
        cardPrefs = JSON.parse(cardRaw);
        localStorage.removeItem('standard-catalog-card-preferences');
      }
    } catch (e) {
      console.warn('[Migration v0→v1] Failed to parse standards card preferences:', e);
    }

    const unified: CatalogPreferencesV1 = {
      table: {
        contentDisplay: tablePrefs?.contentDisplay || [],
        wrapLines: tablePrefs?.wrapLines,
        stripedRows: tablePrefs?.stripedRows,
      },
      cards: {
        contentDisplay: cardPrefs?.contentDisplay || [],
        cardsPerRowBreakpoints: cardPrefs?.cardsPerRowBreakpoints || [...DEFAULT_CARD_BREAKPOINTS],
      },
    };

    return unified;
  },
};

/**
 * Migration from v1 to v2: Update breakpoint thresholds
 *
 * Changes:
 * - 1920 → 1921
 * - 2560 → 2561
 */
export const migrationV1toV2: Migration<CatalogPreferencesV1, CatalogPreferencesV2> = {
  from: 1,
  to: 2,
  description: 'Update breakpoint thresholds (1920→1921, 2560→2561)',
  transforms: {
    'cards.cardsPerRowBreakpoints[].minWidth': (val: number) => {
      if (val === 1920) return 1921;
      if (val === 2560) return 2561;
      return val;
    },
  },
};

/**
 * Migration from v2 to v3: Add viewType and pageSizeFallback
 *
 * Reads from separate localStorage keys and consolidates them
 */
export function createMigrationV2toV3(
  catalogType: 'template' | 'standard'
): Migration<CatalogPreferencesV2, CatalogPreferencesV3> {
  return {
    from: 2,
    to: 3,
    description: 'Add viewType and pageSizeFallback from separate localStorage keys',
    migrate: (oldData: CatalogPreferencesV2) => {
      // Try to read pageSizeFallback from old separate key
      let pageSizeFallback = DEFAULT_PAGE_SIZE_FALLBACK;
      try {
        const pageSizeKey = `${catalogType}-catalog-pagesize-fallback`;
        const stored = localStorage.getItem(pageSizeKey);
        if (stored) {
          const parsed = parseInt(stored, 10);
          if (!isNaN(parsed) && parsed > 0) {
            pageSizeFallback = parsed;
          }
          // Clean up old key
          localStorage.removeItem(pageSizeKey);
        }
      } catch (e) {
        console.warn('[Migration v2→v3] Failed to read pageSizeFallback:', e);
      }

      // Try to read viewType from old separate key
      let viewType: 'table' | 'card' = 'card';
      try {
        const viewKey = `${catalogType}-catalog-view-preferences`;
        const stored = localStorage.getItem(viewKey);
        if (stored) {
          const parsed = JSON.parse(stored);
          if (parsed.viewType === 'table' || parsed.viewType === 'card') {
            viewType = parsed.viewType;
          }
          // Clean up old key
          localStorage.removeItem(viewKey);
        }
      } catch (e) {
        console.warn('[Migration v2→v3] Failed to read viewType:', e);
      }

      return {
        ...oldData,
        viewType,
        pageSizeFallback,
      };
    },
  };
}

export const migrationV2toV3Templates = createMigrationV2toV3('template');
export const migrationV2toV3Standards = createMigrationV2toV3('standard');

/**
 * Migration from v3 to v4: Normalize breakpoints to 3 fixed options
 *
 * Changes:
 * - Converts 5 breakpoints (0, 768, 1366, 1921, 2561) to 3 (768, 1366, 1920)
 * - Maps legacy values: 0→768, 1921→1920, 2561→1920
 * - Clamps card counts to valid ranges per breakpoint
 */
export const migrationV3toV4: Migration<CatalogPreferencesV3, CatalogPreferencesV4> = {
  from: 3,
  to: 4,
  description: 'Normalize card view breakpoints from 5 to 3 fixed options',
  migrate: (oldData: CatalogPreferencesV3): CatalogPreferencesV4 => {
    const existingBreakpoints = oldData?.cards?.cardsPerRowBreakpoints || DEFAULT_CARD_BREAKPOINTS;
    const normalizedBreakpoints = normalizeBreakpoints(existingBreakpoints);

    return {
      ...oldData,
      cards: {
        ...(oldData?.cards || { contentDisplay: [] }),
        cardsPerRowBreakpoints: normalizedBreakpoints,
      },
    };
  },
};
