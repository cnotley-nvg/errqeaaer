/**
 * Type definitions for catalog preferences with versioning
 *
 * Version history:
 * - v0: Separate localStorage keys for table/card preferences
 * - v1: Unified structure with table and cards objects
 * - v2: Updated breakpoint thresholds (1920→1921, 2560→2561)
 * - v3: Added pageSize and viewType to preferences (removed from URL/separate storage)
 * - v4: Normalized breakpoints to 3 fixed options (768, 1366, 1920)
 */

export interface CardBreakpoint {
  minWidth: number; // Minimum screen width in pixels
  cards: number; // Number of cards per row
}

export interface ContentDisplayItem {
  id: string;
  visible: boolean;
}

/**
 * Table-specific preferences (v2)
 */
export interface TablePreferences {
  contentDisplay: ContentDisplayItem[];
  wrapLines?: boolean;
  stripedRows?: boolean;
}

/**
 * Card-specific preferences (v2)
 */
export interface CardPreferences {
  contentDisplay: ContentDisplayItem[];
  cardsPerRowBreakpoints: CardBreakpoint[];
}

/**
 * Unified catalog preferences (v3)
 * Now includes viewType and pageSizeFallback that were previously in separate keys
 */
export interface CatalogPreferencesV3 {
  table: TablePreferences;
  cards: CardPreferences;
  /** View type: 'table' or 'card' (previously in separate 'xxx-catalog-view-preferences' key) */
  viewType: 'table' | 'card';
  /** Fallback page size when not specified in URL (previously in separate 'xxx-catalog-pagesize-fallback' key) */
  pageSizeFallback: number;
}

/**
 * v4 format (current - 3 normalized breakpoints)
 * Breakpoints are normalized to exactly 3 values: 768 (Tablet), 1366 (Laptop), 1920 (Desktop)
 */
export interface CatalogPreferencesV4 {
  table: TablePreferences;
  cards: CardPreferences;
  viewType: 'table' | 'card';
  pageSizeFallback: number;
}

/**
 * v2 format (without pageSize and viewType)
 */
export interface CatalogPreferencesV2 {
  table: TablePreferences;
  cards: CardPreferences;
}

/**
 * Legacy v0 format (separate localStorage keys)
 * Used for migration purposes only
 */
export interface LegacyTablePreferencesV0 {
  pageSize?: number;
  contentDisplay: ContentDisplayItem[];
  wrapLines?: boolean;
  stripedRows?: boolean;
}

export interface LegacyCardPreferencesV0 {
  pageSize?: number;
  contentDisplay: ContentDisplayItem[];
  cardsPerRowBreakpoints?: CardBreakpoint[];
}

/**
 * v0 format (unversioned, sentinel for migration detection)
 * This is a marker type used to detect when data needs migration from v0 to v1
 */
export interface CatalogPreferencesV0 {
  __v0_marker?: never; // This ensures v0 is structurally unique
}

/**
 * v1 format (unified but with old breakpoint thresholds)
 */
export interface CatalogPreferencesV1 {
  table: TablePreferences;
  cards: CardPreferences;
}

/**
 * Current version alias
 */
export type CatalogPreferences = CatalogPreferencesV4;

/**
 * Version number constant
 */
export const CURRENT_VERSION = 4;

/**
 * Storage keys for template and standard catalogs
 */
export const TEMPLATE_CATALOG_KEY = 'template-catalog-preferences';
export const STANDARD_CATALOG_KEY = 'standard-catalog-preferences';
export const PUBLISHED_KIT_CATALOG_KEY = 'published-kit-catalog-preferences';

/**
 * Legacy v0 storage keys (used for migration)
 */
export const TEMPLATE_CATALOG_TABLE_KEY = 'template-catalog-table-preferences';
export const TEMPLATE_CATALOG_CARD_KEY = 'template-catalog-card-preferences';
export const STANDARD_CATALOG_TABLE_KEY = 'standard-catalog-table-preferences';
export const STANDARD_CATALOG_CARD_KEY = 'standard-catalog-card-preferences';
