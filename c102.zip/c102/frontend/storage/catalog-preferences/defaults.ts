/**
 * Default catalog preferences (v3)
 */

import type { CatalogPreferencesV3, CardBreakpoint } from './types';

/**
 * Default breakpoints for card view responsive layout (v3)
 */
export const DEFAULT_CARD_BREAKPOINTS: readonly CardBreakpoint[] = [
  { minWidth: 768, cards: 2 }, // Tablet: 768px - 1365px
  { minWidth: 1366, cards: 3 }, // Laptop: 1366px - 1919px
  { minWidth: 1920, cards: 4 }, // Desktop: 1920px+
] as const;

/**
 * Default page size fallback for catalogs
 */
export const DEFAULT_PAGE_SIZE_FALLBACK = 20;

/**
 * Default catalog preferences for templates (v3)
 */
export const DEFAULT_TEMPLATE_CATALOG_PREFERENCES: CatalogPreferencesV3 = {
  viewType: 'card',
  pageSizeFallback: DEFAULT_PAGE_SIZE_FALLBACK,
  table: {
    contentDisplay: [
      { id: 'name', visible: true },
      { id: 'region', visible: true },
      { id: 'program', visible: true },
      { id: 'facilityType', visible: true },
      { id: 'capacity', visible: true },
      { id: 'stories', visible: true },
      { id: 'businessUnit', visible: true },
      { id: 'updatedAt', visible: true },
      // Hidden by default
      { id: 'siteAcreage', visible: false },
      { id: 'dockDoorCount', visible: false },
      { id: 'totalTrailerParking', visible: false },
      { id: 'maxWeeklyHeadcount', visible: false },
      { id: 'powerKva', visible: false },
      { id: 'createdBy', visible: false },
      { id: 'grossSquareFootage', visible: false },
      { id: 'peakShiftHeadcount', visible: false },
      { id: 'clearHeightFtM', visible: false },
      { id: 'dspParking', visible: false },
      { id: 'generation', visible: false },
    ],
    wrapLines: false,
    stripedRows: false,
  },
  cards: {
    contentDisplay: [
      // Default visible fields
      { id: 'region', visible: true },
      { id: 'program', visible: true },
      { id: 'facilityType', visible: true },
      { id: 'capacity', visible: true },
      { id: 'stories', visible: true },
      { id: 'businessUnit', visible: true },
      // Hidden by default
      { id: 'updatedAt', visible: false },
      { id: 'siteAcreage', visible: false },
      { id: 'dockDoorCount', visible: false },
      { id: 'totalTrailerParking', visible: false },
      { id: 'maxWeeklyHeadcount', visible: false },
      { id: 'powerKva', visible: false },
      { id: 'createdBy', visible: false },
      { id: 'grossSquareFootage', visible: false },
      { id: 'peakShiftHeadcount', visible: false },
      { id: 'clearHeightFtM', visible: false },
      { id: 'dspParking', visible: false },
      { id: 'generation', visible: false },
    ],
    cardsPerRowBreakpoints: [...DEFAULT_CARD_BREAKPOINTS],
  },
};

/**
 * Default catalog preferences for standards (v3)
 * Uses standard-specific field IDs (projectType, updateCadence, version, etc.)
 */
export const DEFAULT_STANDARD_CATALOG_PREFERENCES: CatalogPreferencesV3 = {
  viewType: 'card',
  pageSizeFallback: DEFAULT_PAGE_SIZE_FALLBACK,
  table: {
    contentDisplay: [
      { id: 'name', visible: true },
      { id: 'region', visible: true },
      { id: 'program', visible: true },
      { id: 'projectType', visible: true },
      { id: 'updateCadence', visible: true },
      { id: 'version', visible: true },
      // Hidden by default
      { id: 'roomFeatureZone', visible: false },
      { id: 'approvalInformation', visible: false },
      { id: 'bimLink', visible: false },
      { id: 'createdBy', visible: false },
      { id: 'createdDate', visible: false },
      { id: 'lastModifiedBy', visible: false },
      { id: 'lastModifiedDate', visible: false },
    ],
    wrapLines: false,
    stripedRows: false,
  },
  cards: {
    contentDisplay: [
      // Default visible fields (3 fields for standards)
      { id: 'region', visible: true },
      { id: 'program', visible: true },
      { id: 'projectType', visible: true },
      // Hidden by default
      { id: 'updateCadence', visible: false },
      { id: 'version', visible: false },
      { id: 'roomFeatureZone', visible: false },
      { id: 'approvalInformation', visible: false },
      { id: 'bimLink', visible: false },
      { id: 'createdBy', visible: false },
      { id: 'createdDate', visible: false },
      { id: 'lastModifiedBy', visible: false },
      { id: 'lastModifiedDate', visible: false },
    ],
    cardsPerRowBreakpoints: [...DEFAULT_CARD_BREAKPOINTS],
  },
};

/**
 * Default catalog preferences for published kits (v3)
 *
 * Note: Published kits catalog is table-only today. We still populate the full
 * v3 schema (table + cards) to satisfy validation and keep the storage format consistent.
 */
export const DEFAULT_PUBLISHED_KIT_CATALOG_PREFERENCES: CatalogPreferencesV3 = {
  viewType: 'table',
  pageSizeFallback: DEFAULT_PAGE_SIZE_FALLBACK,
  table: {
    contentDisplay: [
      { id: 'name', visible: true },
      { id: 'description', visible: true },
      { id: 'region', visible: true },
      { id: 'program', visible: true },
      { id: 'projectType', visible: true },
      { id: 'roomFeatureZone', visible: true },
      { id: 'dataType', visible: true },
      { id: 'keyLabel', visible: true },
      { id: 'createdBy', visible: true },
      { id: 'createdOn', visible: true },
    ],
    wrapLines: false,
    stripedRows: false,
  },
  cards: {
    contentDisplay: [],
    cardsPerRowBreakpoints: [...DEFAULT_CARD_BREAKPOINTS],
  },
};
