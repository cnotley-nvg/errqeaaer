/**
 * Versioned storage for recent updates table preferences
 */

import { createVersionedStore } from '../../lib/versioned-storage';
import { coercePageSize } from '../../components/shared/catalog/utils/urlPersistence';
import type { RecentUpdatesPreferences } from './types';
import { CURRENT_VERSION, RECENT_UPDATES_KEY } from './types';
import { DEFAULT_RECENT_UPDATES_PREFERENCES, DEFAULT_VALID_PAGE_SIZES } from './defaults';

/**
 * Default preferences for recent updates table
 */
export const DEFAULT_PREFERENCES = DEFAULT_RECENT_UPDATES_PREFERENCES;

/**
 * Validator for recent updates preferences
 */
const isRecentUpdatesPreferences = (data: unknown): data is RecentUpdatesPreferences => {
  if (!data || typeof data !== 'object') return false;

  const obj = data as Record<string, unknown>;

  // Check required fields with strict validation
  if (typeof obj.pageSize !== 'number' || obj.pageSize <= 0) return false;

  // Validate pageSize against allowed values
  const validPageSize = coercePageSize(
    obj.pageSize.toString(),
    DEFAULT_RECENT_UPDATES_PREFERENCES.pageSize,
    DEFAULT_VALID_PAGE_SIZES
  );
  if (obj.pageSize !== validPageSize) return false;

  if (typeof obj.wrapLines !== 'boolean') return false;
  if (typeof obj.stripedRows !== 'boolean') return false;

  // Check contentDisplay array
  if (!Array.isArray(obj.contentDisplay)) return false;
  if (
    !obj.contentDisplay.every(
      (item: unknown) =>
        typeof item === 'object' &&
        item !== null &&
        typeof (item as any).id === 'string' &&
        (item as any).id.length > 0 &&
        typeof (item as any).visible === 'boolean'
    )
  )
    return false;

  // Check optional stickyColumns
  if (obj.stickyColumns !== undefined) {
    if (typeof obj.stickyColumns !== 'object' || obj.stickyColumns === null) return false;
    const sticky = obj.stickyColumns as Record<string, unknown>;
    if (sticky.first !== undefined && typeof sticky.first !== 'number') return false;
    if (sticky.last !== undefined && typeof sticky.last !== 'number') return false;
  }

  return true;
};

/**
 * Versioned store for recent updates preferences
 */
export const recentUpdatesPreferencesStore = createVersionedStore<RecentUpdatesPreferences>({
  key: RECENT_UPDATES_KEY,
  version: CURRENT_VERSION,
  migrations: [], // No migrations needed for v1
  defaults: DEFAULT_PREFERENCES,
  validator: isRecentUpdatesPreferences,
});
