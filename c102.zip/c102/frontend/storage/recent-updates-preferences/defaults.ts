/**
 * Default recent updates preferences (v1)
 */

import type { RecentUpdatesPreferencesV1 } from './types';

/**
 * Default page size for recent updates table
 */
export const DEFAULT_PAGE_SIZE = 10;

/**
 * Valid page sizes for recent updates table
 */
export const DEFAULT_VALID_PAGE_SIZES = [10, 20, 30, 40] as const;

/**
 * Page size options for recent updates table
 */
export const PAGE_SIZE_OPTIONS = [
  { value: 10, label: '10 updates' },
  { value: 20, label: '20 updates' },
] as const;

/**
 * Content display options for recent updates table
 */
export const CONTENT_DISPLAY_OPTIONS = [
  {
    id: 'details',
    label: 'Item',
    alwaysVisible: true,
  },
  { id: 'message', label: 'Action' },
  { id: 'createdBy', label: 'Updated by' },
  { id: 'createdAt', label: 'Date' },
  { id: 'status', label: 'Status' },
] as const;

/**
 * Sticky columns preference configuration
 */
export const STICKY_COLUMNS_PREFERENCE = {
  firstColumns: {
    title: 'Stick first column(s)',
    description: 'Keep the first column(s) visible while horizontally scrolling the table content.',
    options: [
      { label: 'None', value: 0 },
      { label: 'First column', value: 1 },
      { label: 'First two columns', value: 2 },
    ],
  },
  lastColumns: {
    title: 'Stick last column',
    description: 'Keep the last column visible while horizontally scrolling the table content.',
    options: [
      { label: 'None', value: 0 },
      { label: 'Last column', value: 1 },
    ],
  },
} as const;

/**
 * Default recent updates preferences (v1)
 */
export const DEFAULT_RECENT_UPDATES_PREFERENCES: RecentUpdatesPreferencesV1 = {
  pageSize: DEFAULT_PAGE_SIZE,
  wrapLines: true,
  stripedRows: false,
  contentDisplay: [
    { id: 'details', visible: true },
    { id: 'message', visible: true },
    { id: 'createdBy', visible: true },
    { id: 'createdAt', visible: true },
    { id: 'status', visible: true },
  ],
  stickyColumns: {
    first: 0,
    last: 0,
  },
};
