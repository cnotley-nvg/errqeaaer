/**
 * React hook for recent updates preferences using versioned storage
 */

import { useState, useCallback, useEffect, useRef } from 'react';
import type { CollectionPreferencesProps } from '@amzn/awsui-components-console';
import { recentUpdatesPreferencesStore } from './store';
import type { RecentUpdatesPreferences } from './types';

export interface RecentUpdatesPreferencesHookResult {
  preferences: RecentUpdatesPreferences;
  updatePreferences: (preferences: CollectionPreferencesProps.Preferences) => void;
  resetPreferences: () => void;
}

/**
 * Hook for managing recent updates table preferences with versioned storage
 */
export function useVersionedRecentUpdatesPreferences(): RecentUpdatesPreferencesHookResult {
  // Load initial preferences on mount
  const initialPreferencesRef = useRef<RecentUpdatesPreferences | null>(null);

  if (initialPreferencesRef.current === null) {
    const result = recentUpdatesPreferencesStore.load();
    initialPreferencesRef.current = result.success ? result.data : result.fallback;
  }

  const [preferences, setPreferences] = useState<RecentUpdatesPreferences>(
    initialPreferencesRef.current
  );

  // Sync with localStorage on mount (in case it changed in another tab)
  useEffect(() => {
    const result = recentUpdatesPreferencesStore.load();
    const loadedPrefs = result.success ? result.data : result.fallback;
    setPreferences(loadedPrefs);
  }, []);

  /**
   * Update preferences from CollectionPreferences component
   */
  const updatePreferences = useCallback(
    (newPreferences: CollectionPreferencesProps.Preferences) => {
      setPreferences((prev) => {
        const updated: RecentUpdatesPreferences = {
          pageSize: newPreferences.pageSize ?? prev.pageSize,
          wrapLines: newPreferences.wrapLines ?? prev.wrapLines,
          stripedRows: newPreferences.stripedRows ?? prev.stripedRows,
          contentDisplay: newPreferences.contentDisplay
            ? newPreferences.contentDisplay.map((item) => ({
                id: item.id,
                visible: item.visible ?? true,
              }))
            : prev.contentDisplay,
          stickyColumns: {
            first: newPreferences.stickyColumns?.first ?? prev.stickyColumns?.first ?? 0,
            last: newPreferences.stickyColumns?.last ?? prev.stickyColumns?.last ?? 0,
          },
        };

        // Save to localStorage
        recentUpdatesPreferencesStore.save(updated);

        return updated;
      });
    },
    []
  );

  /**
   * Reset preferences to defaults
   */
  const resetPreferences = useCallback(() => {
    // Remove from localStorage
    recentUpdatesPreferencesStore.remove();

    // Load defaults
    const result = recentUpdatesPreferencesStore.load();
    const defaults = result.success ? result.data : result.fallback;

    setPreferences(defaults);
  }, []);

  return {
    preferences,
    updatePreferences,
    resetPreferences,
  };
}
