/**
 * Type definitions for recent updates table preferences with versioning
 *
 */

export interface ContentDisplayItem {
  id: string;
  visible: boolean;
}

/**
 * Recent updates table preferences (v1)
 */
export interface RecentUpdatesPreferencesV1 {
  pageSize: number;
  wrapLines: boolean;
  stripedRows: boolean;
  contentDisplay: ContentDisplayItem[];
  stickyColumns?: {
    first?: number;
    last?: number;
  };
}

/**
 * Current version alias
 */
export type RecentUpdatesPreferences = RecentUpdatesPreferencesV1;

/**
 * Version number constant
 */
export const CURRENT_VERSION = 1;

/**
 * Storage key for recent updates preferences
 */
export const RECENT_UPDATES_KEY = 'recent-updates-preferences';
