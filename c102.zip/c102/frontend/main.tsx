import '@amzn/awsui-global-styles/polaris.css';

import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { FlagProviderWrapper } from './components/FlagProviderWrapper';
import { loadRuntimeConfig } from './config/runtimeConfig';

const attachRuntimeEnv = () => {
  const metaEnv =
    typeof import.meta !== 'undefined'
      ? (import.meta as unknown as { env?: { VITE_GRAPHQL_ENDPOINT?: string } }).env
      : undefined;

  if (metaEnv) {
    (
      globalThis as { __mosaicImportMetaEnv__?: { VITE_GRAPHQL_ENDPOINT?: string } }
    ).__mosaicImportMetaEnv__ = metaEnv;
  }
};

const startApp = async () => {
  attachRuntimeEnv();
  await loadRuntimeConfig();
  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <BrowserRouter
        future={{
          v7_startTransition: true,
          v7_relativeSplatPath: true,
        }}
      >
        <FlagProviderWrapper>
          <App />
        </FlagProviderWrapper>
      </BrowserRouter>
    </React.StrictMode>
  );
};

void startApp();
