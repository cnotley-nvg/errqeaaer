/**
 * Validation system for versioned storage
 *
 * Provides structural validation to ensure data conforms to expected schema.
 * Validates types and required fields, NOT values (e.g., doesn't check ranges).
 */

import type { ValidationSchema } from './types';
import { ValidationError } from './errors';

/**
 * Pass-through validator that always returns true
 *
 * Used as default when no validator is provided in VersionedStoreConfig.
 * Provides no validation - data is accepted as-is.
 *
 * @example
 * ```typescript
 * const validator = passThroughValidator<MyType>;
 * validator(anyData); // Always true
 * ```
 */
export const passThroughValidator = <T>(_data: unknown): _data is T => true;

/**
 * Create a structural validator from a schema
 *
 * Returns a TypeScript type guard function that validates data structure.
 * Checks types and required fields, but not value constraints.
 *
 * @param schema - Validation schema describing expected structure
 * @returns Type guard function for TypeScript type narrowing
 *
 * @example
 * ```typescript
 * const schema = validators.object({
 *   name: validators.string(true),
 *   age: validators.number(true)
 * }, true);
 *
 * const validate = createStructuralValidator<User>(schema);
 *
 * if (validate(data)) {
 *   // TypeScript knows data is User
 *   console.log(data.name);
 * }
 * ```
 */
export function createStructuralValidator<T>(
  schema: ValidationSchema
): (data: unknown) => data is T {
  return (data: unknown): data is T => {
    try {
      validateValue(data, schema, 'data');
      return true;
    } catch (error) {
      // Validation failed
      return false;
    }
  };
}

/**
 * Validate a value against a schema
 *
 * @param value - Value to validate
 * @param schema - Schema to validate against
 * @param path - Current path for error messages
 * @throws {ValidationError} If validation fails
 */
function validateValue(value: unknown, schema: ValidationSchema, path: string): void {
  // Check required
  if (schema.required && (value === undefined || value === null)) {
    throw new ValidationError(`Required field is missing`, path);
  }

  // Allow undefined/null for optional fields
  if (!schema.required && (value === undefined || value === null)) {
    return;
  }

  // Validate based on type
  switch (schema.type) {
    case 'string':
      if (typeof value !== 'string') {
        throw new ValidationError(`Expected string, got ${typeof value}`, path);
      }
      break;

    case 'number':
      if (typeof value !== 'number' || Number.isNaN(value)) {
        throw new ValidationError(`Expected number, got ${typeof value}`, path);
      }
      break;

    case 'boolean':
      if (typeof value !== 'boolean') {
        throw new ValidationError(`Expected boolean, got ${typeof value}`, path);
      }
      break;

    case 'object':
      if (typeof value !== 'object' || value === null || Array.isArray(value)) {
        throw new ValidationError(`Expected object, got ${typeof value}`, path);
      }
      // Validate object properties if schema provided
      if (schema.properties) {
        validateObject(value as Record<string, unknown>, schema.properties, path);
      }
      break;

    case 'array':
      if (!Array.isArray(value)) {
        throw new ValidationError(`Expected array, got ${typeof value}`, path);
      }
      // Validate array items if schema provided
      if (schema.items) {
        validateArray(value, schema.items, path);
      }
      break;

    case 'any':
      // Accept any type
      break;

    default:
      // Unknown schema type - skip validation
      break;
  }
}

/**
 * Validate object properties
 */
function validateObject(
  obj: Record<string, unknown>,
  properties: Record<string, ValidationSchema>,
  path: string
): void {
  for (const [key, propSchema] of Object.entries(properties)) {
    const propPath = `${path}.${key}`;
    validateValue(obj[key], propSchema, propPath);
  }
}

/**
 * Validate array items
 */
function validateArray(arr: unknown[], itemSchema: ValidationSchema, path: string): void {
  arr.forEach((item, index) => {
    const itemPath = `${path}[${index}]`;
    validateValue(item, itemSchema, itemPath);
  });
}

/**
 * Helper builders for common validation schemas
 *
 * Provides convenient functions to build ValidationSchema objects.
 *
 * @example
 * ```typescript
 * const userSchema = validators.object({
 *   name: validators.string(true),
 *   age: validators.number(true),
 *   email: validators.string(),
 *   tags: validators.array(validators.string())
 * }, true);
 * ```
 */
export const validators = {
  /**
   * String validator
   *
   * @param required - Whether field is required (default: false)
   * @returns ValidationSchema for string
   */
  string: (required = false): ValidationSchema => ({
    type: 'string',
    required,
  }),

  /**
   * Number validator
   *
   * @param required - Whether field is required (default: false)
   * @returns ValidationSchema for number
   */
  number: (required = false): ValidationSchema => ({
    type: 'number',
    required,
  }),

  /**
   * Boolean validator
   *
   * @param required - Whether field is required (default: false)
   * @returns ValidationSchema for boolean
   */
  boolean: (required = false): ValidationSchema => ({
    type: 'boolean',
    required,
  }),

  /**
   * Array validator
   *
   * @param items - Schema for array items
   * @param required - Whether field is required (default: false)
   * @returns ValidationSchema for array
   *
   * @example
   * ```typescript
   * validators.array(validators.string())
   * validators.array(validators.object({ id: validators.string(true) }))
   * ```
   */
  array: (items: ValidationSchema, required = false): ValidationSchema => ({
    type: 'array',
    items,
    required,
  }),

  /**
   * Object validator
   *
   * @param properties - Map of property names to schemas
   * @param required - Whether field is required (default: false)
   * @returns ValidationSchema for object
   *
   * @example
   * ```typescript
   * validators.object({
   *   id: validators.string(true),
   *   count: validators.number()
   * }, true)
   * ```
   */
  object: (properties: Record<string, ValidationSchema>, required = false): ValidationSchema => ({
    type: 'object',
    properties,
    required,
  }),

  /**
   * Any type validator (accepts anything)
   *
   * @param required - Whether field is required (default: false)
   * @returns ValidationSchema for any type
   *
   * @example
   * ```typescript
   * validators.object({
   *   metadata: validators.any() // Accepts any type
   * })
   * ```
   */
  any: (required = false): ValidationSchema => ({
    type: 'any',
    required,
  }),
};
