/**
 * Core type definitions for the versioned storage system
 *
 * This module provides the foundational types for managing localStorage
 * with schema versioning, migrations, and validation.
 */

/**
 * Versioned data wrapper stored in localStorage
 *
 * Every stored data is wrapped with version metadata to enable
 * automatic migration when schema changes.
 *
 * @example
 * ```typescript
 * {
 *   version: 2,
 *   data: { theme: 'dark', notifications: true }
 * }
 * ```
 */
export interface VersionedData<T> {
  /** Schema version number (starts at 0 for legacy unversioned data) */
  version: number;

  /** Actual user data conforming to the schema for this version */
  data: T;
}

/**
 * Declarative transformation types for migrations
 *
 * Transforms define how to modify data at specific paths without
 * writing imperative code. This makes migrations easier to write,
 * test, and maintain.
 */
export type MigrationTransform =
  /**
   * Custom transformation function
   *
   * @example
   * ```typescript
   * (value: number) => value * 2
   * ```
   */
  | ((value: any) => any)

  /**
   * Rename a field to a new path
   *
   * @example
   * ```typescript
   * { rename: 'settings.newFieldName' }
   * ```
   */
  | { rename: string }

  /**
   * Delete a field
   *
   * @example
   * ```typescript
   * { delete: true }
   * ```
   */
  | { delete: true }

  /**
   * Set a default value for a new field
   *
   * @example
   * ```typescript
   * { default: false }
   * ```
   */
  | { default: any }

  /**
   * Map old values to new values
   *
   * @example
   * ```typescript
   * { map: { 'old-value': 'new-value', 'legacy': 'current' } }
   * ```
   */
  | { map: Record<string, any> }

  /**
   * Nested transforms for object properties
   *
   * @example
   * ```typescript
   * {
   *   nested: {
   *     'field1': (val) => val + 1,
   *     'field2': { delete: true }
   *   }
   * }
   * ```
   */
  | { nested: Record<string, MigrationTransform> };

/**
 * Migration definition supporting both declarative and imperative styles
 *
 * Migrations transform data from one schema version to another.
 * Prefer declarative `transforms` for simple changes, use imperative
 * `migrate` function for complex logic.
 *
 * @template TFrom - Type of the source version data
 * @template TTo - Type of the target version data
 */
export interface Migration<TFrom = any, TTo = any> {
  /** Source version number */
  from: number;

  /** Target version number (must be from + 1) */
  to: number;

  /** Human-readable description of what this migration does */
  description: string;

  /**
   * Declarative path-based transforms (preferred)
   *
   * Keys are dot-notation paths supporting array notation:
   * - 'field' - Top-level field
   * - 'nested.field' - Nested field
   * - 'items[].field' - Apply to all array items
   * - 'a[].b[].c' - Nested arrays
   *
   * @example
   * ```typescript
   * {
   *   'cards.breakpoints[].minWidth': (val) => val + 1,
   *   'table.oldField': { rename: 'table.newField' },
   *   'deprecated': { delete: true }
   * }
   * ```
   */
  transforms?: Record<string, MigrationTransform>;

  /**
   * Imperative migration function (fallback for complex logic)
   *
   * Use when declarative transforms are insufficient (e.g., conditional
   * logic, reading from external sources, complex restructuring).
   *
   * @example
   * ```typescript
   * migrate: (oldData) => {
   *   // Complex logic here
   *   return newData;
   * }
   * ```
   */
  migrate?: (oldData: TFrom) => TTo;
}

/**
 * Storage operation result with discriminated union
 *
 * Provides type-safe error handling for storage operations.
 */
export type StorageResult<T> =
  /**
   * Successful operation
   *
   * @property success - Always true
   * @property data - Loaded/migrated data
   * @property migrated - Whether data was migrated from older version
   */
  | {
      success: true;
      data: T;
      migrated: boolean;
    }

  /**
   * Failed operation with fallback
   *
   * @property success - Always false
   * @property error - Error that occurred
   * @property fallback - Default data to use as fallback
   */
  | {
      success: false;
      error: Error;
      fallback: T;
    };

/**
 * Structural validation schema
 *
 * Defines the expected structure of data for validation.
 * Validates types and required fields, NOT values.
 */
export interface ValidationSchema {
  /** Expected type of the value */
  type: 'string' | 'number' | 'boolean' | 'object' | 'array' | 'any';

  /** Whether this field is required (default: false) */
  required?: boolean;

  /** Property schemas for object type */
  properties?: Record<string, ValidationSchema>;

  /** Item schema for array type */
  items?: ValidationSchema;
}

/**
 * Configuration for VersionedStore
 *
 * @template T - Type of the data being stored
 */
export interface VersionedStoreConfig<T> {
  /** localStorage key for storing data */
  key: string;

  /** Current schema version number */
  version: number;

  /** Array of migrations to apply (ordered: v0→v1, v1→v2, etc.) */
  migrations: Migration[];

  /** Default data to use when none exists or on error */
  defaults: T;

  /**
   * Optional validator function (uses pass-through validator if omitted)
   *
   * Should be a TypeScript type guard that checks data structure.
   *
   * @example
   * ```typescript
   * validator: (data): data is MyType => {
   *   return typeof data.field === 'string';
   * }
   * ```
   */
  validator?: (data: unknown) => data is T;

  /**
   * Optional callback invoked on successful migration
   *
   * @param fromVersion - Source version
   * @param toVersion - Target version
   */
  onMigrationSuccess?: (fromVersion: number, toVersion: number) => void;

  /**
   * Optional callback invoked on migration error
   *
   * @param error - Error that occurred during migration
   */
  onMigrationError?: (error: Error) => void;
}
