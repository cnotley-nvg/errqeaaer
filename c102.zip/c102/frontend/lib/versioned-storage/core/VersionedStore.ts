/**
 * VersionedStore - Core storage class with versioning and migration support
 *
 * This class manages localStorage with automatic schema versioning,
 * migrations, validation, and graceful error handling.
 */

import type { VersionedStoreConfig, VersionedData, StorageResult } from './types';
import { SerializationError } from './errors';
import { runMigrations } from './migrator';
import { passThroughValidator } from './validator';
import { deepMerge } from './utils';

/**
 * Main storage class for managing versioned data in localStorage
 *
 * Features:
 * - Automatic migration from old versions to current
 * - Structural validation with fallback to defaults
 * - Deep merge with defaults to ensure all fields exist
 * - Graceful error handling with fallback
 * - Dev-only logging
 *
 * @template T - Type of data being stored
 *
 * @example
 * ```typescript
 * const store = new VersionedStore({
 *   key: 'my-data',
 *   version: 2,
 *   migrations: [migration0to1, migration1to2],
 *   defaults: { foo: 'bar' }
 * });
 *
 * const result = store.load();
 * if (result.success) {
 *   console.log(result.data);
 * }
 * ```
 */
export class VersionedStore<T> {
  private readonly config: VersionedStoreConfig<T>;
  private readonly validator: (data: unknown) => data is T;

  /**
   * Create a new VersionedStore
   *
   * @param config - Configuration for the store
   */
  constructor(config: VersionedStoreConfig<T>) {
    this.config = config;
    this.validator = config.validator ?? passThroughValidator;
  }

  /**
   * Load data from localStorage with automatic migration
   *
   * Flow:
   * 1. Read from localStorage
   * 2. Parse JSON
   * 3. Check version
   * 4. Run migrations if needed (v0→v1→v2→...→vN)
   * 5. Validate data
   * 6. Deep merge with defaults
   * 7. Save migrated data (if migrated)
   * 8. Return result
   *
   * Error handling:
   * - JSON parse error → fallback to defaults
   * - Migration error → fallback to defaults
   * - Validation error → merge with defaults (partial recovery)
   *
   * @returns StorageResult with success/error discriminated union
   *
   * @example
   * ```typescript
   * const result = store.load();
   * if (result.success) {
   *   console.log('Loaded:', result.data);
   *   if (result.migrated) {
   *     console.log('Data was migrated');
   *   }
   * } else {
   *   console.error('Load failed:', result.error);
   *   console.log('Using fallback:', result.fallback);
   * }
   * ```
   */
  load(): StorageResult<T> {
    try {
      const raw = localStorage.getItem(this.config.key);

      // No stored data → use defaults
      if (!raw) {
        return { success: true, data: this.config.defaults, migrated: false };
      }

      // Parse JSON
      let parsed: any;
      try {
        parsed = JSON.parse(raw);
      } catch (error) {
        throw new SerializationError(
          'Failed to parse stored data',
          error instanceof Error ? error : new Error(String(error))
        );
      }

      // Check if versioned
      if (typeof parsed.version === 'number') {
        const versionedData = parsed as VersionedData<any>;

        // Already at current version?
        if (versionedData.version === this.config.version) {
          return this.validateAndMerge(versionedData.data, false);
        }

        // Needs migration
        return this.migrateAndSave(versionedData);
      }

      // Legacy unversioned data - treat as v0
      return this.migrateAndSave({ version: 0, data: parsed });
    } catch (error) {
      return this.handleError(error as Error);
    }
  }

  /**
   * Save data to localStorage with version wrapper
   *
   * Wraps data with version metadata and saves to localStorage.
   * Returns true on success, false on error (e.g., quota exceeded).
   *
   * @param data - Data to save
   * @returns true if saved successfully, false on error
   *
   * @example
   * ```typescript
   * const success = store.save({ foo: 'bar' });
   * if (success) {
   *   console.log('Saved successfully');
   * } else {
   *   console.error('Save failed (quota exceeded?)');
   * }
   * ```
   */
  save(data: T): boolean {
    try {
      const versioned: VersionedData<T> = {
        version: this.config.version,
        data,
      };

      const serialized = JSON.stringify(versioned);
      localStorage.setItem(this.config.key, serialized);

      if ((import.meta as any).env?.DEV) {
        console.log(`[VersionedStorage] Saved ${this.config.key} (v${this.config.version})`);
      }

      return true;
    } catch (error) {
      this.logError('Save failed', error as Error);
      return false;
    }
  }

  /**
   * Remove data from localStorage
   *
   * Clears the stored data. Subsequent load() will return defaults.
   *
   * @example
   * ```typescript
   * store.remove();
   * const result = store.load();
   * // result.data === defaults
   * ```
   */
  remove(): void {
    try {
      localStorage.removeItem(this.config.key);

      if ((import.meta as any).env?.DEV) {
        console.log(`[VersionedStorage] Removed ${this.config.key}`);
      }
    } catch (error) {
      this.logError('Remove failed', error as Error);
    }
  }

  /**
   * Run migrations and save result
   *
   * @private
   */
  private migrateAndSave(versionedData: VersionedData<any>): StorageResult<T> {
    try {
      // Run migration chain
      const migrated = runMigrations<T>(
        versionedData.data,
        versionedData.version,
        this.config.migrations,
        this.config.version
      );

      // Validate and merge with defaults
      const result = this.validateAndMerge(migrated, true);

      if (result.success) {
        // Save migrated data
        this.save(result.data);

        // Notify success callback
        if (this.config.onMigrationSuccess) {
          this.config.onMigrationSuccess(versionedData.version, this.config.version);
        }

        if ((import.meta as any).env?.DEV) {
          console.log(
            `[VersionedStorage] Migrated ${this.config.key}: v${versionedData.version} → v${this.config.version}`
          );
        }
      }

      return result;
    } catch (error) {
      // Migration failed - notify error callback
      if (this.config.onMigrationError) {
        this.config.onMigrationError(error as Error);
      }

      return this.handleError(error as Error);
    }
  }

  /**
   * Validate and deep merge with defaults
   *
   * @private
   */
  private validateAndMerge(data: any, migrated: boolean): StorageResult<T> {
    try {
      // Validate structure
      if (!this.validator(data)) {
        this.logError('Validation failed - using partial recovery', new Error('Invalid structure'));
        // Partial recovery: merge invalid data with defaults
        const merged = deepMerge(data, this.config.defaults);
        return { success: true, data: merged, migrated };
      }

      // Deep merge with defaults to ensure all fields exist
      const merged = deepMerge(data, this.config.defaults);

      return { success: true, data: merged, migrated };
    } catch (error) {
      return this.handleError(error as Error);
    }
  }

  /**
   * Handle errors with fallback to defaults
   *
   * @private
   */
  private handleError(error: Error): StorageResult<T> {
    this.logError('Storage operation failed', error);
    return {
      success: false,
      error,
      fallback: this.config.defaults,
    };
  }

  /**
   * Log error in development mode only
   *
   * @private
   */
  private logError(message: string, error: Error): void {
    if ((import.meta as any).env?.DEV) {
      console.error(`[VersionedStorage] ${message}:`, error);
    }
  }
}
