/**
 * Migration engine for versioned storage system
 *
 * This module handles applying declarative and imperative migrations
 * to transform data from one schema version to another.
 */

import type { Migration, MigrationTransform } from './types';
import { MigrationError } from './errors';

/**
 * Execute a sequential chain of migrations
 *
 * Applies migrations in order: v0→v1→v2→...→vN
 * Validates that migration chain is continuous (no gaps).
 *
 * @param data - Data to migrate
 * @param fromVersion - Current version of the data
 * @param migrations - Array of migrations (must be ordered)
 * @param targetVersion - Target version to migrate to
 * @returns Migrated data at target version
 * @throws {MigrationError} If migration chain is broken or migration fails
 *
 * @example
 * ```typescript
 * const migrations = [
 *   { from: 0, to: 1, description: '...', migrate: ... },
 *   { from: 1, to: 2, description: '...', transforms: ... }
 * ];
 * const migrated = runMigrations(oldData, 0, migrations, 2);
 * ```
 */
export function runMigrations<T>(
  data: any,
  fromVersion: number,
  migrations: Migration[],
  targetVersion: number
): T {
  // Already at target version
  if (fromVersion === targetVersion) {
    return data as T;
  }

  // Find migrations needed for this version range
  const applicableMigrations = migrations.filter(
    (m) => m.from >= fromVersion && m.to <= targetVersion
  );

  // No migrations needed
  if (applicableMigrations.length === 0) {
    return data as T;
  }

  // Sort migrations by source version (should already be sorted, but ensure)
  applicableMigrations.sort((a, b) => a.from - b.from);

  // Validate migration chain is continuous
  for (let i = 0; i < applicableMigrations.length; i++) {
    const migration = applicableMigrations[i];

    // First migration must start from current version
    if (i === 0 && migration.from !== fromVersion) {
      throw new MigrationError(
        `Migration chain broken: Expected migration from v${fromVersion}, found v${migration.from}`,
        fromVersion,
        targetVersion
      );
    }

    // Each migration must connect to the previous one
    if (i > 0) {
      const prevMigration = applicableMigrations[i - 1];
      if (migration.from !== prevMigration.to) {
        throw new MigrationError(
          `Migration chain broken: Gap between v${prevMigration.to} and v${migration.from}`,
          fromVersion,
          targetVersion
        );
      }
    }

    // Each migration must increment version by exactly 1
    if (migration.to !== migration.from + 1) {
      throw new MigrationError(
        `Invalid migration: Must increment version by 1 (got v${migration.from}→v${migration.to})`,
        migration.from,
        migration.to
      );
    }
  }

  // Apply migrations sequentially
  let currentData = data;
  for (const migration of applicableMigrations) {
    try {
      currentData = applyMigration(currentData, migration);
    } catch (error) {
      throw new MigrationError(
        `Migration failed (v${migration.from}→v${migration.to}): ${migration.description}`,
        migration.from,
        migration.to,
        error instanceof Error ? error : new Error(String(error))
      );
    }
  }

  return currentData as T;
}

/**
 * Apply a single migration to data
 *
 * Supports both declarative (transforms) and imperative (migrate function) styles.
 * If both are provided, transforms are applied first, then migrate function.
 *
 * @param data - Data to migrate
 * @param migration - Migration to apply
 * @returns Migrated data
 */
function applyMigration(data: any, migration: Migration): any {
  let result = data;

  // Apply declarative transforms if provided
  if (migration.transforms) {
    result = applyTransforms(result, migration.transforms);
  }

  // Apply imperative migration function if provided
  if (migration.migrate) {
    result = migration.migrate(result);
  }

  // If neither transforms nor migrate provided, return data unchanged
  return result;
}

/**
 * Apply declarative path-based transforms to data
 *
 * Transforms are applied in the order they are defined in the object.
 * Each transform operates on the result of previous transforms.
 *
 * @param data - Data to transform
 * @param transforms - Map of paths to transforms
 * @returns Transformed data
 *
 * @example
 * ```typescript
 * applyTransforms(data, {
 *   'cards.breakpoints[].minWidth': (val) => val + 1,
 *   'table.oldField': { rename: 'table.newField' },
 *   'deprecated': { delete: true }
 * });
 * ```
 */
export function applyTransforms<T>(data: T, transforms: Record<string, MigrationTransform>): T {
  let result = data;

  // Apply each transform in order
  for (const [path, transform] of Object.entries(transforms)) {
    result = applyTransform(result, path, transform);
  }

  return result;
}

/**
 * Apply a single transform at a specific path
 *
 * Supports dot notation with array item notation:
 * - 'field' - Top-level field
 * - 'nested.field' - Nested field
 * - 'items[].field' - Apply to all array items
 * - 'a[].b[].c' - Nested arrays
 *
 * @param data - Data to transform
 * @param path - Dot-notation path (supports array notation with [])
 * @param transform - Transform to apply
 * @returns Transformed data
 */
export function applyTransform(data: any, path: string, transform: MigrationTransform): any {
  // Handle different transform types
  if (typeof transform === 'function') {
    return applyFunctionTransform(data, path, transform);
  }

  if ('rename' in transform) {
    return applyRenameTransform(data, path, transform.rename);
  }

  if ('delete' in transform && transform.delete) {
    return applyDeleteTransform(data, path);
  }

  if ('default' in transform) {
    return applyDefaultTransform(data, path, transform.default);
  }

  if ('map' in transform) {
    return applyMapTransform(data, path, transform.map);
  }

  if ('nested' in transform) {
    return applyNestedTransforms(data, path, transform.nested);
  }

  // Unknown transform type - return unchanged
  return data;
}

/**
 * Apply a function transform at path
 */
function applyFunctionTransform(data: any, path: string, fn: (value: any) => any): any {
  return transformAtPath(data, path, fn);
}

/**
 * Apply a rename transform - move value from old path to new path
 */
function applyRenameTransform(data: any, oldPath: string, newPath: string): any {
  const value = getValueAtPath(data, oldPath);
  if (value === undefined) return data;

  // Delete old path
  let result = applyDeleteTransform(data, oldPath);

  // Set at new path
  result = setValueAtPath(result, newPath, value);

  return result;
}

/**
 * Apply a delete transform - remove field at path
 */
function applyDeleteTransform(data: any, path: string): any {
  return deleteAtPath(data, path);
}

/**
 * Apply a default transform - set value if field doesn't exist
 */
function applyDefaultTransform(data: any, path: string, defaultValue: any): any {
  const value = getValueAtPath(data, path);
  if (value === undefined) {
    return setValueAtPath(data, path, defaultValue);
  }
  return data;
}

/**
 * Apply a map transform - map old values to new values
 */
function applyMapTransform(data: any, path: string, mapping: Record<string, any>): any {
  return transformAtPath(data, path, (value) => {
    return mapping[value] ?? value;
  });
}

/**
 * Apply nested transforms to object at path
 */
function applyNestedTransforms(
  data: any,
  path: string,
  transforms: Record<string, MigrationTransform>
): any {
  return transformAtPath(data, path, (value) => {
    return applyTransforms(value, transforms);
  });
}

/**
 * Transform value at path using a function
 * Handles array notation: 'items[].field'
 */
function transformAtPath(data: any, path: string, fn: (value: any) => any): any {
  // Check if path contains array notation
  if (path.includes('[]')) {
    return transformArrayPath(data, path, fn);
  }

  // Simple path - get, transform, set
  const value = getValueAtPath(data, path);
  if (value === undefined) return data;

  const transformed = fn(value);
  return setValueAtPath(data, path, transformed);
}

/**
 * Transform array items at path
 * Example: 'items[].field' applies to all items in 'items' array
 */
function transformArrayPath(data: any, path: string, fn: (value: any) => any): any {
  const [beforeArray, afterArray] = path.split('[]');

  // Get the array
  const array = getValueAtPath(data, beforeArray);
  if (!Array.isArray(array)) return data;

  // Transform each item
  const transformedArray = array.map((item) => {
    if (afterArray) {
      // There's more path after [] - recurse with remaining path
      const remainingPath = afterArray.startsWith('.') ? afterArray.slice(1) : afterArray;
      return transformAtPath(item, remainingPath, fn);
    } else {
      // Path ends with [] - transform the item itself
      return fn(item);
    }
  });

  // Set transformed array back
  return setValueAtPath(data, beforeArray, transformedArray);
}

/**
 * Get value at dot-notation path
 */
function getValueAtPath(data: any, path: string): any {
  const parts = path.split('.');
  let current = data;

  for (const part of parts) {
    if (current == null) return undefined;
    current = current[part];
  }

  return current;
}

/**
 * Set value at dot-notation path (immutable)
 * Creates intermediate objects as needed
 */
function setValueAtPath(data: any, path: string, value: any): any {
  const parts = path.split('.');

  // Handle root-level assignment
  if (parts.length === 1) {
    return { ...data, [parts[0]]: value };
  }

  // Recursive immutable update
  const [first, ...rest] = parts;
  return {
    ...data,
    [first]: setValueAtPath(data[first] || {}, rest.join('.'), value),
  };
}

/**
 * Delete field at dot-notation path (immutable)
 */
function deleteAtPath(data: any, path: string): any {
  const parts = path.split('.');

  // Handle root-level deletion
  if (parts.length === 1) {
    const { [parts[0]]: _, ...rest } = data;
    return rest;
  }

  // Recursive immutable deletion
  const [first, ...rest] = parts;
  if (data[first] == null) return data;

  return {
    ...data,
    [first]: deleteAtPath(data[first], rest.join('.')),
  };
}
