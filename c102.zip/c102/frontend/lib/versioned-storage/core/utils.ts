/**
 * Utility functions for versioned storage.
 */

/**
 * Checks if a value is a plain object (not an array, Date, etc.)
 */
function isPlainObject(value: unknown): value is Record<string, unknown> {
  return (
    typeof value === 'object' &&
    value !== null &&
    !Array.isArray(value) &&
    Object.prototype.toString.call(value) === '[object Object]'
  );
}

/**
 * Deep merge two objects, with target taking precedence over source.
 * Arrays are replaced, not merged.
 *
 * @param target - Target object (takes precedence, can be partial)
 * @param source - Source object (provides defaults)
 * @returns Merged object
 *
 * @example
 * ```typescript
 * const defaults = { a: 1, b: { c: 2, d: 3 } };
 * const partial = { b: { c: 10 } };
 * const result = deepMerge(partial, defaults);
 * // Result: { a: 1, b: { c: 10, d: 3 } }
 * ```
 */
export function deepMerge<T>(target: Partial<T>, source: T): T {
  // Handle non-object types for source
  if (typeof source !== 'object' || source === null) {
    return target !== undefined && target !== null ? (target as T) : source;
  }

  // Handle arrays - replace entirely, don't merge items
  if (Array.isArray(source)) {
    return Array.isArray(target) ? (target as T) : source;
  }

  // If target is not an object, just return source
  if (typeof target !== 'object' || target === null) {
    return source;
  }

  // Merge objects recursively
  const result: any = { ...source };

  // Iterate over all keys in target (not just own properties)
  for (const key in target) {
    // Check if it's an own property (not inherited)
    if (Object.prototype.hasOwnProperty.call(target, key)) {
      const targetValue = (target as any)[key];
      const sourceValue = (source as any)[key];

      // Skip undefined/null values in target - use source default
      if (targetValue === undefined || targetValue === null) {
        continue;
      }

      // If both are plain objects (not arrays), merge recursively
      if (isPlainObject(targetValue) && isPlainObject(sourceValue)) {
        result[key] = deepMerge(targetValue, sourceValue);
      } else {
        // Primitive or array - use target value
        result[key] = targetValue;
      }
    }
  }

  return result as T;
}
