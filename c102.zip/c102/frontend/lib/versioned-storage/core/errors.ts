/**
 * Custom error classes for versioned storage system
 *
 * These error classes provide structured error information with
 * specific error codes and contextual data.
 */

/**
 * Base error class for all versioned storage errors
 *
 * Extends the standard Error with an error code for programmatic
 * error handling.
 */
export class StorageError extends Error {
  /** Error code for programmatic identification */
  readonly code: string;

  /**
   * Create a new StorageError
   *
   * @param message - Human-readable error description
   * @param code - Machine-readable error code
   */
  constructor(message: string, code: string) {
    super(message);
    this.name = 'StorageError';
    this.code = code;

    // Maintains proper stack trace for where our error was thrown (only available on V8)
    if ((Error as any).captureStackTrace) {
      (Error as any).captureStackTrace(this, StorageError);
    }
  }
}

/**
 * Error that occurs during migration execution
 *
 * Thrown when a migration fails to transform data from one version
 * to another. Includes version context for debugging.
 */
export class MigrationError extends StorageError {
  /** Version being migrated from */
  readonly fromVersion: number;

  /** Version being migrated to */
  readonly toVersion: number;

  /** Original error that caused the migration to fail (if any) */
  readonly cause?: Error;

  /**
   * Create a new MigrationError
   *
   * @param message - Human-readable error description
   * @param fromVersion - Source version number
   * @param toVersion - Target version number
   * @param cause - Optional underlying error that caused this migration to fail
   *
   * @example
   * ```typescript
   * throw new MigrationError(
   *   'Failed to migrate catalog preferences',
   *   1,
   *   2,
   *   new TypeError('Cannot read property of undefined')
   * );
   * ```
   */
  constructor(message: string, fromVersion: number, toVersion: number, cause?: Error) {
    super(message, 'MIGRATION_ERROR');
    this.name = 'MigrationError';
    this.fromVersion = fromVersion;
    this.toVersion = toVersion;
    if (cause) {
      this.cause = cause;
    }

    if ((Error as any).captureStackTrace) {
      (Error as any).captureStackTrace(this, MigrationError);
    }
  }
}

/**
 * Error that occurs during data validation
 *
 * Thrown when stored data doesn't match the expected schema structure.
 * Includes the path to the invalid field for debugging.
 */
export class ValidationError extends StorageError {
  /** Path to the invalid field (e.g., 'cards.breakpoints[0].minWidth') */
  readonly path?: string;

  /**
   * Create a new ValidationError
   *
   * @param message - Human-readable error description
   * @param path - Optional path to the invalid field
   *
   * @example
   * ```typescript
   * throw new ValidationError(
   *   'Expected number, got string',
   *   'cards.breakpoints[0].minWidth'
   * );
   * ```
   */
  constructor(message: string, path?: string) {
    super(message, 'VALIDATION_ERROR');
    this.name = 'ValidationError';
    this.path = path;

    if ((Error as any).captureStackTrace) {
      (Error as any).captureStackTrace(this, ValidationError);
    }
  }
}

/**
 * Error that occurs during JSON serialization or deserialization
 *
 * Thrown when data cannot be stringified to JSON or parsed from JSON.
 * Often indicates corrupt localStorage data or circular references.
 */
export class SerializationError extends StorageError {
  /** Original error that caused the serialization to fail (if any) */
  readonly cause?: Error;

  /**
   * Create a new SerializationError
   *
   * @param message - Human-readable error description
   * @param cause - Optional underlying error
   *
   * @example
   * ```typescript
   * try {
   *   JSON.parse(rawData);
   * } catch (error) {
   *   throw new SerializationError('Failed to parse stored data', error);
   * }
   * ```
   */
  constructor(message: string, cause?: Error) {
    super(message, 'SERIALIZATION_ERROR');
    this.name = 'SerializationError';
    if (cause) {
      this.cause = cause;
    }

    if ((Error as any).captureStackTrace) {
      (Error as any).captureStackTrace(this, SerializationError);
    }
  }
}
