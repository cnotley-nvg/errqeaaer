/**
 * Factory functions for creating versioned storage instances
 */

export * from './createVersionedStore';
