/**
 * Factory function for creating VersionedStore instances
 *
 * Provides a convenient functional interface for creating stores
 * without using the `new` keyword.
 */

import { VersionedStore } from '../core/VersionedStore';
import type { VersionedStoreConfig } from '../core/types';

/**
 * Create a new VersionedStore instance
 *
 * This is a simple factory wrapper around the VersionedStore class
 * that provides a more functional API.
 *
 * @template T - Type of data being stored
 * @param config - Configuration for the store
 * @returns VersionedStore instance
 *
 * @example
 * ```typescript
 * const store = createVersionedStore({
 *   key: 'user-preferences',
 *   version: 2,
 *   migrations: [migration0to1, migration1to2],
 *   defaults: { theme: 'light', fontSize: 14 }
 * });
 *
 * const result = store.load();
 * if (result.success) {
 *   console.log(result.data);
 * }
 * ```
 */
export function createVersionedStore<T>(config: VersionedStoreConfig<T>): VersionedStore<T> {
  return new VersionedStore(config);
}
