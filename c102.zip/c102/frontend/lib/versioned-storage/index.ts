/**
 * Versioned Storage System
 *
 * A robust, type-safe localStorage management system with:
 * - Schema versioning
 * - Automatic migrations
 * - Structural validation
 * - Graceful error handling
 * - Dev-only logging
 *
 * @example
 * ```typescript
 * import { useVersionedStorage } from '@/lib/versioned-storage';
 *
 * function MyComponent() {
 *   const [data, setData, updateData, resetData] = useVersionedStorage({
 *     key: 'my-data',
 *     version: 1,
 *     migrations: [],
 *     defaults: { foo: 'bar' }
 *   });
 *
 *   return <div>{data.foo}</div>;
 * }
 * ```
 *
 * @module versioned-storage
 */

// Core types, errors, migrator, validator, utils, and VersionedStore class
export * from './core';

// Factory functions
export * from './factories';

// React hooks
export * from './react';
