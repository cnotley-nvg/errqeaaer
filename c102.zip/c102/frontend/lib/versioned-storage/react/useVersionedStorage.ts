/**
 * React hook for versioned localStorage with state management
 *
 * Provides a React-friendly interface to VersionedStore with automatic
 * state updates and convenient mutation functions.
 */

import { useState, useCallback, useRef, useEffect } from 'react';
import { VersionedStore } from '../core/VersionedStore';
import type { VersionedStoreConfig } from '../core/types';

/**
 * React hook for managing versioned localStorage data
 *
 * Provides stateful access to versioned localStorage with automatic
 * re-renders on updates. Returns the current data, setter function,
 * update function, and reset function.
 *
 * @template T - Type of data being stored
 * @param config - Configuration for the versioned store
 * @returns Tuple of [data, setData, updateData, resetData]
 *
 * @example
 * ```typescript
 * interface UserPrefs {
 *   theme: 'light' | 'dark';
 *   fontSize: number;
 * }
 *
 * const [prefs, setPrefs, updatePrefs, resetPrefs] = useVersionedStorage<UserPrefs>({
 *   key: 'user-prefs',
 *   version: 1,
 *   migrations: [],
 *   defaults: { theme: 'light', fontSize: 14 }
 * });
 *
 * // Read current data
 * console.log(prefs.theme);
 *
 * // Set entire data object
 * setPrefs({ theme: 'dark', fontSize: 16 });
 *
 * // Update specific fields (deep merge)
 * updatePrefs({ fontSize: 18 });
 *
 * // Reset to defaults
 * resetPrefs();
 * ```
 */
export function useVersionedStorage<T>(
  config: VersionedStoreConfig<T>
): [
  data: T,
  setData: (data: T) => void,
  updateData: (partial: Partial<T>) => void,
  resetData: () => void,
] {
  // Create store instance once (using ref to avoid recreation)
  const storeRef = useRef<VersionedStore<T>>();
  if (!storeRef.current) {
    storeRef.current = new VersionedStore(config);
  }
  const store = storeRef.current;

  // Store defaults in ref for stable reference
  const defaultsRef = useRef(config.defaults);

  // Initialize state from localStorage
  const [data, setDataState] = useState<T>(() => {
    const result = store.load();
    return result.success ? result.data : config.defaults;
  });

  // Sync with localStorage on mount (in case it changed externally)
  useEffect(() => {
    const result = store.load();
    if (result.success) {
      setDataState(result.data);
    }
  }, [store]);

  /**
   * Set entire data object and persist to localStorage
   */
  const setData = useCallback(
    (newData: T) => {
      setDataState(newData);
      store.save(newData);
    },
    [store]
  );

  /**
   * Update specific fields (deep merge) and persist to localStorage
   */
  const updateData = useCallback(
    (partial: Partial<T>) => {
      setDataState((current) => {
        const updated = { ...current, ...partial };
        store.save(updated);
        return updated;
      });
    },
    [store]
  );

  /**
   * Reset to default values and clear localStorage
   */
  const resetData = useCallback(() => {
    store.remove();
    setDataState(defaultsRef.current);
  }, [store]);

  return [data, setData, updateData, resetData];
}
