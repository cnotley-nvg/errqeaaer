declare module 'js-yaml' {
  export function load(input: string): any;
}
