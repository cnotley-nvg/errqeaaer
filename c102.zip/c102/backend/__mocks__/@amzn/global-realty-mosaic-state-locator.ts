// Mock for StateLocator
export class StateLocator {
  initialize(): void {
    // Mock initialization
  }

  findState(latitude: number, longitude: number): { found: boolean; state: string | null } {
    // Mock implementation - return California for default testing
    // Tests can override this behavior using jest.spyOn if needed
    if (latitude >= 32.5 && latitude <= 42 && longitude >= -124.5 && longitude <= -114) {
      return { found: true, state: 'California' };
    }
    return { found: false, state: null };
  }
}
