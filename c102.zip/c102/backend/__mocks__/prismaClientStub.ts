export enum AttributeDatatype {
  TEXT = 'TEXT',
  INT = 'INT',
  NUM = 'NUM',
  BOOL = 'BOOL',
}

export class PrismaClient {
  constructor(..._args: unknown[]) {}
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type Prisma = any;

export const prisma = new PrismaClient();

export const getPrismaClient = (): PrismaClient => prisma;
