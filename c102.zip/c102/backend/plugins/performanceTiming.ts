/**
 * GraphQL Performance Timing Plugin
 *
 * Measures and logs query/mutation execution times to help validate
 * performance documentation and detect regressions.
 *
 * Features:
 * - Logs operation name and duration for every GraphQL request
 * - Tracks parse, validate, and execute phases separately
 * - Includes request ID for tracing
 * - Logs are sent to CloudWatch for analysis with Logs Insights
 *
 * Usage:
 * ```typescript
 * import { createPerformanceTimingPlugin } from './plugins/performanceTiming';
 *
 * const yoga = createYoga({
 *   schema,
 *   plugins: [
 *     createPerformanceTimingPlugin({
 *       logger,
 *       logSlowQueries: true,
 *       slowQueryThreshold: 500, // ms
 *     })
 *   ]
 * });
 * ```
 *
 * For percentile calculations (p50, p95, p99), use CloudWatch Logs Insights queries.
 * See docs/backend/GRAPHQL_PERFORMANCE_MONITORING.md for query examples.
 */

import type { Plugin } from 'graphql-yoga';
import type { Logger } from '../shared';

export interface PerformanceTimingPluginOptions {
  /** Logger instance for outputting timing data */
  logger: Logger;

  /** Log only queries exceeding threshold (default: log all) */
  logSlowQueries?: boolean;

  /** Slow query threshold in milliseconds (default: 500ms) */
  slowQueryThreshold?: number;

  /** Enable detailed phase timing (parse, validate, execute) */
  enableDetailedTiming?: boolean;
}

interface TimingData {
  requestId?: string;
  operationName?: string;
  operationType?: string;
  startTime: number;
  parseStart?: number;
  parseEnd?: number;
  validateStart?: number;
  validateEnd?: number;
  executeStart?: number;
  executeEnd?: number;
}

/**
 * Creates a GraphQL Yoga plugin that measures and logs query execution times.
 *
 * This plugin hooks into the GraphQL request lifecycle to measure:
 * - Parse time: How long to parse the GraphQL query string
 * - Validate time: How long to validate the query against the schema
 * - Execute time: How long to execute resolvers and fetch data
 * - Total time: End-to-end request duration
 *
 * @param options - Configuration options
 * @returns GraphQL Yoga plugin
 */
export function createPerformanceTimingPlugin(options: PerformanceTimingPluginOptions): Plugin {
  const {
    logger,
    logSlowQueries = false,
    slowQueryThreshold = 500,
    enableDetailedTiming = false,
  } = options;

  // Store timing data keyed by request
  const timings = new WeakMap<Request, TimingData>();

  return {
    onRequest({ request }) {
      // Initialize timing data for this request
      const timing: TimingData = {
        requestId: request.headers.get('x-amzn-trace-id') || undefined,
        startTime: Date.now(),
      };
      timings.set(request, timing);
    },

    // Note: onParse and onValidate hooks don't have access to context in Yoga v5
    // These would need to be tracked differently if detailed timing is needed

    onExecute({ args }) {
      const timing = timings.get(args.contextValue.request);
      if (timing) {
        timing.executeStart = Date.now();
        timing.operationName = args.operationName || 'Anonymous';

        // Determine operation type (query/mutation/subscription)
        const document = args.document;
        const operation = document.definitions.find(
          (def: any) => def.kind === 'OperationDefinition'
        );
        if (operation && 'operation' in operation) {
          timing.operationType = operation.operation;
        }
      }

      return {
        onExecuteDone({ result }) {
          const timing = timings.get(args.contextValue.request);
          if (!timing) return;

          timing.executeEnd = Date.now();

          // Calculate durations
          const totalDuration = timing.executeEnd - timing.startTime;
          const executeDuration = timing.executeEnd - (timing.executeStart || timing.startTime);

          // Check for errors (handle both single result and async iterator)
          const hasErrors =
            result && typeof result === 'object' && 'errors' in result
              ? result.errors && result.errors.length > 0
              : false;

          // Build log metadata
          const logData: Record<string, any> = {
            operationName: timing.operationName,
            operationType: timing.operationType || 'unknown',
            duration: totalDuration,
            executeDuration,
            hasErrors,
          };

          if (timing.requestId) {
            logData.requestId = timing.requestId;
          }

          if (enableDetailedTiming) {
            if (timing.parseStart && timing.parseEnd) {
              logData.parseDuration = timing.parseEnd - timing.parseStart;
            }
            if (timing.validateStart && timing.validateEnd) {
              logData.validateDuration = timing.validateEnd - timing.validateStart;
            }
          }

          // Determine if we should log this query
          const shouldLog = !logSlowQueries || totalDuration >= slowQueryThreshold;

          if (shouldLog) {
            const level = totalDuration >= slowQueryThreshold ? 'warn' : 'info';
            const message =
              totalDuration >= slowQueryThreshold
                ? 'Slow GraphQL operation detected'
                : 'GraphQL operation completed';

            logger[level](message, logData);
          }

          // Clean up timing data
          timings.delete(args.contextValue.request);
        },
      };
    },
  };
}
