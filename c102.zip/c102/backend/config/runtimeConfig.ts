import { z } from 'zod';

import { parsePositiveNumber } from '@amzn/global-realty-mosaic-shared-utils';

import type { LogContext } from '../lib/logger';

const DEFAULT_PORT = 4000;
const DEFAULT_CORS_ORIGINS = ['http://localhost:3000', 'http://localhost:3001'];
const DEFAULT_PROXY_TIMEOUT_MS = 5_000;

export interface BackendRuntimeConfig {
  server: {
    port: number;
    corsOrigins: string[];
    publicBaseUrl: string;
  };
  dge?: {
    s3: {
      bucket: string;
      prefix?: string;
      region?: string;
    };
  };
  proxy?: {
    baseUrl: string;
    projectId: string;
    folderId: string;
    timeoutMs: number;
  };
  database: {
    url: string;
  };
}

const parseCorsOrigins = (raw: string | undefined): string[] | undefined => {
  if (!raw) {
    return undefined;
  }

  const tokens = raw
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean);

  return tokens.length ? tokens : undefined;
};

const ConfigSchema = z
  .object({
    server: z.object({
      port: z.number().int().positive().default(DEFAULT_PORT),
      corsOrigins: z.array(z.string().min(1)).default(DEFAULT_CORS_ORIGINS),
      publicBaseUrl: z.string().url().optional(),
    }),
    dge: z
      .object({
        s3: z.object({
          bucket: z.string().min(1),
          prefix: z.string().optional(),
          region: z.string().min(1).optional(),
        }),
      })
      .optional(),
    proxy: z
      .object({
        baseUrl: z.string().url().optional(),
        projectId: z.string().min(1).optional(),
        folderId: z.string().min(1).optional(),
        timeoutMs: z.number().int().positive().default(DEFAULT_PROXY_TIMEOUT_MS),
      })
      .refine(
        ({ baseUrl, projectId, folderId }) => {
          const supplied = [baseUrl, projectId, folderId].filter(Boolean).length;
          return supplied === 0 || supplied === 3;
        },
        {
          message:
            'ACC proxy configuration is incomplete. Provide ACC_PROXY_BASE_URL, APS_PROJECT_ID, and APS_FOLDER_ID.',
        }
      )
      .optional()
      .transform((proxy) => {
        if (!proxy?.baseUrl) {
          return undefined;
        }

        return {
          baseUrl: proxy.baseUrl,
          projectId: proxy.projectId!,
          folderId: proxy.folderId!,
          timeoutMs: proxy.timeoutMs,
        } as BackendRuntimeConfig['proxy'];
      }),
    database: z.object({
      url: z.string().min(1, 'DATABASE_URL must be provided'),
    }),
  })
  .transform(
    (value) =>
      ({
        server: {
          port: value.server.port,
          corsOrigins: value.server.corsOrigins,
          publicBaseUrl: value.server.publicBaseUrl ?? `http://localhost:${value.server.port}`,
        },
        dge: value.dge,
        proxy: value.proxy,
        database: value.database,
      }) satisfies BackendRuntimeConfig
  );

export const getRuntimeConfig = (env: NodeJS.ProcessEnv = process.env): BackendRuntimeConfig => {
  const corsOrigins = parseCorsOrigins(env.BACKEND_CORS_ORIGINS);
  const rawPort = parsePositiveNumber(env.PORT, DEFAULT_PORT);
  const rawPublicBaseUrl = env.BACKEND_PUBLIC_BASE_URL?.trim();
  const databaseUrl = env.DATABASE_URL?.trim();
  const dgeS3Bucket = env.DGE_S3_BUCKET?.trim();
  const dgeS3Prefix = env.DGE_S3_PREFIX?.trim();
  const dgeS3Region = env.DGE_S3_REGION?.trim();

  const configCandidate = {
    server: {
      port: rawPort,
      corsOrigins: corsOrigins ?? DEFAULT_CORS_ORIGINS,
      publicBaseUrl: rawPublicBaseUrl && rawPublicBaseUrl.length ? rawPublicBaseUrl : undefined,
    },
    dge:
      dgeS3Bucket && dgeS3Bucket.length
        ? {
            s3: {
              bucket: dgeS3Bucket,
              prefix: dgeS3Prefix && dgeS3Prefix.length ? dgeS3Prefix : undefined,
              region: dgeS3Region && dgeS3Region.length ? dgeS3Region : undefined,
            },
          }
        : undefined,
    proxy: env.ACC_PROXY_BASE_URL
      ? {
          baseUrl: env.ACC_PROXY_BASE_URL.trim(),
          projectId: env.APS_PROJECT_ID?.trim(),
          folderId: env.APS_FOLDER_ID?.trim(),
          timeoutMs: parsePositiveNumber(env.ACC_PROXY_TIMEOUT_MS, DEFAULT_PROXY_TIMEOUT_MS),
        }
      : undefined,
    database: {
      url: databaseUrl ?? '',
    },
  };

  const parsed = ConfigSchema.safeParse(configCandidate);
  if (!parsed.success) {
    const issues = parsed.error.issues.map((issue) => issue.message).join('; ');
    throw new Error(`Backend configuration invalid: ${issues}`);
  }

  return parsed.data;
};

export interface ConfiguredContext extends LogContext {
  requestId?: string;
}
