import {
  createMetadataClient,
  type AccMetadataClient,
  type AccMetadataClientConfig,
  type AccMetadataClientStatus,
  type SignedUrlOptions,
  type StandardDocumentDescriptor,
} from '@amzn/global-realty-mosaic-acc-client';

export { createMetadataClient };
export type {
  AccMetadataClient,
  AccMetadataClientConfig,
  AccMetadataClientStatus,
  SignedUrlOptions,
  StandardDocumentDescriptor,
};
