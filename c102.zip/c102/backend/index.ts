import 'dotenv/config';

import { startServer } from './server';
import { getRuntimeConfig } from './config/runtimeConfig';

export { startServer, getRuntimeConfig };
export { createGraphqlServer } from './createGraphqlServer';

if (require.main === module) {
  startServer();
}
