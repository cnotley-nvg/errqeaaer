import type { AuthenticatedUser } from '../../../lib/auth';
import { AuthenticationError } from '../../../lib/auth';
import type { Logger } from '../../../shared';

export interface UserResolverContext {
  readonly user: AuthenticatedUser | null;
  readonly logger: Logger;
}

export interface UserGraphQL {
  username: string;
  email: string | null;
  name: string | null;
  givenName: string | null;
  familyName: string | null;
  groups: string[];
  expiresAt: string | null;
  issuedAt: string | null;
  warning: string | null;
}

export interface UserResolverMap {
  Query: {
    whoami: (
      parent: unknown,
      args: Record<string, never>,
      context: UserResolverContext
    ) => UserGraphQL;
  };
}

/**
 * Converts AuthenticatedUser (with Date objects) to UserGraphQL (with ISO strings)
 */
const mapAuthenticatedUserToUser = (authUser: AuthenticatedUser): UserGraphQL => {
  return {
    username: authUser.username,
    email: authUser.email ?? null,
    name: authUser.name ?? null,
    givenName: authUser.givenName ?? null,
    familyName: authUser.familyName ?? null,
    groups: authUser.groups,
    expiresAt: authUser.expiresAt?.toISOString() ?? null,
    issuedAt: authUser.issuedAt?.toISOString() ?? null,
    warning: authUser.warning ?? null,
  };
};

export const createUserResolvers = (): UserResolverMap => ({
  Query: {
    whoami: (_parent, _args, context) => {
      const { user, logger } = context;

      try {
        // Throw error if not authenticated
        if (!user) {
          logger.warn('whoami query called without authentication');
          throw new AuthenticationError(
            'Authentication required. Please ensure you are accessing the application through the ALB with valid OIDC headers.'
          );
        }

        logger.info('whoami query resolved', {
          username: user.username,
          hasEmail: !!user.email,
          hasName: !!user.name,
          groupCount: user.groups.length,
          hasExpiration: !!user.expiresAt,
          hasWarning: !!user.warning,
        });

        return mapAuthenticatedUserToUser(user);
      } catch (error) {
        // Log the error with safe metadata (no sensitive token/header data)
        if (error instanceof AuthenticationError) {
          // Already logged above, just re-throw
          throw error;
        }

        // Log unexpected errors with sanitized context
        logger.error('Unexpected error in whoami resolver', {
          errorName: error instanceof Error ? error.name : 'UnknownError',
          errorMessage: error instanceof Error ? error.message : String(error),
          hasUser: !!user,
          username: user?.username, // Safe to log - already authenticated
        });

        // Re-throw the original error
        throw error;
      }
    },
  },
});
