import type { Logger } from '../../shared';
import { ensureLogger } from '../../shared';
import { createUserResolvers } from './graphql/resolvers';

export interface UserModuleDependencies {
  logger: Logger;
}

/**
 * User module for authentication and user information.
 *
 * Provides GraphQL queries for accessing authenticated user data
 * parsed from OIDC headers (ALB + Amazon Federate).
 */
export const createUserModule = (dependencies: UserModuleDependencies) => {
  const logger = ensureLogger(dependencies.logger, 'user-module');

  logger.info('Initializing user module');

  const resolvers = createUserResolvers();

  return {
    resolvers,
  } as const;
};
