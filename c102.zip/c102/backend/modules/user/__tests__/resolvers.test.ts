import { createUserResolvers } from '../graphql/resolvers';
import { AuthenticationError } from '../../../lib/auth';
import type { AuthenticatedUser } from '../../../lib/auth';
import { createLogger } from '../../../shared';

describe('User Resolvers', () => {
  const logger = createLogger('test');
  const resolvers = createUserResolvers();

  describe('whoami', () => {
    it('should return complete user when authenticated with all claims', () => {
      const mockUser: AuthenticatedUser = {
        username: 'testuser',
        email: 'testuser@amazon.com',
        name: 'Test User',
        givenName: 'Test',
        familyName: 'User',
        groups: ['developers', 'admins'],
        expiresAt: new Date('2025-12-17T18:30:00.000Z'),
        issuedAt: new Date('2025-12-17T08:30:00.000Z'),
      };

      const result = resolvers.Query.whoami({}, {}, { user: mockUser, logger });

      expect(result).toEqual({
        username: 'testuser',
        email: 'testuser@amazon.com',
        name: 'Test User',
        givenName: 'Test',
        familyName: 'User',
        groups: ['developers', 'admins'],
        expiresAt: '2025-12-17T18:30:00.000Z',
        issuedAt: '2025-12-17T08:30:00.000Z',
        warning: null,
      });
    });

    it('should return user with null optional fields when claims are missing', () => {
      const minimalUser: AuthenticatedUser = {
        username: 'testuser',
        groups: [],
      };

      const result = resolvers.Query.whoami({}, {}, { user: minimalUser, logger });

      expect(result).toEqual({
        username: 'testuser',
        email: null,
        name: null,
        givenName: null,
        familyName: null,
        groups: [],
        expiresAt: null,
        issuedAt: null,
        warning: null,
      });
    });

    it('should handle user with empty groups array', () => {
      const mockUser: AuthenticatedUser = {
        username: 'testuser',
        email: 'testuser@amazon.com',
        groups: [],
      };

      const result = resolvers.Query.whoami({}, {}, { user: mockUser, logger });

      expect(result.groups).toEqual([]);
    });

    it('should convert Date objects to ISO 8601 strings', () => {
      const mockUser: AuthenticatedUser = {
        username: 'testuser',
        groups: [],
        expiresAt: new Date('2025-12-17T18:30:00.000Z'),
        issuedAt: new Date('2025-12-17T08:30:00.000Z'),
      };

      const result = resolvers.Query.whoami({}, {}, { user: mockUser, logger });

      expect(result.expiresAt).toBe('2025-12-17T18:30:00.000Z');
      expect(result.issuedAt).toBe('2025-12-17T08:30:00.000Z');
      expect(typeof result.expiresAt).toBe('string');
      expect(typeof result.issuedAt).toBe('string');
    });

    it('should throw AuthenticationError when user is null', () => {
      expect(() => {
        resolvers.Query.whoami({}, {}, { user: null, logger });
      }).toThrow(AuthenticationError);
    });

    it('should throw error with descriptive message when unauthenticated', () => {
      expect(() => {
        resolvers.Query.whoami({}, {}, { user: null, logger });
      }).toThrow('Authentication required');
    });

    it('should include multiple groups in response', () => {
      const mockUser: AuthenticatedUser = {
        username: 'testuser',
        groups: ['developers', 'admins', 'mosaic-team', 'security'],
      };

      const result = resolvers.Query.whoami({}, {}, { user: mockUser, logger });

      expect(result.groups).toHaveLength(4);
      expect(result.groups).toContain('developers');
      expect(result.groups).toContain('security');
    });

    it('should log authentication errors without exposing sensitive data', () => {
      const loggerSpy = {
        ...logger,
        warn: jest.fn(),
        error: jest.fn(),
      };

      expect(() => {
        resolvers.Query.whoami({}, {}, { user: null, logger: loggerSpy });
      }).toThrow(AuthenticationError);

      // Verify warn was called (not error, since it's expected)
      expect(loggerSpy.warn).toHaveBeenCalledWith('whoami query called without authentication');
      expect(loggerSpy.error).not.toHaveBeenCalled();
    });

    it('should return warning field when OIDC parsing failed', () => {
      const mockUser: AuthenticatedUser = {
        username: 'testuser',
        groups: [],
        warning: 'Failed to decode OIDC claims: Invalid JSON. Only username is available.',
      };

      const result = resolvers.Query.whoami({}, {}, { user: mockUser, logger });

      expect(result.username).toBe('testuser');
      expect(result.warning).toBe(
        'Failed to decode OIDC claims: Invalid JSON. Only username is available.'
      );
      expect(result.email).toBeNull();
      expect(result.groups).toEqual([]);
    });

    it('should log unexpected errors with safe metadata only', () => {
      const mockUser: AuthenticatedUser = {
        username: 'testuser',
        groups: ['developers'],
        email: 'testuser@amazon.com',
      };

      // Create a logger spy
      const loggerSpy = {
        ...logger,
        info: jest.fn(),
        error: jest.fn(),
      };

      // Mock the mapper to throw an error
      const brokenResolvers = {
        Query: {
          whoami: (_parent: unknown, _args: Record<string, never>, context: any) => {
            const { user, logger: contextLogger } = context;

            try {
              if (!user) {
                contextLogger.warn('whoami query called without authentication');
                throw new AuthenticationError('Authentication required');
              }

              // Simulate an unexpected error (e.g., mapping failure)
              throw new Error('Unexpected mapping error');
            } catch (error) {
              if (error instanceof AuthenticationError) {
                throw error;
              }

              // Log unexpected errors with sanitized context
              contextLogger.error('Unexpected error in whoami resolver', {
                errorName: error instanceof Error ? error.name : 'UnknownError',
                errorMessage: error instanceof Error ? error.message : String(error),
                hasUser: !!user,
                username: user?.username,
              });

              throw error;
            }
          },
        },
      };

      expect(() => {
        brokenResolvers.Query.whoami({}, {}, { user: mockUser, logger: loggerSpy });
      }).toThrow('Unexpected mapping error');

      // Verify error was logged with safe metadata
      expect(loggerSpy.error).toHaveBeenCalledWith('Unexpected error in whoami resolver', {
        errorName: 'Error',
        errorMessage: 'Unexpected mapping error',
        hasUser: true,
        username: 'testuser',
      });

      // Verify NO sensitive data like email, tokens, or full user object was logged
      const loggedData = loggerSpy.error.mock.calls[0][1];
      expect(loggedData).not.toHaveProperty('email');
      expect(loggedData).not.toHaveProperty('user');
      expect(loggedData).not.toHaveProperty('groups');
      expect(loggedData).not.toHaveProperty('token');
    });
  });
});
