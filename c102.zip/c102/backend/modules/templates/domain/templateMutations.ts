import type { PrismaClient } from '@amzn/global-realty-mosaic-prisma-client';
import type { CreateTemplateFileInput } from '@amzn/global-realty-mosaic-graphql-schema';

type TemplateFileDelegate = PrismaClient['templateFile'];
type TemplateVersionDelegate = PrismaClient['templateVersion'];
type TemplateVersionFindManyArgs = Parameters<TemplateVersionDelegate['findMany']>[0];

export interface TemplateFileMutations {
  create: TemplateFileDelegate['create'];
}

export interface TemplateVersionMutations {
  updateMany: TemplateVersionDelegate['updateMany'];
  update: TemplateVersionDelegate['update'];
  findMany: (args: TemplateVersionFindManyArgs) => ReturnType<TemplateVersionDelegate['findMany']>;
}

export const insertTemplateFiles = async (
  templateFile: TemplateFileMutations,
  templateVersionId: string,
  files: ReadonlyArray<CreateTemplateFileInput>
): Promise<void> => {
  if (!files.length) {
    return;
  }

  await Promise.all(
    files.map((file) =>
      templateFile.create({
        data: {
          templateVersionId,
          accFileId: file.accFileId,
        },
      })
    )
  );
};

export const updateLatestTemplateFlags = async (
  templateVersion: TemplateVersionMutations,
  templateId: string,
  latestId: string
): Promise<void> => {
  await templateVersion.updateMany({ data: { isLatest: false }, where: { templateId } });
  await templateVersion.update({ data: { isLatest: true }, where: { id: latestId } });
};

export const ensureLatestTemplateVersionExists = async (
  templateVersion: TemplateVersionMutations,
  templateId: string
): Promise<void> => {
  const versions = await templateVersion.findMany({
    where: { templateId },
    orderBy: { createdAt: 'desc' },
    select: { id: true, isLatest: true },
  });

  if (!versions.length) {
    return;
  }

  if (versions.some((version) => version.isLatest)) {
    return;
  }

  const [mostRecent] = versions;
  if (mostRecent) {
    await templateVersion.update({
      where: { id: mostRecent.id },
      data: { isLatest: true },
    });
  }
};
