import type {
  Template as PrismaTemplate,
  TemplateFile as PrismaTemplateFile,
  TemplateVersion as PrismaTemplateVersion,
} from '@amzn/global-realty-mosaic-prisma-client';
import type {
  Template,
  TemplateFile,
  TemplateVersion,
} from '@amzn/global-realty-mosaic-graphql-schema';

export type TemplateVersionRecord = PrismaTemplateVersion & {
  template?: PrismaTemplate;
  files?: PrismaTemplateFile[]; // Optional since files can be lazy-loaded via field resolver
};

export type TemplateRecord = PrismaTemplate & {
  versions: TemplateVersionRecord[];
};

export type TemplateAttributeLoader = (
  templateVersionId: string
) => Promise<TemplateVersion['attributes']>;

const toTemplateFileGraph = (file: PrismaTemplateFile): TemplateFile => ({
  id: file.id,
  templateVersionId: file.templateVersionId,
  accFileId: file.accFileId,
  displayName: file.displayName ?? null,
  createdAt: file.createdAt.toISOString(),
});

const createTemplateVersionMapper =
  (attributeLoader: TemplateAttributeLoader) =>
  async (
    record: TemplateVersionRecord,
    templateFallback?: PrismaTemplate
  ): Promise<TemplateVersion> => {
    const attributes = await attributeLoader(record.id);
    const template = record.template ?? templateFallback;
    if (!template) {
      throw new Error('Template reference not loaded for template version.');
    }

    const brsId = record.brsId ?? '';

    return {
      id: record.id,
      templateId: record.templateId,
      template: {
        id: template.id,
        accProjectId: template.accProjectId,
        name: template.name,
        description: template.description ?? null,
        heroImageUrl: template.heroImageUrl ?? null,
        createdAt: template.createdAt.toISOString(),
        updatedAt: template.updatedAt.toISOString(),
        versions: [],
        latestVersion: null,
        facilityTypes: [],
      },
      accFolderId: record.accFolderId,
      brsId,
      version: record.version,
      isLatest: record.isLatest,
      files: record.files?.map(toTemplateFileGraph) ?? [],
      changes: [], // Lazy-loaded via field resolver
      electricalLoadData: [], // Lazy-loaded via field resolver
      attributes,
      createdAt: record.createdAt.toISOString(),
      updatedAt: record.updatedAt.toISOString(),
    } satisfies TemplateVersion;
  };

export const createTemplateMappers = (attributeLoader: TemplateAttributeLoader) => {
  const toTemplateVersionGraph = createTemplateVersionMapper(attributeLoader);

  const toTemplateGraph = async (record: TemplateRecord): Promise<Template> => {
    const versions = await Promise.all(
      record.versions.map((version) => toTemplateVersionGraph(version, record))
    );

    const latestVersion = versions.find((version) => version.isLatest) ?? versions[0] ?? null;
    const facilityTypesSet = new Set<string>();
    for (const version of versions) {
      const attrs = version.attributes as Record<string, unknown> | null;
      const facilityType = attrs?.facilityType;
      if (typeof facilityType === 'string' && facilityType.trim()) {
        facilityTypesSet.add(facilityType.trim());
      } else if (Array.isArray(facilityType)) {
        facilityType.forEach((ft) => {
          if (typeof ft === 'string' && ft.trim()) {
            facilityTypesSet.add(ft.trim());
          }
        });
      }
    }

    return {
      id: record.id,
      accProjectId: record.accProjectId,
      name: record.name,
      description: record.description ?? null,
      heroImageUrl: record.heroImageUrl ?? null,
      createdAt: record.createdAt.toISOString(),
      updatedAt: record.updatedAt.toISOString(),
      versions,
      latestVersion,
      facilityTypes: Array.from(facilityTypesSet).sort(),
    } satisfies Template;
  };

  return {
    toTemplateFileGraph,
    toTemplateVersionGraph,
    toTemplateGraph,
  } as const;
};
