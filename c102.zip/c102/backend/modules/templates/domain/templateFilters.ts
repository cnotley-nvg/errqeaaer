import type { Prisma } from '@amzn/global-realty-mosaic-prisma-client';
import type { FilterInput, FilterTokenGroupInput } from '@amzn/global-realty-mosaic-graphql-schema';

const collectTokenValues = (token: FilterTokenGroupInput): string[] => {
  if (token.values?.length) {
    return token.values.filter(
      (value): value is string => typeof value === 'string' && value.trim().length > 0
    );
  }

  return typeof token.value === 'string' && token.value.trim().length > 0 ? [token.value] : [];
};

const buildStringCondition = (
  field: keyof Prisma.TemplateWhereInput,
  operator: FilterTokenGroupInput['operator'],
  values: string[]
): Prisma.TemplateWhereInput | null => {
  if (!values.length) {
    return null;
  }

  const equalsFilter = (value: string): Prisma.TemplateWhereInput => ({
    [field]: {
      equals: value,
      mode: 'insensitive',
    },
  });

  const containsFilter = (value: string): Prisma.TemplateWhereInput => ({
    [field]: {
      contains: value,
      mode: 'insensitive',
    },
  });

  const startsWithFilter = (value: string): Prisma.TemplateWhereInput => ({
    [field]: {
      startsWith: value,
      mode: 'insensitive',
    },
  });

  switch (operator) {
    case 'EQUALS':
      return values.length === 1
        ? equalsFilter(values[0]!)
        : { OR: values.map((value) => equalsFilter(value)) };
    case 'NOT_EQUALS':
      return {
        AND: values.map((value) => ({ NOT: equalsFilter(value) })),
      } satisfies Prisma.TemplateWhereInput;
    case 'CONTAINS':
      return values.length === 1
        ? containsFilter(values[0]!)
        : { OR: values.map((value) => containsFilter(value)) };
    case 'NOT_CONTAINS':
      return {
        AND: values.map((value) => ({ NOT: containsFilter(value) })),
      } satisfies Prisma.TemplateWhereInput;
    case 'STARTS_WITH':
      return values.length === 1
        ? startsWithFilter(values[0]!)
        : { OR: values.map((value) => startsWithFilter(value)) };
    case 'NOT_STARTS_WITH':
      return {
        AND: values.map((value) => ({ NOT: startsWithFilter(value) })),
      } satisfies Prisma.TemplateWhereInput;
    default:
      return null;
  }
};

const parseDateValue = (value: string): Date | null => {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

const buildDateCondition = (
  field: 'createdAt' | 'updatedAt',
  operator: FilterTokenGroupInput['operator'],
  values: string[]
): Prisma.TemplateWhereInput | null => {
  const [raw] = values;
  if (!raw) {
    return null;
  }

  const parsed = parseDateValue(raw);
  if (!parsed) {
    return null;
  }

  switch (operator) {
    case 'GREATER_THAN':
      return { [field]: { gt: parsed } } as Prisma.TemplateWhereInput;
    case 'GREATER_OR_EQUAL':
      return { [field]: { gte: parsed } } as Prisma.TemplateWhereInput;
    case 'LESS_THAN':
      return { [field]: { lt: parsed } } as Prisma.TemplateWhereInput;
    case 'LESS_OR_EQUAL':
      return { [field]: { lte: parsed } } as Prisma.TemplateWhereInput;
    case 'EQUALS':
      return { [field]: { equals: parsed } } as Prisma.TemplateWhereInput;
    case 'NOT_EQUALS':
      return { NOT: { [field]: { equals: parsed } } } as Prisma.TemplateWhereInput;
    default:
      return null;
  }
};

export const buildWhere = (filter: FilterInput): Prisma.TemplateWhereInput => {
  const query = filter.query;
  if (!query?.tokenGroups?.length) {
    return {};
  }

  const conditions = query.tokenGroups
    .map((token) => {
      const values = collectTokenValues(token);
      if (!values.length) {
        return null;
      }

      switch (token.propertyKey) {
        case 'name':
          return buildStringCondition('name', token.operator, values);
        case 'description':
          return buildStringCondition('description', token.operator, values);
        case 'accProjectId':
          return buildStringCondition('accProjectId', token.operator, values);
        case 'createdAt':
          return buildDateCondition('createdAt', token.operator, values);
        case 'updatedAt':
          return buildDateCondition('updatedAt', token.operator, values);
        default:
          return null;
      }
    })
    .filter((condition): condition is Prisma.TemplateWhereInput => condition !== null);

  if (!conditions.length) {
    return {};
  }

  return query.operation === 'AND'
    ? ({ AND: conditions } satisfies Prisma.TemplateWhereInput)
    : ({ OR: conditions } satisfies Prisma.TemplateWhereInput);
};

export const buildOrderBy = (filter: FilterInput): Prisma.TemplateOrderByWithRelationInput => {
  const direction: Prisma.SortOrder = filter.orderDesc ? 'desc' : 'asc';

  switch (filter.orderBy) {
    case 'name':
      return { name: direction };
    case 'accProjectId':
      return { accProjectId: direction };
    case 'updatedAt':
      return { updatedAt: direction };
    case 'createdAt':
      return { createdAt: direction };
    default:
      return { createdAt: 'desc' };
  }
};

// Helper to build string condition for TemplateVersion fields that exist in template relation
const buildTemplateVersionStringCondition = (
  templateField: keyof Prisma.TemplateWhereInput,
  operator: FilterTokenGroupInput['operator'],
  values: string[]
): Prisma.TemplateVersionWhereInput | null => {
  if (!values.length) {
    return null;
  }

  const equalsFilter = (value: string): Prisma.TemplateVersionWhereInput => ({
    template: {
      [templateField]: {
        equals: value,
        mode: 'insensitive',
      },
    },
  });

  const containsFilter = (value: string): Prisma.TemplateVersionWhereInput => ({
    template: {
      [templateField]: {
        contains: value,
        mode: 'insensitive',
      },
    },
  });

  const startsWithFilter = (value: string): Prisma.TemplateVersionWhereInput => ({
    template: {
      [templateField]: {
        startsWith: value,
        mode: 'insensitive',
      },
    },
  });

  switch (operator) {
    case 'EQUALS':
      return values.length === 1
        ? equalsFilter(values[0]!)
        : { OR: values.map((value) => equalsFilter(value)) };
    case 'NOT_EQUALS':
      return {
        AND: values.map((value) => ({ NOT: equalsFilter(value) })),
      } satisfies Prisma.TemplateVersionWhereInput;
    case 'CONTAINS':
      return values.length === 1
        ? containsFilter(values[0]!)
        : { OR: values.map((value) => containsFilter(value)) };
    case 'NOT_CONTAINS':
      return {
        AND: values.map((value) => ({ NOT: containsFilter(value) })),
      } satisfies Prisma.TemplateVersionWhereInput;
    case 'STARTS_WITH':
      return values.length === 1
        ? startsWithFilter(values[0]!)
        : { OR: values.map((value) => startsWithFilter(value)) };
    case 'NOT_STARTS_WITH':
      return {
        AND: values.map((value) => ({ NOT: startsWithFilter(value) })),
      } satisfies Prisma.TemplateVersionWhereInput;
    default:
      return null;
  }
};

const buildTemplateVersionDateCondition = (
  field: 'createdAt' | 'updatedAt',
  operator: FilterTokenGroupInput['operator'],
  values: string[]
): Prisma.TemplateVersionWhereInput | null => {
  const [raw] = values;
  if (!raw) {
    return null;
  }

  const parsed = parseDateValue(raw);
  if (!parsed) {
    return null;
  }

  switch (operator) {
    case 'GREATER_THAN':
      return { [field]: { gt: parsed } } as Prisma.TemplateVersionWhereInput;
    case 'GREATER_OR_EQUAL':
      return { [field]: { gte: parsed } } as Prisma.TemplateVersionWhereInput;
    case 'LESS_THAN':
      return { [field]: { lt: parsed } } as Prisma.TemplateVersionWhereInput;
    case 'LESS_OR_EQUAL':
      return { [field]: { lte: parsed } } as Prisma.TemplateVersionWhereInput;
    case 'EQUALS':
      return { [field]: { equals: parsed } } as Prisma.TemplateVersionWhereInput;
    case 'NOT_EQUALS':
      return { NOT: { [field]: { equals: parsed } } } as Prisma.TemplateVersionWhereInput;
    default:
      return null;
  }
};

// Build condition for version field (direct field on TemplateVersion)
const buildVersionStringCondition = (
  operator: FilterTokenGroupInput['operator'],
  values: string[]
): Prisma.TemplateVersionWhereInput | null => {
  if (!values.length) {
    return null;
  }

  const equalsFilter = (value: string): Prisma.TemplateVersionWhereInput => ({
    version: {
      equals: value,
      mode: 'insensitive',
    },
  });

  const containsFilter = (value: string): Prisma.TemplateVersionWhereInput => ({
    version: {
      contains: value,
      mode: 'insensitive',
    },
  });

  const startsWithFilter = (value: string): Prisma.TemplateVersionWhereInput => ({
    version: {
      startsWith: value,
      mode: 'insensitive',
    },
  });

  switch (operator) {
    case 'EQUALS':
      return values.length === 1
        ? equalsFilter(values[0]!)
        : { OR: values.map((value) => equalsFilter(value)) };
    case 'NOT_EQUALS':
      return {
        AND: values.map((value) => ({ NOT: equalsFilter(value) })),
      } satisfies Prisma.TemplateVersionWhereInput;
    case 'CONTAINS':
      return values.length === 1
        ? containsFilter(values[0]!)
        : { OR: values.map((value) => containsFilter(value)) };
    case 'NOT_CONTAINS':
      return {
        AND: values.map((value) => ({ NOT: containsFilter(value) })),
      } satisfies Prisma.TemplateVersionWhereInput;
    case 'STARTS_WITH':
      return values.length === 1
        ? startsWithFilter(values[0]!)
        : { OR: values.map((value) => startsWithFilter(value)) };
    case 'NOT_STARTS_WITH':
      return {
        AND: values.map((value) => ({ NOT: startsWithFilter(value) })),
      } satisfies Prisma.TemplateVersionWhereInput;
    default:
      return null;
  }
};

export const buildTemplateVersionWhere = (
  filter: FilterInput
): Prisma.TemplateVersionWhereInput => {
  const query = filter.query;
  if (!query?.tokenGroups?.length) {
    return {};
  }

  const conditions = query.tokenGroups
    .map((token) => {
      const values = collectTokenValues(token);
      if (!values.length) {
        return null;
      }

      // Template fields (accessed via relation)
      switch (token.propertyKey) {
        case 'name':
          return buildTemplateVersionStringCondition('name', token.operator, values);
        case 'description':
          return buildTemplateVersionStringCondition('description', token.operator, values);
        case 'accProjectId':
          return buildTemplateVersionStringCondition('accProjectId', token.operator, values);
        case 'createdAt':
          return buildTemplateVersionDateCondition('createdAt', token.operator, values);
        case 'updatedAt':
          return buildTemplateVersionDateCondition('updatedAt', token.operator, values);
        case 'version':
          return buildVersionStringCondition(token.operator, values);
        default:
          // Attribute-based filters will be handled in-memory
          return null;
      }
    })
    .filter((condition): condition is Prisma.TemplateVersionWhereInput => condition !== null);

  if (!conditions.length) {
    return {};
  }

  return query.operation === 'AND'
    ? ({ AND: conditions } satisfies Prisma.TemplateVersionWhereInput)
    : ({ OR: conditions } satisfies Prisma.TemplateVersionWhereInput);
};

export const buildTemplateVersionOrderBy = (
  filter: FilterInput
): Prisma.TemplateVersionOrderByWithRelationInput => {
  const direction: Prisma.SortOrder = filter.orderDesc ? 'desc' : 'asc';

  switch (filter.orderBy) {
    case 'name':
      return { template: { name: direction } };
    case 'accProjectId':
      return { template: { accProjectId: direction } };
    case 'updatedAt':
      return { updatedAt: direction };
    case 'createdAt':
      return { createdAt: direction };
    case 'version':
      return { version: direction };
    default:
      return { createdAt: 'desc' };
  }
};

export const templateFilterInternals = {
  collectTokenValues,
  buildStringCondition,
  buildDateCondition,
  parseDateValue,
  buildTemplateVersionStringCondition,
  buildTemplateVersionDateCondition,
};
