import type { Logger } from '../../shared';
import { ensureLogger } from '../../shared';
import type { BackendRuntimeConfig } from '../../config/runtimeConfig';
import { createTemplateService, type TemplateService } from './domain/templateService';
import { createTemplateAssetService } from './infra/templateAssetService';
import { createTemplatesResolvers, type TemplateResolverMap } from './graphql/resolvers';

export interface TemplateModule {
  resolvers: TemplateResolverMap;
  service: TemplateService;
}

export interface CreateTemplateModuleArgs {
  logger: Logger;
  config: BackendRuntimeConfig;
}

export const createTemplateModule = ({
  logger,
  config,
}: CreateTemplateModuleArgs): TemplateModule => {
  const moduleLogger = ensureLogger(logger, 'templates-module').child({ module: 'templates' });

  const service = createTemplateService(moduleLogger.child({ component: 'service' }));
  const assetService = createTemplateAssetService(
    config,
    moduleLogger.child({ component: 'asset-service' })
  );

  const resolvers = createTemplatesResolvers({
    templateService: service,
    templateAssetService: assetService,
  });

  return {
    resolvers,
    service,
  };
};
