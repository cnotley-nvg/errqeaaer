import type { BackendRuntimeConfig } from '../../../config/runtimeConfig';
import { ProxyUnavailableError, AccClient, type Logger } from '../../../shared';

export interface TemplateAssetService {
  generateSignedUrl(
    projectId: string,
    accFileId: string,
    options?: {
      disposition?: 'inline' | 'attachment';
      minutesExpiration?: number;
      filename?: string;
    }
  ): Promise<string | null>;
}

export const createTemplateAssetService = (
  config: BackendRuntimeConfig,
  logger: Logger
): TemplateAssetService => {
  const scopedLogger = logger.child({ component: 'template-asset-service' });

  // Create AccClient once
  const { proxy } = config;
  if (!proxy?.baseUrl) {
    throw new ProxyUnavailableError(
      'ACC proxy configuration missing. Configure ACC_PROXY_BASE_URL.'
    );
  }

  const accClient = new AccClient({
    proxyBaseUrl: proxy.baseUrl,
    requestTimeoutMs: proxy.timeoutMs,
  });

  return {
    async generateSignedUrl(
      projectId: string,
      accFileId: string,
      options?: {
        disposition?: 'inline' | 'attachment';
        minutesExpiration?: number;
        filename?: string;
      }
    ): Promise<string | null> {
      if (!accFileId.trim()) {
        return null;
      }

      try {
        return await accClient.getSignedDownloadUrl(projectId, accFileId, {
          disposition: options?.disposition,
          minutesExpiration: options?.minutesExpiration,
          filename: options?.filename,
        });
      } catch (error) {
        scopedLogger.warn('Failed to generate signed URL for template file', {
          accFileId,
          error: error instanceof Error ? error.message : error,
        });
        throw error;
      }
    },
  };
};
