import type {
  CreateTemplateInput,
  CreateTemplateVersionInput,
  FilterInput,
  TemplateFile,
  TemplateVersion,
  TemplateVersionChange,
  UpdateTemplateInput,
  UpdateTemplateVersionInput,
} from '@amzn/global-realty-mosaic-graphql-schema';

import type { TemplateService } from '../domain/templateService';
import type { TemplateAssetService } from '../infra/templateAssetService';
import type { GraphqlContext } from '../../../createGraphqlServer';
import type { ResolverTemplateVersion, ElectricalLoadLookupData } from './types';

interface TemplateResolverDependencies {
  templateService: TemplateService;
  templateAssetService: TemplateAssetService;
}

export interface TemplateResolverMap {
  Query: {
    searchTemplates: (
      parent: unknown,
      args: { filter: FilterInput }
    ) => ReturnType<TemplateService['search']>;
    searchTemplateVersions: (
      parent: unknown,
      args: { templateId: string; filter: FilterInput }
    ) => ReturnType<TemplateService['searchTemplateVersions']>;
    searchLatestTemplateVersions: (
      parent: unknown,
      args: { filter: FilterInput }
    ) => ReturnType<TemplateService['searchLatestTemplateVersions']>;
    template: (parent: unknown, args: { id: string }) => ReturnType<TemplateService['getTemplate']>;
    templateByName: (
      parent: unknown,
      args: { name: string }
    ) => ReturnType<TemplateService['getTemplateByName']>;
    templateVersion: (
      parent: unknown,
      args: { id: string }
    ) => ReturnType<TemplateService['getTemplateVersion']>;
    templateVersions: (
      parent: unknown,
      args: { templateId: string }
    ) => ReturnType<TemplateService['listTemplateVersions']>;
    templateFiles: (
      parent: unknown,
      args: { templateVersionId: string }
    ) => ReturnType<TemplateService['getTemplateFiles']>;
    templateVersionChanges: (
      parent: unknown,
      args: { templateVersionId: string }
    ) => ReturnType<TemplateService['listTemplateVersionChanges']>;
    isTemplateNameAvailable: (
      parent: unknown,
      args: { name: string }
    ) => ReturnType<TemplateService['isTemplateNameAvailable']>;
    templateFilterOptions: (
      parent: unknown,
      args: { fieldName: string }
    ) => ReturnType<TemplateService['getFilterOptions']>;
    templateFileSignedUrl: (
      parent: unknown,
      args: { templateFileId: string; disposition?: 'INLINE' | 'ATTACHMENT' }
    ) => Promise<string | null>;
  };
  Mutation: {
    createTemplate: (
      parent: unknown,
      args: { input: CreateTemplateInput }
    ) => ReturnType<TemplateService['createTemplate']>;
    updateTemplate: (
      parent: unknown,
      args: { id: string; input: UpdateTemplateInput }
    ) => ReturnType<TemplateService['updateTemplate']>;
    deleteTemplate: (
      parent: unknown,
      args: { id: string }
    ) => ReturnType<TemplateService['deleteTemplate']>;
    createTemplateVersion: (
      parent: unknown,
      args: { templateId: string; input: CreateTemplateVersionInput }
    ) => ReturnType<TemplateService['createTemplateVersion']>;
    updateTemplateVersion: (
      parent: unknown,
      args: { id: string; input: UpdateTemplateVersionInput }
    ) => ReturnType<TemplateService['updateTemplateVersion']>;
    deleteTemplateVersion: (
      parent: unknown,
      args: { id: string }
    ) => ReturnType<TemplateService['deleteTemplateVersion']>;
    setLatestTemplateVersion: (
      parent: unknown,
      args: { id: string }
    ) => ReturnType<TemplateService['setLatestTemplateVersion']>;
    addTemplateFile: (
      parent: unknown,
      args: { templateVersionId: string; accFileId: string }
    ) => ReturnType<TemplateService['addTemplateFile']>;
    removeTemplateFile: (
      parent: unknown,
      args: { id: string }
    ) => ReturnType<TemplateService['removeTemplateFile']>;
  };
  TemplateVersion: {
    changes: (
      parent: ResolverTemplateVersion,
      args: unknown,
      context: GraphqlContext
    ) => Promise<TemplateVersionChange[]>;
    electricalLoadData: (
      parent: ResolverTemplateVersion,
      args: unknown,
      context: GraphqlContext
    ) => Promise<ElectricalLoadLookupData[]>;
    files: (
      parent: ResolverTemplateVersion,
      args: unknown,
      context: GraphqlContext
    ) => Promise<TemplateFile[]>;
  };
}

export const createTemplatesResolvers = ({
  templateService,
  templateAssetService,
}: TemplateResolverDependencies): TemplateResolverMap => {
  return {
    Query: {
      searchTemplates: (_, { filter }) => templateService.search(filter),
      searchTemplateVersions: (_, { templateId, filter }) =>
        templateService.searchTemplateVersions(templateId, filter),
      searchLatestTemplateVersions: (_, { filter }) =>
        templateService.searchLatestTemplateVersions(filter),
      template: (_, { id }) => templateService.getTemplate(id),
      templateByName: (_, { name }) => templateService.getTemplateByName(name),
      templateVersion: (_, { id }) => templateService.getTemplateVersion(id),
      templateVersions: (_, { templateId }) => templateService.listTemplateVersions(templateId),
      templateFiles: (_, { templateVersionId }) =>
        templateService.getTemplateFiles(templateVersionId),
      templateVersionChanges: (_, { templateVersionId }) =>
        templateService.listTemplateVersionChanges(templateVersionId),
      isTemplateNameAvailable: (_, { name }) => templateService.isTemplateNameAvailable(name),
      templateFilterOptions: (_, { fieldName }) => templateService.getFilterOptions(fieldName),
      templateFileSignedUrl: async (_parent, { templateFileId, disposition }) => {
        const file = await templateService.getTemplateFile(templateFileId);
        if (!file) {
          return null;
        }

        // Need to get templateVersion and template to access projectId and folderId
        const templateVersion = await templateService.getTemplateVersion(file.templateVersionId);
        if (!templateVersion) {
          return null;
        }

        const template = await templateService.getTemplate(templateVersion.templateId);
        if (!template) {
          return null;
        }

        const normalizedDisposition = disposition === 'ATTACHMENT' ? 'attachment' : 'inline';

        // Use displayName for the download filename, fallback to a sanitized default
        const filename = file.displayName
          ? `${file.displayName}.pdf`
          : `template-file-${templateFileId}.pdf`;

        const url = await templateAssetService.generateSignedUrl(
          template.accProjectId,
          file.accFileId,
          {
            disposition: normalizedDisposition,
            filename,
          }
        );
        return url ?? null;
      },
    },
    Mutation: {
      createTemplate: (_, { input }) => templateService.createTemplate(input),
      updateTemplate: (_, { id, input }) => templateService.updateTemplate(id, input),
      deleteTemplate: (_, { id }) => templateService.deleteTemplate(id),
      createTemplateVersion: (_, { templateId, input }) =>
        templateService.createTemplateVersion(templateId, input),
      updateTemplateVersion: (_, { id, input }) => templateService.updateTemplateVersion(id, input),
      deleteTemplateVersion: (_, { id }) => templateService.deleteTemplateVersion(id),
      setLatestTemplateVersion: (_, { id }) => templateService.setLatestTemplateVersion(id),
      addTemplateFile: (_, { templateVersionId, accFileId }) =>
        templateService.addTemplateFile(templateVersionId, accFileId),
      removeTemplateFile: (_, { id }) => templateService.removeTemplateFile(id),
    },
    TemplateVersion: {
      changes: async (parent, _args, context) => {
        // If changes were already loaded (e.g., explicitly fetched), return them
        if (parent.changes !== undefined && Array.isArray(parent.changes)) {
          return parent.changes;
        }

        // Otherwise, lazy-load using the per-request batch loader from context
        // The batch loader will automatically batch multiple concurrent requests within this request
        return context.loaders.templateVersionChanges.load(parent.id);
      },
      electricalLoadData: async (parent, _args, context) => {
        // If electricalLoadData was already loaded, return it
        if (parent.electricalLoadData !== undefined && Array.isArray(parent.electricalLoadData)) {
          return parent.electricalLoadData;
        }

        // Otherwise, lazy-load using the per-request batch loader from context
        return context.loaders.electricalLoadData.load(parent.id);
      },
      files: async (parent, _args, context) => {
        // If files were already loaded (e.g., explicitly fetched), return them
        if (parent.files !== undefined && Array.isArray(parent.files)) {
          return parent.files;
        }

        // Otherwise, lazy-load using the per-request batch loader from context
        return context.loaders.templateFiles.load(parent.id);
      },
    },
  };
};
