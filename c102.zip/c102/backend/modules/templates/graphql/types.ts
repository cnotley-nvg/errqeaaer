import type {
  TemplateVersion,
  TemplateFile,
  TemplateVersionChange,
} from '@amzn/global-realty-mosaic-graphql-schema';

/**
 * Electrical load lookup data (without circular reference).
 *
 * Omits the `templateVersion` field to break the circular type reference:
 * ElectricalLoadLookup.templateVersion → TemplateVersion → electricalLoadData → ElectricalLoadLookup
 *
 * This type matches the data returned by `batchLoadElectricalLoadData` in templateService.
 */
export interface ElectricalLoadLookupData {
  templateVersionId: string;
  electricalLoadCategoryId: string;
  connectedLoadKVA: number;
  demandDiversityFactor: number;
  utilityDemandFactor: number;
  electricalLoadCategory: {
    id: string;
    name: string;
    ord: number;
  };
  /**
   * Minimal back-reference to parent template version.
   * Contains only the ID to avoid circular reference.
   */
  templateVersion: {
    id: string;
  };
}

/**
 * TemplateVersion as it appears in GraphQL field resolvers.
 *
 * Field resolvers receive parent objects that may have lazy-loaded fields
 * either pre-populated (eager loading) or absent (lazy loading via batch loader).
 *
 * This type represents the reality of what resolvers receive, with optional
 * fields for data that may or may not have been loaded yet.
 *
 * @example
 * // Scenario 1: Minimal data from mapper (no relations loaded)
 * const parent: ResolverTemplateVersion = {
 *   id: '123',
 *   templateId: 't1',
 *   version: '1.0',
 *   // No files, changes, or electricalLoadData
 * };
 *
 * @example
 * // Scenario 2: With pre-loaded files
 * const parent: ResolverTemplateVersion = {
 *   id: '123',
 *   templateId: 't1',
 *   version: '1.0',
 *   files: [{ id: 'f1', ... }],  // Pre-loaded
 *   // changes and electricalLoadData still absent
 * };
 */
export type ResolverTemplateVersion = Omit<
  TemplateVersion,
  'files' | 'changes' | 'electricalLoadData'
> & {
  /**
   * Template files may be pre-loaded (eager loading) or absent (lazy loading).
   * Field resolver should check presence and use batch loader as fallback.
   */
  files?: TemplateFile[];

  /**
   * Version changes/changelog may be pre-loaded or absent.
   * Field resolver should check presence and use batch loader as fallback.
   */
  changes?: TemplateVersionChange[];

  /**
   * Electrical load lookup data may be pre-loaded or absent.
   * Field resolver should check presence and use batch loader as fallback.
   *
   * Type uses ElectricalLoadLookupData instead of full ElectricalLoadLookup
   * to avoid circular reference (ElectricalLoadLookup.templateVersion → TemplateVersion).
   */
  electricalLoadData?: ElectricalLoadLookupData[];
};
