import type { Logger } from '../../shared';
import { ensureLogger } from '../../shared';
import { prisma } from '../../lib/prisma';
import { createEventsResolvers } from './graphql/resolvers';

export interface EventsModule {
  resolvers: {
    Query: ReturnType<typeof createEventsResolvers>['Query'];
    Mutation: ReturnType<typeof createEventsResolvers>['Mutation'];
  };
}

export interface CreateEventsModuleArgs {
  logger: Logger;
}

export const createEventsModule = ({ logger }: CreateEventsModuleArgs): EventsModule => {
  const moduleLogger = ensureLogger(logger, 'events-module').child({ module: 'events' });

  const resolvers = createEventsResolvers(prisma, moduleLogger.child({ component: 'resolver' }));

  return {
    resolvers,
  };
};

// Re-export for testing
export { EventsService } from './domain/eventsService';
export * from './domain/eventsMappers';
export * from './domain/eventsFilters';
export * from './domain/eventsMutations';
