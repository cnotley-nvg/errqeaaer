import type { PrismaClient } from '@amzn/global-realty-mosaic-prisma-client';
import type { Logger } from '@amzn/global-realty-mosaic-shared-utils';
import { EventsService } from '../domain/eventsService';
import type { SystemEventFilterInput } from '../domain/eventsFilters';
import { mapSystemEventToGraphQL } from '../domain/eventsMappers';
import type { CreateSystemEventInput } from '@amzn/global-realty-mosaic-graphql-schema';
import { createSystemEvent } from '../domain/eventsMutations';

export function createEventsResolvers(prisma: PrismaClient, logger: Logger) {
  const service = new EventsService(prisma, logger);

  return {
    Query: {
      searchSystemEvents: async (
        _parent: unknown,
        args: {
          filter?: SystemEventFilterInput;
        }
      ) => {
        const { items, total } = await service.searchSystemEvents(args);

        return {
          items: items.map(mapSystemEventToGraphQL),
          total,
          pageIdx: args.filter?.pageIdx ?? 0,
          limit: args.filter?.limit ?? 10,
          hasNext: ((args.filter?.pageIdx ?? 0) + 1) * (args.filter?.limit ?? 10) < total,
        };
      },

      systemEvent: async (_parent: unknown, args: { id: string }) => {
        const event = await service.getSystemEvent(args.id);
        return event ? mapSystemEventToGraphQL(event) : null;
      },
    },

    Mutation: {
      createSystemEvent: async (_parent: unknown, args: { input: CreateSystemEventInput }) => {
        try {
          const event = await createSystemEvent(prisma, args.input, logger);
          return {
            success: true,
            message: 'System event created successfully',
            systemEvent: mapSystemEventToGraphQL(event),
          };
        } catch (error) {
          logger.error('Failed to create system event', { error, input: args.input });
          return {
            success: false,
            message: error instanceof Error ? error.message : 'Failed to create system event',
            systemEvent: null,
          };
        }
      },
    },
  };
}
