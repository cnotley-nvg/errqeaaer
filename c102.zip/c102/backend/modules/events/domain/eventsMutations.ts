import type { PrismaClient, SystemEvent } from '@amzn/global-realty-mosaic-prisma-client';
import type { Logger } from '@amzn/global-realty-mosaic-shared-utils';
import type { CreateSystemEventInput } from '@amzn/global-realty-mosaic-graphql-schema';

export async function createSystemEvent(
  prisma: PrismaClient,
  input: CreateSystemEventInput,
  logger: Logger
): Promise<SystemEvent> {
  logger.info('Creating system event', { type: input.type, message: input.message });

  return prisma.systemEvent.create({
    data: {
      type: input.type,
      message: input.message,
      details: input.details || {},
      createdBy: input.createdBy,
    },
  });
}
