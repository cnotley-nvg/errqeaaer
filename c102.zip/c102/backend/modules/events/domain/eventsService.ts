import { PrismaClient, type SystemEvent } from '@amzn/global-realty-mosaic-prisma-client';
import type { Logger } from '@amzn/global-realty-mosaic-shared-utils';
import type { SystemEventFilterInput } from './eventsFilters';

export class EventsService {
  constructor(
    private readonly prisma: PrismaClient,
    private readonly logger: Logger
  ) {}

  async searchSystemEvents(args: {
    filter?: SystemEventFilterInput;
  }): Promise<{ items: SystemEvent[]; total: number }> {
    const { filter } = args;
    const pageIdx = filter?.pageIdx ?? 0;
    const limit = filter?.limit ?? 4;
    const orderBy = filter?.orderBy ?? 'createdAt';
    const orderDesc = filter?.orderDesc ?? true;

    if (filter?.searchTerm) {
      const searchTerm = `%${filter.searchTerm}%`;
      const orderByColumn = orderBy === 'createdAt' ? 'created_at' : orderBy;
      const orderDirection = orderDesc ? 'DESC' : 'ASC';

      const [items, totalResult] = await Promise.all([
        this.prisma.$queryRawUnsafe<SystemEvent[]>(
          `SELECT id, type, message, details, status, created_by as "createdBy", created_at as "createdAt"
           FROM system_events 
           WHERE details::text ILIKE $1
           ORDER BY ${orderByColumn} ${orderDirection}
           LIMIT $2 OFFSET $3`,
          searchTerm,
          limit,
          pageIdx * limit
        ),
        this.prisma.$queryRaw<[{ count: bigint }]>`
          SELECT COUNT(*) as count FROM system_events 
          WHERE details::text ILIKE ${searchTerm}
        `,
      ]);

      return {
        items,
        total: Number(totalResult[0].count),
      };
    }

    const [items, total] = await Promise.all([
      this.prisma.systemEvent.findMany({
        skip: pageIdx * limit,
        take: limit,
        orderBy: { [orderBy]: orderDesc ? 'desc' : 'asc' },
      }),
      this.prisma.systemEvent.count(),
    ]);

    return { items, total };
  }

  async getSystemEvent(id: string): Promise<SystemEvent | null> {
    return this.prisma.systemEvent.findUnique({
      where: { id },
    });
  }
}
