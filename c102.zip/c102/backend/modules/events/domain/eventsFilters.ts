export interface SystemEventFilterInput {
  searchTerm?: string | null;
  limit?: number | null;
  pageIdx?: number | null;
  orderBy?: string | null;
  orderDesc?: boolean | null;
}
