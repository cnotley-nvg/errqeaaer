import type { SystemEvent as PrismaSystemEvent } from '@amzn/global-realty-mosaic-prisma-client';
import type { SystemEvent } from '@amzn/global-realty-mosaic-graphql-schema';

export function mapSystemEventToGraphQL(event: PrismaSystemEvent): SystemEvent {
  let createdAtISO: string;

  if (event.createdAt instanceof Date) {
    createdAtISO = event.createdAt.toISOString();
  } else {
    const date = new Date(event.createdAt);
    if (isNaN(date.getTime())) {
      throw new Error(`Invalid date value: ${event.createdAt}`);
    }
    createdAtISO = date.toISOString();
  }

  return {
    id: event.id,
    type: event.type as SystemEvent['type'],
    message: event.message,
    details: event.details,
    status: event.status as SystemEvent['status'],
    createdBy: event.createdBy,
    createdAt: createdAtISO,
  };
}
