import type { SubmitFeedbackInput } from '@amzn/global-realty-mosaic-graphql-schema';
import type { Logger } from '@amzn/global-realty-mosaic-shared-utils';
import type { AuthenticatedUser } from '../../../lib/auth';
import { submitFeedback } from '../domain/feedbackService';

export interface FeedbackResolverContext {
  readonly user: AuthenticatedUser | null;
  readonly logger: Logger;
}

export const createFeedbackResolvers = (logger: Logger) => ({
  Mutation: {
    submitFeedback: async (
      _: unknown,
      { input }: { input: SubmitFeedbackInput },
      context: FeedbackResolverContext
    ) => {
      return await submitFeedback(input, context.user, logger);
    },
  },
});
