import type {
  SubmitFeedbackInput,
  SubmitFeedbackResponse,
} from '@amzn/global-realty-mosaic-graphql-schema';
import type { Logger } from '@amzn/global-realty-mosaic-shared-utils';
import type { AuthenticatedUser } from '../../../lib/auth';
import { Tickety, CreateTicketRequest, Severity } from '@amzn/tickety-typescript-sdk';
import { fromNodeProviderChain } from '@aws-sdk/credential-providers';
import { CrtSignerV4 } from '@aws-sdk/signature-v4-crt';
import { AwsSigningAlgorithm } from 'aws-crt/dist/native/auth';
import { Sha256 } from '@aws-crypto/sha256-js';

const getTicketyClient = (): Tickety => {
  const credentials = fromNodeProviderChain();
  const endpoint = process.env.TICKETY_ENDPOINT;

  const signer = new CrtSignerV4({
    sha256: Sha256,
    credentials,
    region: '*',
    service: 'tickety',
    signingAlgorithm: AwsSigningAlgorithm.SigV4Asymmetric,
    applyChecksum: true,
  });

  return new Tickety({
    endpoint,
    credentials,
    signer,
    retryMode: 'adaptive',
  });
};

export const submitFeedback = async (
  input: SubmitFeedbackInput,
  user: AuthenticatedUser | null,
  logger: Logger
): Promise<SubmitFeedbackResponse> => {
  if (!user?.username) {
    logger.warn('Feedback submission attempted without authenticated user');
    return {
      success: false,
      message: 'Authentication required to submit feedback.',
    };
  }

  const username = user.username;
  const ticketyBaseUrl = process.env.TICKETY_APP_BASEURL;

  logger.info('Feedback submitted:', {
    feedbackType: input.feedbackType,
    issueType: input.issueType,
    description: input.description,
    requester: username,
    timestamp: new Date().toISOString(),
  });

  try {
    const ticketyClient = getTicketyClient();

    const createTicketRequest: CreateTicketRequest = {
      awsAccountId: 'Default',
      ticketingSystemName: 'Default',
      ticket: {
        title: `User Feedback: ${input.feedbackType}${input.issueType ? ` - ${input.issueType}` : ''}`,
        description: input.description,
        severity: Severity.SEV_5,
        requester: { namespace: 'MIDWAY', value: username },
        assignedGroup: { namespace: 'RESOLVER_GROUP', value: process.env.TICKETY_RESOLVER_GROUP },
      },
    };

    const response = await ticketyClient.createTicket(createTicketRequest);

    logger.info('Tickety ticket created successfully', { ticketId: response.id });

    return {
      success: true,
      message: 'Feedback submitted!',
      ticketUrl: `${ticketyBaseUrl}/${response.id}`,
    };
  } catch (error) {
    logger.error('Failed to create Tickety ticket', {
      error: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined,
      feedbackInput: input,
      requester: username,
    });

    return {
      success: false,
      message: 'Failed to submit feedback. Please try again.',
    };
  }
};
