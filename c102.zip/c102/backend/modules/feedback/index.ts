import type { Logger } from '../../shared';
import { ensureLogger } from '../../shared';
import { createFeedbackResolvers } from './graphql/resolvers';

export interface FeedbackModuleDependencies {
  logger: Logger;
}

export const createFeedbackModule = (dependencies: FeedbackModuleDependencies) => {
  const logger = ensureLogger(dependencies.logger, 'feedback-module');

  logger.info('Initializing feedback module');

  const resolvers = createFeedbackResolvers(logger);

  return {
    resolvers,
  } as const;
};
