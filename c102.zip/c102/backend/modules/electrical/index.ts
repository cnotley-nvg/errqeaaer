import type { Logger } from '../../shared';
import { ensureLogger } from '../../shared';
import { createElectricalResolvers, type ElectricalResolverMap } from './graphql/resolvers';

export interface ElectricalModule {
  resolvers: ElectricalResolverMap;
}

export interface CreateElectricalModuleArgs {
  logger: Logger;
}

export const createElectricalModule = ({
  logger,
}: CreateElectricalModuleArgs): ElectricalModule => {
  const moduleLogger = ensureLogger(logger, 'electrical-module').child({ module: 'electrical' });

  const resolvers = createElectricalResolvers({
    logger: moduleLogger.child({ component: 'resolvers' }),
  });

  return {
    resolvers,
  };
};
