import { calculateElectrical } from '@amzn/global-realty-mosaic-electrical-calculator';
import type {
  ElectricalCalculatorInput,
  ElectricalCalculatorResult,
  ElectricalLoadCategory,
  ElectricalLoadLookup,
  ElectricalLookupRecordOutput,
} from '@amzn/global-realty-mosaic-graphql-schema';

import type { Logger } from '../../../shared';
import { prisma } from '../../../lib/prisma';

interface ElectricalResolverDependencies {
  logger: Logger;
}

// Return type for ElectricalLoadLookup resolver - GraphQL will resolve nested fields
type ElectricalLoadLookupResult = Omit<
  ElectricalLoadLookup,
  'templateVersion' | 'electricalLoadCategory'
> & {
  templateVersion: unknown;
  electricalLoadCategory: unknown;
};

export interface ElectricalResolverMap {
  Query: {
    calculateElectrical: (
      parent: unknown,
      args: { input: ElectricalCalculatorInput }
    ) => Promise<ElectricalCalculatorResult>;
    electricalLoadCategories: () => Promise<ElectricalLoadCategory[]>;
    electricalLoadCategory: (
      parent: unknown,
      args: { id: string }
    ) => Promise<ElectricalLoadCategory | null>;
    electricalLoadLookup: (
      parent: unknown,
      args: { templateVersionId: string; electricalLoadCategoryId: string }
    ) => Promise<ElectricalLoadLookupResult | null>;
    electricalLoadLookupsByTemplateVersion: (
      parent: unknown,
      args: { templateVersionId: string }
    ) => Promise<ElectricalLookupRecordOutput[]>;
  };
}

export const createElectricalResolvers = ({
  logger,
}: ElectricalResolverDependencies): ElectricalResolverMap => {
  return {
    Query: {
      async calculateElectrical(_, { input }) {
        logger.info('Electrical calculation requested', { input });

        try {
          const result = calculateElectrical(input);
          logger.info('Electrical calculation completed successfully', {
            categoryCount: result.categoryLoads.length,
            totalUtilityDemandKVA: result.total.utilityPowerDemand.kVA,
            o1kVA: result.o1.kVA,
            o2kVA: result.o2.kVA,
            o3kVA: result.o3.kVA,
            o4Switchboards: result.o4,
          });

          return result;
        } catch (error) {
          logger.error('Electrical calculation failed', { error, input });
          throw error;
        }
      },

      async electricalLoadCategories() {
        logger.info('Fetching all electrical load categories');

        try {
          const categories = await prisma.electricalLoadCategory.findMany({
            orderBy: { ord: 'asc' },
          });

          logger.info('Electrical load categories fetched successfully', {
            count: categories.length,
          });

          return categories;
        } catch (error) {
          logger.error('Failed to fetch electrical load categories', { error });
          throw error;
        }
      },

      async electricalLoadCategory(_, { id }) {
        logger.info('Fetching electrical load category by id', { id });

        try {
          const category = await prisma.electricalLoadCategory.findUnique({
            where: { id },
          });

          if (!category) {
            logger.warn('Electrical load category not found', { id });
          }

          return category;
        } catch (error) {
          logger.error('Failed to fetch electrical load category', { error, id });
          throw error;
        }
      },

      async electricalLoadLookup(_, { templateVersionId, electricalLoadCategoryId }) {
        logger.info('Fetching electrical load lookup', {
          templateVersionId,
          electricalLoadCategoryId,
        });

        try {
          const lookup = await prisma.electricalLoadLookup.findUnique({
            where: {
              templateVersionId_electricalLoadCategoryId: {
                templateVersionId,
                electricalLoadCategoryId,
              },
            },
            include: {
              templateVersion: true,
              electricalLoadCategory: true,
            },
          });

          if (!lookup) {
            logger.warn('Electrical load lookup not found', {
              templateVersionId,
              electricalLoadCategoryId,
            });
            return null;
          }

          // Convert Decimal fields to numbers for GraphQL
          return {
            templateVersionId: lookup.templateVersionId,
            electricalLoadCategoryId: lookup.electricalLoadCategoryId,
            connectedLoadKVA: lookup.connectedLoadKVA.toNumber(),
            demandDiversityFactor: lookup.demandDiversityFactor.toNumber(),
            utilityDemandFactor: lookup.utilityDemandFactor.toNumber(),
            templateVersion: lookup.templateVersion,
            electricalLoadCategory: lookup.electricalLoadCategory,
          };
        } catch (error) {
          logger.error('Failed to fetch electrical load lookup', {
            error,
            templateVersionId,
            electricalLoadCategoryId,
          });
          throw error;
        }
      },

      async electricalLoadLookupsByTemplateVersion(_, { templateVersionId }) {
        logger.info('Fetching electrical load lookups by template version', {
          templateVersionId,
        });

        try {
          const lookups = await prisma.electricalLoadLookup.findMany({
            where: { templateVersionId },
            include: {
              electricalLoadCategory: true,
            },
            orderBy: {
              electricalLoadCategory: {
                ord: 'asc',
              },
            },
          });

          logger.info('Electrical load lookups fetched successfully', {
            templateVersionId,
            count: lookups.length,
          });

          // Convert to ElectricalLookupRecordOutput format
          return lookups.map((lookup) => ({
            category: lookup.electricalLoadCategory.name,
            connectedLoadKVA: lookup.connectedLoadKVA.toNumber(),
            demandDiversityFactor: lookup.demandDiversityFactor.toNumber(),
            utilityDemandFactor: lookup.utilityDemandFactor.toNumber(),
          }));
        } catch (error) {
          logger.error('Failed to fetch electrical load lookups', {
            error,
            templateVersionId,
          });
          throw error;
        }
      },
    },
  };
};
