import type {
  SchedulerTask as PrismaSchedulerTask,
  SchedulerMetricDaily as PrismaSchedulerMetricDaily,
} from '@amzn/global-realty-mosaic-prisma-client';
import type {
  SchedulerTask,
  SchedulerDailyMetric,
} from '@amzn/global-realty-mosaic-graphql-schema';

/**
 * Map Prisma SchedulerTask to GraphQL SchedulerTask
 */
export function mapTaskToGraphQL(task: PrismaSchedulerTask): SchedulerTask {
  return {
    id: task.id,
    taskType: task.taskType,
    status: task.status,
    priority: task.priority,
    originalInput: task.originalInput,
    input: task.input,
    idempotencyKey: task.idempotencyKey || null,
    scheduleAt: task.scheduleAt.toISOString(),
    leasedBy: task.leasedBy || null,
    leasedUntil: task.leasedUntil?.toISOString() || null,
    leaseDurationMs: task.leaseDurationMs,
    failures: task.failures,
    totalExecutions: task.totalExecutions,
    maxFailures: task.maxFailures,
    lastError: task.lastError,
    startedAt: task.startedAt?.toISOString() || null,
    createdAt: task.createdAt.toISOString(),
    updatedAt: task.updatedAt.toISOString(),
    completedAt: task.completedAt?.toISOString() || null,
  };
}

/**
 * Map Prisma SchedulerMetricDaily to GraphQL SchedulerDailyMetric
 */
export function mapDailyMetricToGraphQL(metric: PrismaSchedulerMetricDaily): SchedulerDailyMetric {
  const successRate =
    metric.totalExecutions > 0 ? (metric.successfulExecutions / metric.totalExecutions) * 100 : 0;

  return {
    date: metric.date.toISOString().split('T')[0],
    taskType: metric.taskType,
    totalExecutions: metric.totalExecutions,
    successfulExecutions: metric.successfulExecutions,
    failedExecutions: metric.failedExecutions,
    successRate,
    avgDurationMs: metric.avgDurationMs ? Number(metric.avgDurationMs) : null,
    p50DurationMs: metric.p50DurationMs ? Number(metric.p50DurationMs) : null,
    p95DurationMs: metric.p95DurationMs ? Number(metric.p95DurationMs) : null,
    p99DurationMs: metric.p99DurationMs ? Number(metric.p99DurationMs) : null,
    createdAt: metric.createdAt.toISOString(),
    updatedAt: metric.updatedAt.toISOString(),
  };
}
