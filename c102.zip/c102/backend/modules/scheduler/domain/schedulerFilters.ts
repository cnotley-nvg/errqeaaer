import type { Prisma } from '@amzn/global-realty-mosaic-prisma-client';

export interface SchedulerTaskFilterInput {
  status?: 'PENDING' | 'LEASED' | 'PROCESSING' | 'SUCCEEDED' | 'FAILED' | 'CANCELLED';
  taskType?: string;
  leasedBy?: string;
  scheduleAtBefore?: string;
  scheduleAtAfter?: string;
}

/**
 * Build Prisma where clause from filter input
 */
export function buildTaskWhereClause(
  filter?: SchedulerTaskFilterInput
): Prisma.SchedulerTaskWhereInput {
  const where: Prisma.SchedulerTaskWhereInput = {};

  if (!filter) return where;

  if (filter.status) {
    where.status = filter.status;
  }

  if (filter.taskType) {
    where.taskType = filter.taskType;
  }

  if (filter.leasedBy) {
    where.leasedBy = filter.leasedBy;
  }

  if (filter.scheduleAtBefore || filter.scheduleAtAfter) {
    where.scheduleAt = {};
    if (filter.scheduleAtBefore) {
      where.scheduleAt.lte = new Date(filter.scheduleAtBefore);
    }
    if (filter.scheduleAtAfter) {
      where.scheduleAt.gte = new Date(filter.scheduleAtAfter);
    }
  }

  return where;
}

/**
 * Build Prisma orderBy clause
 */
export function buildTaskOrderByClause(
  orderBy?: string,
  orderDesc?: boolean
): Prisma.SchedulerTaskOrderByWithRelationInput {
  const direction = orderDesc ? 'desc' : 'asc';

  switch (orderBy) {
    case 'scheduleAt':
      return { scheduleAt: direction };
    case 'priority':
      return { priority: direction };
    case 'createdAt':
      return { createdAt: direction };
    case 'updatedAt':
      return { updatedAt: direction };
    default:
      return { scheduleAt: 'asc' }; // Default: soonest first
  }
}
