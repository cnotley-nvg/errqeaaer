import type { PrismaClient, SchedulerTask } from '@amzn/global-realty-mosaic-prisma-client';
import type { Logger } from '@amzn/global-realty-mosaic-shared-utils';
import { buildTaskWhereClause, buildTaskOrderByClause } from './schedulerFilters';
import type { SchedulerTaskFilterInput } from './schedulerFilters';
import { validateDateRange } from './schedulerValidation';

export interface SchedulerSystemStatus {
  pendingTasks: number;
  processingTasks: number;
  deadLetterTasks: number;
  completedToday: number;
  activeWorkers: number;
  timestamp: string;
}

export interface SchedulerTaskTypeStats {
  taskType: string;
  pendingCount: number;
  processingCount: number;
  completedCount: number;
  deadLetterCount: number;
  avgDurationMs: number | null;
  successRate: number | null;
}

export class SchedulerService {
  constructor(
    private readonly prisma: PrismaClient,
    private readonly logger: Logger
  ) {}

  /**
   * Search and filter tasks with pagination
   */
  async searchTasks(params: {
    filter?: SchedulerTaskFilterInput;
    pageIdx: number;
    limit: number;
    orderBy?: string;
    orderDesc?: boolean;
  }): Promise<{ items: SchedulerTask[]; total: number }> {
    const where = buildTaskWhereClause(params.filter);
    const orderBy = buildTaskOrderByClause(params.orderBy, params.orderDesc);

    const [items, total] = await Promise.all([
      this.prisma.schedulerTask.findMany({
        where,
        orderBy,
        skip: params.pageIdx * params.limit,
        take: params.limit,
      }),
      this.prisma.schedulerTask.count({ where }),
    ]);

    return { items, total };
  }

  /**
   * Get single task by ID
   */
  async getTask(id: string): Promise<SchedulerTask | null> {
    return await this.prisma.schedulerTask.findUnique({
      where: { id },
    });
  }

  /**
   * Get system status (counts by status)
   */
  async getSystemStatus(): Promise<SchedulerSystemStatus> {
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);

    const [pending, processing, failed, succeededToday, activeWorkers] = await Promise.all([
      this.prisma.schedulerTask.count({ where: { status: 'PENDING' } }),
      this.prisma.schedulerTask.count({ where: { status: 'PROCESSING' } }),
      this.prisma.schedulerTask.count({ where: { status: 'FAILED' } }),
      this.prisma.schedulerTask.count({
        where: {
          status: 'SUCCEEDED',
          completedAt: { gte: startOfToday },
        },
      }),
      // Approximate active workers by counting unique leasedBy in the last 5 minutes
      this.prisma.schedulerTask
        .findMany({
          where: {
            leasedBy: { not: null },
            leasedUntil: { gte: new Date(Date.now() - 5 * 60 * 1000) },
          },
          select: { leasedBy: true },
          distinct: ['leasedBy'],
        })
        .then((workers) => workers.length),
    ]);

    return {
      pendingTasks: pending,
      processingTasks: processing,
      deadLetterTasks: failed,
      completedToday: succeededToday,
      activeWorkers,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Get task type statistics
   */
  async getTaskTypeStats(taskType?: string): Promise<SchedulerTaskTypeStats[]> {
    const where = taskType ? { taskType } : {};

    // Get counts by status for each task type
    const tasks = await this.prisma.schedulerTask.groupBy({
      by: ['taskType', 'status'],
      where,
      _count: { id: true },
    });

    // Build stats map
    const statsMap = new Map<string, SchedulerTaskTypeStats>();

    // Initialize with task types from tasks
    for (const task of tasks) {
      if (!statsMap.has(task.taskType)) {
        statsMap.set(task.taskType, {
          taskType: task.taskType,
          pendingCount: 0,
          processingCount: 0,
          completedCount: 0,
          deadLetterCount: 0,
          avgDurationMs: null,
          successRate: null,
        });
      }

      const stats = statsMap.get(task.taskType)!;
      switch (task.status) {
        case 'PENDING':
          stats.pendingCount = task._count.id;
          break;
        case 'PROCESSING':
          stats.processingCount = task._count.id;
          break;
        case 'SUCCEEDED':
          stats.completedCount = task._count.id;
          break;
        case 'FAILED':
        case 'CANCELLED':
          stats.deadLetterCount = task._count.id;
          break;
      }
    }

    // Calculate success rates and avg duration from daily metrics
    for (const [taskTypeKey, stats] of statsMap.entries()) {
      const total = stats.completedCount + stats.deadLetterCount;
      if (total > 0) {
        stats.successRate = (stats.completedCount / total) * 100;
      }

      // Get average duration from daily metrics
      const dailyMetrics = await this.prisma.schedulerMetricDaily.findMany({
        where: { taskType: taskTypeKey },
        orderBy: { date: 'desc' },
        take: 7, // Last 7 days
      });

      if (dailyMetrics.length > 0) {
        const totalAvgDuration = dailyMetrics.reduce((sum, m) => {
          return sum + (m.avgDurationMs ? Number(m.avgDurationMs) : 0);
        }, 0);
        stats.avgDurationMs = totalAvgDuration / dailyMetrics.length;
      }
    }

    return Array.from(statsMap.values());
  }

  /**
   * Get daily metrics for date range
   */
  async getDailyMetrics(params: { taskType?: string; startDate: Date; endDate: Date }) {
    validateDateRange(params.startDate.toISOString(), params.endDate.toISOString());

    const where: { taskType?: string; date: { gte: Date; lte: Date } } = {
      date: {
        gte: params.startDate,
        lte: params.endDate,
      },
    };

    if (params.taskType) {
      where.taskType = params.taskType;
    }

    return await this.prisma.schedulerMetricDaily.findMany({
      where,
      orderBy: { date: 'asc' },
    });
  }
}
