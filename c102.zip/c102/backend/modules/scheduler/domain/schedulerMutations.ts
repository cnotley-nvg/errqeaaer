import type { PrismaClient, Prisma, SchedulerTask } from '@amzn/global-realty-mosaic-prisma-client';
import type { Logger } from '@amzn/global-realty-mosaic-shared-utils';
import { validateTaskType } from './schedulerValidation';

export interface CreateSchedulerTaskInput {
  taskType: string;
  input: unknown;
  idempotencyKey?: string;
  scheduleAt?: string;
  priority?: number;
  maxFailures?: number;
}

export interface UpdateSchedulerTaskInput {
  input?: unknown;
  priority?: number;
  scheduleAt?: string;
  maxFailures?: number;
}

/**
 * Create task with validation and idempotency
 */
export async function createSchedulerTask(
  prisma: PrismaClient,
  input: CreateSchedulerTaskInput,
  logger: Logger
): Promise<SchedulerTask> {
  // 1. Validate task type exists in registry
  if (!validateTaskType(input.taskType)) {
    throw new Error(`Invalid task type: ${input.taskType}`);
  }

  // 2. Check idempotency via SchedulerTask table (idempotency key is unique)
  if (input.idempotencyKey) {
    const existing = await prisma.schedulerTask.findUnique({
      where: { idempotencyKey: input.idempotencyKey },
    });

    if (existing) {
      logger.info('Task already exists (idempotent)', {
        idempotencyKey: input.idempotencyKey,
        taskId: existing.id,
      });

      return existing;
    }
  }

  // 3. Create task with idempotency key (if provided)
  const scheduleAt = input.scheduleAt ? new Date(input.scheduleAt) : new Date();

  const task = await prisma.schedulerTask.create({
    data: {
      taskType: input.taskType,
      input: input.input as Prisma.InputJsonValue,
      originalInput: input.input as Prisma.InputJsonValue,
      scheduleAt,
      priority: input.priority ?? 0,
      maxFailures: input.maxFailures ?? 3,
      idempotencyKey: input.idempotencyKey || null,
    },
  });

  logger.info('Task created', { taskId: task.id, taskType: input.taskType });

  return task;
}

/**
 * Update task (only if PENDING)
 */
export async function updateSchedulerTask(
  prisma: PrismaClient,
  id: string,
  input: UpdateSchedulerTaskInput,
  logger: Logger
): Promise<SchedulerTask> {
  // 1. Get task and validate status
  const existing = await prisma.schedulerTask.findUnique({
    where: { id },
  });

  if (!existing) {
    throw new Error(`Task not found: ${id}`);
  }

  if (existing.status !== 'PENDING') {
    throw new Error(`Cannot update task in ${existing.status} status`);
  }

  // 2. Build update data
  const data: Prisma.SchedulerTaskUpdateInput = {};

  if (input.input !== undefined) data.input = input.input as Prisma.InputJsonValue;
  if (input.priority !== undefined) data.priority = input.priority;
  if (input.scheduleAt !== undefined) data.scheduleAt = new Date(input.scheduleAt);
  if (input.maxFailures !== undefined) data.maxFailures = input.maxFailures;

  // 3. Update task
  const task = await prisma.schedulerTask.update({
    where: { id },
    data,
  });

  logger.info('Task updated', { taskId: id });

  return task;
}

/**
 * Cancel task (move to CANCELLED with cancellation reason)
 */
export async function cancelSchedulerTask(
  prisma: PrismaClient,
  id: string,
  logger: Logger
): Promise<SchedulerTask> {
  const existing = await prisma.schedulerTask.findUnique({
    where: { id },
  });

  if (!existing) {
    throw new Error(`Task not found: ${id}`);
  }

  if (existing.status !== 'PENDING' && existing.status !== 'PROCESSING') {
    throw new Error(`Cannot cancel task in ${existing.status} status`);
  }

  const task = await prisma.schedulerTask.update({
    where: { id },
    data: {
      status: 'CANCELLED',
      lastError: {
        reason: 'CANCELLED_BY_USER',
        timestamp: new Date().toISOString(),
      } as Prisma.InputJsonValue,
    },
  });

  logger.info('Task cancelled', { taskId: id });

  return task;
}

/**
 * Retry failed task (reset to PENDING)
 */
export async function retrySchedulerTask(
  prisma: PrismaClient,
  id: string,
  logger: Logger
): Promise<SchedulerTask> {
  const existing = await prisma.schedulerTask.findUnique({
    where: { id },
  });

  if (!existing) {
    throw new Error(`Task not found: ${id}`);
  }

  if (existing.status !== 'FAILED') {
    throw new Error(`Can only retry tasks in FAILED status`);
  }

  const task = await prisma.schedulerTask.update({
    where: { id },
    data: {
      status: 'PENDING',
      failures: 0,
      leasedBy: null,
      leasedUntil: null,
      scheduleAt: new Date(), // Reschedule for immediate execution
    },
  });

  logger.info('Task retried', { taskId: id });

  return task;
}

/**
 * Delete task (only if SUCCEEDED, FAILED, or CANCELLED)
 */
export async function deleteSchedulerTask(
  prisma: PrismaClient,
  id: string,
  logger: Logger
): Promise<void> {
  const existing = await prisma.schedulerTask.findUnique({
    where: { id },
  });

  if (!existing) {
    throw new Error(`Task not found: ${id}`);
  }

  if (
    existing.status !== 'SUCCEEDED' &&
    existing.status !== 'FAILED' &&
    existing.status !== 'CANCELLED'
  ) {
    throw new Error(`Can only delete tasks in SUCCEEDED, FAILED, or CANCELLED status`);
  }

  await prisma.schedulerTask.delete({
    where: { id },
  });

  logger.info('Task deleted', { taskId: id });
}
