/**
 * Validate cron expression (basic validation)
 */
export function validateCronExpression(cron: string): boolean {
  // Basic validation: 5 or 6 fields separated by spaces
  const parts = cron.trim().split(/\s+/);
  return parts.length === 5 || parts.length === 6;
}

/**
 * Validate task type
 */
export function validateTaskType(taskType: string): boolean {
  const validTypes = [
    'SYNC_EXTERNAL_DATA',
    'AGGREGATE_METRICS',
    'CLEANUP_OLD_RECORDS',
    'CLEANUP_METRICS',
  ];
  return validTypes.includes(taskType);
}

/**
 * Validate date range
 */
export function validateDateRange(startDate: string, endDate: string): void {
  const start = new Date(startDate);
  const end = new Date(endDate);

  if (isNaN(start.getTime())) {
    throw new Error('Invalid start date');
  }

  if (isNaN(end.getTime())) {
    throw new Error('Invalid end date');
  }

  if (start > end) {
    throw new Error('Start date must be before end date');
  }

  // Max range: 90 days
  const maxRange = 90 * 24 * 60 * 60 * 1000;
  if (end.getTime() - start.getTime() > maxRange) {
    throw new Error('Date range cannot exceed 90 days');
  }
}
