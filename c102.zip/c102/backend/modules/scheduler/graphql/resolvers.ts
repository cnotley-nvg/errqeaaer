import type { PrismaClient } from '@amzn/global-realty-mosaic-prisma-client';
import type { Logger } from '@amzn/global-realty-mosaic-shared-utils';
import { SchedulerService } from '../domain/schedulerService';
import type { SchedulerTaskFilterInput } from '../domain/schedulerFilters';
import { mapTaskToGraphQL, mapDailyMetricToGraphQL } from '../domain/schedulerMappers';
import type {
  CreateSchedulerTaskInput,
  UpdateSchedulerTaskInput,
} from '../domain/schedulerMutations';
import {
  createSchedulerTask,
  updateSchedulerTask,
  cancelSchedulerTask,
  retrySchedulerTask,
  deleteSchedulerTask,
} from '../domain/schedulerMutations';

export function createSchedulerResolvers(prisma: PrismaClient, logger: Logger) {
  const service = new SchedulerService(prisma, logger);

  return {
    Query: {
      /**
       * Search and filter tasks
       */
      searchSchedulerTasks: async (
        _parent: unknown,
        args: {
          filter?: SchedulerTaskFilterInput;
          pageIdx: number;
          limit: number;
          orderBy?: string;
          orderDesc?: boolean;
        }
      ) => {
        const { items, total } = await service.searchTasks(args);

        return {
          items: items.map(mapTaskToGraphQL),
          total,
          pageIdx: args.pageIdx,
          limit: args.limit,
          hasNext: (args.pageIdx + 1) * args.limit < total,
        };
      },

      /**
       * Get single task
       */
      schedulerTask: async (_parent: unknown, args: { id: string }) => {
        const task = await service.getTask(args.id);
        return task ? mapTaskToGraphQL(task) : null;
      },

      /**
       * Get system status
       */
      schedulerSystemStatus: async () => {
        return await service.getSystemStatus();
      },

      /**
       * Get task type statistics
       */
      schedulerTaskTypeStats: async (_parent: unknown, args: { taskType?: string }) => {
        return await service.getTaskTypeStats(args.taskType);
      },

      /**
       * Get daily metrics
       */
      schedulerDailyMetrics: async (
        _parent: unknown,
        args: {
          taskType?: string;
          startDate: string;
          endDate: string;
        }
      ) => {
        const metrics = await service.getDailyMetrics({
          taskType: args.taskType,
          startDate: new Date(args.startDate),
          endDate: new Date(args.endDate),
        });

        return metrics.map(mapDailyMetricToGraphQL);
      },
    },

    Mutation: {
      /**
       * Create task
       */
      createSchedulerTask: async (_parent: unknown, args: { input: CreateSchedulerTaskInput }) => {
        try {
          const task = await createSchedulerTask(prisma, args.input, logger);
          return {
            success: true,
            message: 'Task created successfully',
            task: mapTaskToGraphQL(task),
          };
        } catch (error) {
          logger.error('Failed to create task', { error, input: args.input });
          return {
            success: false,
            message: error instanceof Error ? error.message : 'Failed to create task',
            task: null,
          };
        }
      },

      /**
       * Update task
       */
      updateSchedulerTask: async (
        _parent: unknown,
        args: { id: string; input: UpdateSchedulerTaskInput }
      ) => {
        try {
          const task = await updateSchedulerTask(prisma, args.id, args.input, logger);
          return {
            success: true,
            message: 'Task updated successfully',
            task: mapTaskToGraphQL(task),
          };
        } catch (error) {
          logger.error('Failed to update task', { error, id: args.id });
          return {
            success: false,
            message: error instanceof Error ? error.message : 'Failed to update task',
            task: null,
          };
        }
      },

      /**
       * Cancel task
       */
      cancelSchedulerTask: async (_parent: unknown, args: { id: string }) => {
        try {
          const task = await cancelSchedulerTask(prisma, args.id, logger);
          return {
            success: true,
            message: 'Task cancelled successfully',
            task: mapTaskToGraphQL(task),
          };
        } catch (error) {
          logger.error('Failed to cancel task', { error, id: args.id });
          return {
            success: false,
            message: error instanceof Error ? error.message : 'Failed to cancel task',
            task: null,
          };
        }
      },

      /**
       * Retry task
       */
      retrySchedulerTask: async (_parent: unknown, args: { id: string }) => {
        try {
          const task = await retrySchedulerTask(prisma, args.id, logger);
          return {
            success: true,
            message: 'Task will be retried',
            task: mapTaskToGraphQL(task),
          };
        } catch (error) {
          logger.error('Failed to retry task', { error, id: args.id });
          return {
            success: false,
            message: error instanceof Error ? error.message : 'Failed to retry task',
            task: null,
          };
        }
      },

      /**
       * Delete task
       */
      deleteSchedulerTask: async (_parent: unknown, args: { id: string }) => {
        try {
          await deleteSchedulerTask(prisma, args.id, logger);
          return {
            success: true,
            message: 'Task deleted successfully',
            task: null,
          };
        } catch (error) {
          logger.error('Failed to delete task', { error, id: args.id });
          return {
            success: false,
            message: error instanceof Error ? error.message : 'Failed to delete task',
            task: null,
          };
        }
      },
    },
  };
}
