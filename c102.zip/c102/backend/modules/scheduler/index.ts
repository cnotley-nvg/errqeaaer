import type { Logger } from '../../shared';
import { ensureLogger } from '../../shared';
import { prisma } from '../../lib/prisma';
import { createSchedulerResolvers } from './graphql/resolvers';

export interface SchedulerModule {
  resolvers: {
    Query: ReturnType<typeof createSchedulerResolvers>['Query'];
    Mutation: ReturnType<typeof createSchedulerResolvers>['Mutation'];
  };
}

export interface CreateSchedulerModuleArgs {
  logger: Logger;
}

export const createSchedulerModule = ({ logger }: CreateSchedulerModuleArgs): SchedulerModule => {
  const moduleLogger = ensureLogger(logger, 'scheduler-module').child({ module: 'scheduler' });

  const resolvers = createSchedulerResolvers(prisma, moduleLogger.child({ component: 'resolver' }));

  return {
    resolvers,
  };
};

// Re-export for testing
export { SchedulerService } from './domain/schedulerService';
export * from './domain/schedulerMappers';
export * from './domain/schedulerFilters';
export * from './domain/schedulerMutations';
export * from './domain/schedulerValidation';
