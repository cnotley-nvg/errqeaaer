import type { FilterInput } from '@amzn/global-realty-mosaic-graphql-schema';

export const sortEntities = <
  T extends {
    name?: string | null;
    desc?: string | null;
    description?: string | null;
    accProjectId?: string | null;
    createdAt: string;
    updatedAt: string;
    latestVersion?: { attributes?: Record<string, unknown> | null } | null;
  },
>(
  entities: T[],
  filter: FilterInput
): T[] => {
  const direction = filter.orderDesc ? -1 : 1;

  const extractAttributeValue = (entity: T, key: string): unknown => {
    const attributes = entity.latestVersion?.attributes ?? null;
    if (!attributes || typeof attributes !== 'object') {
      return null;
    }

    const raw = (attributes as Record<string, unknown>)[key];
    if (raw === undefined || raw === null) {
      return null;
    }

    if (Array.isArray(raw)) {
      return raw[0] ?? null;
    }

    if (typeof raw === 'object' && raw !== null && 'value' in (raw as Record<string, unknown>)) {
      const valueCandidate = (raw as { value?: unknown }).value;
      return valueCandidate ?? null;
    }

    return raw;
  };

  const coerceForCompare = (value: unknown): { numeric: number | null; text: string } => {
    if (value === null || value === undefined) {
      return { numeric: null, text: '' };
    }

    if (typeof value === 'number') {
      return { numeric: value, text: value.toString() };
    }

    if (typeof value === 'string') {
      const numericCandidate = Number.parseFloat(value.replace(/[^0-9.+-]/g, ''));
      return {
        numeric: Number.isFinite(numericCandidate) ? numericCandidate : null,
        text: value.toLowerCase(),
      };
    }

    const serialized = JSON.stringify(value);
    const numericCandidate = Number.parseFloat(serialized.replace(/[^0-9.+-]/g, ''));
    return {
      numeric: Number.isFinite(numericCandidate) ? numericCandidate : null,
      text: serialized.toLowerCase(),
    };
  };

  const getSortableValue = (entity: T): { numeric: number | null; text: string } => {
    switch (filter.orderBy) {
      case 'name': {
        return coerceForCompare(entity.name ?? '');
      }
      case 'desc':
      case 'description': {
        return coerceForCompare(entity.description ?? entity.desc ?? '');
      }
      case 'accProjectId': {
        return coerceForCompare((entity as { accProjectId?: string | null }).accProjectId ?? '');
      }
      case 'updatedAt': {
        return coerceForCompare(entity.updatedAt);
      }
      case 'createdAt': {
        return coerceForCompare(entity.createdAt);
      }

      case 'region':
        return coerceForCompare(extractAttributeValue(entity, 'region'));
      case 'program':
        return coerceForCompare(extractAttributeValue(entity, 'program'));
      case 'throughput':
        return coerceForCompare(extractAttributeValue(entity, 'throughput'));
      case 'stories':
        return coerceForCompare(extractAttributeValue(entity, 'stories'));
      case 'facilityType':
        return coerceForCompare(extractAttributeValue(entity, 'facilityType'));
      default: {
        return coerceForCompare(entity.createdAt);
      }
    }
  };

  return entities.slice().sort((a, b) => {
    const aValue = getSortableValue(a);
    const bValue = getSortableValue(b);

    if (aValue.numeric !== null && bValue.numeric !== null) {
      if (aValue.numeric < bValue.numeric) {
        return -1 * direction;
      }
      if (aValue.numeric > bValue.numeric) {
        return 1 * direction;
      }
      return 0;
    }

    if (aValue.text < bValue.text) {
      return -1 * direction;
    }
    if (aValue.text > bValue.text) {
      return 1 * direction;
    }
    return 0;
  });
};
