/**
 * Helper functions for extracting and normalizing attribute values from JSONB data.
 * Handles both single values and arrays consistently.
 */

/**
 * Extracts all non-empty string values from an attribute that can be single or array.
 * Returns empty array for null/undefined.
 *
 * @param raw - The raw attribute value (can be string, array, null, or undefined)
 * @returns Array of non-empty string values
 *
 * @example
 * extractAttributeValues('GCF') → ['GCF']
 * extractAttributeValues(['GCF', 'ATS', 'AMXL']) → ['GCF', 'ATS', 'AMXL']
 * extractAttributeValues([null, '', 'GCF']) → ['GCF']
 * extractAttributeValues(null) → []
 *
 * @example Single value extraction
 * extractAttributeValues('NA')[0] ?? null → 'NA'
 * extractAttributeValues(['NA', 'EU'])[0] ?? null → 'NA'
 * extractAttributeValues(null)[0] ?? null → null
 */
export const extractAttributeValues = (raw: unknown): string[] => {
  if (raw === null || raw === undefined) {
    return [];
  }

  const values = Array.isArray(raw) ? raw : [raw];
  const result: string[] = [];

  for (const value of values) {
    if (value === null || value === undefined) {
      continue;
    }
    if (typeof value === 'object') {
      continue;
    }
    const token = String(value).trim();
    if (token.length > 0) {
      result.push(token);
    }
  }

  return result;
};
