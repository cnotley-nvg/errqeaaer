import type {
  AttributeMap,
  AttributeValue as GraphAttributeValue,
  NumericAttributeValue as GraphNumericAttributeValue,
} from '@amzn/global-realty-mosaic-graphql-schema';
import type { Prisma, PrismaClient } from '@amzn/global-realty-mosaic-prisma-client';
import { AttributeDatatype } from '@amzn/global-realty-mosaic-prisma-client';

export type AttributeRecord = AttributeMap | null | undefined;

type PrismaExecutor = PrismaClient | Prisma.TransactionClient;

type NumericAttributeInput = GraphNumericAttributeValue;

type AttributeScalarInput = string | number | boolean | NumericAttributeInput;
type AttributeInputValue = AttributeScalarInput | AttributeScalarInput[];

type AttributeEntityValue = 'KIT_VERSION' | 'STANDARD_VERSION' | 'TEMPLATE_VERSION';

export type AttributeDefinitionConfig = {
  datatype?: AttributeDatatype;
  isMulti?: boolean;
  unitDimensionId?: string | null;
  description?: string | null;
};

export type AttributeDefinitionConfigMap = Record<string, AttributeDefinitionConfig | undefined>;

type NormalizedNumericValue = {
  value: number;
  unitId: string | null;
  unitCode: string | null;
  unitDimensionId: string | null;
  valueSi: number;
};

const isNumericAttributeInput = (value: unknown): value is NumericAttributeInput => {
  return (
    value !== null &&
    typeof value === 'object' &&
    Object.prototype.hasOwnProperty.call(value, 'value') &&
    typeof (value as { value: unknown }).value === 'number'
  );
};

const toScalarValues = (input: AttributeInputValue): AttributeScalarInput[] => {
  const values = Array.isArray(input) ? input : [input];
  return values.filter(
    (value): value is AttributeScalarInput => value !== null && value !== undefined
  );
};

const determineDatatype = (raw: AttributeInputValue): AttributeDatatype => {
  const [candidate] = toScalarValues(raw);
  if (candidate === undefined) {
    return AttributeDatatype.TEXT;
  }

  if (isNumericAttributeInput(candidate)) {
    return AttributeDatatype.NUM;
  }

  if (typeof candidate === 'boolean') {
    return AttributeDatatype.BOOL;
  }

  if (typeof candidate === 'number') {
    return Number.isInteger(candidate) ? AttributeDatatype.INT : AttributeDatatype.NUM;
  }

  return AttributeDatatype.TEXT;
};

const ensureAttributeDefinition = async (
  client: PrismaExecutor,
  name: string,
  rawValue: AttributeInputValue,
  overrides: AttributeDefinitionConfig = {}
): Promise<{
  id: string;
  datatype: AttributeDatatype;
  isMulti: boolean;
  unitDimensionId: string | null;
}> => {
  const sanitizedValues = toScalarValues(rawValue);

  if (sanitizedValues.length > 1 && overrides.isMulti === false) {
    throw new Error(
      `Attribute '${name}' received multiple values but is configured as single-value.`
    );
  }

  const existing = await client.attributeDefinition.findUnique({ where: { name } });
  const inferredDatatype = overrides.datatype ?? determineDatatype(rawValue);
  const inferredIsMulti =
    overrides.isMulti ?? (sanitizedValues.length > 1 || Array.isArray(rawValue));

  if (existing) {
    if (overrides.datatype && existing.datatype !== overrides.datatype) {
      throw new Error(
        `Attribute '${name}' already exists with datatype '${existing.datatype}' and cannot be updated to '${overrides.datatype}'.`
      );
    }

    // Allow INT values when NUM is expected (INT is subset of NUM)
    // Allow NUM/INT values when DEC is expected (plain numbers map to DEC)
    const isCompatible =
      existing.datatype === inferredDatatype ||
      (existing.datatype === AttributeDatatype.NUM && inferredDatatype === AttributeDatatype.INT) ||
      (existing.datatype === AttributeDatatype.DEC &&
        (inferredDatatype === AttributeDatatype.NUM || inferredDatatype === AttributeDatatype.INT));

    if (!isCompatible) {
      throw new Error(
        `Attribute '${name}' expects datatype '${existing.datatype}' but received '${inferredDatatype}'.`
      );
    }

    if (!existing.isMulti && sanitizedValues.length > 1) {
      throw new Error(`Attribute '${name}' does not accept multiple values.`);
    }

    if (overrides.isMulti !== undefined && overrides.isMulti !== existing.isMulti) {
      throw new Error(`Attribute '${name}' already exists with isMulti='${existing.isMulti}'.`);
    }

    if (overrides.unitDimensionId !== undefined) {
      const expected = existing.unitDimensionId ?? null;
      if (expected !== overrides.unitDimensionId) {
        throw new Error(
          `Attribute '${name}' is bound to unit dimension '${expected}' and cannot be updated to '${overrides.unitDimensionId}'.`
        );
      }
    }

    return {
      id: existing.id,
      datatype: existing.datatype,
      isMulti: existing.isMulti,
      unitDimensionId: existing.unitDimensionId ?? null,
    };
  }

  const created = await client.attributeDefinition.create({
    data: {
      name,
      description: overrides.description ?? null,
      datatype: inferredDatatype,
      isRequired: false,
      isMulti: inferredIsMulti,
      unitDimensionId: overrides.unitDimensionId ?? null,
    },
  });

  return {
    id: created.id,
    datatype: created.datatype,
    isMulti: created.isMulti,
    unitDimensionId: created.unitDimensionId ?? null,
  };
};

const resolveUnit = async (
  client: PrismaExecutor,
  unitCode: string | null | undefined
): Promise<{
  id: string;
  code: string;
  unitDimensionId: string;
  factorToSi: number;
  offsetToSi: number;
} | null> => {
  if (!unitCode) {
    return null;
  }

  const unit = await client.unit.findFirst({
    where: {
      code: {
        equals: unitCode,
        mode: 'insensitive',
      },
    },
  });
  if (!unit) {
    throw new Error(`Unit '${unitCode}' was not found.`);
  }

  return {
    id: unit.id,
    code: unit.code,
    unitDimensionId: unit.unitDimensionId,
    factorToSi: Number(unit.factorToSi),
    offsetToSi: Number(unit.offsetToSi),
  };
};

const normalizeNumericValue = async (
  client: PrismaExecutor,
  raw: NumericAttributeInput
): Promise<NormalizedNumericValue> => {
  const resolvedUnit = await resolveUnit(client, raw.unit ?? null);
  const baseValue = raw.value;
  const valueSi = resolvedUnit
    ? baseValue * resolvedUnit.factorToSi + resolvedUnit.offsetToSi
    : baseValue;
  return {
    value: baseValue,
    unitId: resolvedUnit?.id ?? null,
    unitCode: resolvedUnit?.code ?? null,
    unitDimensionId: resolvedUnit?.unitDimensionId ?? null,
    valueSi,
  };
};

const deleteExistingValues = async (client: PrismaExecutor, entityId: string): Promise<void> => {
  await Promise.all([
    client.attributeTextValue.deleteMany({ where: { entityId } }),
    client.attributeIntValue.deleteMany({ where: { entityId } }),
    client.attributeNumericValue.deleteMany({ where: { entityId } }),
    client.attributeDecimalValue.deleteMany({ where: { entityId } }),
    client.attributeBoolValue.deleteMany({ where: { entityId } }),
  ]);
};

export const storeAttributes = async (
  client: PrismaExecutor,
  entityType: AttributeEntityValue,
  entityId: string,
  attributes: AttributeRecord,
  definitionOverrides: AttributeDefinitionConfigMap = {}
): Promise<void> => {
  await deleteExistingValues(client, entityId);

  if (!attributes) {
    return;
  }

  const entries = Object.entries(attributes).filter(
    ([, value]) => value !== undefined && value !== null
  );
  if (!entries.length) {
    return;
  }

  for (const [name, rawValue] of entries) {
    const values = toScalarValues(rawValue as AttributeInputValue);

    if (!values.length) {
      continue;
    }

    const definition = await ensureAttributeDefinition(
      client,
      name,
      rawValue as AttributeInputValue,
      definitionOverrides[name]
    );

    if (!definition.isMulti && values.length > 1) {
      throw new Error(`Attribute '${name}' does not accept multiple values.`);
    }

    switch (definition.datatype) {
      case AttributeDatatype.TEXT: {
        for (const [index, value] of values.entries()) {
          if (typeof value !== 'string') {
            throw new Error(`Attribute '${name}' expects text values.`);
          }

          const ord = index + 1;
          await client.attributeTextValue.create({
            data: {
              entityType,
              entityId,
              attrDefId: definition.id,
              ord,
              value,
            },
          });
        }
        break;
      }
      case AttributeDatatype.INT: {
        for (const [index, value] of values.entries()) {
          if (typeof value !== 'number' || !Number.isInteger(value)) {
            throw new Error(`Attribute '${name}' expects integer values.`);
          }

          const ord = index + 1;
          await client.attributeIntValue.create({
            data: {
              entityType,
              entityId,
              attrDefId: definition.id,
              ord,
              value: BigInt(value),
            },
          });
        }
        break;
      }
      case AttributeDatatype.BOOL: {
        if (definition.isMulti && values.length > 1) {
          throw new Error(`Attribute '${name}' does not support multiple boolean values.`);
        }

        const [booleanValue] = values;
        if (typeof booleanValue !== 'boolean') {
          throw new Error(`Attribute '${name}' expects boolean values.`);
        }

        await client.attributeBoolValue.create({
          data: {
            entityType,
            entityId,
            attrDefId: definition.id,
            ord: 0,
            value: booleanValue,
          },
        });
        break;
      }
      case AttributeDatatype.NUM: {
        for (const [index, value] of values.entries()) {
          const numeric =
            typeof value === 'number'
              ? { value, unit: null }
              : isNumericAttributeInput(value)
                ? value
                : null;

          if (!numeric) {
            throw new Error(
              `Attribute '${name}' expects numeric objects { value, unit }. Received ${JSON.stringify(value)}.`
            );
          }

          const normalized = await normalizeNumericValue(client, numeric);
          if (definition.unitDimensionId) {
            if (!normalized.unitId) {
              throw new Error(
                `Attribute '${name}' requires a unit within dimension '${definition.unitDimensionId}'.`
              );
            }

            if (normalized.unitDimensionId !== definition.unitDimensionId) {
              throw new Error(
                `Attribute '${name}' requires unit dimension '${definition.unitDimensionId}' but received '${normalized.unitDimensionId}'.`
              );
            }
          } else if (!normalized.unitId) {
            throw new Error(`Attribute '${name}' requires a unit.`);
          }

          const ord = index + 1;
          await client.attributeNumericValue.create({
            data: {
              entityType,
              entityId,
              attrDefId: definition.id,
              ord,
              value: normalized.value,
              valueSi: normalized.valueSi,
              unitId: normalized.unitId,
            },
          });
        }
        break;
      }
      case AttributeDatatype.DEC: {
        for (const [index, value] of values.entries()) {
          if (typeof value !== 'number') {
            throw new Error(`Attribute '${name}' expects decimal values.`);
          }

          const ord = index + 1;
          await client.attributeDecimalValue.create({
            data: {
              entityType,
              entityId,
              attrDefId: definition.id,
              ord,
              value: value,
            },
          });
        }
        break;
      }
      default: {
        throw new Error(`Unsupported attribute datatype '${definition.datatype}'.`);
      }
    }
  }
};

export type AttributeValueMap = AttributeMap;

const appendValue = (
  target: AttributeValueMap,
  key: string,
  value: GraphAttributeValue,
  isMulti: boolean
) => {
  if (isMulti) {
    if (!Array.isArray(target[key])) {
      target[key] = [];
    }
    (target[key] as GraphAttributeValue[]).push(value);
    return;
  }

  target[key] = value;
};

export const loadAttributes = async (
  client: PrismaExecutor,
  entityId: string
): Promise<AttributeValueMap> => {
  const [textValues, intValues, boolValues, numericValues, decimalValues] = await Promise.all([
    client.attributeTextValue.findMany({
      where: { entityId },
      include: { attrDef: true },
      orderBy: [{ attrDefId: 'asc' }, { ord: 'asc' }],
    }),
    client.attributeIntValue.findMany({
      where: { entityId },
      include: { attrDef: true },
      orderBy: [{ attrDefId: 'asc' }, { ord: 'asc' }],
    }),
    client.attributeBoolValue.findMany({
      where: { entityId },
      include: { attrDef: true },
      orderBy: [{ attrDefId: 'asc' }, { ord: 'asc' }],
    }),
    client.attributeNumericValue.findMany({
      where: { entityId },
      include: { attrDef: true, unit: true },
      orderBy: [{ attrDefId: 'asc' }, { ord: 'asc' }],
    }),
    client.attributeDecimalValue.findMany({
      where: { entityId },
      include: { attrDef: true },
      orderBy: [{ attrDefId: 'asc' }, { ord: 'asc' }],
    }),
  ]);

  const attributes: AttributeValueMap = {};

  for (const row of textValues) {
    appendValue(attributes, row.attrDef.name, row.value, row.attrDef.isMulti);
  }

  for (const row of intValues) {
    appendValue(attributes, row.attrDef.name, Number(row.value), row.attrDef.isMulti);
  }

  for (const row of boolValues) {
    appendValue(attributes, row.attrDef.name, row.value, row.attrDef.isMulti);
  }

  for (const row of numericValues) {
    const value = {
      value: Number(row.value),
      ...(row.unit ? { unit: row.unit.code } : {}),
    };

    appendValue(attributes, row.attrDef.name, value, row.attrDef.isMulti);
  }

  for (const row of decimalValues) {
    appendValue(attributes, row.attrDef.name, Number(row.value), row.attrDef.isMulti);
  }

  return attributes;
};
