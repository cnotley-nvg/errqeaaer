import type { PrismaClient } from '@amzn/global-realty-mosaic-prisma-client';

/**
 * Configuration for filter options query.
 */
export interface FilterOptionsConfig {
  /**
   * Entity type for EAV attribute queries.
   * Must match EntityType enum in Prisma schema.
   */
  entityType: 'TEMPLATE_VERSION' | 'STANDARD_VERSION';

  /**
   * Version table name (e.g., 'templateVersion', 'standardVersion')
   */
  versionTable: 'templateVersion' | 'standardVersion';

  /**
   * Parent table name (e.g., 'template', 'standard')
   */
  parentTable: 'template' | 'standard';

  /**
   * Parent ID field name in version table (e.g., 'templateId', 'standardId')
   */
  parentIdField: 'templateId' | 'standardId';

  /**
   * Direct fields that exist on the version table itself.
   * Example: ['version']
   */
  directFields: string[];

  /**
   * Parent fields that exist on the parent table (via relation).
   * Example: ['name', 'accProjectId']
   */
  parentFields: string[];

  /**
   * ACC metadata fields that exist on the version table.
   * Example: ['accCreatedBy', 'accUpdatedBy']
   */
  accMetadataFields?: string[];

  /**
   * Attribute fields stored in EAV tables.
   * Example: ['program', 'region', 'facilityType']
   */
  attributeFields: string[];
}

/**
 * Shared utility to fetch distinct filter values for a field from latest versions.
 *
 * Supports four types of fields:
 * 1. Direct fields: columns on version table (e.g., version)
 * 2. Parent fields: columns on parent table via relation (e.g., name, accProjectId)
 * 3. ACC metadata fields: columns on version table for ACC data (e.g., accCreatedBy, accUpdatedBy)
 * 4. Attribute fields: EAV attributes stored in attribute value tables (e.g., program, region)
 *
 * Returns sorted array of unique non-null values from latest versions only.
 * Throws error if fieldName is invalid for the given configuration.
 *
 * @param prisma - Prisma client instance
 * @param fieldName - Name of field to get options for
 * @param config - Configuration specifying entity type and valid fields
 * @returns Sorted array of distinct non-null string values
 *
 * @example
 * ```typescript
 * const options = await getFilterOptions(prisma, 'program', {
 *   entityType: 'TEMPLATE_VERSION',
 *   versionTable: 'templateVersion',
 *   parentTable: 'template',
 *   parentIdField: 'templateId',
 *   directFields: ['version'],
 *   parentFields: ['name', 'accProjectId'],
 *   attributeFields: ['program', 'region', 'facilityType'],
 * });
 * // => ['ARS', 'IXD', 'Prime', ...]
 * ```
 */
export async function getFilterOptions(
  prisma: PrismaClient,
  fieldName: string,
  config: FilterOptionsConfig
): Promise<string[]> {
  const {
    entityType,
    versionTable,
    parentTable,
    parentIdField,
    directFields,
    parentFields,
    accMetadataFields = [],
    attributeFields,
  } = config;

  // Validate field name
  const allValidFields = [
    ...directFields,
    ...parentFields,
    ...accMetadataFields,
    ...attributeFields,
  ];
  if (!allValidFields.includes(fieldName)) {
    throw new Error(
      `Invalid filter field: "${fieldName}". Valid fields: ${allValidFields.join(', ')}`
    );
  }

  // Handle direct fields (version table columns)
  if (directFields.includes(fieldName)) {
    const results = await (prisma[versionTable] as any).findMany({
      where: { isLatest: true },
      select: { [fieldName]: true },
      distinct: [fieldName],
    });

    return results
      .map((record: any) => record[fieldName])
      .filter((value: any) => value && String(value).trim().length > 0)
      .sort((a: string, b: string) => a.localeCompare(b));
  }

  // Handle parent fields (parent table columns via relation)
  if (parentFields.includes(fieldName)) {
    const results = await (prisma[versionTable] as any).findMany({
      where: { isLatest: true },
      include: { [parentTable]: true },
      distinct: [parentIdField],
    });

    const uniqueValues = new Set<string>();
    for (const versionRecord of results) {
      const value = versionRecord[parentTable]?.[fieldName];
      if (value && String(value).trim().length > 0) {
        uniqueValues.add(String(value));
      }
    }

    return Array.from(uniqueValues).sort((a, b) => a.localeCompare(b));
  }

  // Handle ACC metadata fields (version table columns for ACC data)
  if (accMetadataFields.includes(fieldName)) {
    const results = await (prisma[versionTable] as any).findMany({
      where: { isLatest: true },
      select: { [fieldName]: true },
      distinct: [fieldName],
    });

    const uniqueValues = new Set<string>();
    for (const record of results) {
      const value = record[fieldName];
      if (value && String(value).trim().length > 0) {
        uniqueValues.add(String(value));
      }
    }

    return Array.from(uniqueValues).sort((a, b) => a.localeCompare(b));
  }

  // Handle attribute fields (EAV attributes)
  const attrDef = await prisma.attributeDefinition.findUnique({
    where: { name: fieldName },
  });
  if (!attrDef) {
    return [];
  }

  // Get latest version IDs
  const latestVersions = await (prisma[versionTable] as any).findMany({
    where: { isLatest: true },
    select: { id: true },
  });
  const entityIds = latestVersions.map((v: any) => v.id);
  if (entityIds.length === 0) {
    return [];
  }

  // Query value table based on datatype
  let values: string[] = [];

  switch (attrDef.datatype) {
    case 'TEXT': {
      const textResults = await prisma.attributeTextValue.findMany({
        where: {
          attrDefId: attrDef.id,
          entityType,
          entityId: { in: entityIds },
        },
        select: { value: true },
        distinct: ['value'],
        orderBy: { value: 'asc' },
      });
      values = textResults.map((r) => r.value);
      break;
    }

    case 'INT': {
      const intResults = await prisma.attributeIntValue.findMany({
        where: {
          attrDefId: attrDef.id,
          entityType,
          entityId: { in: entityIds },
        },
        select: { value: true },
        distinct: ['value'],
        orderBy: { value: 'asc' },
      });
      values = intResults.map((r) => String(r.value));
      break;
    }

    case 'BOOL': {
      const boolResults = await prisma.attributeBoolValue.findMany({
        where: {
          attrDefId: attrDef.id,
          entityType,
          entityId: { in: entityIds },
        },
        select: { value: true },
        distinct: ['value'],
        orderBy: { value: 'asc' },
      });
      values = boolResults.map((r) => String(r.value));
      break;
    }

    case 'NUM': {
      const numResults = await prisma.attributeNumericValue.findMany({
        where: {
          attrDefId: attrDef.id,
          entityType,
          entityId: { in: entityIds },
        },
        select: { value: true },
        distinct: ['value'],
        orderBy: { value: 'asc' },
      });
      values = numResults.map((r) => r.value.toString());
      break;
    }
  }

  return values.filter((v) => v && v.trim().length > 0).sort((a, b) => a.localeCompare(b));
}
