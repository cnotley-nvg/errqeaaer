import type {
  AttributeMap,
  FilterQueryInput,
  FilterTokenGroupInput,
} from '@amzn/global-realty-mosaic-graphql-schema';

export const collectAttributeTokens = (
  query: FilterQueryInput | null | undefined,
  baseFieldNames: ReadonlySet<string>
): FilterTokenGroupInput[] => {
  if (!query?.tokenGroups?.length) {
    return [];
  }

  return query.tokenGroups.filter((token) => !baseFieldNames.has(token.propertyKey));
};

const toCandidateStrings = (token: FilterTokenGroupInput): string[] => {
  const rawValues = token.values?.length ? token.values : token.value ? [token.value] : [];

  return rawValues
    .map((value) => `${value}`.trim().toLowerCase())
    .filter((value) => value.length > 0);
};

const normalizeAttributeValue = (value: unknown): string | null => {
  if (value === null || value === undefined) {
    return null;
  }

  if (typeof value === 'string') {
    const trimmed = value.trim();
    return trimmed.length ? trimmed.toLowerCase() : null;
  }

  if (typeof value === 'boolean') {
    return value ? 'true' : 'false';
  }

  if (typeof value === 'number') {
    return value.toString();
  }

  if (typeof value === 'object' && 'value' in (value as Record<string, unknown>)) {
    const numeric = (value as { value: unknown; unit?: unknown }).value;
    if (typeof numeric === 'number' || typeof numeric === 'string') {
      return `${numeric}`.toLowerCase();
    }
  }

  return JSON.stringify(value).toLowerCase();
};

const listAttributeValues = (
  attributes: AttributeMap | null | undefined,
  key: string
): string[] => {
  if (!attributes) {
    return [];
  }

  const raw = (attributes as Record<string, unknown>)[key];
  if (raw === null || raw === undefined) {
    return [];
  }

  const values = Array.isArray(raw) ? raw : [raw];
  return values.map(normalizeAttributeValue).filter((value): value is string => value !== null);
};

const matchesAttributeToken = (
  attributeMap: AttributeMap | null | undefined,
  token: FilterTokenGroupInput
): boolean => {
  const attributeValues = listAttributeValues(attributeMap, token.propertyKey);
  const candidates = toCandidateStrings(token);

  const hasValues = attributeValues.length > 0;

  // Debug logging for numeric comparisons
  if (token.propertyKey === 'stories') {
    console.log('🔍 DEBUG stories filter:', {
      operator: token.operator,
      tokenValue: token.value,
      candidates,
      attributeValues,
      hasValues,
      rawAttributeMap: attributeMap
        ? (attributeMap as Record<string, unknown>)['stories']
        : 'no map',
    });
  }

  // Check for special :empty/:null syntax
  if (candidates.length === 1) {
    const special = candidates[0]!;
    if (special === ':empty' || special === ':null') {
      return !hasValues;
    }
    if (special === ':notempty' || special === ':notnull') {
      return hasValues;
    }
  }

  const valuesToSearch = attributeValues;

  // Handle numeric comparisons
  const isNumericComparison = [
    'GREATER_THAN',
    'LESS_THAN',
    'GREATER_OR_EQUAL',
    'LESS_OR_EQUAL',
  ].includes(token.operator);

  if (isNumericComparison) {
    const candidateNum = parseFloat(candidates[0] || '');
    if (isNaN(candidateNum)) {
      if (token.propertyKey === 'stories') {
        console.log('❌ candidateNum is NaN');
      }
      return false;
    }

    const result = valuesToSearch.some((attrValue) => {
      const attrNum = parseFloat(attrValue);
      if (isNaN(attrNum)) {
        if (token.propertyKey === 'stories') {
          console.log('❌ attrNum is NaN for value:', attrValue);
        }
        return false;
      }

      let matches = false;
      switch (token.operator) {
        case 'GREATER_THAN':
          matches = attrNum > candidateNum;
          break;
        case 'LESS_THAN':
          matches = attrNum < candidateNum;
          break;
        case 'GREATER_OR_EQUAL':
          matches = attrNum >= candidateNum;
          break;
        case 'LESS_OR_EQUAL':
          matches = attrNum <= candidateNum;
          break;
        default:
          matches = false;
      }

      if (token.propertyKey === 'stories') {
        console.log(`  Comparison: ${attrNum} ${token.operator} ${candidateNum} = ${matches}`);
      }

      return matches;
    });

    if (token.propertyKey === 'stories') {
      console.log('✅ Final result:', result);
    }

    return result;
  }

  // Handle string comparisons
  switch (token.operator) {
    case 'EQUALS': {
      if (!candidates.length || !hasValues) {
        return false;
      }
      return candidates.some((candidate) => valuesToSearch.some((value) => value === candidate));
    }
    case 'NOT_EQUALS': {
      if (!candidates.length) {
        return true;
      }
      if (!hasValues) {
        return true;
      }
      return candidates.every((candidate) => valuesToSearch.every((value) => value !== candidate));
    }
    case 'CONTAINS': {
      if (!candidates.length || !hasValues) {
        return false;
      }
      return candidates.some((candidate) =>
        valuesToSearch.some((value) => value.includes(candidate))
      );
    }
    case 'NOT_CONTAINS': {
      if (!candidates.length) {
        return true;
      }
      if (!hasValues) {
        return true;
      }
      return candidates.every((candidate) =>
        valuesToSearch.every((value) => !value.includes(candidate))
      );
    }
    case 'STARTS_WITH': {
      if (!candidates.length || !hasValues) {
        return false;
      }
      return candidates.some((candidate) =>
        valuesToSearch.some((value) => value.startsWith(candidate))
      );
    }
    case 'NOT_STARTS_WITH': {
      if (!candidates.length) {
        return true;
      }
      if (!hasValues) {
        return true;
      }
      return candidates.every((candidate) =>
        valuesToSearch.every((value) => !value.startsWith(candidate))
      );
    }
    default: {
      return true;
    }
  }
};

export const applyAttributeFilters = <
  T extends { latestVersion?: { attributes?: AttributeMap | null } | null },
>(
  entities: T[],
  tokens: FilterTokenGroupInput[],
  operation: FilterQueryInput['operation'] | null | undefined
): T[] => {
  if (!tokens.length) {
    return entities;
  }

  const mode = operation?.toUpperCase() === 'OR' ? 'OR' : 'AND';

  return entities.filter((entity) => {
    const attributeMap = entity.latestVersion?.attributes ?? null;

    // Group tokens by propertyKey to handle multi-value filters correctly
    const tokensByProperty = new Map<string, FilterTokenGroupInput[]>();
    for (const token of tokens) {
      const existing = tokensByProperty.get(token.propertyKey) || [];
      existing.push(token);
      tokensByProperty.set(token.propertyKey, existing);
    }

    // Evaluate each property group
    const propertyEvaluations: boolean[] = [];

    for (const [propertyKey, propertyTokens] of tokensByProperty.entries()) {
      if (propertyTokens.length === 1) {
        // Single token for this property - use normal matching
        propertyEvaluations.push(matchesAttributeToken(attributeMap, propertyTokens[0]!));
      } else if (mode === 'AND') {
        // Multiple tokens for same property with AND operation
        // This means: template must have ALL the specified values
        // Example: program=ARS AND program=IXD → template must have both ARS and IXD
        const attributeValues = listAttributeValues(attributeMap, propertyKey);
        const allRequiredValues = propertyTokens.flatMap((token) => toCandidateStrings(token));

        // Check if ALL required values are present in the attribute
        const hasAllValues = allRequiredValues.every((requiredValue) =>
          attributeValues.some((attrValue) => attrValue === requiredValue)
        );
        propertyEvaluations.push(hasAllValues);
      } else {
        // Multiple tokens for same property with OR operation
        // This means: template must have ANY of the specified values
        const hasAnyMatch = propertyTokens.some((token) =>
          matchesAttributeToken(attributeMap, token)
        );
        propertyEvaluations.push(hasAnyMatch);
      }
    }

    // Apply global operation across different properties
    return mode === 'OR' ? propertyEvaluations.some(Boolean) : propertyEvaluations.every(Boolean);
  });
};
