import type { Logger } from '../../shared';
import { ensureLogger } from '../../shared';
import { createKitService, type KitService } from './domain/kitService';
import type { StandardService } from '../standards/domain/standardService';
import { createKitResolvers, type KitResolverMap } from './graphql/resolvers';

export interface KitModule {
  resolvers: KitResolverMap;
  service: KitService;
}

export interface CreateKitModuleArgs {
  logger: Logger;
  standardService: StandardService;
}

export const createKitModule = ({ logger, standardService }: CreateKitModuleArgs): KitModule => {
  const moduleLogger = ensureLogger(logger, 'kits-module').child({ module: 'kits' });

  const service = createKitService(moduleLogger.child({ component: 'service' }), standardService);

  const resolvers = createKitResolvers({ kitService: service });

  return {
    resolvers,
    service,
  };
};
