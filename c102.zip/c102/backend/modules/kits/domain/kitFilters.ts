import type { Prisma } from '@amzn/global-realty-mosaic-prisma-client';
import type { FilterInput, FilterTokenGroupInput } from '@amzn/global-realty-mosaic-graphql-schema';

const collectTokenValues = (token: FilterTokenGroupInput): string[] => {
  if (token.values?.length) {
    return token.values.filter(
      (value): value is string => typeof value === 'string' && value.trim().length > 0
    );
  }

  return typeof token.value === 'string' && token.value.trim().length > 0 ? [token.value] : [];
};

const buildStringCondition = (
  field: keyof Prisma.KitWhereInput,
  operator: FilterTokenGroupInput['operator'],
  values: string[]
): Prisma.KitWhereInput | null => {
  if (!values.length) {
    return null;
  }

  const insensitiveEquals = (value: string): Prisma.KitWhereInput => ({
    [field]: {
      equals: value,
      mode: 'insensitive',
    },
  });

  const insensitiveContains = (value: string): Prisma.KitWhereInput => ({
    [field]: {
      contains: value,
      mode: 'insensitive',
    },
  });

  const insensitiveStartsWith = (value: string): Prisma.KitWhereInput => ({
    [field]: {
      startsWith: value,
      mode: 'insensitive',
    },
  });

  switch (operator) {
    case 'EQUALS':
      return values.length === 1
        ? insensitiveEquals(values[0]!)
        : { OR: values.map((value) => insensitiveEquals(value)) };
    case 'NOT_EQUALS':
      return {
        AND: values.map((value) => ({ NOT: insensitiveEquals(value) })),
      } satisfies Prisma.KitWhereInput;
    case 'CONTAINS':
      return values.length === 1
        ? insensitiveContains(values[0]!)
        : { OR: values.map((value) => insensitiveContains(value)) };
    case 'NOT_CONTAINS':
      return {
        AND: values.map((value) => ({ NOT: insensitiveContains(value) })),
      } satisfies Prisma.KitWhereInput;
    case 'STARTS_WITH':
      return values.length === 1
        ? insensitiveStartsWith(values[0]!)
        : { OR: values.map((value) => insensitiveStartsWith(value)) };
    case 'NOT_STARTS_WITH':
      return {
        AND: values.map((value) => ({ NOT: insensitiveStartsWith(value) })),
      } satisfies Prisma.KitWhereInput;
    default:
      return null;
  }
};

const parseDateValue = (value: string): Date | null => {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

const buildDateCondition = (
  field: 'createdAt' | 'updatedAt',
  operator: FilterTokenGroupInput['operator'],
  values: string[]
): Prisma.KitWhereInput | null => {
  const [raw] = values;
  if (!raw) {
    return null;
  }

  const parsed = parseDateValue(raw);
  if (!parsed) {
    return null;
  }

  switch (operator) {
    case 'GREATER_THAN':
      return { [field]: { gt: parsed } } as Prisma.KitWhereInput;
    case 'GREATER_OR_EQUAL':
      return { [field]: { gte: parsed } } as Prisma.KitWhereInput;
    case 'LESS_THAN':
      return { [field]: { lt: parsed } } as Prisma.KitWhereInput;
    case 'LESS_OR_EQUAL':
      return { [field]: { lte: parsed } } as Prisma.KitWhereInput;
    case 'EQUALS':
      return { [field]: { equals: parsed } } as Prisma.KitWhereInput;
    case 'NOT_EQUALS':
      return { NOT: { [field]: { equals: parsed } } } as Prisma.KitWhereInput;
    default:
      return null;
  }
};

export const buildWhere = (filter: FilterInput): Prisma.KitWhereInput => {
  const query = filter.query;
  if (!query?.tokenGroups?.length) {
    return {};
  }

  const conditions = query.tokenGroups
    .map((token) => {
      const values = collectTokenValues(token);
      if (!values.length) {
        return null;
      }

      switch (token.propertyKey) {
        case 'name':
          return buildStringCondition('name', token.operator, values);
        case 'desc':
        case 'description':
          return buildStringCondition('description', token.operator, values);
        case 'createdAt':
          return buildDateCondition('createdAt', token.operator, values);
        case 'updatedAt':
          return buildDateCondition('updatedAt', token.operator, values);
        default:
          return null;
      }
    })
    .filter((condition): condition is Prisma.KitWhereInput => condition !== null);

  if (!conditions.length) {
    return {};
  }

  return query.operation === 'AND'
    ? ({ AND: conditions } satisfies Prisma.KitWhereInput)
    : ({ OR: conditions } satisfies Prisma.KitWhereInput);
};

export const buildOrderBy = (filter: FilterInput): Prisma.KitOrderByWithRelationInput => {
  const direction: Prisma.SortOrder = filter.orderDesc ? 'desc' : 'asc';

  switch (filter.orderBy) {
    case 'name':
      return { name: direction };
    case 'desc':
    case 'description':
      return { description: direction };
    case 'updatedAt':
      return { updatedAt: direction };
    case 'createdAt':
      return { createdAt: direction };
    default:
      return { createdAt: 'desc' };
  }
};

export const kitFilterInternals = {
  collectTokenValues,
  buildStringCondition,
  buildDateCondition,
  parseDateValue,
};
