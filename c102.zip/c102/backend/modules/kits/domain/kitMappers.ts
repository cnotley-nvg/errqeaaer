import type {
  Kit as PrismaKit,
  KitVersion as PrismaKitVersion,
  Standard as PrismaStandard,
  StandardVersion as PrismaStandardVersion,
} from '@amzn/global-realty-mosaic-prisma-client';
import type {
  AttributeMap,
  Kit,
  KitVersion,
  StandardVersion,
} from '@amzn/global-realty-mosaic-graphql-schema';

export type StandardVersionWithStandard = PrismaStandardVersion & {
  standard: PrismaStandard;
};

export type KitVersionWithRelations = PrismaKitVersion & {
  kit: PrismaKit;
  standards: {
    standardVersion: StandardVersionWithStandard;
  }[];
};

export type KitRecord = PrismaKit & {
  versions: KitVersionWithRelations[];
};

export type KitAttributeLoader = (entityId: string) => Promise<AttributeMap>;

const createStandardVersionMapper =
  (attributeLoader: KitAttributeLoader) =>
  async (record: StandardVersionWithStandard): Promise<StandardVersion> => {
    const attributes = await attributeLoader(record.id);

    return {
      id: record.id,
      standardId: record.standardId,
      standard: {
        id: record.standard.id,
        accProjectId: record.standard.accProjectId,
        name: record.standard.name,
        description: record.standard.description ?? null,
        createdAt: record.standard.createdAt.toISOString(),
        updatedAt: record.standard.updatedAt.toISOString(),
        versions: [],
        latestVersion: null,
      },
      accFolderId: record.accFolderId,
      accFileId: record.accFileId,
      version: record.version,
      isLatest: record.isLatest,
      kits: [],
      attributes,
      createdAt: record.createdAt.toISOString(),
      updatedAt: record.updatedAt.toISOString(),
    } satisfies StandardVersion;
  };

const createKitVersionMapper =
  (
    attributeLoader: KitAttributeLoader,
    toStandardVersionGraph: ReturnType<typeof createStandardVersionMapper>
  ) =>
  async (record: KitVersionWithRelations): Promise<KitVersion> => {
    const attributes = await attributeLoader(record.id);
    const standards = await Promise.all(
      record.standards.map((link) => toStandardVersionGraph(link.standardVersion))
    );

    return {
      id: record.id,
      kitId: record.kitId,
      kit: {
        id: record.kit.id,
        name: record.kit.name,
        desc: record.kit.description ?? null,
        createdAt: record.kit.createdAt.toISOString(),
        updatedAt: record.kit.updatedAt.toISOString(),
        versions: [],
        latestVersion: null,
      },
      version: record.version,
      isLatest: record.isLatest,
      standards,
      attributes,
      createdAt: record.createdAt.toISOString(),
      updatedAt: record.updatedAt.toISOString(),
    } satisfies KitVersion;
  };

export const createKitMappers = (attributeLoader: KitAttributeLoader) => {
  const toStandardVersionGraph = createStandardVersionMapper(attributeLoader);
  const toKitVersionGraph = createKitVersionMapper(attributeLoader, toStandardVersionGraph);

  const toKitGraph = async (record: KitRecord): Promise<Kit> => {
    const versions = await Promise.all(
      record.versions.map((version) =>
        toKitVersionGraph({
          ...version,
          kit: record,
        })
      )
    );

    const latestVersion = versions.find((version) => version.isLatest) ?? versions[0] ?? null;

    return {
      id: record.id,
      name: record.name,
      desc: record.description ?? null,
      createdAt: record.createdAt.toISOString(),
      updatedAt: record.updatedAt.toISOString(),
      versions,
      latestVersion,
    } satisfies Kit;
  };

  return {
    toStandardVersionGraph,
    toKitVersionGraph,
    toKitGraph,
  } as const;
};
