import type { Prisma } from '@amzn/global-realty-mosaic-prisma-client';

export interface KitVersionMutations {
  updateMany: (args: Prisma.KitVersionUpdateManyArgs) => Promise<unknown>;
  update: (args: Prisma.KitVersionUpdateArgs) => Promise<unknown>;
  findMany: (
    args: Prisma.KitVersionFindManyArgs
  ) => Promise<Array<{ id: string; isLatest: boolean }>>;
}

export interface KitVersionStandardLinkMutations {
  deleteMany: (args: Prisma.KitVersionStandardLinkDeleteManyArgs) => Promise<unknown>;
  create: (args: Prisma.KitVersionStandardLinkCreateArgs) => Promise<unknown>;
}

export interface StandardVersionQueries {
  findMany: (args: Prisma.StandardVersionFindManyArgs) => Promise<Array<{ id: string }>>;
}

export const validateStandardVersions = async (
  standardVersion: StandardVersionQueries,
  ids: readonly string[]
): Promise<void> => {
  if (!ids.length) {
    throw new Error('At least one standard version must be provided.');
  }

  const records = await standardVersion.findMany({ where: { id: { in: [...ids] } } });
  if (records.length !== ids.length) {
    throw new Error('One or more standard versions could not be found.');
  }
};

export const linkStandardVersions = async (
  kitStandardLink: KitVersionStandardLinkMutations,
  kitVersionId: string,
  standardVersionIds: readonly string[]
): Promise<void> => {
  await kitStandardLink.deleteMany({ where: { kitVersionId } });

  for (const standardVersionId of standardVersionIds) {
    await kitStandardLink.create({
      data: {
        kitVersionId,
        standardVersionId,
      },
    });
  }
};

export const updateLatestKitVersionFlags = async (
  kitVersion: KitVersionMutations,
  kitId: string,
  latestId: string
): Promise<void> => {
  await kitVersion.updateMany({ data: { isLatest: false }, where: { kitId } });
  await kitVersion.update({ data: { isLatest: true }, where: { id: latestId } });
};

export const ensureLatestKitVersionExists = async (
  kitVersion: KitVersionMutations,
  kitId: string
): Promise<void> => {
  const versions = await kitVersion.findMany({
    where: { kitId },
    orderBy: { createdAt: 'desc' },
    select: { id: true, isLatest: true },
  });

  if (!versions.length) {
    return;
  }

  if (versions.some((version) => version.isLatest)) {
    return;
  }

  const [mostRecent] = versions;
  if (mostRecent) {
    await kitVersion.update({ where: { id: mostRecent.id }, data: { isLatest: true } });
  }
};
