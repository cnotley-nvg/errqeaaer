import type { Prisma } from '@amzn/global-realty-mosaic-prisma-client';

import type {
  AttributeMap,
  CreateKitInput,
  CreateKitVersionInput,
  FilterInput,
  Kit,
  KitConnection,
  KitOptions,
  KitMutationResponse,
  KitVersion,
  KitVersionMutationResponse,
  KitCompatibleStandardsInput,
  KitCompatibleStandard,
  UpdateKitInput,
  UpdateKitVersionInput,
} from '@amzn/global-realty-mosaic-graphql-schema';
import type { StandardService } from '../../standards/domain/standardService';

import type { AuthenticatedUser } from '../../../lib/auth';
import type { Logger } from '../../../shared';
import { prisma } from '../../../lib/prisma';
import { loadAttributes, storeAttributes } from '../../shared/attributeStore';
import { collectAttributeTokens, applyAttributeFilters } from '../../shared/attributeFilterUtils';
import { extractAttributeValues } from '../../shared/attributeHelpers';
import { sortEntities } from '../../shared/searchSort';
import { buildOrderBy, buildWhere } from './kitFilters';
import { createKitMappers, type KitRecord, type KitVersionWithRelations } from './kitMappers';
import {
  ensureLatestKitVersionExists,
  linkStandardVersions,
  updateLatestKitVersionFlags,
  validateStandardVersions,
} from './kitMutations';

import { createSystemEvent } from '../../events/domain/eventsMutations';

const emptyAttributes = Object.freeze({}) as AttributeMap;

const KIT_VERSION_INCLUDE = {
  kit: true,
  standards: {
    orderBy: { createdAt: 'asc' },
    include: {
      standardVersion: {
        include: {
          standard: true,
        },
      },
    },
  },
} as const satisfies Prisma.KitVersionInclude;

const KIT_INCLUDE = {
  versions: {
    orderBy: { createdAt: 'desc' },
    include: {
      kit: true,
      standards: {
        orderBy: { createdAt: 'asc' },
        include: {
          standardVersion: {
            include: {
              standard: true,
            },
          },
        },
      },
    },
  },
} as const satisfies Prisma.KitInclude;

const attributeLoader = (entityId: string) => loadAttributes(prisma, entityId);
const { toKitVersionGraph, toKitGraph } = createKitMappers(attributeLoader);

const STANDARD_VERSION_INCLUDE = {
  standard: true,
} as const satisfies Prisma.StandardVersionInclude;

const BASE_FILTER_FIELDS = new Set(['name', 'desc', 'description', 'createdAt', 'updatedAt']);

const ATTRIBUTE_SORT_FIELDS = new Set([
  'region',
  'program',
  'useCase',
  'facilityType',
  'throughput',
  'stories',
]);

const fetchKitRecord = async (where: Prisma.KitWhereUniqueInput): Promise<KitRecord | null> => {
  return prisma.kit.findUnique({
    where,
    include: KIT_INCLUDE,
  }) as Promise<KitRecord | null>;
};

const fetchKitVersionRecord = async (
  where: Prisma.KitVersionWhereUniqueInput
): Promise<KitVersionWithRelations | null> => {
  return prisma.kitVersion.findUnique({
    where,
    include: KIT_VERSION_INCLUDE,
  }) as Promise<KitVersionWithRelations | null>;
};

export interface KitService {
  search(filter: FilterInput): Promise<KitConnection>;
  searchPublishedKits(filter: FilterInput): Promise<KitConnection>;
  getKit(id: string): Promise<Kit | null>;
  getKitByName(name: string): Promise<Kit | null>;
  listKitVersions(kitId: string): Promise<KitVersion[]>;
  getKitVersion(id: string): Promise<KitVersion | null>;
  isKitNameAvailable(name: string): Promise<boolean>;
  createKit(input: CreateKitInput, user?: AuthenticatedUser | null): Promise<KitMutationResponse>;
  updateKit(id: string, input: UpdateKitInput): Promise<KitMutationResponse>;
  deleteKit(id: string): Promise<KitMutationResponse>;
  createKitVersion(
    kitId: string,
    input: CreateKitVersionInput
  ): Promise<KitVersionMutationResponse>;
  updateKitVersion(id: string, input: UpdateKitVersionInput): Promise<KitVersionMutationResponse>;
  deleteKitVersion(id: string): Promise<KitVersionMutationResponse>;
  setLatestKitVersion(id: string): Promise<KitVersionMutationResponse>;
  linkStandardVersion(kitVersionId: string, standardVersionId: string): Promise<boolean>;
  unlinkStandardVersion(kitVersionId: string, standardVersionId: string): Promise<boolean>;
  kitOptions(): Promise<KitOptions>;
  kitCompatibleStandards(input: KitCompatibleStandardsInput): Promise<KitCompatibleStandard[]>;
}

export const createKitService = (logger: Logger, standardService: StandardService): KitService => ({
  async search(filter: FilterInput): Promise<KitConnection> {
    const page = Math.max(filter.pageIdx, 0);
    const limit = Math.max(filter.limit, 1);

    const where = buildWhere(filter);
    const orderBy = buildOrderBy(filter);
    const attributeTokens = collectAttributeTokens(filter.query ?? null, BASE_FILTER_FIELDS);

    const orderByKey = typeof filter.orderBy === 'string' ? filter.orderBy : '';
    const requiresAttributeProcessing =
      attributeTokens.length > 0 || ATTRIBUTE_SORT_FIELDS.has(orderByKey);

    if (requiresAttributeProcessing) {
      const records = await prisma.kit.findMany({
        where,
        orderBy,
        include: KIT_INCLUDE,
      });

      const mappedItems = await Promise.all(
        records.map((record) => toKitGraph(record as KitRecord))
      );

      const filteredItems = attributeTokens.length
        ? applyAttributeFilters(mappedItems, attributeTokens, filter.query?.operation ?? null)
        : mappedItems;

      //const filteredItems = applyAttributeFilters(mappedItems, attributeTokens, filter.query?.operation ?? null);
      const sortedItems = sortEntities(filteredItems, filter);

      const total = sortedItems.length;
      const start = page * limit;
      const pagedItems = sortedItems.slice(start, start + limit);

      return {
        items: pagedItems,
        total,
        pageIdx: page,
        limit,
        hasNext: start + limit < total,
      } satisfies KitConnection;
    }

    const [total, records] = await Promise.all([
      prisma.kit.count({ where }),
      prisma.kit.findMany({
        where,
        orderBy,
        skip: page * limit,
        take: limit,
        include: KIT_INCLUDE,
      }),
    ]);

    const items = await Promise.all(records.map((record) => toKitGraph(record as KitRecord)));

    return {
      items,
      total,
      pageIdx: page,
      limit,
      hasNext: (page + 1) * limit < total,
    } satisfies KitConnection;
  },

  async searchPublishedKits(filter: FilterInput): Promise<KitConnection> {
    // "Published" kits are those that have at least one latest version.
    // This prevents draft/empty kits (no versions) from showing in the published catalog.
    const publishedWhere: Prisma.KitWhereInput = {
      versions: { some: { isLatest: true } },
    };

    // Reuse existing search logic by injecting the "published" constraint.
    // We intentionally keep the rest of the FilterInput behavior identical.
    const baseWhere = buildWhere(filter);
    const combinedWhere: Prisma.KitWhereInput =
      baseWhere && Object.keys(baseWhere).length
        ? { AND: [publishedWhere, baseWhere] }
        : publishedWhere;

    const page = Math.max(filter.pageIdx, 0);
    const limit = Math.max(filter.limit, 1);

    const orderBy = buildOrderBy(filter);
    const attributeTokens = collectAttributeTokens(filter.query ?? null, BASE_FILTER_FIELDS);

    const orderByKey = typeof filter.orderBy === 'string' ? filter.orderBy : '';
    const requiresAttributeProcessing =
      attributeTokens.length > 0 || ATTRIBUTE_SORT_FIELDS.has(orderByKey);

    if (requiresAttributeProcessing) {
      const records = await prisma.kit.findMany({
        where: combinedWhere,
        orderBy,
        include: KIT_INCLUDE,
      });

      const mappedItems = await Promise.all(
        records.map((record) => toKitGraph(record as KitRecord))
      );

      const filteredItems = attributeTokens.length
        ? applyAttributeFilters(mappedItems, attributeTokens, filter.query?.operation ?? null)
        : mappedItems;

      const sortedItems = sortEntities(filteredItems, filter);

      const total = sortedItems.length;
      const start = page * limit;
      const pagedItems = sortedItems.slice(start, start + limit);

      return {
        items: pagedItems,
        total,
        pageIdx: page,
        limit,
        hasNext: start + limit < total,
      } satisfies KitConnection;
    }

    const [total, records] = await Promise.all([
      prisma.kit.count({ where: combinedWhere }),
      prisma.kit.findMany({
        where: combinedWhere,
        orderBy,
        skip: page * limit,
        take: limit,
        include: KIT_INCLUDE,
      }),
    ]);

    const items = await Promise.all(records.map((record) => toKitGraph(record as KitRecord)));

    return {
      items,
      total,
      pageIdx: page,
      limit,
      hasNext: (page + 1) * limit < total,
    } satisfies KitConnection;
  },

  async getKit(id: string): Promise<Kit | null> {
    const record = await fetchKitRecord({ id });
    if (!record) {
      return null;
    }

    return toKitGraph(record);
  },

  async getKitByName(name: string): Promise<Kit | null> {
    const record = await fetchKitRecord({ name });
    if (!record) {
      return null;
    }

    return toKitGraph(record);
  },

  async listKitVersions(kitId: string): Promise<KitVersion[]> {
    const kit = await prisma.kit.findUnique({
      where: { id: kitId },
      include: KIT_INCLUDE,
    });

    if (!kit) {
      return [];
    }

    return Promise.all(
      kit.versions.map((version) =>
        toKitVersionGraph({
          ...version,
          kit,
        } as KitVersionWithRelations)
      )
    );
  },

  async getKitVersion(id: string): Promise<KitVersion | null> {
    const record = await fetchKitVersionRecord({ id });
    if (!record) {
      return null;
    }

    return toKitVersionGraph(record);
  },

  async isKitNameAvailable(name: string): Promise<boolean> {
    const existing = await prisma.kit.findUnique({ where: { name } });
    return existing === null;
  },

  async kitOptions(): Promise<KitOptions> {
    // Collect distinct attribute values from the latest version of each standard.
    const latestVersions = await prisma.standardVersion.findMany({
      where: { isLatest: true },
      include: STANDARD_VERSION_INCLUDE,
    });

    const regions = new Set<string>();
    const programs = new Set<string>();
    const useCases = new Set<string>();
    const projectTypes = new Set<string>();
    const roomFeatureZones = new Set<string>();
    const dataTypes = new Set<string>();

    const pushValues = (raw: unknown, target: Set<string>) => {
      if (raw === null || raw === undefined) {
        return;
      }

      const values = Array.isArray(raw) ? raw : [raw];
      for (const value of values) {
        if (value === null || value === undefined) {
          continue;
        }

        if (typeof value === 'object') {
          continue;
        }

        const token = String(value).trim();
        if (token.length) {
          target.add(token);
        }
      }
    };

    for (const version of latestVersions) {
      const attrs = await loadAttributes(prisma, version.id);
      pushValues((attrs as Record<string, unknown>).region, regions);
      pushValues((attrs as Record<string, unknown>).program, programs);
      pushValues((attrs as Record<string, unknown>).useCase, useCases);
      pushValues((attrs as Record<string, unknown>).projectType, projectTypes);
      pushValues((attrs as Record<string, unknown>).roomFeatureZone, roomFeatureZones);
      pushValues((attrs as Record<string, unknown>).dataType, dataTypes);
    }

    const toSortedArray = (input: Set<string>): string[] =>
      Array.from(input).sort((a, b) => a.localeCompare(b));

    return {
      regions: toSortedArray(regions),
      programs: toSortedArray(programs),
      useCases: toSortedArray(useCases),
      projectTypes: toSortedArray(projectTypes),
      roomFeatureZones: toSortedArray(roomFeatureZones),
      dataTypes: toSortedArray(dataTypes),
    };
  },

  async kitCompatibleStandards(
    input: KitCompatibleStandardsInput
  ): Promise<KitCompatibleStandard[]> {
    // Normalize filters: trim, lowercase, de-dupe.
    const normalizeList = (values?: readonly string[] | null): string[] => {
      if (!values) {
        return [];
      }

      const unique = new Set<string>();
      for (const value of values) {
        const trimmed = typeof value === 'string' ? value.trim().toLowerCase() : '';
        if (trimmed.length) {
          unique.add(trimmed);
        }
      }
      return Array.from(unique);
    };

    const filterRegions = normalizeList(input.regions);
    const filterPrograms = normalizeList(input.programs);
    const filterUseCases = normalizeList(input.useCases);
    const filterProjectTypes = normalizeList(input.projectTypes);
    const filterRoomFeatureZones = normalizeList(input.roomFeatureZones);
    const filterDataTypes = normalizeList(input.dataTypes);

    // Helper to list attribute values as lowercase strings for comparison.
    const listAttrValues = (raw: unknown): string[] => {
      if (raw === null || raw === undefined) {
        return [];
      }

      const values = Array.isArray(raw) ? raw : [raw];
      return values
        .map((candidate) => {
          if (candidate === null || candidate === undefined) {
            return null;
          }
          if (typeof candidate === 'object') {
            return null;
          }
          const token = String(candidate).trim().toLowerCase();
          return token.length ? token : null;
        })
        .filter((token): token is string => Boolean(token));
    };

    const matchesFilter = (filterVals: string[], attrRaw: unknown): boolean => {
      if (!filterVals.length) {
        return true;
      }
      const attrVals = listAttrValues(attrRaw);
      if (!attrVals.length) {
        return false;
      }
      return filterVals.some((f) => attrVals.some((v) => v === f));
    };

    // Build standards search filter from kit criteria (Option A: large limit, server-forced filters)
    const tokenGroups: Array<{
      propertyKey: string;
      operator: 'EQUALS';
      value?: string;
      values?: string[];
    }> = [];
    if (filterRegions.length) {
      tokenGroups.push({ propertyKey: 'region', operator: 'EQUALS', values: filterRegions });
    }
    if (filterPrograms.length) {
      tokenGroups.push({ propertyKey: 'program', operator: 'EQUALS', values: filterPrograms });
    }
    if (filterUseCases.length) {
      tokenGroups.push({ propertyKey: 'useCase', operator: 'EQUALS', values: filterUseCases });
    }
    if (filterProjectTypes.length) {
      tokenGroups.push({
        propertyKey: 'projectType',
        operator: 'EQUALS',
        values: filterProjectTypes,
      });
    }
    if (filterRoomFeatureZones.length) {
      tokenGroups.push({
        propertyKey: 'roomFeatureZone',
        operator: 'EQUALS',
        values: filterRoomFeatureZones,
      });
    }
    if (filterDataTypes.length) {
      tokenGroups.push({ propertyKey: 'dataType', operator: 'EQUALS', values: filterDataTypes });
    }

    // Use searchLatestStandardVersions for better performance and correct filtering
    const searchResult = await standardService.searchLatestStandardVersions({
      pageIdx: 0,
      limit: 500,
      orderBy: 'name',
      orderDesc: false,
      query: tokenGroups.length
        ? {
            operation: 'AND',
            tokenGroups,
          }
        : undefined,
    });

    const results: KitCompatibleStandard[] = [];

    // searchLatestStandardVersions returns StandardVersion records directly
    for (const latestVersion of searchResult.items) {
      if (!latestVersion) {
        continue;
      }
      const attrs = latestVersion.attributes ?? {};
      const rawRegion = (attrs as Record<string, unknown>).region;
      const rawProgram = (attrs as Record<string, unknown>).program;
      const rawUseCase = (attrs as Record<string, unknown>).useCase;
      const rawProjectType = (attrs as Record<string, unknown>).projectType;
      const rawRoomFeatureZone = (attrs as Record<string, unknown>).roomFeatureZone;
      const rawDataType = (attrs as Record<string, unknown>).dataType;

      // Note: searchLatestStandardVersions() already filters by these attributes at the database level
      // This redundant in-memory filtering is kept as a safety net and for backwards compatibility
      // However, it should not filter out valid results if search() works correctly
      if (!matchesFilter(filterRegions, rawRegion)) {
        continue;
      }
      if (!matchesFilter(filterPrograms, rawProgram)) {
        continue;
      }
      if (!matchesFilter(filterUseCases, rawUseCase)) {
        continue;
      }
      if (!matchesFilter(filterProjectTypes, rawProjectType)) {
        continue;
      }
      if (!matchesFilter(filterRoomFeatureZones, rawRoomFeatureZone)) {
        continue;
      }
      if (!matchesFilter(filterDataTypes, rawDataType)) {
        continue;
      }

      // Extract attribute values - single values stay as single, multi-values as arrays
      const regions = extractAttributeValues(rawRegion);
      const programs = extractAttributeValues(rawProgram);
      const useCases = extractAttributeValues(rawUseCase);
      const projectTypes = extractAttributeValues(rawProjectType);
      const roomFeatureZones = extractAttributeValues(rawRoomFeatureZone);
      const dataTypes = extractAttributeValues(rawDataType);

      // Skip standards that are missing required fields for the response type
      // Only region is required (non-nullable) in the GraphQL type
      if (regions.length === 0) {
        continue;
      }

      results.push({
        id: latestVersion.id,
        standardId: latestVersion.standardId,
        standardName: latestVersion.standard.name,
        version: latestVersion.version,
        region: regions[0], // Region is single value (first one)
        program: (programs.length > 0 ? programs : null) as string[] | null,
        useCase: (useCases[0] ?? null) as string | null, // legacy field (no longer used by Build Kit UI)
        projectType: (projectTypes.length > 0 ? projectTypes : null) as string[] | null,
        roomFeatureZone: (roomFeatureZones.length > 0 ? roomFeatureZones : null) as string[] | null,
        dataType: (dataTypes[0] ?? null) as string | null, // dataType is single value
      } as KitCompatibleStandard);
    }

    return results;
  },

  async createKit(
    input: CreateKitInput,
    user?: AuthenticatedUser | null
  ): Promise<KitMutationResponse> {
    try {
      const trimmedName = input.name.trim();
      if (!trimmedName.length) {
        throw new Error('Kit name is required.');
      }

      const existing = await prisma.kit.findUnique({ where: { name: trimmedName } });
      if (existing) {
        throw new Error(`Kit name '${trimmedName}' already exists`);
      }

      if (input.initialVersion?.standardVersionIds?.length) {
        await validateStandardVersions(
          prisma.standardVersion,
          input.initialVersion.standardVersionIds
        );
      }

      const createdKit = await prisma.$transaction(async (tx) => {
        const kit = await tx.kit.create({
          data: {
            name: trimmedName,
            description: input.desc ?? null,
          },
        });

        if (input.initialVersion) {
          if (!input.initialVersion.standardVersionIds?.length) {
            throw new Error(
              'At least one standard version must be provided for the initial kit version.'
            );
          }

          const kitVersion = await tx.kitVersion.create({
            data: {
              kitId: kit.id,
              version: input.initialVersion.version,
              isLatest: true,
            },
          });

          await linkStandardVersions(
            tx.kitVersionStandardLink,
            kitVersion.id,
            input.initialVersion.standardVersionIds
          );

          const createdBy = user?.username ?? 'system';
          const mergedAttributes: AttributeMap = {
            ...(input.initialVersion.attributes ?? emptyAttributes),
            createdBy,
          };

          await storeAttributes(tx, 'KIT_VERSION', kitVersion.id, mergedAttributes);
        }

        return tx.kit.findUnique({
          where: { id: kit.id },
          include: KIT_INCLUDE,
        }) as Promise<KitRecord | null>;
      });

      if (!createdKit) {
        throw new Error('Unable to load kit after creation.');
      }

      const graph = await toKitGraph(createdKit);

      // Create system event for kit creation
      try {
        const eventCreatedBy = user?.username ?? 'system';
        await createSystemEvent(
          prisma,
          {
            type: 'KIT',
            message: 'New kit created',
            details: {
              id: graph.id,
              name: graph.name,
            },
            status: 'PUBLISHED',
            createdBy: eventCreatedBy,
          },
          logger
        );
      } catch (eventError) {
        logger.warn('Failed to create system event for kit creation', {
          kitId: graph.id,
          error: eventError instanceof Error ? eventError.message : eventError,
        });
      }

      return { success: true, kit: graph } satisfies KitMutationResponse;
    } catch (error) {
      logger.error('Failed to create kit', {
        error: error instanceof Error ? error.message : error,
      });
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
        kit: null,
      };
    }
  },

  async updateKit(id: string, input: UpdateKitInput): Promise<KitMutationResponse> {
    try {
      const existing = await prisma.kit.findUnique({ where: { id } });
      if (!existing) {
        throw new Error('Kit not found.');
      }

      const data: Prisma.KitUpdateInput = {};
      if (input.name !== undefined) {
        if (input.name === null) {
          throw new Error('Kit name cannot be null.');
        }
        data.name = input.name;
      }
      if (input.desc !== undefined) {
        data.description = input.desc ?? null;
      }

      await prisma.kit.update({
        where: { id },
        data,
      });

      const updated = await fetchKitRecord({ id });
      if (!updated) {
        throw new Error('Unable to load kit after update.');
      }

      const graph = await toKitGraph(updated);

      // Create system event for kit update
      try {
        await createSystemEvent(
          prisma,
          {
            type: 'KIT',
            message: 'Kit updated',
            details: {
              id: graph.id,
              name: graph.name,
            },
            status: 'UPDATED',
            createdBy: 'system',
          },
          logger
        );
      } catch (eventError) {
        logger.warn('Failed to create system event for kit update', {
          kitId: graph.id,
          error: eventError instanceof Error ? eventError.message : eventError,
        });
      }

      return { success: true, kit: await toKitGraph(updated) } satisfies KitMutationResponse;
    } catch (error) {
      logger.error('Failed to update kit', {
        kitId: id,
        error: error instanceof Error ? error.message : error,
      });
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
        kit: null,
      };
    }
  },

  async deleteKit(id: string): Promise<KitMutationResponse> {
    try {
      await prisma.kit.delete({ where: { id } });
      return { success: true, kit: null } satisfies KitMutationResponse;
    } catch (error) {
      logger.error('Failed to delete kit', {
        kitId: id,
        error: error instanceof Error ? error.message : error,
      });
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
        kit: null,
      };
    }
  },

  async createKitVersion(
    kitId: string,
    input: CreateKitVersionInput
  ): Promise<KitVersionMutationResponse> {
    try {
      await validateStandardVersions(prisma.standardVersion, input.standardVersionIds);

      const kitVersion = await prisma.$transaction(async (tx) => {
        const kit = await tx.kit.findUnique({ where: { id: kitId } });
        if (!kit) {
          throw new Error('Kit not found.');
        }

        const created = await tx.kitVersion.create({
          data: {
            kitId,
            version: input.version,
            isLatest: false,
          },
        });

        await linkStandardVersions(tx.kitVersionStandardLink, created.id, input.standardVersionIds);
        await storeAttributes(tx, 'KIT_VERSION', created.id, input.attributes ?? emptyAttributes);
        await updateLatestKitVersionFlags(tx.kitVersion, kitId, created.id);

        return created.id;
      });

      const graph = await this.getKitVersion(kitVersion);
      return { success: true, kitVersion: graph } satisfies KitVersionMutationResponse;
    } catch (error) {
      logger.error('Failed to create kit version', {
        kitId,
        error: error instanceof Error ? error.message : error,
      });
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
        kitVersion: null,
      };
    }
  },

  async updateKitVersion(
    id: string,
    input: UpdateKitVersionInput
  ): Promise<KitVersionMutationResponse> {
    const inputWithLatest = input as UpdateKitVersionInput & { isLatest?: boolean | null };
    try {
      const existing = await prisma.kitVersion.findUnique({
        where: { id },
        select: { kitId: true },
      });
      if (!existing) {
        throw new Error('Kit version not found.');
      }

      const illegalChangeRequested =
        input.version !== undefined ||
        input.standardVersionIds !== undefined ||
        input.attributes !== undefined;
      if (illegalChangeRequested) {
        throw new Error('Kit versions are immutable. Create a new version instead of updating.');
      }

      if (inputWithLatest.isLatest === undefined) {
        throw new Error(
          'No mutable fields provided. Use setLatestKitVersion to promote a version.'
        );
      }

      await prisma.$transaction(async (tx) => {
        if (inputWithLatest.isLatest === null) {
          throw new Error('isLatest cannot be null.');
        }

        await tx.kitVersion.update({ where: { id }, data: { isLatest: inputWithLatest.isLatest } });

        if (inputWithLatest.isLatest) {
          await updateLatestKitVersionFlags(tx.kitVersion, existing.kitId, id);
        } else {
          await ensureLatestKitVersionExists(tx.kitVersion, existing.kitId);
        }
      });

      const graph = await this.getKitVersion(id);
      return { success: true, kitVersion: graph } satisfies KitVersionMutationResponse;
    } catch (error) {
      logger.error('Failed to update kit version', {
        kitVersionId: id,
        error: error instanceof Error ? error.message : error,
      });
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
        kitVersion: null,
      } satisfies KitVersionMutationResponse;
    }
  },

  async deleteKitVersion(id: string): Promise<KitVersionMutationResponse> {
    try {
      const version = await prisma.kitVersion.findUnique({
        where: { id },
        select: { kitId: true, isLatest: true },
      });
      if (!version) {
        throw new Error('Kit version not found.');
      }

      await prisma.$transaction(async (tx) => {
        await tx.kitVersion.delete({ where: { id } });
        await ensureLatestKitVersionExists(tx.kitVersion, version.kitId);
      });

      return { success: true, kitVersion: null } satisfies KitVersionMutationResponse;
    } catch (error) {
      logger.error('Failed to delete kit version', {
        kitVersionId: id,
        error: error instanceof Error ? error.message : error,
      });
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
        kitVersion: null,
      };
    }
  },

  async setLatestKitVersion(id: string): Promise<KitVersionMutationResponse> {
    try {
      const version = await prisma.kitVersion.findUnique({
        where: { id },
        select: { kitId: true },
      });
      if (!version) {
        throw new Error('Kit version not found.');
      }

      await prisma.$transaction(async (tx) => {
        await updateLatestKitVersionFlags(tx.kitVersion, version.kitId, id);
      });

      const graph = await this.getKitVersion(id);
      return { success: true, kitVersion: graph } satisfies KitVersionMutationResponse;
    } catch (error) {
      logger.error('Failed to set latest kit version', {
        kitVersionId: id,
        error: error instanceof Error ? error.message : error,
      });
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
        kitVersion: null,
      };
    }
  },

  async linkStandardVersion(kitVersionId: string, standardVersionId: string): Promise<boolean> {
    try {
      await validateStandardVersions(prisma.standardVersion, [standardVersionId]);
      await prisma.kitVersionStandardLink.create({
        data: {
          kitVersionId,
          standardVersionId,
        },
      });
      return true;
    } catch (error) {
      logger.error('Failed to link standard version to kit', {
        kitVersionId,
        standardVersionId,
        error: error instanceof Error ? error.message : error,
      });
      return false;
    }
  },

  async unlinkStandardVersion(kitVersionId: string, standardVersionId: string): Promise<boolean> {
    try {
      await prisma.kitVersionStandardLink.delete({
        where: { kitVersionId_standardVersionId: { kitVersionId, standardVersionId } },
      });
      return true;
    } catch (error) {
      logger.error('Failed to unlink standard version from kit', {
        kitVersionId,
        standardVersionId,
        error: error instanceof Error ? error.message : error,
      });
      return false;
    }
  },
});
