import type {
  CreateKitInput,
  CreateKitVersionInput,
  FilterInput,
  FilterTokenGroupInput,
  KitCompatibleStandardsInput,
  KitFilterInput,
  KitSortInput,
  UpdateKitInput,
  UpdateKitVersionInput,
} from '@amzn/global-realty-mosaic-graphql-schema';

import type { AuthenticatedUser } from '../../../lib/auth';
import type { KitService } from '../domain/kitService';

interface KitResolverDependencies {
  kitService: KitService;
}

export interface KitResolverContext {
  readonly user: AuthenticatedUser | null;
}

const normalizeStringList = (values?: readonly string[] | null): string[] => {
  if (!values?.length) {
    return [];
  }

  const unique = new Set<string>();
  values.forEach((value) => {
    if (typeof value !== 'string') {
      return;
    }
    const trimmed = value.trim();
    if (trimmed.length) {
      unique.add(trimmed);
    }
  });

  return Array.from(unique);
};

const appendToken = (
  tokens: FilterTokenGroupInput[],
  propertyKey: FilterTokenGroupInput['propertyKey'],
  operator: FilterTokenGroupInput['operator'],
  values: string[]
): void => {
  if (!values.length) {
    return;
  }

  tokens.push({ propertyKey, operator, values });
};

const buildKitFilterTokens = (filter?: KitFilterInput | null): FilterTokenGroupInput[] => {
  if (!filter) {
    return [];
  }

  const tokens: FilterTokenGroupInput[] = [];

  appendToken(tokens, 'name', 'CONTAINS', normalizeStringList(filter.nameContains));
  appendToken(tokens, 'description', 'CONTAINS', normalizeStringList(filter.descriptionContains));
  appendToken(tokens, 'region', 'EQUALS', normalizeStringList(filter.regionIn));
  appendToken(tokens, 'program', 'EQUALS', normalizeStringList(filter.programIn));
  appendToken(tokens, 'useCase', 'EQUALS', normalizeStringList(filter.useCaseIn));

  return tokens;
};

const SORT_FIELD_MAP: Record<
  NonNullable<KitSortInput['field']>,
  NonNullable<FilterInput['orderBy']>
> = {
  NAME: 'name',
  DESCRIPTION: 'description',
  REGION: 'region',
  PROGRAM: 'program',
  USE_CASE: 'useCase',
  CREATED_AT: 'createdAt',
  UPDATED_AT: 'updatedAt',
};

const buildPublishedKitFilterInput = ({
  filter,
  sort,
  pageIdx,
  pageSize,
}: {
  filter?: KitFilterInput | null;
  sort?: KitSortInput | null;
  pageIdx: number;
  pageSize: number;
}): FilterInput => {
  const sanitizedPageIdx = Number.isFinite(pageIdx) ? Math.max(0, Math.floor(pageIdx)) : 0;
  const sanitizedPageSize = Number.isFinite(pageSize) ? Math.max(1, Math.floor(pageSize)) : 10;

  const sortField = sort?.field ? (SORT_FIELD_MAP[sort.field] ?? 'createdAt') : 'createdAt';
  const orderDesc = Boolean(sort?.descending);

  const tokenGroups = buildKitFilterTokens(filter);

  return {
    pageIdx: sanitizedPageIdx,
    limit: sanitizedPageSize,
    orderBy: sortField,
    orderDesc,
    query: tokenGroups.length
      ? {
          operation: 'AND',
          tokenGroups,
        }
      : undefined,
  } satisfies FilterInput;
};

export interface KitResolverMap {
  Query: {
    searchKits: (
      parent: unknown,
      args: { filter: FilterInput }
    ) => ReturnType<KitService['search']>;
    searchPublishedKits: (
      parent: unknown,
      args: { filter: FilterInput }
    ) => ReturnType<KitService['searchPublishedKits']>;
    kit: (parent: unknown, args: { id: string }) => ReturnType<KitService['getKit']>;
    kitByName: (parent: unknown, args: { name: string }) => ReturnType<KitService['getKitByName']>;
    kitVersion: (parent: unknown, args: { id: string }) => ReturnType<KitService['getKitVersion']>;
    kitVersions: (
      parent: unknown,
      args: { kitId: string }
    ) => ReturnType<KitService['listKitVersions']>;
    isKitNameAvailable: (
      parent: unknown,
      args: { name: string }
    ) => ReturnType<KitService['isKitNameAvailable']>;
    kitOptions: (
      parent: unknown,
      args: Record<string, never>
    ) => ReturnType<KitService['kitOptions']>;
    kitCompatibleStandards: (
      parent: unknown,
      args: { input: KitCompatibleStandardsInput }
    ) => ReturnType<KitService['kitCompatibleStandards']>;
    publishedKits: (
      parent: unknown,
      args: {
        filter?: KitFilterInput | null;
        sort?: KitSortInput | null;
        pageIdx: number;
        pageSize: number;
      }
    ) => ReturnType<KitService['search']>;
  };
  Mutation: {
    createKit: (
      parent: unknown,
      args: { input: CreateKitInput },
      context: KitResolverContext
    ) => ReturnType<KitService['createKit']>;
    updateKit: (
      parent: unknown,
      args: { id: string; input: UpdateKitInput }
    ) => ReturnType<KitService['updateKit']>;
    deleteKit: (parent: unknown, args: { id: string }) => ReturnType<KitService['deleteKit']>;
    createKitVersion: (
      parent: unknown,
      args: { kitId: string; input: CreateKitVersionInput }
    ) => ReturnType<KitService['createKitVersion']>;
    updateKitVersion: (
      parent: unknown,
      args: { id: string; input: UpdateKitVersionInput }
    ) => ReturnType<KitService['updateKitVersion']>;
    deleteKitVersion: (
      parent: unknown,
      args: { id: string }
    ) => ReturnType<KitService['deleteKitVersion']>;
    setLatestKitVersion: (
      parent: unknown,
      args: { id: string }
    ) => ReturnType<KitService['setLatestKitVersion']>;
    linkStandardToKit: (
      parent: unknown,
      args: { kitVersionId: string; standardVersionId: string }
    ) => ReturnType<KitService['linkStandardVersion']>;
    unlinkStandardFromKit: (
      parent: unknown,
      args: { kitVersionId: string; standardVersionId: string }
    ) => ReturnType<KitService['unlinkStandardVersion']>;
  };
}

export const createKitResolvers = ({ kitService }: KitResolverDependencies): KitResolverMap => ({
  Query: {
    searchKits: (_, { filter }) => kitService.search(filter),
    searchPublishedKits: (_, { filter }) => kitService.searchPublishedKits(filter),
    kit: (_, { id }) => kitService.getKit(id),
    kitByName: (_, { name }) => kitService.getKitByName(name),
    kitVersion: (_, { id }) => kitService.getKitVersion(id),
    kitVersions: (_, { kitId }) => kitService.listKitVersions(kitId),
    isKitNameAvailable: (_, { name }) => kitService.isKitNameAvailable(name),
    kitOptions: (_, __) => kitService.kitOptions(),
    kitCompatibleStandards: (_, { input }) => kitService.kitCompatibleStandards(input),
    publishedKits: (_, args) => kitService.search(buildPublishedKitFilterInput(args)),
  },
  Mutation: {
    createKit: (_, { input }, context) => kitService.createKit(input, context.user),
    updateKit: (_, { id, input }) => kitService.updateKit(id, input),
    deleteKit: (_, { id }) => kitService.deleteKit(id),
    createKitVersion: (_, { kitId, input }) => kitService.createKitVersion(kitId, input),
    updateKitVersion: (_, { id, input }) => kitService.updateKitVersion(id, input),
    deleteKitVersion: (_, { id }) => kitService.deleteKitVersion(id),
    setLatestKitVersion: (_, { id }) => kitService.setLatestKitVersion(id),
    linkStandardToKit: (_, { kitVersionId, standardVersionId }) =>
      kitService.linkStandardVersion(kitVersionId, standardVersionId),
    unlinkStandardFromKit: (_, { kitVersionId, standardVersionId }) =>
      kitService.unlinkStandardVersion(kitVersionId, standardVersionId),
  },
});
