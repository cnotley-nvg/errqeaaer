import type { ServerResponse } from 'node:http';

export const text = (res: ServerResponse, statusCode: number, message: string) => {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.end(message);
};

export const endBinary = (
  res: ServerResponse,
  statusCode: number,
  payload: Buffer,
  headers: Record<string, string> = {}
) => {
  res.statusCode = statusCode;
  for (const [key, value] of Object.entries(headers)) {
    res.setHeader(key, value);
  }
  res.end(payload);
};

export const endText = (
  res: ServerResponse,
  statusCode: number,
  payload: string,
  headers: Record<string, string> = {}
) => {
  res.statusCode = statusCode;
  for (const [key, value] of Object.entries(headers)) {
    res.setHeader(key, value);
  }
  res.end(payload);
};
