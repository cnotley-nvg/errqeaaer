import type { IncomingMessage, ServerResponse } from 'node:http';
import type { URL } from 'node:url';

export interface RouteContext {
  req: IncomingMessage;
  res: ServerResponse;
  url: URL;
}
