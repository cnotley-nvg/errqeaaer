const stripApiPrefix = (pathname: string): string =>
  pathname.startsWith('/api/') ? pathname.slice(4) : pathname;

export const isMatchmakerReportRoute = (pathname: string) =>
  stripApiPrefix(pathname) === '/matchmaker/report';

export const isMatchmakerAssetRoute = (pathname: string) =>
  stripApiPrefix(pathname) === '/matchmaker/asset';
