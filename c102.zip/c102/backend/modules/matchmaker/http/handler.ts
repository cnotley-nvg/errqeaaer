import type { IncomingMessage, ServerResponse } from 'node:http';
import { URL } from 'node:url';
import { basename } from 'node:path';

import type { BackendRuntimeConfig } from '../../../config/runtimeConfig';
import type { Logger } from '../../../shared';
import type { MatchmakerService } from '../infra/matchmakerService';

import { isMatchmakerAssetRoute, isMatchmakerReportRoute } from './routing';
import { endBinary, endText, text } from './responseWriter';
import type { RouteContext } from './types';

const toRouteContext = (
  req: IncomingMessage,
  res: ServerResponse,
  config: BackendRuntimeConfig
): RouteContext | null => {
  if (!req.url || !req.method) {
    return null;
  }

  const base = config.server.publicBaseUrl || `http://localhost:${config.server.port}`;
  const url = new URL(req.url, base);
  return { req, res, url };
};

type AssetKeyValidation = { ok: true } | { ok: false; reason: string };

const validateAssetKey = (rawKey: string): AssetKeyValidation => {
  const key = (rawKey ?? '').trim();

  if (!key) return { ok: false, reason: 'empty' };
  if (key.startsWith('/') || key.startsWith('\\')) return { ok: false, reason: 'absolute-path' };
  if (key.includes(':')) return { ok: false, reason: 'contains-scheme' };
  if (key.length > 2048) return { ok: false, reason: 'too-long' };
  if (key.includes('..')) return { ok: false, reason: 'path-traversal' };

  const ok = /^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/.test(key);
  return ok ? { ok: true } : { ok: false, reason: 'invalid-characters' };
};

const describeKeyForLogs = (key: string) => {
  const raw = key;
  const trimmed = key.trim();
  const badChars: Array<{ index: number; codePoint: number; char: string }> = [];

  for (let i = 0; i < key.length; i += 1) {
    const code = key.charCodeAt(i);
    if (code <= 0x1f || code === 0x7f) {
      badChars.push({ index: i, codePoint: code, char: String.fromCharCode(code) });
    }
  }

  return {
    raw,
    rawJson: JSON.stringify(raw),
    trimmed,
    trimmedJson: JSON.stringify(trimmed),
    rawLength: raw.length,
    trimmedLength: trimmed.length,
    badChars,
  };
};

export const createMatchmakerHttpHandler = (
  config: BackendRuntimeConfig,
  logger: Logger,
  matchmakerService: MatchmakerService
) => {
  return async (req: IncomingMessage, res: ServerResponse): Promise<boolean> => {
    const context = toRouteContext(req, res, config);
    if (!context) {
      return false;
    }

    if (context.req.method !== 'GET') {
      return false;
    }

    if (isMatchmakerReportRoute(context.url.pathname)) {
      const templateId = context.url.searchParams.get('templateId') ?? '';
      if (!templateId) {
        text(context.res, 404, 'Report not found');
        return true;
      }

      try {
        const report = await matchmakerService.getReportHtml(templateId);
        if (!report) {
          text(context.res, 404, 'Report not found');
          return true;
        }

        endText(context.res, 200, report, {
          'Content-Type': 'text/html; charset=utf-8',
          'Content-Disposition': `inline; filename="${templateId}.html"`,
          'Cache-Control': 'no-store',
        });
        return true;
      } catch (error) {
        logger.warn('Failed to serve matchmaker report', {
          error: error instanceof Error ? error.message : String(error),
          templateId,
        });
        text(context.res, 502, 'Unable to serve report');
        return true;
      }
    }

    if (isMatchmakerAssetRoute(context.url.pathname)) {
      const rawKey = context.url.searchParams.get('key') ?? '';
      const key = rawKey.trim();
      const validation = validateAssetKey(rawKey);
      const unsafeReason = validation.ok ? undefined : validation.reason;

      logger.info('Matchmaker asset request', {
        pathname: context.url.pathname,
        query: context.url.search,
        ...describeKeyForLogs(rawKey),
        isSafe: validation.ok,
        unsafeReason,
      });

      if (!validation.ok) {
        logger.warn('Matchmaker asset request rejected (unsafe key)', {
          rawKey,
          unsafeReason,
        });
        text(context.res, 404, 'Not found');
        return true;
      }

      try {
        const asset = await matchmakerService.getAsset(key);
        if (!asset) {
          logger.warn('Matchmaker asset not found (S3 lookup returned null)', { rawKey: key });
          text(context.res, 404, 'Not found');
          return true;
        }

        logger.info('Matchmaker asset served', {
          rawKey: key,
          contentType: asset.contentType,
          sizeBytes: asset.body?.byteLength,
        });
        endBinary(context.res, 200, asset.body, {
          'Content-Type': asset.contentType || 'application/octet-stream',
          'Content-Disposition': `inline; filename="${basename(key)}"`,
          'Cache-Control': 'no-store',
        });
        return true;
      } catch (error) {
        logger.warn('Failed to serve matchmaker asset', {
          error: error instanceof Error ? error.message : String(error),
          key,
        });
        text(context.res, 502, 'Unable to serve asset');
        return true;
      }
    }

    return false;
  };
};
