import type { Logger } from '../../shared';
import { ensureLogger } from '../../shared';
import type { BackendRuntimeConfig } from '../../config/runtimeConfig';
import { createMatchmakerService, type MatchmakerService } from './infra/matchmakerService';
import { createMatchmakerResolvers, type MatchmakerResolverMap } from './graphql/resolvers';

export interface MatchmakerModule {
  resolvers: MatchmakerResolverMap;
  service: MatchmakerService;
}

export interface CreateMatchmakerModuleArgs {
  logger: Logger;
  config: BackendRuntimeConfig;
}

export const createMatchmakerModule = ({
  logger,
  config,
}: CreateMatchmakerModuleArgs): MatchmakerModule => {
  const moduleLogger = ensureLogger(logger, 'matchmaker-module').child({ module: 'matchmaker' });

  const service = createMatchmakerService(config, moduleLogger.child({ component: 'service' }));
  const resolvers = createMatchmakerResolvers({ service });

  return {
    resolvers,
    service,
  };
};
