import type {
  DesignGeneratorAlternative,
  DesignGeneratorInput,
  DesignGeneratorBaselineThroughput,
} from '@amzn/global-realty-mosaic-graphql-schema';

import type { MatchmakerService } from '../infra/matchmakerService';

interface MatchmakerResolverDependencies {
  service: MatchmakerService;
}

export interface MatchmakerResolverMap {
  Query: {
    designGeneratorAlternatives: (
      parent: unknown,
      args: { input: DesignGeneratorInput }
    ) => Promise<DesignGeneratorAlternative[]>;
    designGeneratorBaselineThroughput: (
      parent: unknown,
      args: { program: import('@amzn/global-realty-mosaic-graphql-schema').DesignGeneratorProgram }
    ) => Promise<DesignGeneratorBaselineThroughput | null>;
  };
}

export const createMatchmakerResolvers = ({
  service,
}: MatchmakerResolverDependencies): MatchmakerResolverMap => ({
  Query: {
    designGeneratorAlternatives: async (_parent, { input }) => service.listAlternatives(input),
    designGeneratorBaselineThroughput: async (_parent, { program }) =>
      service.getBaselineThroughput(program),
  },
});
