import { basename } from 'node:path';
import { Readable } from 'node:stream';

import { load as yamlLoad } from 'js-yaml';

import type {
  DesignGeneratorAlternative,
  DesignGeneratorInput,
  DesignGeneratorProgram,
  DesignGeneratorRegion,
  DesignGeneratorBaselineThroughput,
  DesignGeneratorThroughputUnits,
} from '@amzn/global-realty-mosaic-graphql-schema';
import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';

import type { BackendRuntimeConfig } from '../../../config/runtimeConfig';
import type { Logger } from '../../../shared';

type Catalog = {
  templates?: Record<
    string,
    {
      design?: Record<string, CatalogEntry>;
      pareto?: Record<string, CatalogEntry>;
    }
  >;
};

type CatalogEntry = {
  template_id?: string;
  facility_type?: string;
  template_type?: string;
  template_area?: number;
  throughput?: number;
  baseline?: unknown;
  throughput_units?: unknown;
  template_path?: string;
  visualization_path?: string[];
  report_path?: string;
  design_type?: string;
  region?: string;
};

const clampInt = (value: unknown, fallback: number): number => {
  const n = typeof value === 'number' ? value : Number(value);
  if (!Number.isFinite(n)) {
    return fallback;
  }
  return Math.max(0, Math.floor(n));
};

const normalizePercent = (range: DesignGeneratorInput['throughputRange']): number | null => {
  switch (range) {
    case 'PLUS_MINUS_10':
      return 0.1;
    case 'PLUS_MINUS_25':
      return 0.25;
    case 'PLUS_MINUS_50':
      return 0.5;
    default:
      return null;
  }
};

const programToFacilityKey = (program: DesignGeneratorProgram): string => {
  switch (program) {
    case 'IXD':
      return 'ixd';
    case 'SSD':
      return 'ssd';
    case 'ARS':
      return 'ars';
    default:
      return String(program).toLowerCase();
  }
};

// Display labels aligned with the frontend Program dropdown.
const programToDisplayLabel = (program: DesignGeneratorProgram): string => {
  switch (program) {
    case 'IXD':
      return 'IXD GEN 5';
    case 'ARS':
      return 'ARS GEN 14';
    case 'SSD':
      return 'SSD FC';
    default:
      return String(program).toUpperCase();
  }
};

const formatCompactThroughput = (value: unknown): string | null => {
  const n = typeof value === 'number' ? value : Number(value);
  if (!Number.isFinite(n)) {
    return null;
  }

  const abs = Math.abs(n);
  const withSuffix = (divisor: number, suffix: string) => {
    const raw = n / divisor;
    const fixed = raw.toFixed(1);
    const trimmed = fixed.endsWith('.0') ? fixed.slice(0, -2) : fixed;
    return `${trimmed}${suffix}`;
  };

  if (abs >= 1_000_000_000) return withSuffix(1_000_000_000, 'B');
  if (abs >= 1_000_000) return withSuffix(1_000_000, 'M');
  if (abs >= 1_000) return withSuffix(1_000, 'K');
  return `${Math.round(n)}`;
};

const isWithin = (value: number, target: number, percent: number | null): boolean => {
  if (!percent) {
    return true;
  }
  const min = target * (1 - percent);
  const max = target * (1 + percent);
  return value >= min && value <= max;
};

const evenlySpacedSample = <T>(items: T[], count: number): T[] => {
  if (count <= 0) {
    return [];
  }
  if (items.length <= count) {
    return items;
  }
  if (count === 1) {
    return [items[0]];
  }
  const lastIdx = items.length - 1;
  const result: T[] = [];
  for (let i = 0; i < count; i += 1) {
    const idx = Math.round((i * lastIdx) / (count - 1));
    result.push(items[idx]);
  }
  return result;
};

const getPath = (obj: any, path: Array<string | number>): any => {
  let cur: any = obj;
  for (const key of path) {
    if (cur == null) {
      return undefined;
    }
    if (typeof key === 'number') {
      if (!Array.isArray(cur) || key < 0 || key >= cur.length) {
        return undefined;
      }
      cur = cur[key];
      continue;
    }
    if (typeof cur !== 'object' || !(key in cur)) {
      return undefined;
    }
    cur = cur[key];
  }
  return cur;
};

const toNumberOrNull = (value: unknown): number | null => {
  const n = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(n) ? n : null;
};

const normalizeBaseline = (value: unknown): boolean => {
  if (typeof value === 'boolean') {
    return value;
  }
  if (typeof value === 'number') {
    return value !== 0;
  }
  if (typeof value === 'string') {
    const upper = value.trim().toUpperCase();
    if (upper === 'YES' || upper === 'TRUE' || upper === '1') {
      return true;
    }
    if (upper === 'NO' || upper === 'FALSE' || upper === '0' || upper === '') {
      return false;
    }
  }
  return false;
};

const normalizeThroughputUnits = (value: unknown): DesignGeneratorThroughputUnits | null => {
  if (typeof value !== 'string') {
    return null;
  }
  const upper = value.trim().toUpperCase();
  if (upper === 'WEEKLY') return 'WEEKLY';
  if (upper === 'DAILY') return 'DAILY';
  return null;
};

export interface MatchmakerService {
  listAlternatives(input: DesignGeneratorInput): Promise<DesignGeneratorAlternative[]>;
  getBaselineThroughput(
    program: DesignGeneratorProgram
  ): Promise<DesignGeneratorBaselineThroughput | null>;
  resolveReportPath(templateId: string): Promise<string | null>;
  getReportHtml(templateId: string): Promise<string | null>;
  getAsset(key: string): Promise<{ body: Buffer; contentType?: string | null } | null>;
}

export const createMatchmakerService = (
  config: BackendRuntimeConfig,
  logger: Logger
): MatchmakerService => {
  const s3 = config.dge?.s3;
  const s3Client = s3?.bucket ? new S3Client({ region: s3.region }) : null;

  const withPrefix = (key: string): string => {
    const prefix = (s3?.prefix ?? '').trim();
    if (!prefix) {
      return key.replace(/^\/+/, '');
    }
    const normalizedPrefix = prefix.endsWith('/') ? prefix : `${prefix}/`;
    return `${normalizedPrefix}${key.replace(/^\/+/, '')}`;
  };

  const streamToBuffer = async (body: any): Promise<Buffer> => {
    if (!body) {
      return Buffer.from('');
    }
    if (Buffer.isBuffer(body)) {
      return body;
    }
    if (typeof body === 'string') {
      return Buffer.from(body);
    }
    const readable: Readable = body instanceof Readable ? body : Readable.from(body as any);
    const chunks: Buffer[] = [];
    await new Promise<void>((resolve, reject) => {
      readable.on('data', (chunk: any) =>
        chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk))
      );
      readable.on('end', () => resolve());
      readable.on('error', reject);
    });
    return Buffer.concat(chunks);
  };

  const getObjectFromS3 = async (
    key: string
  ): Promise<{ body: Buffer; contentType?: string | null } | null> => {
    if (!s3?.bucket) {
      logger.warn('Matchmaker S3 access attempted but DGE_S3_BUCKET is not configured', {
        key,
      });
      return null;
    }
    if (!s3Client) {
      logger.warn(
        'Matchmaker S3 client not initialized (missing region or client creation failed)',
        {
          bucket: s3.bucket,
          region: s3.region,
          key,
        }
      );
      return null;
    }

    const resolvedKey = withPrefix(key);
    logger.info('Fetching matchmaker asset from S3', {
      bucket: s3.bucket,
      region: s3.region,
      prefix: s3.prefix,
      key,
      resolvedKey,
    });

    try {
      const out = await s3Client.send(
        new GetObjectCommand({
          Bucket: s3.bucket,
          Key: resolvedKey,
        })
      );
      const body = await streamToBuffer(out.Body);
      logger.info('Successfully fetched matchmaker asset from S3', {
        bucket: s3.bucket,
        key,
        resolvedKey,
        contentType: out.ContentType ?? null,
        sizeBytes: body.byteLength,
      });
      return { body, contentType: out.ContentType ?? null };
    } catch (error) {
      logger.warn('Failed to read DGE object from S3', {
        bucket: s3.bucket,
        key,
        resolvedKey,
        error: error instanceof Error ? error.message : String(error),
      });
      return null;
    }
  };

  const loadCatalog = async (): Promise<Catalog | null> => {
    try {
      if (!s3?.bucket) {
        logger.warn(
          'DGE S3 bucket not configured; set DGE_S3_BUCKET (and optional DGE_S3_PREFIX / DGE_S3_REGION).'
        );
        return null;
      }
      const obj = await getObjectFromS3('all_designs.json');
      if (!obj) {
        return null;
      }
      return JSON.parse(obj.body.toString('utf-8')) as Catalog;
    } catch (error) {
      logger.warn('Failed to read DGE catalog', {
        error: error instanceof Error ? error.message : String(error),
      });
      return null;
    }
  };

  const flattenDesignEntries = (catalog: Catalog, facilityKey: string): CatalogEntry[] => {
    const byFacility = catalog.templates?.[facilityKey];
    const design = byFacility?.design ?? {};
    return Object.values(design);
  };

  const findEntryByTemplateId = (catalog: Catalog, templateId: string): CatalogEntry | null => {
    const facilities = Object.keys(catalog.templates ?? {});
    for (const facilityKey of facilities) {
      const entries = flattenDesignEntries(catalog, facilityKey);
      const match = entries.find((entry) => entry.template_id === templateId);
      if (match) {
        return match;
      }
    }
    return null;
  };

  const pickSmallestVisualization = (paths: string[] | undefined | null): string | null => {
    const list = (paths ?? []).filter(Boolean);
    if (!list.length) {
      return null;
    }
    const score = (p: string): { floor: number; name: string } => {
      const name = basename(p).toLowerCase();
      const floorMatch = name.match(/floor\\s*(\\d+)/i) ?? name.match(/floor(\\d+)/i);
      const floor = floorMatch ? Number(floorMatch[1]) : Number.POSITIVE_INFINITY;
      return { floor: Number.isFinite(floor) ? floor : Number.POSITIVE_INFINITY, name };
    };
    return list.slice().sort((a, b) => {
      const sa = score(a);
      const sb = score(b);
      if (sa.floor !== sb.floor) return sa.floor - sb.floor;
      if (sa.name.length !== sb.name.length) return sa.name.length - sb.name.length;
      return sa.name.localeCompare(sb.name);
    })[0]!;
  };

  const buildAlternative = async ({
    entry,
    program,
    region,
    catalog,
  }: {
    entry: CatalogEntry;
    program: DesignGeneratorProgram;
    region: DesignGeneratorRegion;
    catalog: Catalog;
  }): Promise<DesignGeneratorAlternative | null> => {
    const templateId = entry.template_id ?? '';
    if (!templateId) {
      return null;
    }
    if (!s3?.bucket) {
      return null;
    }

    const programLabel = programToDisplayLabel(program).toUpperCase();
    const throughputLabel = formatCompactThroughput(entry.throughput);
    const title = (
      throughputLabel ? `${programLabel} - ${throughputLabel}` : programLabel
    ).toUpperCase();
    const throughput = entry.throughput ?? 0;
    const minArea = entry.template_area ?? 0;

    let warehouseAreaSqft: number | null = null;
    let realEstateCostUsd: number | null = null;
    let vcpuUsdPerUnit: number | null = null;
    let utilityDemandAmps: number | null = null;
    let carbonFootprintTco2: number | null = null;
    let seasonalPeakMorningVehPerHr: number | null = null;
    let seasonalPeakEveningVehPerHr: number | null = null;

    let templateUrl: string | null = null;
    const visualizationUrls: string[] = [];

    if (entry.template_path) {
      const yamlObj = await getObjectFromS3(entry.template_path);
      if (yamlObj) {
        try {
          const parsed = yamlLoad(yamlObj.body.toString('utf-8'));
          warehouseAreaSqft = toNumberOrNull(
            getPath(parsed, ['WAREHOUSE_METRICS', 'Total_Warehouse_Area_SqFt'])
          );
          realEstateCostUsd = toNumberOrNull(getPath(parsed, ['COST_METRICS', 'Total Cost']));
          vcpuUsdPerUnit = toNumberOrNull(getPath(parsed, ['COST_METRICS', 'VCPU']));
          utilityDemandAmps = toNumberOrNull(
            getPath(parsed, ['UTILITY_METRICS', 'Total Utility Demand (Amps)'])
          );
          carbonFootprintTco2 = toNumberOrNull(
            getPath(parsed, ['CARBON_METRICS', 'Total Carbon (tCO2)'])
          );
          seasonalPeakMorningVehPerHr = toNumberOrNull(
            getPath(parsed, [
              'TRAFFIC_METRICS',
              'key_metrics',
              'seasonal_peak_day',
              'ite_compliance_peaks',
              'morning',
              'vehicles',
            ])
          );
          seasonalPeakEveningVehPerHr = toNumberOrNull(
            getPath(parsed, [
              'TRAFFIC_METRICS',
              'key_metrics',
              'seasonal_peak_day',
              'operational_peaks',
              'evening',
              'vehicles',
            ])
          );
        } catch (error) {
          logger.warn('Failed to parse DGE YAML from S3; continuing with partial data', {
            templateId,
            error: error instanceof Error ? error.message : String(error),
          });
        }
      }
    }

    const trimmedBase = config.server.publicBaseUrl.replace(/\/$/, '');
    const isLocalhost = trimmedBase.includes('localhost');
    const apiBase = isLocalhost ? trimmedBase : `${trimmedBase}/api`;

    const reportUrl = entry.report_path
      ? `${apiBase}/matchmaker/report?templateId=${encodeURIComponent(templateId)}`
      : null;

    const bestVizKey = pickSmallestVisualization(entry.visualization_path);
    if (bestVizKey) {
      visualizationUrls.push(`${apiBase}/matchmaker/asset?key=${encodeURIComponent(bestVizKey)}`);
    }

    return {
      templateId,
      title,
      region,
      program,
      throughput,
      minRequiredSiteAreaSqft: minArea,
      warehouseAreaSqft,
      realEstateCostUsd,
      vcpuUsdPerUnit,
      utilityDemandAmps,
      carbonFootprintTco2,
      seasonalPeakMorningVehPerHr,
      seasonalPeakEveningVehPerHr,
      links: {
        reportUrl,
        templateUrl,
        visualizationUrls,
      },
    } satisfies DesignGeneratorAlternative;
  };

  return {
    async listAlternatives(input) {
      const catalog = await loadCatalog();
      if (!catalog) {
        return [];
      }

      const facilityKey = programToFacilityKey(input.program);
      const entries = flattenDesignEntries(catalog, facilityKey).filter((entry) => {
        const entryRegion = (entry.region ?? '').toUpperCase();
        const regionMatches = input.region === 'NA' ? entryRegion === 'NA' : true;
        const tp = entry.throughput ?? 0;
        const percent = normalizePercent(input.throughputRange);
        const within = isWithin(tp, input.projectedWeeklyThroughput, percent);
        return regionMatches && within;
      });

      entries.sort((a, b) => (a.throughput ?? 0) - (b.throughput ?? 0));

      const count = Math.max(1, clampInt(input.numberOfAlternatives, 4));
      const sampled = evenlySpacedSample(entries, count);

      const out: DesignGeneratorAlternative[] = [];
      for (const entry of sampled) {
        const candidate = await buildAlternative({
          entry,
          program: input.program,
          region: input.region,
          catalog,
        });
        if (candidate) {
          out.push(candidate);
        }
      }
      return out;
    },

    async getBaselineThroughput(program: DesignGeneratorProgram) {
      const catalog = await loadCatalog();
      if (!catalog) {
        return null;
      }
      const facilityKey = programToFacilityKey(program);
      const entries = flattenDesignEntries(catalog, facilityKey);
      const baselineEntry = entries.find((e) => normalizeBaseline(e.baseline));
      const tp = baselineEntry?.throughput;
      if (!(typeof tp === 'number' && Number.isFinite(tp))) {
        return null;
      }
      const units = normalizeThroughputUnits(baselineEntry?.throughput_units) ?? 'WEEKLY';
      return {
        throughput: tp,
        throughputUnits: units,
      } satisfies DesignGeneratorBaselineThroughput;
    },

    async resolveReportPath(_templateId: string) {
      return null;
    },

    async getReportHtml(templateId: string) {
      const catalog = await loadCatalog();
      if (!catalog) {
        return null;
      }
      const entry = findEntryByTemplateId(catalog, templateId);
      const key = entry?.report_path;
      if (!key) {
        return null;
      }
      const obj = await getObjectFromS3(key);
      return obj ? obj.body.toString('utf-8') : null;
    },

    async getAsset(key: string) {
      if (!s3?.bucket) {
        return null;
      }
      return getObjectFromS3(key);
    },
  };
};
