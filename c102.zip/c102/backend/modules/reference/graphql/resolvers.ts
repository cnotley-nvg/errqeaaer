import type { ReferenceService } from '../domain/referenceService';

interface ReferenceResolverDependencies {
  referenceService: ReferenceService;
}

export interface ReferenceResolverMap {
  Query: {
    attrDefs: () => ReturnType<ReferenceService['listAttrDefs']>;
    units: () => ReturnType<ReferenceService['listUnits']>;
  };
}

export const createReferenceResolvers = ({
  referenceService,
}: ReferenceResolverDependencies): ReferenceResolverMap => ({
  Query: {
    attrDefs: () => referenceService.listAttrDefs(),
    units: () => referenceService.listUnits(),
  },
});
