import type { Logger } from '../../shared';
import { ensureLogger } from '../../shared';
import { createReferenceService, type ReferenceService } from './domain/referenceService';
import { createReferenceResolvers, type ReferenceResolverMap } from './graphql/resolvers';

export interface ReferenceModule {
  resolvers: ReferenceResolverMap;
  service: ReferenceService;
}

export interface CreateReferenceModuleArgs {
  logger: Logger;
}

export const createReferenceModule = ({ logger }: CreateReferenceModuleArgs): ReferenceModule => {
  const moduleLogger = ensureLogger(logger, 'reference-module').child({ module: 'reference-data' });

  const service = createReferenceService(moduleLogger.child({ component: 'service' }));
  const resolvers = createReferenceResolvers({ referenceService: service });

  return {
    resolvers,
    service,
  };
};
