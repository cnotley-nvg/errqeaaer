import type { Prisma } from '@amzn/global-realty-mosaic-prisma-client';

import type { AttrDef, Unit } from '@amzn/global-realty-mosaic-graphql-schema';

const mapDatatype = (datatype: string): AttrDef['datatype'] => {
  switch (datatype) {
    case 'BOOL':
      return 'BOOLEAN';
    case 'NUM':
      return 'NUMERIC';
    case 'INT':
      return 'INT';
    default:
      return 'TEXT';
  }
};

import type { Logger } from '../../../shared';
import { prisma } from '../../../lib/prisma';

const toAttrDefGraph = (
  record: Prisma.AttributeDefinitionGetPayload<{ include: { unitDimension: true } }>
): AttrDef => ({
  id: record.id,
  name: record.name,
  description: record.description ?? null,
  datatype: mapDatatype(record.datatype),
  unitDimensionId: record.unitDimensionId ?? null,
  unitDimension: record.unitDimension
    ? {
        id: record.unitDimension.id,
        code: record.unitDimension.code,
      }
    : null,
  isRequired: record.isRequired,
  isMulti: record.isMulti,
});

const toUnitGraph = (
  record: Prisma.UnitGetPayload<{ include: { unitDimension: true } }>
): Unit => ({
  id: record.id,
  code: record.code,
  symbol: record.symbol,
  factorToSi: Number(record.factorToSi),
  offsetToSi: Number(record.offsetToSi),
  unitDimension: {
    id: record.unitDimension.id,
    code: record.unitDimension.code,
  },
});

export interface ReferenceService {
  listAttrDefs(): Promise<AttrDef[]>;
  listUnits(): Promise<Unit[]>;
}

export const createReferenceService = (_logger: Logger): ReferenceService => ({
  async listAttrDefs(): Promise<AttrDef[]> {
    const records = await prisma.attributeDefinition.findMany({
      orderBy: { name: 'asc' },
      include: { unitDimension: true },
    });

    return records.map(toAttrDefGraph);
  },

  async listUnits(): Promise<Unit[]> {
    const records = await prisma.unit.findMany({
      orderBy: { code: 'asc' },
      include: { unitDimension: true },
    });

    return records.map(toUnitGraph);
  },
});
