import type { BackendRuntimeConfig } from '../../../config/runtimeConfig';
import { ProxyUnavailableError, AccClient, type Logger, ensureLogger } from '../../../shared';

export interface StandardMetadataService {
  getStandardDocumentUrls(
    projectId: string,
    standardId: string
  ): Promise<{ viewerUrl?: string; downloadUrl?: string } | null>;
}

const buildViewerProxyUrl = (config: BackendRuntimeConfig, standardId: string): string => {
  const trimmedBase = config.server.publicBaseUrl.replace(/\/$/, '');
  const encodedId = encodeURIComponent(standardId);
  const isLocalhost = trimmedBase.includes('localhost');
  return isLocalhost
    ? `${trimmedBase}/standards/${encodedId}/viewer`
    : `${trimmedBase}/api/standards/${encodedId}/viewer`;
};

export const createStandardMetadataService = (
  config: BackendRuntimeConfig,
  logger: Logger
): StandardMetadataService => {
  const scopedLogger = ensureLogger(logger, 'standard-metadata-service');

  // Create AccClient once
  const { proxy } = config;
  if (!proxy?.baseUrl) {
    throw new ProxyUnavailableError('ACC proxy configuration missing. Provide ACC_PROXY_BASE_URL.');
  }

  const accClient = new AccClient({
    proxyBaseUrl: proxy.baseUrl,
    requestTimeoutMs: proxy.timeoutMs,
  });

  return {
    async getStandardDocumentUrls(projectId: string, standardId: string) {
      if (!standardId) {
        return null;
      }

      try {
        // Use AccClient to get the download URL in a single optimized call
        const downloadUrl = await accClient.getSignedDownloadUrl(projectId, standardId, {
          disposition: 'attachment',
        });

        const viewerUrl = buildViewerProxyUrl(config, standardId);

        return {
          viewerUrl,
          downloadUrl,
        };
      } catch (error) {
        scopedLogger.warn('Failed to generate document URLs', {
          error: error instanceof Error ? error.message : error,
          projectId,
          standardId,
        });
        throw new ProxyUnavailableError('Failed to generate document URLs.', { cause: error });
      }
    },
  };
};
