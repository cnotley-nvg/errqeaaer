import type {
  CreateStandardInput,
  CreateStandardVersionInput,
  FilterInput,
  UpdateStandardInput,
  UpdateStandardVersionInput,
  StandardVersionKeyItemConnection,
  StandardVersionKeyItemSortInput,
} from '@amzn/global-realty-mosaic-graphql-schema';

import type { StandardService } from '../domain/standardService';
import type { StandardMetadataService } from '../infra/standardMetadataService';
import { prisma } from '../../../lib/prisma';
import { loadAttributes } from '../../shared/attributeStore';

interface StandardsResolverDependencies {
  standardService: StandardService;
  standardMetadataService: StandardMetadataService;
}

export interface StandardsResolverMap {
  Query: {
    searchStandards: (
      parent: unknown,
      args: { filter: FilterInput }
    ) => ReturnType<StandardService['search']>;
    searchLatestStandardVersions: (
      parent: unknown,
      args: { filter: FilterInput }
    ) => ReturnType<StandardService['searchLatestStandardVersions']>;
    standard: (parent: unknown, args: { id: string }) => ReturnType<StandardService['getStandard']>;
    standardByName: (
      parent: unknown,
      args: { name: string }
    ) => ReturnType<StandardService['getStandardByName']>;
    standardVersion: (
      parent: unknown,
      args: { id: string }
    ) => ReturnType<StandardService['getStandardVersion']>;
    standardVersions: (
      parent: unknown,
      args: { standardId: string }
    ) => ReturnType<StandardService['listStandardVersions']>;
    isStandardNameAvailable: (
      parent: unknown,
      args: { name: string }
    ) => ReturnType<StandardService['isStandardNameAvailable']>;
    standardsByKitVersion: (
      parent: unknown,
      args: { kitVersionId: string }
    ) => ReturnType<StandardService['listStandardsByKitVersion']>;
    standardDocumentLinks: (
      parent: unknown,
      args: { standardVersionId: string }
    ) => Promise<Awaited<ReturnType<StandardMetadataService['getStandardDocumentUrls']>>>;
    standardMetadata: (
      parent: unknown,
      args: { standardVersionId: string }
    ) => Promise<
      Array<{
        id: string;
        title: string;
        fields: Array<{ key: string; label: string; value: string }>;
      }>
    >;
    standardVersionChanges: (
      parent: unknown,
      args: { standardVersionId: string }
    ) => ReturnType<StandardService['listStandardVersionChanges']>;
    standardVersionKeyItems: (
      parent: unknown,
      args: { standardVersionId: string; orderBy?: string | null; orderDesc?: boolean | null }
    ) => ReturnType<StandardService['listStandardVersionKeyItems']>;
    standardVersionKeyItemsConnection: (
      parent: unknown,
      args: {
        standardVersionId: string;
        pageIdx: number;
        limit: number;
        sort?: StandardVersionKeyItemSortInput[] | null;
        categoryContains?: string | null;
      }
    ) => ReturnType<StandardService['listStandardVersionKeyItemsConnection']>;
    standardVersionReferences: (
      parent: unknown,
      args: { standardVersionId: string }
    ) => ReturnType<StandardService['listStandardVersionReferences']>;
    standardVersionReferencesConnection: (
      parent: unknown,
      args: {
        standardVersionId: string;
        pageIdx: number;
        limit: number;
        sort?: { field: string; desc?: boolean | null }[] | null;
        nameContains?: string | null;
      }
    ) => ReturnType<StandardService['listStandardVersionReferencesConnection']>;
    standardFilterOptions: (
      parent: unknown,
      args: { fieldName: string }
    ) => ReturnType<StandardService['getFilterOptions']>;
  };
  Mutation: {
    createStandard: (
      parent: unknown,
      args: { input: CreateStandardInput }
    ) => ReturnType<StandardService['createStandard']>;
    updateStandard: (
      parent: unknown,
      args: { id: string; input: UpdateStandardInput }
    ) => ReturnType<StandardService['updateStandard']>;
    deleteStandard: (
      parent: unknown,
      args: { id: string }
    ) => ReturnType<StandardService['deleteStandard']>;
    createStandardVersion: (
      parent: unknown,
      args: { standardId: string; input: CreateStandardVersionInput }
    ) => ReturnType<StandardService['createStandardVersion']>;
    updateStandardVersion: (
      parent: unknown,
      args: { id: string; input: UpdateStandardVersionInput }
    ) => ReturnType<StandardService['updateStandardVersion']>;
    deleteStandardVersion: (
      parent: unknown,
      args: { id: string }
    ) => ReturnType<StandardService['deleteStandardVersion']>;
    setLatestStandardVersion: (
      parent: unknown,
      args: { id: string }
    ) => ReturnType<StandardService['setLatestStandardVersion']>;
  };
}

export const createStandardsResolvers = ({
  standardService,
  standardMetadataService,
}: StandardsResolverDependencies): StandardsResolverMap => ({
  Query: {
    searchStandards: (_, { filter }) => standardService.search(filter),
    searchLatestStandardVersions: (_, { filter }) =>
      standardService.searchLatestStandardVersions(filter),
    standard: (_, { id }) => standardService.getStandard(id),
    standardByName: (_, { name }) => standardService.getStandardByName(name),
    standardVersion: (_, { id }) => standardService.getStandardVersion(id),
    standardVersions: (_, { standardId }) => standardService.listStandardVersions(standardId),
    isStandardNameAvailable: (_, { name }) => standardService.isStandardNameAvailable(name),
    standardsByKitVersion: (_, { kitVersionId }) =>
      standardService.listStandardsByKitVersion(kitVersionId),
    standardDocumentLinks: async (_parent, { standardVersionId }) => {
      const version = await standardService.getStandardVersion(standardVersionId);
      if (!version) {
        return null;
      }

      // Fetch the standard to get projectId
      const standard = await prisma.standard.findUnique({
        where: { id: version.standardId },
      });

      if (!standard) {
        return null;
      }

      return standardMetadataService.getStandardDocumentUrls(
        standard.accProjectId,
        version.accFileId ?? ''
      );
    },
    standardMetadata: async (_parent, { standardVersionId }) => {
      const version = await standardService.getStandardVersion(standardVersionId);
      if (!version) {
        return [];
      }
      const attributes = await loadAttributes(prisma, version.id);
      const fields = Object.entries(attributes).map(([key, value]) => ({
        key,
        label: key,
        value: typeof value === 'object' ? JSON.stringify(value) : String(value),
      }));
      if (!fields.length) {
        return [];
      }
      return [
        {
          id: `standard-metadata-${version.id}`,
          title: 'Standard metadata',
          fields,
        },
      ];
    },
    standardVersionChanges: (_parent, { standardVersionId }) =>
      standardService.listStandardVersionChanges(standardVersionId),
    standardVersionKeyItems: (_parent, { standardVersionId, orderBy, orderDesc }) =>
      standardService.listStandardVersionKeyItems(standardVersionId, orderBy, orderDesc),
    standardVersionKeyItemsConnection: (_parent, args) =>
      standardService.listStandardVersionKeyItemsConnection(
        args.standardVersionId,
        args.pageIdx,
        args.limit,
        args.sort ?? null,
        args.categoryContains ?? null
      ),
    standardVersionReferences: (_parent, { standardVersionId }) =>
      standardService.listStandardVersionReferences(standardVersionId),
    standardVersionReferencesConnection: (_parent, args) =>
      standardService.listStandardVersionReferencesConnection(
        args.standardVersionId,
        args.pageIdx,
        args.limit,
        args.sort ?? null,
        args.nameContains ?? null
      ),
    standardFilterOptions: (_, { fieldName }) => standardService.getFilterOptions(fieldName),
  },
  Mutation: {
    createStandard: (_, { input }) => standardService.createStandard(input),
    updateStandard: (_, { id, input }) => standardService.updateStandard(id, input),
    deleteStandard: (_, { id }) => standardService.deleteStandard(id),
    createStandardVersion: (_, { standardId, input }) =>
      standardService.createStandardVersion(standardId, input),
    updateStandardVersion: (_, { id, input }) => standardService.updateStandardVersion(id, input),
    deleteStandardVersion: (_, { id }) => standardService.deleteStandardVersion(id),
    setLatestStandardVersion: (_, { id }) => standardService.setLatestStandardVersion(id),
  },
});
