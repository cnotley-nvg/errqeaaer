import type { Prisma } from '@amzn/global-realty-mosaic-prisma-client';
import type { FilterInput, FilterTokenGroupInput } from '@amzn/global-realty-mosaic-graphql-schema';

const collectTokenValues = (token: FilterTokenGroupInput): string[] => {
  if (token.values?.length) {
    return token.values.filter(
      (value): value is string => typeof value === 'string' && value.trim().length > 0
    );
  }

  return typeof token.value === 'string' && token.value.trim().length > 0 ? [token.value] : [];
};

const buildStringCondition = (
  field: keyof Prisma.StandardWhereInput,
  operator: FilterTokenGroupInput['operator'],
  values: string[]
): Prisma.StandardWhereInput | null => {
  if (!values.length) {
    return null;
  }

  const equalsFilter = (value: string): Prisma.StandardWhereInput => ({
    [field]: {
      equals: value,
      mode: 'insensitive',
    },
  });

  const containsFilter = (value: string): Prisma.StandardWhereInput => ({
    [field]: {
      contains: value,
      mode: 'insensitive',
    },
  });

  const startsWithFilter = (value: string): Prisma.StandardWhereInput => ({
    [field]: {
      startsWith: value,
      mode: 'insensitive',
    },
  });

  switch (operator) {
    case 'EQUALS':
      return values.length === 1
        ? equalsFilter(values[0]!)
        : { OR: values.map((value) => equalsFilter(value)) };
    case 'NOT_EQUALS':
      return {
        AND: values.map((value) => ({ NOT: equalsFilter(value) })),
      } satisfies Prisma.StandardWhereInput;
    case 'CONTAINS':
      return values.length === 1
        ? containsFilter(values[0]!)
        : { OR: values.map((value) => containsFilter(value)) };
    case 'NOT_CONTAINS':
      return {
        AND: values.map((value) => ({ NOT: containsFilter(value) })),
      } satisfies Prisma.StandardWhereInput;
    case 'STARTS_WITH':
      return values.length === 1
        ? startsWithFilter(values[0]!)
        : { OR: values.map((value) => startsWithFilter(value)) };
    case 'NOT_STARTS_WITH':
      return {
        AND: values.map((value) => ({ NOT: startsWithFilter(value) })),
      } satisfies Prisma.StandardWhereInput;
    default:
      return null;
  }
};

const parseDateValue = (value: string): Date | null => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return null;
  }

  // For date-only fields (@db.Date in Prisma), normalize to UTC midnight
  // This ensures consistent comparison with PostgreSQL DATE fields
  const normalized = new Date(
    Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), 0, 0, 0, 0)
  );

  return normalized;
};

const buildDateCondition = (
  field: 'createdAt' | 'updatedAt',
  operator: FilterTokenGroupInput['operator'],
  values: string[]
): Prisma.StandardWhereInput | null => {
  const [raw] = values;
  if (!raw) {
    return null;
  }

  const parsed = parseDateValue(raw);
  if (!parsed) {
    return null;
  }

  switch (operator) {
    case 'GREATER_THAN':
      return { [field]: { gt: parsed } } as Prisma.StandardWhereInput;
    case 'GREATER_OR_EQUAL':
      return { [field]: { gte: parsed } } as Prisma.StandardWhereInput;
    case 'LESS_THAN':
      return { [field]: { lt: parsed } } as Prisma.StandardWhereInput;
    case 'LESS_OR_EQUAL':
      return { [field]: { lte: parsed } } as Prisma.StandardWhereInput;
    case 'EQUALS':
      return { [field]: { equals: parsed } } as Prisma.StandardWhereInput;
    case 'NOT_EQUALS':
      return { NOT: { [field]: { equals: parsed } } } as Prisma.StandardWhereInput;
    default:
      return null;
  }
};

export const buildWhere = (filter: FilterInput): Prisma.StandardWhereInput => {
  const query = filter.query;
  if (!query?.tokenGroups?.length) {
    return {};
  }

  const conditions = query.tokenGroups
    .map((token) => {
      const values = collectTokenValues(token);
      if (!values.length) {
        return null;
      }

      switch (token.propertyKey) {
        case 'name':
          return buildStringCondition('name', token.operator, values);
        case 'description':
          return buildStringCondition('description', token.operator, values);
        case 'accProjectId':
          return buildStringCondition('accProjectId', token.operator, values);
        case 'createdAt':
          return buildDateCondition('createdAt', token.operator, values);
        case 'updatedAt':
          return buildDateCondition('updatedAt', token.operator, values);
        default:
          return null;
      }
    })
    .filter((condition): condition is Prisma.StandardWhereInput => condition !== null);

  if (!conditions.length) {
    return {};
  }

  return query.operation === 'AND'
    ? ({ AND: conditions } satisfies Prisma.StandardWhereInput)
    : ({ OR: conditions } satisfies Prisma.StandardWhereInput);
};

export const buildOrderBy = (filter: FilterInput): Prisma.StandardOrderByWithRelationInput => {
  const direction: Prisma.SortOrder = filter.orderDesc ? 'desc' : 'asc';

  switch (filter.orderBy) {
    case 'name':
      return { name: direction };
    case 'accProjectId':
      return { accProjectId: direction };
    case 'updatedAt':
      return { updatedAt: direction };
    case 'createdAt':
      return { createdAt: direction };
    default:
      return { createdAt: 'desc' };
  }
};

// ============================================================================
// StandardVersion Filtering (for searchLatestStandardVersions)
// ============================================================================

const buildStandardVersionStringCondition = (
  field: keyof Prisma.StandardVersionWhereInput,
  operator: FilterTokenGroupInput['operator'],
  values: string[]
): Prisma.StandardVersionWhereInput | null => {
  if (!values.length) {
    return null;
  }

  const equalsFilter = (value: string): Prisma.StandardVersionWhereInput => ({
    [field]: {
      equals: value,
      mode: 'insensitive',
    },
  });

  const containsFilter = (value: string): Prisma.StandardVersionWhereInput => ({
    [field]: {
      contains: value,
      mode: 'insensitive',
    },
  });

  const startsWithFilter = (value: string): Prisma.StandardVersionWhereInput => ({
    [field]: {
      startsWith: value,
      mode: 'insensitive',
    },
  });

  switch (operator) {
    case 'EQUALS':
      return values.length === 1
        ? equalsFilter(values[0]!)
        : { OR: values.map((value) => equalsFilter(value)) };
    case 'NOT_EQUALS':
      return {
        AND: values.map((value) => ({ NOT: equalsFilter(value) })),
      } satisfies Prisma.StandardVersionWhereInput;
    case 'CONTAINS':
      return values.length === 1
        ? containsFilter(values[0]!)
        : { OR: values.map((value) => containsFilter(value)) };
    case 'NOT_CONTAINS':
      return {
        AND: values.map((value) => ({ NOT: containsFilter(value) })),
      } satisfies Prisma.StandardVersionWhereInput;
    case 'STARTS_WITH':
      return values.length === 1
        ? startsWithFilter(values[0]!)
        : { OR: values.map((value) => startsWithFilter(value)) };
    case 'NOT_STARTS_WITH':
      return {
        AND: values.map((value) => ({ NOT: startsWithFilter(value) })),
      } satisfies Prisma.StandardVersionWhereInput;
    default:
      return null;
  }
};

const buildStandardVersionDateCondition = (
  field:
    | 'createdAt'
    | 'updatedAt'
    | 'accCreatedAt'
    | 'accUpdatedAt'
    | 'publishedOn'
    | 'firstPublishedOn',
  operator: FilterTokenGroupInput['operator'],
  values: string[]
): Prisma.StandardVersionWhereInput | null => {
  const [raw] = values;
  if (!raw) {
    return null;
  }

  const parsed = parseDateValue(raw);
  if (!parsed) {
    return null;
  }

  switch (operator) {
    case 'GREATER_THAN':
      return { [field]: { gt: parsed } } as Prisma.StandardVersionWhereInput;
    case 'GREATER_OR_EQUAL':
      return { [field]: { gte: parsed } } as Prisma.StandardVersionWhereInput;
    case 'LESS_THAN':
      return { [field]: { lt: parsed } } as Prisma.StandardVersionWhereInput;
    case 'LESS_OR_EQUAL':
      return { [field]: { lte: parsed } } as Prisma.StandardVersionWhereInput;
    case 'EQUALS':
      return { [field]: { equals: parsed } } as Prisma.StandardVersionWhereInput;
    case 'NOT_EQUALS':
      return { NOT: { [field]: { equals: parsed } } } as Prisma.StandardVersionWhereInput;
    default:
      return null;
  }
};

export const buildStandardVersionWhere = (
  filter: FilterInput
): Prisma.StandardVersionWhereInput => {
  const query = filter.query;
  if (!query?.tokenGroups?.length) {
    return {};
  }

  const conditions = query.tokenGroups
    .map((token) => {
      const values = collectTokenValues(token);
      if (!values.length) {
        return null;
      }

      switch (token.propertyKey) {
        // StandardVersion direct fields
        case 'version':
          return buildStandardVersionStringCondition('version', token.operator, values);
        case 'accCreatedBy':
          return buildStandardVersionStringCondition('accCreatedBy', token.operator, values);
        case 'accUpdatedBy':
          return buildStandardVersionStringCondition('accUpdatedBy', token.operator, values);
        case 'accCreatedAt':
          return buildStandardVersionDateCondition('accCreatedAt', token.operator, values);
        case 'accUpdatedAt':
          return buildStandardVersionDateCondition('accUpdatedAt', token.operator, values);
        case 'publishedOn':
          return buildStandardVersionDateCondition('publishedOn', token.operator, values);
        case 'firstPublishedOn':
          return buildStandardVersionDateCondition('firstPublishedOn', token.operator, values);
        case 'createdAt':
          return buildStandardVersionDateCondition('createdAt', token.operator, values);
        case 'updatedAt':
          return buildStandardVersionDateCondition('updatedAt', token.operator, values);

        // Standard fields (accessed via relation)
        case 'name':
          return { standard: buildStringCondition('name', token.operator, values) };
        case 'description':
          return { standard: buildStringCondition('description', token.operator, values) };
        case 'accProjectId':
          return { standard: buildStringCondition('accProjectId', token.operator, values) };

        default:
          // Attribute-based filters will be handled in-memory
          return null;
      }
    })
    .filter((condition): condition is Prisma.StandardVersionWhereInput => condition !== null);

  if (!conditions.length) {
    return {};
  }

  return query.operation === 'AND'
    ? ({ AND: conditions } satisfies Prisma.StandardVersionWhereInput)
    : ({ OR: conditions } satisfies Prisma.StandardVersionWhereInput);
};

export const buildStandardVersionOrderBy = (
  filter: FilterInput
): Prisma.StandardVersionOrderByWithRelationInput => {
  const direction: Prisma.SortOrder = filter.orderDesc ? 'desc' : 'asc';

  switch (filter.orderBy) {
    case 'version':
      return { version: direction };
    case 'accCreatedBy':
      return { accCreatedBy: direction };
    case 'accUpdatedBy':
      return { accUpdatedBy: direction };
    case 'accCreatedAt':
      return { accCreatedAt: direction };
    case 'accUpdatedAt':
      return { accUpdatedAt: direction };
    case 'publishedOn':
      return { publishedOn: direction };
    case 'firstPublishedOn':
      return { firstPublishedOn: direction };
    case 'createdAt':
      return { createdAt: direction };
    case 'updatedAt':
      return { updatedAt: direction };

    // Standard fields (via relation)
    case 'name':
      return { standard: { name: direction } };
    case 'accProjectId':
      return { standard: { accProjectId: direction } };

    default:
      return { createdAt: 'desc' };
  }
};

export const standardFilterInternals = {
  collectTokenValues,
  buildStringCondition,
  buildDateCondition,
  parseDateValue,
};
