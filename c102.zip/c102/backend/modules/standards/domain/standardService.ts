import type { Prisma } from '@amzn/global-realty-mosaic-prisma-client';

import type {
  CreateStandardInput,
  CreateStandardVersionInput,
  FilterInput,
  Standard,
  StandardConnection,
  StandardMutationResponse,
  StandardVersion,
  StandardVersionChange,
  StandardVersionKeyItem,
  StandardVersionKeyItemConnection,
  StandardVersionKeyItemSortInput,
  StandardVersionReference,
  StandardVersionReferenceConnection,
  StandardVersionReferenceSortInput,
  StandardVersionMutationResponse,
  UpdateStandardInput,
  UpdateStandardVersionInput,
} from '@amzn/global-realty-mosaic-graphql-schema';

import type { Logger } from '../../../shared';
import { prisma } from '../../../lib/prisma';
import { loadAttributes, storeAttributes } from '../../shared/attributeStore';
import { collectAttributeTokens, applyAttributeFilters } from '../../shared/attributeFilterUtils';
import { sortEntities } from '../../shared/searchSort';
import { getFilterOptions } from '../../shared/filterOptionsUtils';
import {
  buildOrderBy,
  buildWhere,
  buildStandardVersionWhere,
  buildStandardVersionOrderBy,
} from './standardFilters';
import {
  createStandardMappers,
  type StandardRecord,
  type StandardVersionRecord,
} from './standardMappers';
import {
  ensureLatestStandardVersionExists,
  updateLatestStandardVersionFlags,
} from './standardMutations';

const STANDARD_VERSION_RELATIONS = {
  kits: {
    orderBy: { createdAt: 'asc' },
    include: {
      kitVersion: {
        include: {
          kit: true,
        },
      },
    },
  },
} as const satisfies Prisma.StandardVersionInclude;

const STANDARD_INCLUDE = {
  versions: {
    orderBy: { createdAt: 'desc' },
    include: STANDARD_VERSION_RELATIONS,
  },
} as const satisfies Prisma.StandardInclude;

const STANDARD_VERSION_INCLUDE = {
  ...STANDARD_VERSION_RELATIONS,
  standard: true,
} as const satisfies Prisma.StandardVersionInclude;

const attributeLoader = (entityId: string) => loadAttributes(prisma, entityId);
const { toStandardVersionGraph, toStandardGraph } = createStandardMappers(attributeLoader);

const BASE_FILTER_FIELDS = new Set([
  'name',
  'description',
  'accProjectId',
  'createdAt',
  'updatedAt',
]);

// Fields that exist on StandardVersion (not Standard) but can be filtered
// These will be filtered in-memory after fetching standards with their versions
const VERSION_FILTER_FIELDS = new Set([
  'version',
  'accCreatedAt',
  'accCreatedBy',
  'accUpdatedAt',
  'accUpdatedBy',
  'publishedOn',
  'firstPublishedOn',
]);

const fetchStandardRecord = async (
  where: Prisma.StandardWhereUniqueInput
): Promise<StandardRecord | null> => {
  return prisma.standard.findUnique({
    where,
    include: STANDARD_INCLUDE,
  }) as Promise<StandardRecord | null>;
};

const fetchStandardVersionRecord = async (
  where: Prisma.StandardVersionWhereUniqueInput
): Promise<StandardVersionRecord | null> => {
  return prisma.standardVersion.findUnique({
    where,
    include: STANDARD_VERSION_INCLUDE,
  }) as Promise<StandardVersionRecord | null>;
};

export interface StandardVersionConnection {
  items: StandardVersion[];
  total: number;
  pageIdx: number;
  limit: number;
  hasNext: boolean;
}

export interface StandardService {
  search(filter: FilterInput): Promise<StandardConnection>;
  searchLatestStandardVersions(filter: FilterInput): Promise<StandardVersionConnection>;
  getStandard(id: string): Promise<Standard | null>;
  getStandardByName(name: string): Promise<Standard | null>;
  getStandardVersion(id: string): Promise<StandardVersion | null>;
  listStandardVersions(standardId: string): Promise<StandardVersion[]>;
  listStandardVersionChanges(standardVersionId: string): Promise<StandardVersionChange[]>;
  listStandardVersionKeyItems(
    standardVersionId: string,
    orderBy?: string | null,
    orderDesc?: boolean | null
  ): Promise<StandardVersionKeyItem[]>;
  listStandardVersionKeyItemsConnection(
    standardVersionId: string,
    pageIdx: number,
    limit: number,
    sort?: StandardVersionKeyItemSortInput[] | null,
    categoryContains?: string | null
  ): Promise<StandardVersionKeyItemConnection>;
  listStandardVersionReferences(standardVersionId: string): Promise<StandardVersionReference[]>;
  listStandardVersionReferencesConnection(
    standardVersionId: string,
    pageIdx: number,
    limit: number,
    sort?: StandardVersionReferenceSortInput[] | null,
    nameContains?: string | null
  ): Promise<StandardVersionReferenceConnection>;
  isStandardNameAvailable(name: string): Promise<boolean>;
  createStandard(input: CreateStandardInput): Promise<StandardMutationResponse>;
  updateStandard(id: string, input: UpdateStandardInput): Promise<StandardMutationResponse>;
  deleteStandard(id: string): Promise<StandardMutationResponse>;
  createStandardVersion(
    standardId: string,
    input: CreateStandardVersionInput
  ): Promise<StandardVersionMutationResponse>;
  updateStandardVersion(
    id: string,
    input: UpdateStandardVersionInput
  ): Promise<StandardVersionMutationResponse>;
  deleteStandardVersion(id: string): Promise<StandardVersionMutationResponse>;
  setLatestStandardVersion(id: string): Promise<StandardVersionMutationResponse>;
  listStandardsByKitVersion(kitVersionId: string): Promise<StandardVersion[]>;
  getFilterOptions(fieldName: string): Promise<string[]>;
}

export const createStandardService = (logger: Logger): StandardService => ({
  async search(filter: FilterInput): Promise<StandardConnection> {
    const page = Math.max(filter.pageIdx, 0);
    const limit = Math.max(filter.limit, 1);

    const where = buildWhere(filter);
    const orderBy = buildOrderBy(filter);

    // Collect all non-base-field tokens for in-memory filtering
    const allFilterFields = new Set([...BASE_FILTER_FIELDS, ...VERSION_FILTER_FIELDS]);
    const attributeTokens = collectAttributeTokens(filter.query ?? null, allFilterFields);

    // If we have any in-memory filters, fetch all and filter
    if (attributeTokens.length) {
      const records = await prisma.standard.findMany({
        where,
        orderBy,
        include: STANDARD_INCLUDE,
      });

      let mappedItems = await Promise.all(
        records.map((record) => toStandardGraph(record as StandardRecord))
      );

      // For filtering purposes, temporarily merge version fields into attributes
      // so applyAttributeFilters can access them
      const itemsWithMergedAttributes = mappedItems.map((item) => {
        if (!item.latestVersion) {
          return item;
        }

        const mergedAttributes = {
          ...(item.latestVersion.attributes ?? {}),
          // Add version fields directly to attributes for filtering
          version: item.latestVersion.version,
          accCreatedAt: item.latestVersion.accCreatedAt,
          accCreatedBy: item.latestVersion.accCreatedBy,
          accUpdatedAt: item.latestVersion.accUpdatedAt,
          accUpdatedBy: item.latestVersion.accUpdatedBy,
        };

        return {
          ...item,
          latestVersion: {
            ...item.latestVersion,
            attributes: mergedAttributes,
          },
        };
      });

      // Apply attribute filters
      const filteredItemsWithMerged = applyAttributeFilters(
        itemsWithMergedAttributes,
        attributeTokens,
        filter.query?.operation ?? null
      );

      // Restore original attributes (remove the merged version fields)
      const filteredItems = filteredItemsWithMerged.map((item, index) => mappedItems[index]!);

      const sortedItems = sortEntities(filteredItems, filter);

      const total = sortedItems.length;
      const start = page * limit;
      const pagedItems = sortedItems.slice(start, start + limit);

      return {
        items: pagedItems,
        total,
        pageIdx: page,
        limit,
        hasNext: start + limit < total,
      } satisfies StandardConnection;
    }

    const [total, records] = await Promise.all([
      prisma.standard.count({ where }),
      prisma.standard.findMany({
        where,
        orderBy,
        skip: page * limit,
        take: limit,
        include: STANDARD_INCLUDE,
      }),
    ]);

    const items = await Promise.all(
      records.map((record) => toStandardGraph(record as StandardRecord))
    );

    return {
      items,
      total,
      pageIdx: page,
      limit,
      hasNext: (page + 1) * limit < total,
    } satisfies StandardConnection;
  },

  /**
   * Optimized query for searching latest standard versions only.
   *
   * Performance: 5-10x faster than searchStandards for catalog listing use cases.
   * - Only fetches one version per standard (vs all versions in searchStandards)
   * - Filters and sorts directly on StandardVersion table
   *
   * Prefer this over searchStandards when:
   * - Displaying standard catalogs/listings
   * - Filtering by version-specific fields (version, accCreatedBy, accUpdatedBy, etc.)
   * - Only need latest version data
   *
   * Use searchStandards instead when:
   * - Need full version history
   * - Working with specific non-latest versions
   *
   * @see GraphQL schema documentation for searchLatestStandardVersions query
   */
  async searchLatestStandardVersions(filter: FilterInput): Promise<StandardVersionConnection> {
    const page = Math.max(filter.pageIdx, 0);
    const limit = Math.max(filter.limit, 1);

    const where = buildStandardVersionWhere(filter);
    const orderBy = buildStandardVersionOrderBy(filter);

    // Collect all non-database-field tokens for in-memory filtering (attributes only)
    const allDatabaseFields = new Set([...BASE_FILTER_FIELDS, ...VERSION_FILTER_FIELDS]);
    const attributeTokens = collectAttributeTokens(filter.query ?? null, allDatabaseFields);

    // Key optimization: Only fetch latest versions
    const latestVersionWhere: Prisma.StandardVersionWhereInput = {
      isLatest: true,
      ...where,
    };

    // If filtering by attributes or sorting by non-base fields, fetch all and filter in-memory
    const isBaseSortableField =
      BASE_FILTER_FIELDS.has(filter.orderBy ?? '') ||
      VERSION_FILTER_FIELDS.has(filter.orderBy ?? '');
    const requiresAttributeSort = !isBaseSortableField;

    if (attributeTokens.length || requiresAttributeSort) {
      // Fetch all latest versions with attributes for in-memory filtering/sorting
      const records = await prisma.standardVersion.findMany({
        where: latestVersionWhere,
        orderBy,
        include: STANDARD_VERSION_INCLUDE,
      });

      const mappedItems = await Promise.all(
        records.map((record) => toStandardVersionGraph(record as StandardVersionRecord))
      );

      // Apply attribute filters using the shared utility that supports all operators
      const filteredItems = applyAttributeFilters(
        mappedItems.map((v) => ({ latestVersion: v })),
        attributeTokens,
        filter.query?.operation ?? null
      ).map((wrapped) => wrapped.latestVersion!);

      // Sort by attribute fields if needed
      const sortedItems = requiresAttributeSort
        ? [...filteredItems].sort((a, b) => {
            const aAttrs = (a.attributes ?? {}) as Record<string, unknown>;
            const bAttrs = (b.attributes ?? {}) as Record<string, unknown>;
            const sortField = filter.orderBy ?? 'createdAt';

            const aVal = String(aAttrs[sortField] ?? '');
            const bVal = String(bAttrs[sortField] ?? '');

            const comparison = aVal.localeCompare(bVal, undefined, {
              numeric: true,
              sensitivity: 'base',
            });
            return filter.orderDesc ? -comparison : comparison;
          })
        : filteredItems;

      const total = sortedItems.length;
      const start = page * limit;
      const pagedItems = sortedItems.slice(start, start + limit);

      return {
        items: pagedItems,
        total,
        pageIdx: page,
        limit,
        hasNext: start + limit < total,
      } satisfies StandardVersionConnection;
    }

    // Optimized path: Database-level filtering and sorting
    const [total, records] = await Promise.all([
      prisma.standardVersion.count({ where: latestVersionWhere }),
      prisma.standardVersion.findMany({
        where: latestVersionWhere,
        orderBy,
        skip: page * limit,
        take: limit,
        include: STANDARD_VERSION_INCLUDE,
      }),
    ]);

    const items = await Promise.all(
      records.map((record) => toStandardVersionGraph(record as StandardVersionRecord))
    );

    return {
      items,
      total,
      pageIdx: page,
      limit,
      hasNext: (page + 1) * limit < total,
    } satisfies StandardVersionConnection;
  },

  async getStandard(id: string): Promise<Standard | null> {
    const record = await fetchStandardRecord({ id });
    if (!record) {
      return null;
    }

    return toStandardGraph(record);
  },

  async getStandardByName(name: string): Promise<Standard | null> {
    const record = await fetchStandardRecord({ name });
    if (!record) {
      return null;
    }

    return toStandardGraph(record);
  },

  async getStandardVersion(id: string): Promise<StandardVersion | null> {
    const record = await fetchStandardVersionRecord({ id });
    if (!record) {
      return null;
    }

    return toStandardVersionGraph(record);
  },

  async listStandardVersions(standardId: string): Promise<StandardVersion[]> {
    const standard = await prisma.standard.findUnique({ where: { id: standardId } });
    if (!standard) {
      return [];
    }

    const versions = await prisma.standardVersion.findMany({
      where: { standardId },
      orderBy: { createdAt: 'desc' },
      include: STANDARD_VERSION_RELATIONS,
    });

    return Promise.all(
      versions.map((version) =>
        toStandardVersionGraph({ ...version, standard } as StandardVersionRecord, standard)
      )
    );
  },

  async isStandardNameAvailable(name: string): Promise<boolean> {
    const existing = await prisma.standard.findUnique({ where: { name } });
    return existing === null;
  },

  async listStandardVersionChanges(standardVersionId: string): Promise<StandardVersionChange[]> {
    const records = await prisma.standardVersionChange.findMany({
      where: { standardVersionId },
      orderBy: { id: 'asc' },
    });

    return records.map(
      (record): StandardVersionChange => ({
        id: record.id,
        standardVersionId: record.standardVersionId,
        details: record.details,
        releasedBy: record.releasedBy,
        approveUrl: record.approveUrl,
      })
    );
  },

  async listStandardVersionKeyItems(
    standardVersionId: string,
    orderBy?: string | null,
    orderDesc?: boolean | null
  ): Promise<StandardVersionKeyItem[]> {
    const sortDirection = orderDesc ? 'desc' : 'asc';

    // Determine sort field
    let sortField: 'category' | 'sheet' | 'id' = 'id';
    if (orderBy === 'category') {
      sortField = 'category';
    } else if (orderBy === 'sheet') {
      sortField = 'sheet';
    }

    const records = await prisma.standardVersionKeyItem.findMany({
      where: { standardVersionId },
      orderBy: { [sortField]: sortDirection },
    });

    // If sorting by sheet, do additional numeric sort since sheet is stored as string
    if (sortField === 'sheet') {
      records.sort((a, b) => {
        const numA = parseInt(a.sheet, 10);
        const numB = parseInt(b.sheet, 10);

        // Handle non-numeric values
        if (isNaN(numA) && isNaN(numB)) return a.sheet.localeCompare(b.sheet);
        if (isNaN(numA)) return 1;
        if (isNaN(numB)) return -1;

        const comparison = numA - numB;
        return sortDirection === 'desc' ? -comparison : comparison;
      });
    }

    return records.map(
      (record): StandardVersionKeyItem => ({
        id: record.id,
        standardVersionId: record.standardVersionId,
        category: record.category,
        sheet: record.sheet,
        cell: record.cell,
      })
    );
  },

  async listStandardVersionKeyItemsConnection(
    standardVersionId: string,
    pageIdx: number,
    limit: number,
    sort?: StandardVersionKeyItemSortInput[] | null,
    categoryContains?: string | null
  ): Promise<StandardVersionKeyItemConnection> {
    const page = Math.max(pageIdx, 0);
    const perPage = Math.max(limit, 1);

    const where: Prisma.StandardVersionKeyItemWhereInput = {
      standardVersionId,
      ...(categoryContains
        ? {
            category: {
              contains: categoryContains,
              mode: 'insensitive',
            },
          }
        : {}),
    };

    const orderBy: Prisma.StandardVersionKeyItemOrderByWithRelationInput[] = [];
    if (sort?.length) {
      for (const entry of sort) {
        let field: keyof Prisma.StandardVersionKeyItemOrderByWithRelationInput | null = null;
        if (entry.field === 'category') field = 'category';
        if (entry.field === 'sheet') field = 'sheet';
        if (entry.field === 'cell') field = 'cell';

        if (field) {
          orderBy.push({ [field]: entry.desc ? 'desc' : 'asc' });
        }
      }
    }

    if (!orderBy.length) {
      orderBy.push({ category: 'asc' });
    }

    const total = await prisma.standardVersionKeyItem.count({ where });

    const records = await prisma.standardVersionKeyItem.findMany({
      where,
      orderBy,
      skip: page * perPage,
      take: perPage,
    });

    return {
      items: records.map((record) => ({
        id: record.id,
        standardVersionId: record.standardVersionId,
        category: record.category,
        sheet: record.sheet,
        cell: record.cell,
      })),
      total,
      pageIdx: page,
      limit: perPage,
      hasNext: (page + 1) * perPage < total,
    };
  },

  async listStandardVersionReferences(
    standardVersionId: string
  ): Promise<StandardVersionReference[]> {
    const records = await prisma.standardVersionReference.findMany({
      where: { standardVersionId },
      orderBy: { id: 'asc' },
    });

    return records.map(
      (record): StandardVersionReference => ({
        id: record.id,
        standardVersionId: record.standardVersionId,
        specification: record.specification,
        name: record.name,
        createdAt: record.createdAt ? record.createdAt.toISOString().slice(0, 10) : null,
        ownedBy: record.ownedBy ?? null,
        link: record.link ?? null,
      })
    );
  },

  async listStandardVersionReferencesConnection(
    standardVersionId: string,
    pageIdx: number,
    limit: number,
    sort?: StandardVersionReferenceSortInput[] | null,
    nameContains?: string | null
  ): Promise<StandardVersionReferenceConnection> {
    const page = Math.max(pageIdx, 0);
    const perPage = Math.max(limit, 1);

    const where: Prisma.StandardVersionReferenceWhereInput = {
      standardVersionId,
      ...(nameContains
        ? {
            name: {
              contains: nameContains,
              mode: 'insensitive',
            },
          }
        : {}),
    };

    const orderBy: Prisma.StandardVersionReferenceOrderByWithRelationInput[] = [];
    if (sort && sort.length) {
      for (const entry of sort) {
        let field: keyof Prisma.StandardVersionReferenceOrderByWithRelationInput | null = null;
        if (entry.field === 'specification') field = 'specification';
        if (entry.field === 'name') field = 'name';
        if (entry.field === 'createdAt') field = 'createdAt';
        if (entry.field === 'ownedBy') field = 'ownedBy';

        if (field) {
          orderBy.push({
            [field]: entry.desc ? 'desc' : 'asc',
          });
        }
      }
    }

    if (!orderBy.length) {
      orderBy.push({ id: 'asc' });
    }

    const total = await prisma.standardVersionReference.count({ where });

    const records = await prisma.standardVersionReference.findMany({
      where,
      orderBy,
      skip: page * perPage,
      take: perPage,
    });

    const items: StandardVersionReference[] = records.map((record) => ({
      id: record.id,
      standardVersionId: record.standardVersionId,
      specification: record.specification,
      name: record.name,
      createdAt: record.createdAt ? record.createdAt.toISOString().slice(0, 10) : null,
      ownedBy: record.ownedBy ?? null,
      link: record.link ?? null,
    }));

    return {
      items,
      total,
      pageIdx: page,
      limit: perPage,
      hasNext: (page + 1) * perPage < total,
    };
  },

  /**
   * Get distinct filter values for a specific field from latest standard versions.
   *
   * Supports four categories of fields:
   * - Direct fields: version (from StandardVersion table)
   * - Parent fields: name, accProjectId (from Standard table via relation)
   * - ACC metadata fields: accCreatedBy, accUpdatedBy (from StandardVersion table)
   * - Attribute fields: program, region, projectType, roomFeatureZone, updateCadence
   *
   * Returns sorted array of unique non-null values from latest versions only.
   * Throws error if fieldName is invalid.
   */
  async getFilterOptions(fieldName: string): Promise<string[]> {
    return getFilterOptions(prisma, fieldName, {
      entityType: 'STANDARD_VERSION',
      versionTable: 'standardVersion',
      parentTable: 'standard',
      parentIdField: 'standardId',
      directFields: ['version'],
      parentFields: ['name', 'accProjectId'],
      accMetadataFields: ['accCreatedBy', 'accUpdatedBy'],
      attributeFields: ['program', 'region', 'projectType', 'roomFeatureZone', 'updateCadence'],
    });
  },

  async createStandard(input: CreateStandardInput): Promise<StandardMutationResponse> {
    try {
      const created = await prisma.$transaction(async (tx) => {
        const standard = await tx.standard.create({
          data: {
            accProjectId: input.accProjectId,
            name: input.name,
            description: input.description ?? null,
          },
        });

        if (input.initialVersion) {
          const accFileId = input.initialVersion.accFileId?.trim();
          if (!accFileId) {
            throw new Error('accFileId is required for the initial standard version.');
          }

          const version = await tx.standardVersion.create({
            data: {
              standardId: standard.id,
              accFolderId: input.initialVersion.accFolderId,
              accFileId,
              version: input.initialVersion.version,
              isLatest: false,
            },
          });

          await storeAttributes(
            tx,
            'STANDARD_VERSION',
            version.id,
            input.initialVersion.attributes ?? null
          );
          await updateLatestStandardVersionFlags(tx.standardVersion, standard.id, version.id);
        }

        return fetchStandardRecord({ id: standard.id });
      });

      if (!created) {
        throw new Error('Unable to create standard.');
      }

      const graph = await toStandardGraph(created);
      return { success: true, standard: graph } satisfies StandardMutationResponse;
    } catch (error) {
      logger.error('Failed to create standard', {
        error: error instanceof Error ? error.message : error,
      });
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
        standard: null,
      };
    }
  },

  async updateStandard(id: string, input: UpdateStandardInput): Promise<StandardMutationResponse> {
    try {
      const existing = await prisma.standard.findUnique({ where: { id } });
      if (!existing) {
        throw new Error('Standard not found.');
      }

      const data: Prisma.StandardUpdateInput = {};
      if (input.accProjectId !== undefined) {
        if (input.accProjectId === null) {
          throw new Error('accProjectId cannot be null.');
        }
        data.accProjectId = input.accProjectId;
      }
      if (input.name !== undefined) {
        if (input.name === null) {
          throw new Error('Standard name cannot be null.');
        }
        data.name = input.name;
      }
      if (input.description !== undefined) {
        data.description = input.description ?? null;
      }

      await prisma.standard.update({
        where: { id },
        data,
      });

      const updated = await fetchStandardRecord({ id });
      if (!updated) {
        throw new Error('Unable to load standard after update.');
      }

      return {
        success: true,
        standard: await toStandardGraph(updated),
      } satisfies StandardMutationResponse;
    } catch (error) {
      logger.error('Failed to update standard', {
        standardId: id,
        error: error instanceof Error ? error.message : error,
      });
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
        standard: null,
      };
    }
  },

  async deleteStandard(id: string): Promise<StandardMutationResponse> {
    try {
      await prisma.standard.delete({ where: { id } });
      return { success: true, standard: null } satisfies StandardMutationResponse;
    } catch (error) {
      logger.error('Failed to delete standard', {
        standardId: id,
        error: error instanceof Error ? error.message : error,
      });
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
        standard: null,
      };
    }
  },

  async createStandardVersion(
    standardId: string,
    input: CreateStandardVersionInput
  ): Promise<StandardVersionMutationResponse> {
    try {
      const standard = await prisma.standard.findUnique({ where: { id: standardId } });
      if (!standard) {
        throw new Error('Standard not found.');
      }

      const createdId = await prisma.$transaction(async (tx) => {
        const accFileId = input.accFileId?.trim();
        if (!accFileId) {
          throw new Error('accFileId is required.');
        }

        const created = await tx.standardVersion.create({
          data: {
            standardId,
            accFolderId: input.accFolderId,
            accFileId,
            version: input.version,
            isLatest: false,
          },
        });

        await storeAttributes(tx, 'STANDARD_VERSION', created.id, input.attributes ?? null);
        await updateLatestStandardVersionFlags(tx.standardVersion, standardId, created.id);
        return created.id;
      });

      const graph = await this.getStandardVersion(createdId);
      return { success: true, standardVersion: graph } satisfies StandardVersionMutationResponse;
    } catch (error) {
      logger.error('Failed to create standard version', {
        standardId,
        error: error instanceof Error ? error.message : error,
      });
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
        standardVersion: null,
      };
    }
  },

  async updateStandardVersion(
    id: string,
    input: UpdateStandardVersionInput
  ): Promise<StandardVersionMutationResponse> {
    try {
      const existing = await prisma.standardVersion.findUnique({
        where: { id },
        select: { standardId: true },
      });
      if (!existing) {
        throw new Error('Standard version not found.');
      }

      // Standard versions are immutable. The only supported mutation is toggling which version is
      // marked latest. All other edits must be expressed as a new version via createStandardVersion.

      const illegalChangeRequested =
        input.accFolderId !== undefined ||
        input.accFileId !== undefined ||
        input.version !== undefined ||
        input.attributes !== undefined;

      if (illegalChangeRequested) {
        throw new Error(
          'Standard versions are immutable. Create a new version instead of updating.'
        );
      }

      if (input.isLatest === undefined) {
        throw new Error(
          'No mutable fields provided. Use setLatestStandardVersion to promote a version.'
        );
      }

      await prisma.$transaction(async (tx) => {
        if (input.isLatest === null) {
          throw new Error('isLatest cannot be null.');
        }

        await tx.standardVersion.update({
          where: { id },
          data: { isLatest: input.isLatest },
        });

        if (input.isLatest) {
          await updateLatestStandardVersionFlags(tx.standardVersion, existing.standardId, id);
        } else {
          await ensureLatestStandardVersionExists(tx.standardVersion, existing.standardId);
        }
      });

      const graph = await this.getStandardVersion(id);
      return { success: true, standardVersion: graph } satisfies StandardVersionMutationResponse;
    } catch (error) {
      logger.error('Failed to update standard version', {
        standardVersionId: id,
        error: error instanceof Error ? error.message : error,
      });
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
        standardVersion: null,
      };
    }
  },

  async deleteStandardVersion(id: string): Promise<StandardVersionMutationResponse> {
    try {
      const version = await prisma.standardVersion.findUnique({
        where: { id },
        select: { standardId: true },
      });
      if (!version) {
        throw new Error('Standard version not found.');
      }

      await prisma.$transaction(async (tx) => {
        await tx.standardVersion.delete({ where: { id } });
        await ensureLatestStandardVersionExists(tx.standardVersion, version.standardId);
      });

      return { success: true, standardVersion: null } satisfies StandardVersionMutationResponse;
    } catch (error) {
      logger.error('Failed to delete standard version', {
        standardVersionId: id,
        error: error instanceof Error ? error.message : error,
      });
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
        standardVersion: null,
      };
    }
  },

  async setLatestStandardVersion(id: string): Promise<StandardVersionMutationResponse> {
    try {
      const version = await prisma.standardVersion.findUnique({
        where: { id },
        select: { standardId: true },
      });
      if (!version) {
        throw new Error('Standard version not found.');
      }

      await prisma.$transaction(async (tx) => {
        await updateLatestStandardVersionFlags(tx.standardVersion, version.standardId, id);
      });

      const graph = await this.getStandardVersion(id);
      return { success: true, standardVersion: graph } satisfies StandardVersionMutationResponse;
    } catch (error) {
      logger.error('Failed to set latest standard version', {
        standardVersionId: id,
        error: error instanceof Error ? error.message : error,
      });
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
        standardVersion: null,
      };
    }
  },

  async listStandardsByKitVersion(kitVersionId: string): Promise<StandardVersion[]> {
    const links = await prisma.kitVersionStandardLink.findMany({
      where: { kitVersionId },
      orderBy: { createdAt: 'asc' },
      include: {
        standardVersion: {
          include: STANDARD_VERSION_INCLUDE,
        },
      },
    });

    return Promise.all(
      links.map((link) => toStandardVersionGraph(link.standardVersion as StandardVersionRecord))
    );
  },
});
