import type {
  Kit as PrismaKit,
  KitVersion as PrismaKitVersion,
  Standard as PrismaStandard,
  StandardVersion as PrismaStandardVersion,
} from '@amzn/global-realty-mosaic-prisma-client';
import type {
  KitVersion,
  Standard,
  StandardVersion,
} from '@amzn/global-realty-mosaic-graphql-schema';

export type KitVersionWithKit = PrismaKitVersion & {
  kit: PrismaKit;
};

export type StandardVersionRecord = PrismaStandardVersion & {
  standard?: PrismaStandard;
  kits: {
    kitVersion: KitVersionWithKit;
  }[];
};

export type StandardRecord = PrismaStandard & {
  versions: StandardVersionRecord[];
};

export type StandardAttributeLoader = (entityId: string) => Promise<StandardVersion['attributes']>;

const createKitVersionMapper =
  (attributeLoader: StandardAttributeLoader) =>
  async (record: KitVersionWithKit): Promise<KitVersion> => {
    const attributes = await attributeLoader(record.id);

    return {
      id: record.id,
      kitId: record.kitId,
      kit: {
        id: record.kit.id,
        name: record.kit.name,
        desc: record.kit.description ?? null,
        createdAt: record.kit.createdAt.toISOString(),
        updatedAt: record.kit.updatedAt.toISOString(),
        versions: [],
        latestVersion: null,
      },
      version: record.version,
      isLatest: record.isLatest,
      standards: [],
      attributes,
      createdAt: record.createdAt.toISOString(),
      updatedAt: record.updatedAt.toISOString(),
    } satisfies KitVersion;
  };

const createStandardVersionMapper =
  (
    attributeLoader: StandardAttributeLoader,
    toKitVersionGraph: ReturnType<typeof createKitVersionMapper>
  ) =>
  async (
    record: StandardVersionRecord,
    standardFallback?: PrismaStandard
  ): Promise<StandardVersion> => {
    const attributes = await attributeLoader(record.id);
    const kits = await Promise.all(record.kits.map((link) => toKitVersionGraph(link.kitVersion)));

    const standard = record.standard ?? standardFallback;
    if (!standard) {
      throw new Error('Standard reference not loaded for standard version.');
    }

    return {
      id: record.id,
      standardId: record.standardId,
      standard: {
        id: standard.id,
        accProjectId: standard.accProjectId,
        name: standard.name,
        description: standard.description ?? null,
        createdAt: standard.createdAt.toISOString(),
        updatedAt: standard.updatedAt.toISOString(),
        versions: [],
        latestVersion: null,
      },
      accFolderId: record.accFolderId,
      accFileId: record.accFileId,
      version: record.version,
      isLatest: record.isLatest,
      kits,
      attributes,
      createdAt: record.createdAt.toISOString(),
      updatedAt: record.updatedAt.toISOString(),
      accCreatedAt: record.accCreatedAt?.toISOString() ?? null,
      accCreatedBy: record.accCreatedBy ?? null,
      accUpdatedAt: record.accUpdatedAt?.toISOString() ?? null,
      accUpdatedBy: record.accUpdatedBy ?? null,
      // Format date-only fields as YYYY-MM-DD to avoid timezone conversion issues
      publishedOn: record.publishedOn?.toISOString().split('T')[0] ?? null,
      firstPublishedOn: record.firstPublishedOn?.toISOString().split('T')[0] ?? null,
    } satisfies StandardVersion;
  };

export const createStandardMappers = (attributeLoader: StandardAttributeLoader) => {
  const toKitVersionGraph = createKitVersionMapper(attributeLoader);
  const toStandardVersionGraph = createStandardVersionMapper(attributeLoader, toKitVersionGraph);

  const toStandardGraph = async (record: StandardRecord): Promise<Standard> => {
    const versions = await Promise.all(
      record.versions.map((version) => toStandardVersionGraph(version, record))
    );
    const latestVersion = versions.find((version) => version.isLatest) ?? versions[0] ?? null;

    return {
      id: record.id,
      accProjectId: record.accProjectId,
      name: record.name,
      description: record.description ?? null,
      createdAt: record.createdAt.toISOString(),
      updatedAt: record.updatedAt.toISOString(),
      versions,
      latestVersion,
    } satisfies Standard;
  };

  return {
    toKitVersionGraph,
    toStandardVersionGraph,
    toStandardGraph,
  } as const;
};
