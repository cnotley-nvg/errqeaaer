import type { Prisma } from '@amzn/global-realty-mosaic-prisma-client';

export interface StandardVersionMutations {
  updateMany: (args: Prisma.StandardVersionUpdateManyArgs) => Promise<unknown>;
  update: (args: Prisma.StandardVersionUpdateArgs) => Promise<unknown>;
  findMany: (
    args: Prisma.StandardVersionFindManyArgs
  ) => Promise<Array<{ id: string; isLatest: boolean }>>;
}

export const updateLatestStandardVersionFlags = async (
  standardVersion: StandardVersionMutations,
  standardId: string,
  latestId: string
): Promise<void> => {
  await standardVersion.updateMany({ data: { isLatest: false }, where: { standardId } });
  await standardVersion.update({ data: { isLatest: true }, where: { id: latestId } });
};

export const ensureLatestStandardVersionExists = async (
  standardVersion: StandardVersionMutations,
  standardId: string
): Promise<void> => {
  const versions = await standardVersion.findMany({
    where: { standardId },
    orderBy: { createdAt: 'desc' },
    select: { id: true, isLatest: true },
  });

  if (!versions.length) {
    return;
  }

  if (versions.some((version) => version.isLatest)) {
    return;
  }

  const [mostRecent] = versions;
  if (mostRecent) {
    await standardVersion.update({ where: { id: mostRecent.id }, data: { isLatest: true } });
  }
};
