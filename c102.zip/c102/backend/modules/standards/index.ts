import type { Logger } from '../../shared';
import { ensureLogger } from '../../shared';
import type { BackendRuntimeConfig } from '../../config/runtimeConfig';
import { createStandardService, type StandardService } from './domain/standardService';
import {
  createStandardMetadataService,
  type StandardMetadataService,
} from './infra/standardMetadataService';
import { createStandardsResolvers, type StandardsResolverMap } from './graphql/resolvers';

export interface StandardsModule {
  resolvers: StandardsResolverMap;
  service: StandardService;
}

export interface CreateStandardsModuleArgs {
  logger: Logger;
  config: BackendRuntimeConfig;
}

export const createStandardsModule = ({
  logger,
  config,
}: CreateStandardsModuleArgs): StandardsModule => {
  const moduleLogger = ensureLogger(logger, 'standards-module').child({ module: 'standards' });

  const service = createStandardService(moduleLogger.child({ component: 'service' }));
  const metadataService: StandardMetadataService = createStandardMetadataService(
    config,
    moduleLogger.child({ component: 'metadata-service' })
  );

  const resolvers = createStandardsResolvers({
    standardService: service,
    standardMetadataService: metadataService,
  });

  return {
    resolvers,
    service,
  };
};
