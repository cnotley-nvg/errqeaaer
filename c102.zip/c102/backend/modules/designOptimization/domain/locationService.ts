import {
  LocationClient,
  SearchPlaceIndexForTextCommand,
  SearchPlaceIndexForPositionCommand,
} from '@aws-sdk/client-location';

const client = new LocationClient({ region: process.env.AWS_REGION || 'us-east-1' });
const INDEX_NAME = process.env.LOCATION_INDEX_NAME || 'mosaic-place-index';

export interface GeocodeResult {
  latitude: number;
  longitude: number;
  address: string;
  city?: string;
  state?: string;
  zipcode?: string;
  country?: string;
}

export const geocodeAddress = async (
  address: string,
  zipcode?: string
): Promise<GeocodeResult | null> => {
  try {
    const searchText = zipcode ? `${address}, ${zipcode}` : address;
    const command = new SearchPlaceIndexForTextCommand({
      IndexName: INDEX_NAME,
      Text: searchText,
      MaxResults: 1,
    });

    const response = await client.send(command);
    const result = response.Results?.[0];

    if (!result?.Place) return null;

    const place = result.Place;
    return {
      latitude: place.Geometry?.Point?.[1] || 0,
      longitude: place.Geometry?.Point?.[0] || 0,
      address: place.Label || address,
      city: place.Municipality,
      state: place.Region,
      zipcode: place.PostalCode,
      country: place.Country,
    };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    if (errorMsg.includes('ResourceNotFoundException') || errorMsg.includes('not found')) {
      console.warn(`Location index not found: ${INDEX_NAME}. Geocoding service unavailable.`);
    } else {
      console.error('Geocoding error:', error);
    }
    return null;
  }
};

export const reverseGeocodeCoordinates = async (
  latitude: number,
  longitude: number
): Promise<GeocodeResult | null> => {
  try {
    const command = new SearchPlaceIndexForPositionCommand({
      IndexName: INDEX_NAME,
      Position: [longitude, latitude],
      MaxResults: 1,
    });

    const response = await client.send(command);
    const result = response.Results?.[0];

    if (!result?.Place) return null;

    const place = result.Place;
    return {
      latitude,
      longitude,
      address: place.Label || '',
      city: place.Municipality,
      state: place.Region,
      zipcode: place.PostalCode,
      country: place.Country,
    };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    if (errorMsg.includes('ResourceNotFoundException') || errorMsg.includes('not found')) {
      console.warn(
        `Location index not found: ${INDEX_NAME}. Reverse geocoding service unavailable.`
      );
    } else {
      console.error('Reverse geocoding error:', error);
    }
    return null;
  }
};
