import type { Logger } from '../../../shared';
import type {
  OptimizeDesignCalculationInput,
  LightningProtectionData,
} from '@amzn/global-realty-mosaic-graphql-schema';

const LIGHTNING_SERVICE_URL = process.env.LIGHTNING_SERVICE_URL || 'http://localhost:5001';
const FEET_TO_METERS = 0.3048;

export const createLightningProtectionService = (logger: Logger) => ({
  async calculate(
    input: OptimizeDesignCalculationInput
  ): Promise<Omit<LightningProtectionData, '__typename'>> {
    const { latitude, longitude, length, width, height, cd, c2 } = input;
    const cdValue = cd ?? 1.0;
    const c2Value = c2 ?? 1.0;

    logger.info('Calculating lightning protection', {
      latitude,
      longitude,
      lengthFt: length,
      widthFt: width,
      heightFt: height,
    });

    // Convert dimensions from feet to meters (NFPA 780 formula requires meters)
    const lengthM = (length ?? 0) * FEET_TO_METERS;
    const widthM = (width ?? 0) * FEET_TO_METERS;
    const heightM = (height ?? 0) * FEET_TO_METERS;

    const response = await fetch(
      `${LIGHTNING_SERVICE_URL}/density?lat=${latitude}&lon=${longitude}`
    );

    if (!response.ok) {
      throw new Error('Failed to fetch lightning density');
    }

    const data = await response.json();
    const nsg = data.density || 0;

    // Calculate per NFPA 780 (all dimensions must be in meters)
    const ad =
      lengthM * widthM + 6 * heightM * (lengthM + widthM) + Math.PI * 9 * heightM * heightM;
    const nd = nsg * ad * cdValue * 1e-6;
    const c = c2Value * 1.0 * 1.0 * 1.0; // c3, c4, c5 locked at 1.0
    const nc = 1.5e-3 / c;

    return {
      recommendation: nd > nc ? 'required' : 'not-required',
      nd,
      nc,
      nsg,
      ad,
      c,
      error: null,
    };
  },
});
