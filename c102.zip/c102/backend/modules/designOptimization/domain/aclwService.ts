import type { Logger } from '../../../shared';

const ACLW_SERVICE_URL = process.env.ACLW_SERVICE_URL || 'http://localhost:5002';

export const createACLWService = (logger: Logger) => ({
  async calculate(latitude: number, longitude: number, squareFootage: number) {
    logger.info('Calculating ACLW', { latitude, longitude, squareFootage });

    const response = await fetch(
      `${ACLW_SERVICE_URL}/calculate?lat=${latitude}&lon=${longitude}&sqft=${squareFootage}`
    );

    if (!response.ok) {
      throw new Error('Failed to fetch ACLW calculation');
    }

    return response.json();
  },
});
