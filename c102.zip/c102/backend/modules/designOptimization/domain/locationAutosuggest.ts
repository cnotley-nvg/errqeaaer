import {
  LocationClient,
  SearchPlaceIndexForSuggestionsCommand,
  GetPlaceCommand,
} from '@aws-sdk/client-location';

const client = new LocationClient({ region: process.env.AWS_REGION || 'us-east-1' });
const INDEX_NAME = process.env.LOCATION_INDEX_NAME || 'mosaic-place-index';

export interface AutosuggestResult {
  label: string;
  address: string;
  city?: string;
  state?: string;
  zipcode?: string;
  country?: string;
  latitude?: number;
  longitude?: number;
}

export const getAddressSuggestions = async (
  text?: string,
  country?: string,
  city?: string
): Promise<AutosuggestResult[]> => {
  if (!text || typeof text !== 'string' || text.trim().length < 2) return [];

  const trimmedText = text.trim();

  try {
    const response = await client.send(
      new SearchPlaceIndexForSuggestionsCommand({
        IndexName: INDEX_NAME,
        Text: trimmedText,
        MaxResults: 5,
        FilterCountries: country ? [country] : undefined,
        BiasPosition: [-98.5795, 39.8283], // Center of US for better results
      })
    );

    const suggestions = response.Results || [];

    // Fetch full place details for suggestions that have PlaceId
    const results = await Promise.all(
      suggestions.map(async (result) => {
        if (result.PlaceId) {
          try {
            const placeResponse = await client.send(
              new GetPlaceCommand({
                IndexName: INDEX_NAME,
                PlaceId: result.PlaceId,
              })
            );
            const place = placeResponse.Place;
            const label = place?.Label || result.Text || '';
            return {
              label,
              address: label,
              city: place?.Municipality,
              state: place?.Region,
              zipcode: place?.PostalCode,
              country: place?.Country,
              latitude: place?.Geometry?.Point?.[1],
              longitude: place?.Geometry?.Point?.[0],
            };
          } catch {
            // Fallback to text-only if GetPlace fails
            const label = result.Text || '';
            return {
              label,
              address: label,
              city: undefined,
              state: undefined,
              zipcode: undefined,
              country: undefined,
              latitude: undefined,
              longitude: undefined,
            };
          }
        }
        // No PlaceId, use text only
        const label = result.Text || '';
        return {
          label,
          address: label,
          city: undefined,
          state: undefined,
          zipcode: undefined,
          country: undefined,
          latitude: undefined,
          longitude: undefined,
        };
      })
    );

    return results.filter((result) => result.label.trim());
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    if (errorMsg.includes('not found')) {
      console.warn(`Location index not found: ${INDEX_NAME}`);
    } else {
      console.error('Autosuggest error:', error);
    }
    return [];
  }
};
