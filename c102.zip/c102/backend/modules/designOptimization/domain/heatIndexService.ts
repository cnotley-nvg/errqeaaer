import type { Logger } from '../../../shared';
import type {
  OptimizeDesignCalculationInput,
  HeatIndexData,
  HeatIndexLevel,
} from '@amzn/global-realty-mosaic-graphql-schema';

const HVAC_SERVICE_URL = process.env.HVAC_SERVICE_URL || 'http://localhost:5003';
const AMZL_FACILITY_TYPES = ['AMZL', 'Amazon Logistics (AMZL)'];

const calculateHVACRecommendation = (
  levels: HeatIndexLevel[],
  facilityType?: string | null
): { recommendation: string; hvacRecommendation: string; riskWithoutMitigation: string } => {
  // Non-AMZL facilities default to Option 3
  if (facilityType && !AMZL_FACILITY_TYPES.includes(facilityType)) {
    return {
      recommendation: 'recommended',
      hvacRecommendation:
        'Option 3 - Permanent HVAC System: Install permanent mechanical air-conditioning equipment to maintain <85°F during peaks.',
      riskWithoutMitigation: 'High risk',
    };
  }

  const h0 = levels[0]?.hours ?? 0;
  const h1 = levels[1]?.hours ?? 0;
  const h2 = levels[2]?.hours ?? 0;
  const h3 = levels[3]?.hours ?? 0;
  const h4 = levels[4]?.hours ?? 0;

  const totalHours = 8760;
  const h90to100 = h2;
  const h101to110 = h3;

  let recommendation = 'optional';
  let hvacRecommendation = '';
  let riskWithoutMitigation = '';

  // Option 1: Natural Ventilation (check first)
  // Int. HI <80°F for >92.5% of year (Level 0) OR Int. HI <90°F for >99% of year (Levels 0-1)
  if (h0 > totalHours * 0.925 || h0 + h1 > totalHours * 0.99) {
    hvacRecommendation =
      'Option 1 - Natural Ventilation: Basic ventilation and passive cooling are sufficient - HVLS fans only or Install Unit Ventilator Fans to flush out the building hot air.';
    riskWithoutMitigation = 'Low risk';
    recommendation = 'recommended';
  }
  // Option 3: Permanent HVAC System
  // Scenario A: Int. HI 90-100°F for >500 hrs/year (5.7% of annual hours)
  // Scenario B: Int. HI 100-114°F for >300 hrs/year (3.4% of annual hours)
  // Scenario C: Int. HI ≥115°F for ≥1 hr/year
  else if (h90to100 > 500 || h101to110 > 300 || h4 >= 1) {
    hvacRecommendation =
      'Option 3 - Permanent HVAC System: Install permanent mechanical air-conditioning equipment to maintain <85°F during peaks.';
    riskWithoutMitigation = 'High risk';
    recommendation = 'recommended';
  }
  // Option 2: Partial Mechanical Cooling
  // 100 hrs/year ≤ Int. HI 90-100°F < 500 hrs/year (1.15%-5.7% of annual hours)
  else if (h90to100 >= 100 && h90to100 < 500 && h101to110 <= 300 && h4 < 1) {
    hvacRecommendation =
      'Option 2 - Partial Mechanical Cooling: Rent AC units only during peak summer months.';
    riskWithoutMitigation = 'Medium risk';
    recommendation = 'recommended';
  }
  // Fallback to Option 1 for edge cases
  else {
    hvacRecommendation =
      'Option 1 - Natural Ventilation: Basic ventilation and passive cooling are sufficient - HVLS fans only or Install Unit Ventilator Fans to flush out the building hot air.';
    riskWithoutMitigation = 'Low risk';
    recommendation = 'recommended';
  }

  return { recommendation, hvacRecommendation, riskWithoutMitigation };
};

export const createHeatIndexService = (logger: Logger) => ({
  async calculate(
    input: OptimizeDesignCalculationInput
  ): Promise<Omit<HeatIndexData, '__typename'>> {
    const { latitude, longitude } = input;

    logger.info('Calculating internal heat index', { latitude, longitude });

    try {
      const response = await fetch(
        `${HVAC_SERVICE_URL}/heat-index-levels?lat=${latitude}&lon=${longitude}`
      );

      if (!response.ok) {
        throw new Error('Failed to fetch weather data');
      }

      const data = await response.json();

      if (!data.dataAvailable) {
        return {
          recommendation: 'optional',
          hvacRecommendation: 'Data not available for this location',
          riskWithoutMitigation: 'Unknown',
          levels: [],
          elevation: null,
          operatingHours: null,
          dataAvailable: false,
          error: 'Weather data not available for this location',
        };
      }

      const { recommendation, hvacRecommendation, riskWithoutMitigation } =
        calculateHVACRecommendation(data.levels, input.facilityType);

      return {
        recommendation,
        hvacRecommendation,
        riskWithoutMitigation,
        levels: data.levels,
        elevation: null,
        operatingHours: null,
        dataAvailable: true,
        error: null,
      };
    } catch (error) {
      logger.error('Internal heat index calculation failed', {
        error: error instanceof Error ? error.message : String(error),
      });

      return {
        recommendation: 'optional',
        hvacRecommendation: 'Unable to calculate internal heat index',
        riskWithoutMitigation: 'Unknown',
        levels: [],
        elevation: null,
        operatingHours: null,
        dataAvailable: false,
        error: error instanceof Error ? error.message : 'Internal heat index service unavailable',
      };
    }
  },
});
