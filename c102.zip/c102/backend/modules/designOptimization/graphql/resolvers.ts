import type {
  DesignOptimizationResult,
  OptimizeDesignInput,
  OptimizeDesignCalculationInput,
  OptimizeDesignCalculationResult,
} from '@amzn/global-realty-mosaic-graphql-schema';

import type { Logger } from '../../../shared';
import { createLightningProtectionService } from '../domain/lightningProtectionService';
import { createACLWService } from '../domain/aclwService';
import { createHeatIndexService } from '../domain/heatIndexService';
import { geocodeAddress, reverseGeocodeCoordinates } from '../domain/locationService';
import { getAddressSuggestions } from '../domain/locationAutosuggest';

interface DesignOptimizationResolverDependencies {
  logger: Logger;
}

export interface DesignOptimizationResolverMap {
  Query: {
    optimizeDesign: (
      parent: unknown,
      args: { input: OptimizeDesignInput }
    ) => Promise<DesignOptimizationResult>;
    calculateOptimizeDesign: (
      parent: unknown,
      args: { input: OptimizeDesignCalculationInput }
    ) => Promise<Omit<OptimizeDesignCalculationResult, '__typename'>>;
    geocodeAddress: (
      parent: unknown,
      args: { address: string; zipcode?: string }
    ) => Promise<{
      latitude: number;
      longitude: number;
      address: string;
      city?: string;
      state?: string;
      zipcode?: string;
      country?: string;
    } | null>;
    reverseGeocodeCoordinates: (
      parent: unknown,
      args: { latitude: number; longitude: number }
    ) => Promise<{
      latitude: number;
      longitude: number;
      address: string;
      city?: string;
      state?: string;
      zipcode?: string;
      country?: string;
    } | null>;
    getAddressSuggestions: (
      parent: unknown,
      args: { text: string; country?: string; city?: string }
    ) => Promise<
      Array<{
        label: string;
        address: string;
        city?: string;
        state?: string;
        zipcode?: string;
        country?: string;
      }>
    >;
  };
}

const deriveCoordinates = (input: OptimizeDesignInput): { latitude: number; longitude: number } => {
  if (
    input.locationType === 'LAT_LONG' &&
    typeof input.latitude === 'number' &&
    typeof input.longitude === 'number'
  ) {
    return { latitude: input.latitude, longitude: input.longitude };
  }

  // Deterministic mock coordinates derived from string inputs to keep results stable between calls
  const seed = `${input.locationType}:${input.zipCode ?? input.siteCode ?? input.address ?? '0,0'}`;
  let hash = 0;
  for (let index = 0; index < seed.length; index += 1) {
    hash = (hash * 31 + seed.charCodeAt(index)) % 1000;
  }

  const latitude = 30 + (hash % 4000) / 100;
  const longitude = -120 + ((hash >> 2) % 4000) / 100;

  return { latitude, longitude };
};

const buildMockRecommendations = (): DesignOptimizationResult['recommendations'] => {
  const now = new Date().toISOString();

  return [
    {
      id: 'rec-mech-001',
      reportId: 'MM-001',
      title: 'Optimize HVAC zoning for energy efficiency',
      description:
        'Reconfigure HVAC zones to align with occupancy patterns, reducing peak load requirements by ~12%.',
      category: 'MECHANICAL',
      riskLevel: 'MEDIUM',
      costImpact: {
        min: 180000,
        max: 260000,
        currency: 'USD',
      },
      timelineImpact: 'Adds 3-4 weeks to mechanical design timeline',
      project: 'Mechanical Systems Review',
      reportUrl: 'https://example.com/reports/MM-001',
      generatedAt: now,
    },
    {
      id: 'rec-struct-002',
      reportId: 'ST-014',
      title: 'Upgrade mezzanine live load rating',
      description:
        'Increase mezzanine live load rating to support alternative automation layouts in future generations.',
      category: 'STRUCTURAL',
      riskLevel: 'HIGH',
      costImpact: {
        min: 320000,
        max: 480000,
        currency: 'USD',
      },
      timelineImpact: 'Requires structural peer review; 6-week impact',
      project: 'Structural Assessment',
      reportUrl: 'https://example.com/reports/ST-014',
      generatedAt: now,
    },
  ];
};

export const createDesignOptimizationResolvers = ({
  logger,
}: DesignOptimizationResolverDependencies): DesignOptimizationResolverMap => {
  const lightningService = createLightningProtectionService(
    logger.child({ component: 'lightning-service' })
  );
  const aclwService = createACLWService(logger.child({ component: 'aclw-service' }));
  const heatIndexService = createHeatIndexService(
    logger.child({ component: 'heat-index-service' })
  );

  return {
    Query: {
      async optimizeDesign(_, { input }) {
        logger.info('Design optimization requested', { input });

        const coordinates = deriveCoordinates(input);

        return {
          location: {
            latitude: coordinates.latitude,
            longitude: coordinates.longitude,
            type: input.locationType,
          },
          projectParameters: {
            function: input.function,
            program: input.program,
            totalSquareFootage: input.totalSquareFootage,
          },
          recommendations: buildMockRecommendations(),
        } satisfies DesignOptimizationResult;
      },
      async calculateOptimizeDesign(_, { input }): Promise<OptimizeDesignCalculationResult> {
        logger.info('Optimize design calculation requested', { input });

        let lightningProtection: OptimizeDesignCalculationResult['lightningProtection'];
        if (!input.length || !input.width || !input.height) {
          lightningProtection = {
            recommendation: 'not-provided',
            nd: 0,
            nc: 0,
            nsg: 0,
            ad: 0,
            c: 0,
            error:
              'Building dimensions required. Please go back and enter height, width, and length in Project Parameters, or refer to Amazon Specifications (3PS) for Lightning Protection requirements.',
          };
        } else {
          lightningProtection = await lightningService.calculate(input);
        }

        let windLoading: OptimizeDesignCalculationResult['windLoading'] = null;
        if (input.squareFootage) {
          try {
            const aclwResult = await aclwService.calculate(
              input.latitude,
              input.longitude,
              input.squareFootage
            );
            windLoading = {
              recommendation: aclwResult.isCandidate ? 'required' : 'not-required',
              guidelineUrl: aclwResult.isCandidate ? 'https://example.com/aclw-guideline' : null,
              tornadoSpeed: aclwResult.tornadoSpeed ?? null,
              windSpeed: aclwResult.windSpeed ?? null,
              isTornadoRegion: aclwResult.isTornadoRegion ?? null,
              error: null,
            };
          } catch (error) {
            logger.error('ACLW calculation failed', {
              error: error instanceof Error ? error.message : String(error),
            });
            windLoading = {
              recommendation: '',
              guidelineUrl: null,
              tornadoSpeed: null,
              windSpeed: null,
              isTornadoRegion: null,
              error: 'Wind loading service unavailable. Please try again later.',
            };
          }
        }

        let heatIndex: OptimizeDesignCalculationResult['heatIndex'] = null;
        try {
          heatIndex = await heatIndexService.calculate(input);
        } catch (error) {
          logger.error('Heat index calculation failed', {
            error: error instanceof Error ? error.message : String(error),
          });
        }

        return { lightningProtection, windLoading, heatIndex };
      },
      async geocodeAddress(_, { address, zipcode }) {
        logger.info('Geocoding address', { address, zipcode });
        return geocodeAddress(address, zipcode);
      },
      async reverseGeocodeCoordinates(_, { latitude, longitude }) {
        logger.info('Reverse geocoding coordinates', { latitude, longitude });
        return reverseGeocodeCoordinates(latitude, longitude);
      },
      async getAddressSuggestions(_, { text, country, city }) {
        logger.info('Getting address suggestions', { text, country, city });
        return getAddressSuggestions(text, country, city);
      },
    },
  };
};
