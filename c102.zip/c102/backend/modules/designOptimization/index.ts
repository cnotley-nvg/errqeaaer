import type { Logger } from '../../shared';
import { ensureLogger } from '../../shared';
import {
  createDesignOptimizationResolvers,
  type DesignOptimizationResolverMap,
} from './graphql/resolvers';

export interface DesignOptimizationModule {
  resolvers: DesignOptimizationResolverMap;
}

export interface CreateDesignOptimizationModuleArgs {
  logger: Logger;
}

export const createDesignOptimizationModule = ({
  logger,
}: CreateDesignOptimizationModuleArgs): DesignOptimizationModule => {
  const moduleLogger = ensureLogger(logger, 'design-optimization-module').child({
    module: 'design-optimization',
  });

  const resolvers = createDesignOptimizationResolvers({
    logger: moduleLogger.child({ component: 'resolvers' }),
  });

  return {
    resolvers,
  };
};
