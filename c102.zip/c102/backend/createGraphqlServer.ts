import crypto from 'node:crypto';

import { createSchema, createYoga } from 'graphql-yoga';
import { typeDefs } from '@amzn/global-realty-mosaic-graphql-schema';

import type { BackendRuntimeConfig } from './config/runtimeConfig';
import type { Logger } from './shared';
import { ensureLogger } from './shared';
import { type AuthenticatedUser, extractAuthHeaders } from './lib/auth';
import { BatchLoader } from './lib/batchLoader';
import { createPerformanceTimingPlugin } from './plugins/performanceTiming';
import { createUserModule } from './modules/user';
import { createStandardsModule } from './modules/standards';
import { createTemplateModule } from './modules/templates';
import { createKitModule } from './modules/kits';
import { createReferenceModule } from './modules/reference';
import { createDesignOptimizationModule } from './modules/designOptimization';
import { createElectricalModule } from './modules/electrical';
import { createSchedulerModule } from './modules/scheduler';
import { createMatchmakerModule } from './modules/matchmaker';
import { createEventsModule } from './modules/events';
import { createFeedbackModule } from './modules/feedback';
import type {
  TemplateVersionChange,
  TemplateFile,
} from '@amzn/global-realty-mosaic-graphql-schema';
import type { ElectricalLoadLookupData } from './modules/templates/graphql/types';

export interface GraphqlServerDependencies {
  logger: Logger;
}

/**
 * GraphQL context available to all resolvers.
 * Created per-request to ensure isolation.
 */
export interface GraphqlContext {
  readonly logger: Logger;
  readonly request: Request;
  readonly user: AuthenticatedUser | null;
  readonly loaders: {
    readonly templateVersionChanges: BatchLoader<string, TemplateVersionChange[]>;
    readonly electricalLoadData: BatchLoader<string, ElectricalLoadLookupData[]>;
    readonly templateFiles: BatchLoader<string, TemplateFile[]>;
  };
}

export const createGraphqlServer = (
  config: BackendRuntimeConfig,
  dependencies: GraphqlServerDependencies
) => {
  const logger = ensureLogger(dependencies.logger, 'graphql-root').child({ component: 'graphql' });

  const userModule = createUserModule({ logger });
  const standardsModule = createStandardsModule({ logger, config });
  const templatesModule = createTemplateModule({ logger, config });
  const kitModule = createKitModule({ logger, standardService: standardsModule.service });
  const referenceModule = createReferenceModule({ logger });
  const designOptimizationModule = createDesignOptimizationModule({ logger });
  const electricalModule = createElectricalModule({ logger });
  const schedulerModule = createSchedulerModule({ logger });
  const matchmakerModule = createMatchmakerModule({ logger, config });
  const eventsModule = createEventsModule({ logger });
  const feedbackModule = createFeedbackModule({ logger });

  const wrapResolver =
    (resolver: any, operationName: string) =>
    async (...args: any[]) => {
      try {
        return await resolver(...args);
      } catch (error) {
        throw error;
      }
    };

  const wrapResolvers = (resolvers: any) => {
    const wrapped: any = {};
    for (const [key, resolver] of Object.entries(resolvers)) {
      wrapped[key] = wrapResolver(resolver, key);
    }
    return wrapped;
  };

  const schema = createSchema<GraphqlContext>({
    typeDefs,
    resolvers: {
      Query: wrapResolvers({
        ...userModule.resolvers.Query,
        ...standardsModule.resolvers.Query,
        ...templatesModule.resolvers.Query,
        ...kitModule.resolvers.Query,
        ...referenceModule.resolvers.Query,
        ...designOptimizationModule.resolvers.Query,
        ...electricalModule.resolvers.Query,
        ...schedulerModule.resolvers.Query,
        ...matchmakerModule.resolvers.Query,
        ...eventsModule.resolvers.Query,
      }),
      Mutation: wrapResolvers({
        ...standardsModule.resolvers.Mutation,
        ...templatesModule.resolvers.Mutation,
        ...kitModule.resolvers.Mutation,
        ...schedulerModule.resolvers.Mutation,
        ...eventsModule.resolvers.Mutation,
        ...feedbackModule.resolvers.Mutation,
      }),
      TemplateVersion: templatesModule.resolvers.TemplateVersion,
    },
  });

  const yoga = createYoga({
    schema,
    plugins: [
      createPerformanceTimingPlugin({
        logger,
        logSlowQueries: false, // Log all queries initially to collect data
        slowQueryThreshold: 500, // Warn if query takes > 500ms
      }),
    ],
    context: ({ request }): GraphqlContext => {
      const requestId = request.headers.get('x-amzn-trace-id') ?? crypto.randomUUID();
      const contextLogger = logger.child({ requestId });

      // Collect all headers for debugging
      const allHeaders: Record<string, string> = {};
      if (typeof request.headers.forEach === 'function') {
        request.headers.forEach((value, key) => {
          allHeaders[key] = value;
        });
      }

      let user: AuthenticatedUser | null = null;
      try {
        user = extractAuthHeaders(request, contextLogger);
        contextLogger.info('Authenticated request', { username: user.username });
      } catch (error) {
        contextLogger.warn('Unauthenticated request', { error, headers: allHeaders });
      }

      // Create per-request BatchLoaders to prevent cross-request contamination
      const loaders = {
        templateVersionChanges: new BatchLoader<string, TemplateVersionChange[]>(
          async (templateVersionIds) =>
            templatesModule.service.batchLoadTemplateVersionChanges(templateVersionIds)
        ),
        electricalLoadData: new BatchLoader<string, ElectricalLoadLookupData[]>(
          async (templateVersionIds) =>
            templatesModule.service.batchLoadElectricalLoadData(templateVersionIds)
        ),
        templateFiles: new BatchLoader<string, TemplateFile[]>(async (templateVersionIds) =>
          templatesModule.service.batchLoadTemplateFiles(templateVersionIds)
        ),
      };

      return {
        logger: contextLogger,
        request,
        user,
        loaders,
      };
    },
    cors: {
      origin: config.server.corsOrigins,
      credentials: true,
    },
  });

  return {
    schema,
    yoga,
  } as const;
};
