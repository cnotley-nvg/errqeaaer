import { createServer as createHttpServer } from 'node:http';
import { URL } from 'node:url';

import {
  collectBufferedPayload,
  readRequestBody,
  toNodeReadable,
} from '@amzn/global-realty-mosaic-shared-utils';

import type { BackendRuntimeConfig } from './config/runtimeConfig';
import { getRuntimeConfig } from './config/runtimeConfig';
import type { Logger } from './shared';
import { ensureLogger, rootLogger, AccClient, ProxyUnavailableError } from './shared';
import { createGraphqlServer } from './createGraphqlServer';
import { prisma } from './lib/prisma';
import { extractAuthHeaders } from './lib/auth';
import { createMatchmakerService } from './modules/matchmaker/infra/matchmakerService';
import { createMatchmakerHttpHandler } from './modules/matchmaker/http';
import { initializeFeatureFlags, destroyFeatureFlags } from './lib/featureFlags';

export interface StartServerOverrides {
  config?: BackendRuntimeConfig;
  logger?: Logger;
}

export const startServer = async (overrides: StartServerOverrides = {}) => {
  const config = overrides.config ?? getRuntimeConfig();
  const logger = ensureLogger(overrides.logger ?? rootLogger, 'http-server');

  await initializeFeatureFlags();

  const { yoga } = createGraphqlServer(config, { logger });

  // Create AccClient for the viewer endpoint
  const { proxy } = config;
  if (!proxy?.baseUrl) {
    throw new ProxyUnavailableError('ACC proxy configuration missing. Provide ACC_PROXY_BASE_URL.');
  }

  const accClient = new AccClient({
    proxyBaseUrl: proxy.baseUrl,
    requestTimeoutMs: proxy.timeoutMs,
  });

  const matchmakerService = config.dge?.s3?.bucket
    ? createMatchmakerService(config, logger.child({ component: 'matchmaker-service' }))
    : null;
  const matchmakerHttp = matchmakerService
    ? createMatchmakerHttpHandler(
        config,
        logger.child({ component: 'matchmaker-http' }),
        matchmakerService
      )
    : null;

  const handler = async (request: any, response: any) => {
    const req = request as {
      url?: string | null;
      method?: string | null;
      headers?: Record<string, unknown>;
    };
    const res = response as {
      statusCode: number;
      setHeader: (name: string, value: string) => void;
      end: (body?: unknown) => void;
    };

    const rawUrl = req.url ?? '';
    const parsedUrl = new URL(
      rawUrl,
      config.server.publicBaseUrl || `http://localhost:${config.server.port}`
    );

    logger.info('Incoming request', {
      method: req.method,
      pathname: parsedUrl.pathname,
      url: rawUrl,
    });

    if (req.method === 'GET' && parsedUrl.pathname === '/health') {
      res.statusCode = 200;
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ status: 'healthy', service: 'backend' }));
      return;
    }

    if (
      req.method === 'GET' &&
      (parsedUrl.pathname === '/login' || parsedUrl.pathname === '/api/login')
    ) {
      const frontendUrl =
        config.server.publicBaseUrl?.replace('/api', '') ||
        'https://beta.mosaic.realm.wwops.amazon.dev';
      logger.info('Redirecting authenticated user to homepage', {
        frontendUrl,
        pathname: parsedUrl.pathname,
      });
      res.statusCode = 302;
      res.setHeader('Location', frontendUrl);
      res.end();
      return;
    }

    if (req.method === 'GET' && parsedUrl.pathname === '/oauth2/idpresponse') {
      const frontendUrl =
        config.server.publicBaseUrl?.replace('/api', '') ||
        'https://beta.mosaic.realm.wwops.amazon.dev';
      res.statusCode = 302;
      res.setHeader('Location', frontendUrl);
      res.end();
      return;
    }

    const viewerMatch = /^\/(?:api\/)?standards\/([^/]+)\/viewer$/.exec(parsedUrl.pathname);
    if (req.method === 'GET' && viewerMatch) {
      const encodedId = viewerMatch[1];
      const standardId = decodeURIComponent(encodedId);

      try {
        // Fetch the standard version to get projectId and folderId
        const standardVersion = await prisma.standardVersion.findFirst({
          where: { accFileId: standardId },
          include: { standard: true },
        });

        if (!standardVersion) {
          res.statusCode = 404;
          res.end('Standard not found');
          return;
        }

        const projectId = standardVersion.standard.accProjectId;

        // Use AccClient to get inline URL for PDF viewer
        const inlineUrl = await accClient.getSignedDownloadUrl(projectId, standardId, {
          disposition: 'inline',
        });

        const upstream = await fetch(inlineUrl);
        if (!upstream.ok) {
          res.statusCode = 502;
          res.end('Unable to fetch document for inline display');
          return;
        }

        const upstreamContentType = upstream.headers.get('content-type');
        const contentType =
          upstreamContentType && upstreamContentType !== 'application/octet-stream'
            ? upstreamContentType
            : 'application/pdf';
        const upstreamContentLength = upstream.headers.get('content-length');

        // Construct meaningful filename: StandardName_Version.pdf
        const filename = `${standardVersion.standard.name.replace(/\s+/g, '_')}_${standardVersion.version}.pdf`;

        res.statusCode = 200;
        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Disposition', `inline; filename="${filename}"`);
        if (upstreamContentLength) {
          res.setHeader('Content-Length', upstreamContentLength);
        }

        const stream = toNodeReadable(upstream.body);
        if (stream) {
          stream.on('error', () => {
            res.statusCode = 502;
            res.end('Error streaming document');
          });
          stream.pipe(response as any);
          return;
        }

        const buffer = await collectBufferedPayload(upstream as any);
        res.end(buffer);
        return;
      } catch (error) {
        logger.warn('Failed to generate inline viewer URL', {
          error: error instanceof Error ? error.message : String(error),
          standardId,
        });
        res.statusCode = 502;
        res.end('Upstream service unavailable');
        return;
      }
    }

    // Matchmaker download/asset proxy routes (DGE/S3-backed).
    if (matchmakerHttp) {
      const handled = await matchmakerHttp(request as any, response as any);
      if (handled) {
        return;
      }
    }

    return yoga(request as any, response as any);
  };

  const server = createHttpServer(handler as any);

  server.listen(config.server.port, () => {
    logger.info('GraphQL server listening', {
      port: config.server.port,
      url: `http://localhost:${config.server.port}/graphql`,
    });
  });

  const shutdown = () => {
    destroyFeatureFlags();
    server.close();
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);

  return server;
};
