import type { Logger } from './logger';

export interface AuthenticatedUser {
  username: string;
  email?: string;
  name?: string;
  givenName?: string;
  familyName?: string;
  groups: string[];
  expiresAt?: Date;
  issuedAt?: Date;
  warning?: string;
}

export class AuthenticationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AuthenticationError';
  }
}

export const extractAuthHeaders = (request: Request, logger: Logger): AuthenticatedUser => {
  const username = request.headers.get('x-amzn-oidc-identity');
  const encodedData = request.headers.get('x-amzn-oidc-data');

  if (!username) {
    logger.warn('Missing x-amzn-oidc-identity header');
    throw new AuthenticationError('Authentication required - missing identity header');
  }

  // Initialize with defaults
  let email: string | undefined;
  let name: string | undefined;
  let givenName: string | undefined;
  let familyName: string | undefined;
  let groups: string[] = [];
  let expiresAt: Date | undefined;
  let issuedAt: Date | undefined;
  let warning: string | undefined;

  if (encodedData) {
    try {
      let claims: Record<string, unknown>;

      // AWS ALB sends JWT tokens (header.payload.signature)
      // Need to extract and decode the payload (middle part)
      if (encodedData.includes('.')) {
        // It's a JWT token - split and decode the payload
        const parts = encodedData.split('.');
        if (parts.length !== 3) {
          throw new Error(`Invalid JWT format: expected 3 parts, got ${parts.length}`);
        }
        const payload = parts[1];
        const decoded = Buffer.from(payload, 'base64').toString('utf8');
        claims = JSON.parse(decoded);
        logger.info('Decoded JWT token', { tokenFormat: 'JWT' });
      } else {
        // It's base64-encoded JSON (for testing/dev)
        const decoded = Buffer.from(encodedData, 'base64').toString('utf8');
        claims = JSON.parse(decoded);
        logger.info('Decoded base64 JSON', { tokenFormat: 'base64-json' });
      }

      // Extract standard claims - handle both standard OIDC names and Amazon Federate names
      // Amazon Federate uses uppercase claims: EMAIL, GIVEN_NAME, UID
      email =
        typeof claims.email === 'string'
          ? claims.email
          : typeof claims.EMAIL === 'string'
            ? claims.EMAIL
            : undefined;
      name = typeof claims.name === 'string' ? claims.name : undefined;
      givenName =
        typeof claims.given_name === 'string'
          ? claims.given_name
          : typeof claims.GIVEN_NAME === 'string'
            ? claims.GIVEN_NAME
            : undefined;
      familyName = typeof claims.family_name === 'string' ? claims.family_name : undefined;

      // Groups may be in different formats
      groups = Array.isArray(claims.groups)
        ? (claims.groups as string[])
        : Array.isArray(claims.GROUPS)
          ? (claims.GROUPS as string[])
          : Array.isArray(claims['cognito:groups'])
            ? (claims['cognito:groups'] as string[])
            : [];

      // Parse timestamps (Unix epoch seconds to Date)
      if (claims.exp && typeof claims.exp === 'number') {
        expiresAt = new Date(claims.exp * 1000);
      }
      if (claims.iat && typeof claims.iat === 'number') {
        issuedAt = new Date(claims.iat * 1000);
      }

      logger.info('Successfully parsed OIDC data', {
        username,
        hasEmail: !!email,
        groupCount: groups.length,
        claimKeys: Object.keys(claims), // Log available claims for debugging
      });
    } catch (error) {
      // Log full diagnostic info including complete header value for troubleshooting
      // But don't throw - return partial user data with username and warning
      const errorMessage = error instanceof Error ? error.message : String(error);
      warning = `Failed to decode OIDC claims: ${errorMessage}. Only username is available.`;

      logger.warn('Failed to decode OIDC data - returning partial user data', {
        username,
        errorName: error instanceof Error ? error.name : 'UnknownError',
        errorMessage,
        headerLength: encodedData.length,
        fullHeader: encodedData, // Complete header for diagnosis
        isValidBase64: /^[A-Za-z0-9+/=]+$/.test(encodedData),
      });
    }
  } else {
    logger.info('No OIDC data header present - returning minimal user data', { username });
    warning = 'OIDC data header not present. Only username is available.';
  }

  return {
    username,
    email,
    name,
    givenName,
    familyName,
    groups,
    expiresAt,
    issuedAt,
    warning,
  };
};
