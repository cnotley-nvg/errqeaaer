import {
  createStructuredLogger,
  type LogContext,
  type Logger,
} from '@amzn/global-realty-mosaic-shared-utils';

export const createLogger = (scope: string, context: LogContext = {}): Logger =>
  createStructuredLogger(scope, context);

export const rootLogger = createLogger('backend');

const REQUIRED_METHODS: (keyof Logger)[] = ['info', 'warn', 'error', 'child'];

export const ensureLogger = (candidate: Logger, scope: string): Logger => {
  const missing = REQUIRED_METHODS.filter((method) => typeof candidate[method] !== 'function');

  if (missing.length) {
    throw new Error(`Logger for ${scope} is missing methods: ${missing.join(', ')}`);
  }

  return candidate;
};

export type { LogContext, Logger };
