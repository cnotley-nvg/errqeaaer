/**
 * Simple batching utility for GraphQL field resolvers.
 * Batches multiple requests into a single database query to avoid N+1 problems.
 */

type BatchLoadFn<K, V> = (keys: readonly K[]) => Promise<readonly V[]>;

interface BatchLoaderOptions {
  /**
   * Maximum time to wait before executing a batch (in milliseconds).
   * Default: 1ms (next tick)
   */
  batchScheduleFn?: (callback: () => void) => void;
}

export class BatchLoader<K, V> {
  private readonly loadFn: BatchLoadFn<K, V>;
  private readonly batchScheduleFn: (callback: () => void) => void;
  private queue: Array<{
    key: K;
    resolve: (value: V) => void;
    reject: (error: Error) => void;
  }> = [];
  private batchScheduled = false;

  constructor(loadFn: BatchLoadFn<K, V>, options: BatchLoaderOptions = {}) {
    this.loadFn = loadFn;
    this.batchScheduleFn = options.batchScheduleFn ?? ((cb) => process.nextTick(cb));
  }

  load(key: K): Promise<V> {
    return new Promise((resolve, reject) => {
      this.queue.push({ key, resolve, reject });

      if (!this.batchScheduled) {
        this.batchScheduled = true;
        this.batchScheduleFn(() => this.executeBatch());
      }
    });
  }

  private async executeBatch(): Promise<void> {
    const batch = this.queue;
    this.queue = [];
    this.batchScheduled = false;

    if (batch.length === 0) {
      return;
    }

    try {
      const keys = batch.map((item) => item.key);
      const results = await this.loadFn(keys);

      if (results.length !== keys.length) {
        throw new Error(
          `BatchLoader: loadFn returned ${results.length} results but expected ${keys.length}`
        );
      }

      batch.forEach((item, index) => {
        item.resolve(results[index]);
      });
    } catch (error) {
      batch.forEach((item) => {
        item.reject(error as Error);
      });
    }
  }

  /**
   * Clear the internal cache. This is primarily useful for testing.
   */
  clear(): void {
    this.queue = [];
    this.batchScheduled = false;
  }
}
