import { extractAuthHeaders, AuthenticationError } from '../auth';
import { createLogger } from '../logger';

describe('extractAuthHeaders', () => {
  const logger = createLogger('test');

  const createMockRequest = (headers: Record<string, string>): Request => {
    return {
      headers: {
        get: (name: string) => headers[name.toLowerCase()] ?? null,
      },
    } as Request;
  };

  const createOIDCData = (claims: Record<string, unknown>): string => {
    return Buffer.from(JSON.stringify(claims)).toString('base64');
  };

  describe('successful parsing', () => {
    it('should parse complete OIDC token with all claims', () => {
      const claims = {
        sub: 'testuser',
        email: 'testuser@amazon.com',
        name: 'Test User',
        given_name: 'Test',
        family_name: 'User',
        groups: ['developers', 'admins'],
        exp: 1734460200,
        iat: 1734424200,
      };

      const request = createMockRequest({
        'x-amzn-oidc-identity': 'testuser',
        'x-amzn-oidc-data': createOIDCData(claims),
      });

      const result = extractAuthHeaders(request, logger);

      expect(result).toEqual({
        username: 'testuser',
        email: 'testuser@amazon.com',
        name: 'Test User',
        givenName: 'Test',
        familyName: 'User',
        groups: ['developers', 'admins'],
        expiresAt: new Date(1734460200 * 1000),
        issuedAt: new Date(1734424200 * 1000),
        warning: undefined,
      });
    });

    it('should handle minimal token with only required claims', () => {
      const claims = {
        sub: 'testuser',
      };

      const request = createMockRequest({
        'x-amzn-oidc-identity': 'testuser',
        'x-amzn-oidc-data': createOIDCData(claims),
      });

      const result = extractAuthHeaders(request, logger);

      expect(result).toEqual({
        username: 'testuser',
        email: undefined,
        name: undefined,
        givenName: undefined,
        familyName: undefined,
        groups: [],
        expiresAt: undefined,
        issuedAt: undefined,
        warning: undefined,
      });
    });

    it('should default to empty array when groups claim is missing', () => {
      const claims = {
        sub: 'testuser',
        email: 'testuser@amazon.com',
      };

      const request = createMockRequest({
        'x-amzn-oidc-identity': 'testuser',
        'x-amzn-oidc-data': createOIDCData(claims),
      });

      const result = extractAuthHeaders(request, logger);

      expect(result.groups).toEqual([]);
    });

    it('should parse timestamps correctly', () => {
      const exp = Math.floor(Date.now() / 1000) + 3600; // 1 hour from now
      const iat = Math.floor(Date.now() / 1000);

      const claims = {
        sub: 'testuser',
        exp,
        iat,
      };

      const request = createMockRequest({
        'x-amzn-oidc-identity': 'testuser',
        'x-amzn-oidc-data': createOIDCData(claims),
      });

      const result = extractAuthHeaders(request, logger);

      expect(result.expiresAt).toBeInstanceOf(Date);
      expect(result.issuedAt).toBeInstanceOf(Date);
      expect(result.expiresAt!.getTime()).toBe(exp * 1000);
      expect(result.issuedAt!.getTime()).toBe(iat * 1000);
    });

    it('should handle missing optional claims gracefully', () => {
      const claims = {
        sub: 'testuser',
        groups: ['developers'],
      };

      const request = createMockRequest({
        'x-amzn-oidc-identity': 'testuser',
        'x-amzn-oidc-data': createOIDCData(claims),
      });

      const result = extractAuthHeaders(request, logger);

      expect(result.username).toBe('testuser');
      expect(result.email).toBeUndefined();
      expect(result.name).toBeUndefined();
      expect(result.givenName).toBeUndefined();
      expect(result.familyName).toBeUndefined();
      expect(result.groups).toEqual(['developers']);
    });

    it('should parse Amazon Federate uppercase claims (EMAIL, GIVEN_NAME)', () => {
      const claims = {
        sub: 'testuser',
        EMAIL: 'testuser@amazon.com',
        GIVEN_NAME: 'Test',
        UID: 'testuser',
        exp: 1734460200,
        iat: 1734424200,
      };

      const request = createMockRequest({
        'x-amzn-oidc-identity': 'testuser',
        'x-amzn-oidc-data': createOIDCData(claims),
      });

      const result = extractAuthHeaders(request, logger);

      expect(result.username).toBe('testuser');
      expect(result.email).toBe('testuser@amazon.com');
      expect(result.givenName).toBe('Test');
      expect(result.name).toBeUndefined(); // Federate doesn't provide full name
      expect(result.familyName).toBeUndefined(); // Federate doesn't provide family name
      expect(result.groups).toEqual([]);
      expect(result.expiresAt).toEqual(new Date(1734460200 * 1000));
      expect(result.warning).toBeUndefined();
    });

    it('should parse JWT token format (header.payload.signature)', () => {
      const header = Buffer.from(JSON.stringify({ alg: 'RS256', kid: 'key-id' })).toString(
        'base64'
      );
      const payload = Buffer.from(
        JSON.stringify({
          sub: 'testuser',
          email: 'testuser@amazon.com',
          given_name: 'Test',
          family_name: 'User',
          groups: ['developers'],
          exp: 1734460200,
          iat: 1734424200,
        })
      ).toString('base64');
      const signature = 'fake-signature';
      const jwtToken = `${header}.${payload}.${signature}`;

      const request = createMockRequest({
        'x-amzn-oidc-identity': 'testuser',
        'x-amzn-oidc-data': jwtToken,
      });

      const result = extractAuthHeaders(request, logger);

      expect(result.username).toBe('testuser');
      expect(result.email).toBe('testuser@amazon.com');
      expect(result.givenName).toBe('Test');
      expect(result.familyName).toBe('User');
      expect(result.groups).toEqual(['developers']);
      expect(result.expiresAt).toEqual(new Date(1734460200 * 1000));
      expect(result.warning).toBeUndefined();
    });
  });

  describe('error handling', () => {
    it('should throw AuthenticationError when identity header is missing', () => {
      const request = createMockRequest({});

      expect(() => extractAuthHeaders(request, logger)).toThrow(AuthenticationError);
      expect(() => extractAuthHeaders(request, logger)).toThrow('missing identity header');
    });

    it('should return partial data with warning when OIDC data is invalid base64', () => {
      const request = createMockRequest({
        'x-amzn-oidc-identity': 'testuser',
        'x-amzn-oidc-data': 'invalid-base64!!!',
      });

      const result = extractAuthHeaders(request, logger);

      expect(result.username).toBe('testuser');
      expect(result.groups).toEqual([]);
      expect(result.warning).toContain('Failed to decode OIDC claims');
      expect(result.warning).toContain('Only username is available');
    });

    it('should return partial data with warning when OIDC data is not valid JSON', () => {
      const invalidJson = Buffer.from('not-json').toString('base64');

      const request = createMockRequest({
        'x-amzn-oidc-identity': 'testuser',
        'x-amzn-oidc-data': invalidJson,
      });

      const result = extractAuthHeaders(request, logger);

      expect(result.username).toBe('testuser');
      expect(result.groups).toEqual([]);
      expect(result.warning).toContain('Failed to decode OIDC claims');
    });

    it('should include error details in warning message', () => {
      const invalidJson = Buffer.from('{invalid json}').toString('base64');

      const request = createMockRequest({
        'x-amzn-oidc-identity': 'testuser',
        'x-amzn-oidc-data': invalidJson,
      });

      const result = extractAuthHeaders(request, logger);

      expect(result.warning).toMatch(/Failed to decode OIDC claims/);
      expect(result.warning).toContain('Only username is available');
    });
  });

  describe('edge cases', () => {
    it('should handle empty groups array', () => {
      const claims = {
        sub: 'testuser',
        groups: [],
      };

      const request = createMockRequest({
        'x-amzn-oidc-identity': 'testuser',
        'x-amzn-oidc-data': createOIDCData(claims),
      });

      const result = extractAuthHeaders(request, logger);

      expect(result.groups).toEqual([]);
    });

    it('should handle null exp/iat timestamps', () => {
      const claims = {
        sub: 'testuser',
        exp: null,
        iat: null,
      };

      const request = createMockRequest({
        'x-amzn-oidc-identity': 'testuser',
        'x-amzn-oidc-data': createOIDCData(claims),
      });

      const result = extractAuthHeaders(request, logger);

      expect(result.expiresAt).toBeUndefined();
      expect(result.issuedAt).toBeUndefined();
    });

    it('should handle non-numeric exp/iat timestamps', () => {
      const claims = {
        sub: 'testuser',
        exp: 'not-a-number',
        iat: 'not-a-number',
      };

      const request = createMockRequest({
        'x-amzn-oidc-identity': 'testuser',
        'x-amzn-oidc-data': createOIDCData(claims),
      });

      const result = extractAuthHeaders(request, logger);

      expect(result.expiresAt).toBeUndefined();
      expect(result.issuedAt).toBeUndefined();
    });

    it('should return warning when x-amzn-oidc-data header is missing', () => {
      const request = createMockRequest({
        'x-amzn-oidc-identity': 'testuser',
      });

      const result = extractAuthHeaders(request, logger);

      expect(result).toEqual({
        username: 'testuser',
        email: undefined,
        name: undefined,
        givenName: undefined,
        familyName: undefined,
        groups: [],
        expiresAt: undefined,
        issuedAt: undefined,
        warning: 'OIDC data header not present. Only username is available.',
      });
    });
  });
});
