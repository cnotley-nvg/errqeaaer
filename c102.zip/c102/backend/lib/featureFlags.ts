import { initialize, Unleash, Context } from 'unleash-client';

let unleashInstance: Unleash | null = null;
let initializingPromise: Promise<void> | null = null;

export const FeatureFlags = {
  MosaicTestBanner: 'MosaicTestBanner',
} as const;

type FeatureFlagKey = (typeof FeatureFlags)[keyof typeof FeatureFlags];

export async function initializeFeatureFlags(): Promise<void> {
  if (unleashInstance) return;
  if (initializingPromise) return initializingPromise;

  const url = process.env.UNLEASH_API_URL;
  const token = process.env.UNLEASH_API_TOKEN;

  if (!url || !token) {
    console.warn(
      '[Feature Flags] Server SDK not configured. Set UNLEASH_API_URL and UNLEASH_API_TOKEN.'
    );
    return;
  }

  initializingPromise = new Promise((resolve, reject) => {
    try {
      unleashInstance = initialize({
        url,
        appName: 'mosaic-backend',
        customHeaders: { Authorization: token },
        refreshInterval: 60000, // 60 seconds
        metricsInterval: 60000,
      });

      unleashInstance.on('ready', () => {
        resolve();
      });

      unleashInstance.on('error', (error: Error) => {
        console.error('[Feature Flags] Server SDK error:', error);
        resolve();
      });
    } catch (error) {
      console.error('[Feature Flags] Failed to initialize:', error);
      resolve();
    }
  });

  return initializingPromise;
}

export function isFeatureEnabled(flagName: FeatureFlagKey, context?: Context): boolean {
  if (!unleashInstance) return false;
  return unleashInstance.isEnabled(flagName, context);
}

export function getAllFeatureFlags(): Record<string, boolean> {
  const flags: Record<string, boolean> = {};
  for (const [key, flagName] of Object.entries(FeatureFlags)) {
    flags[flagName] = isFeatureEnabled(flagName);
  }
  return flags;
}

export function destroyFeatureFlags(): void {
  if (unleashInstance) {
    unleashInstance.destroy();
    unleashInstance = null;
    initializingPromise = null;
  }
}
