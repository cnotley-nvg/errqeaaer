export { prisma, getPrismaClient } from '@amzn/global-realty-mosaic-prisma-client';
export type { Prisma, PrismaClient } from '@amzn/global-realty-mosaic-prisma-client';
