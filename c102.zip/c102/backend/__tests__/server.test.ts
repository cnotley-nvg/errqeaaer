import type { BackendRuntimeConfig } from '../config/runtimeConfig';
import { startServer } from '../server';
import type { Logger } from '../shared';

function createMockLogger(): jest.Mocked<Logger> {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;

  logger.child.mockReturnValue(logger);
  return logger;
}

var rootLoggerMock: jest.Mocked<Logger>;
let capturedHandler: ((req: any, res: any) => Promise<void> | void) | null;

jest.mock('node:http', () => ({
  createServer: jest.fn(),
}));

jest.mock('../config/runtimeConfig', () => ({
  getRuntimeConfig: jest.fn(),
}));

const mockGetSignedDownloadUrl = jest.fn();

jest.mock('../shared', () => {
  const actual = jest.requireActual('../shared');
  rootLoggerMock = createMockLogger();

  // Mock AccClient
  class MockAccClient {
    getSignedDownloadUrl = mockGetSignedDownloadUrl;
  }

  return {
    ...actual,
    rootLogger: rootLoggerMock,
    ensureLogger: jest.fn((_logger: Logger) => _logger),
    AccClient: MockAccClient,
  };
});

jest.mock('../createGraphqlServer', () => ({
  createGraphqlServer: jest.fn(),
}));

jest.mock('../modules/standards/infra/standardMetadataService', () => ({
  createStandardMetadataService: jest.fn(),
}));

jest.mock('../lib/prisma', () => ({
  prisma: {
    standardVersion: {
      findFirst: jest.fn(),
    },
  },
}));

jest.mock('../lib/featureFlags', () => ({
  initializeFeatureFlags: jest.fn().mockResolvedValue(undefined),
  isFeatureEnabled: jest.fn().mockReturnValue(false),
  shutdownFeatureFlags: jest.fn().mockResolvedValue(undefined),
  FeatureFlag: {
    MosaicTestBanner: 'MosaicTestBanner',
  },
}));

describe('startServer', () => {
  const buildConfig = (port = 5000): BackendRuntimeConfig => ({
    server: { port, corsOrigins: [], publicBaseUrl: `http://localhost:${port}` },
    proxy: {
      baseUrl: 'http://localhost:8080',
      timeoutMs: 5000,
    },
    database: { url: 'postgresql://user:pass@localhost:5432/mosaic' },
  });

  const createLogger = createMockLogger;

  const buildServer = () => ({
    listen: jest.fn((_port: number, callback: () => void) => {
      callback();
    }),
    close: jest.fn(),
  });

  beforeEach(() => {
    jest.clearAllMocks();
    mockGetSignedDownloadUrl.mockReset();
    capturedHandler = null;
    const httpModule = require('node:http');
    httpModule.createServer.mockImplementation(
      (handler: (req: any, res: any) => void | Promise<void>) => {
        capturedHandler = handler;
        return buildServer();
      }
    );

    const graphqlModule = require('../createGraphqlServer');
    graphqlModule.createGraphqlServer.mockReturnValue({
      yoga: jest.fn(),
    });

    // Default mock for AccClient
    mockGetSignedDownloadUrl.mockResolvedValue('https://signed-inline-url');

    const prismaModule = require('../lib/prisma');
    prismaModule.prisma.standardVersion.findFirst.mockResolvedValue({
      accFileId: 'std-123',
      accFolderId: 'folder-456',
      standardId: 'standard-789',
      standard: {
        accProjectId: 'project-abc',
      },
    });
  });

  it('creates a server using runtime configuration and default logger', async () => {
    const config = buildConfig(4000);
    const httpModule = require('node:http');
    const runtimeModule = require('../config/runtimeConfig');
    const sharedModule = require('../shared');
    const graphqlModule = require('../createGraphqlServer');

    runtimeModule.getRuntimeConfig.mockReturnValue(config);

    const server = await startServer();

    expect(runtimeModule.getRuntimeConfig).toHaveBeenCalledTimes(1);
    expect(graphqlModule.createGraphqlServer).toHaveBeenCalledWith(config, {
      logger: sharedModule.rootLogger,
    });
    expect(httpModule.createServer).toHaveBeenCalledWith(expect.any(Function));

    const createdServer = httpModule.createServer.mock.results[0].value;
    expect(createdServer.listen).toHaveBeenCalledWith(4000, expect.any(Function));
    expect(sharedModule.rootLogger.info).toHaveBeenCalledWith('GraphQL server listening', {
      port: 4000,
      url: 'http://localhost:4000/graphql',
    });

    expect(server).toBe(createdServer);
  });

  it('supports dependency overrides for configuration and logger', async () => {
    const config = buildConfig(4500);
    const logger = createLogger();
    const httpModule = require('node:http');
    const runtimeModule = require('../config/runtimeConfig');
    const graphqlModule = require('../createGraphqlServer');

    const server = await startServer({ config, logger });

    expect(runtimeModule.getRuntimeConfig).not.toHaveBeenCalled();
    expect(graphqlModule.createGraphqlServer).toHaveBeenCalledWith(config, { logger });

    const createdServer = httpModule.createServer.mock.results[0].value;
    expect(createdServer.listen).toHaveBeenCalledWith(4500, expect.any(Function));
    expect(logger.info).toHaveBeenCalledWith('GraphQL server listening', {
      port: 4500,
      url: 'http://localhost:4500/graphql',
    });

    expect(server).toBe(createdServer);
  });

  it('serves /standards/:id/viewer inline when a signed url is available', async () => {
    const config = buildConfig(4600);
    const logger = createLogger();

    const prismaModule = require('../lib/prisma');
    prismaModule.prisma.standardVersion.findFirst.mockResolvedValue({
      accFileId: 'std-123',
      version: '1.0',
      standard: {
        accProjectId: 'project-abc',
        name: 'Test Standard',
      },
    });

    const metadataModule = require('../modules/standards/infra/standardMetadataService');
    const mockMetadataService = {
      getFileStorageUrn: jest.fn().mockResolvedValue('urn:adsk.objects:os.object:bucket/key.pdf'),
      getSignedUrl: jest.fn().mockResolvedValue('https://signed-inline-url'),
    };
    metadataModule.createStandardMetadataService.mockReturnValue(mockMetadataService);

    // @ts-expect-error
    global.fetch = jest.fn(async (input: string) => {
      if (input !== 'https://signed-inline-url') {
        return {
          ok: false,
          status: 404,
          headers: { get: () => null },
        };
      }
      const pdfBuffer = Buffer.from('%PDF-1.4\n%...mock-pdf...');
      return {
        ok: true,
        status: 200,
        body: {},
        headers: {
          get: (name: string) => (name.toLowerCase() === 'content-type' ? 'application/pdf' : null),
        },
        arrayBuffer: async () => pdfBuffer,
      };
    });

    await startServer({ config, logger });

    const req = { method: 'GET', url: '/standards/std-123/viewer', headers: {} };
    const res = {
      statusCode: 0,
      headers: {} as Record<string, string>,
      setHeader(name: string, value: string) {
        this.headers[name] = value;
      },
      end: jest.fn(),
    };

    await capturedHandler?.(req, res);

    expect(mockGetSignedDownloadUrl).toHaveBeenCalledWith('project-abc', 'std-123', {
      disposition: 'inline',
    });

    expect(res.statusCode).toBe(200);
    expect(res.headers['Content-Type']).toBe('application/pdf');
    expect(res.headers['Content-Disposition']).toBe('inline; filename="Test_Standard_1.0.pdf"');
    expect(res.end).toHaveBeenCalled();
  });

  it('returns 404 when the standard document cannot be found', async () => {
    const config = buildConfig(4700);
    const logger = createLogger();

    const prismaModule = require('../lib/prisma');
    prismaModule.prisma.standardVersion.findFirst.mockResolvedValue({
      accFileId: 'std-404',
      accFolderId: 'folder-456',
      standardId: 'standard-789',
      standard: {
        accProjectId: 'project-abc',
      },
    });

    // Mock AccClient to throw ProxyRequestError (simulating file not found)
    const { ProxyRequestError } = require('@amzn/global-realty-mosaic-acc-client/dist/errors');
    mockGetSignedDownloadUrl.mockRejectedValue(
      new ProxyRequestError({
        label: 'get-storage-urn',
        status: 404,
        url: 'http://test',
        details: 'No metadata found for file',
      })
    );

    await startServer({ config, logger });

    const req = { method: 'GET', url: '/standards/std-404/viewer', headers: {} };
    const res = {
      statusCode: 0,
      headers: {} as Record<string, string>,
      setHeader() {},
      end: jest.fn(),
    };

    await capturedHandler?.(req, res);

    expect(res.statusCode).toBe(502);
    expect(logger.warn).toHaveBeenCalled();
  });

  it('returns 502 when a signed viewer URL cannot be generated', async () => {
    const config = buildConfig(4800);
    const logger = createLogger();

    const prismaModule = require('../lib/prisma');
    prismaModule.prisma.standardVersion.findFirst.mockResolvedValue({
      accFileId: 'std-502',
      accFolderId: 'folder-456',
      standardId: 'standard-789',
      standard: {
        accProjectId: 'project-abc',
      },
    });

    // Mock AccClient to throw an error
    mockGetSignedDownloadUrl.mockRejectedValue(new Error('Failed to generate signed URL'));

    await startServer({ config, logger });

    const req = { method: 'GET', url: '/standards/std-502/viewer', headers: {} };
    const res = {
      statusCode: 0,
      headers: {} as Record<string, string>,
      setHeader() {},
      end: jest.fn(),
    };

    await capturedHandler?.(req, res);

    expect(res.statusCode).toBe(502);
    expect(logger.warn).toHaveBeenCalled();
  });

  it('returns 502 and logs warn when upstream call throws', async () => {
    const config = buildConfig(4900);
    const logger = createLogger();

    const prismaModule = require('../lib/prisma');
    prismaModule.prisma.standardVersion.findFirst.mockResolvedValue({
      accFileId: 'std-err',
      accFolderId: 'folder-456',
      standardId: 'standard-789',
      standard: {
        accProjectId: 'project-abc',
      },
    });

    // Mock AccClient to succeed
    mockGetSignedDownloadUrl.mockResolvedValueOnce('https://signed-url');

    // Mock the upstream fetch to throw
    global.fetch = jest.fn().mockRejectedValue(new Error('boom'));

    await startServer({ config, logger });

    const req = { method: 'GET', url: '/standards/std-err/viewer', headers: {} };
    const res = {
      statusCode: 0,
      headers: {} as Record<string, string>,
      setHeader() {},
      end: jest.fn(),
    };

    await capturedHandler?.(req, res);

    expect(res.statusCode).toBe(502);
    expect(res.end).toHaveBeenCalledWith('Upstream service unavailable');
    expect(logger.warn).toHaveBeenCalledWith(
      'Failed to generate inline viewer URL',
      expect.any(Object)
    );
  });
});
