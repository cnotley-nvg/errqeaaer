import { BatchLoader } from '../../lib/batchLoader';

describe('BatchLoader', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Basic Functionality', () => {
    it('should batch multiple load calls into a single loadFn invocation', async () => {
      const loadFn = jest.fn(async (keys: readonly number[]) => {
        return keys.map((key) => key * 2);
      });

      const loader = new BatchLoader(loadFn);

      // Make multiple simultaneous load calls
      const promise1 = loader.load(1);
      const promise2 = loader.load(2);
      const promise3 = loader.load(3);

      const [result1, result2, result3] = await Promise.all([promise1, promise2, promise3]);

      // All three calls should be batched into one loadFn invocation
      expect(loadFn).toHaveBeenCalledTimes(1);
      expect(loadFn).toHaveBeenCalledWith([1, 2, 3]);

      // Results should be correctly mapped
      expect(result1).toBe(2);
      expect(result2).toBe(4);
      expect(result3).toBe(6);
    });

    it('should handle single load call', async () => {
      const loadFn = jest.fn(async (keys: readonly string[]) => {
        return keys.map((key) => `result-${key}`);
      });

      const loader = new BatchLoader(loadFn);

      const result = await loader.load('test');

      expect(loadFn).toHaveBeenCalledTimes(1);
      expect(loadFn).toHaveBeenCalledWith(['test']);
      expect(result).toBe('result-test');
    });

    it('should handle empty batch gracefully', async () => {
      const loadFn = jest.fn(async (keys: readonly number[]) => {
        return keys.map((key) => key * 2);
      });

      const loader = new BatchLoader(loadFn);

      // Trigger batch execution without any loads
      await new Promise((resolve) => process.nextTick(resolve));

      expect(loadFn).not.toHaveBeenCalled();
    });
  });

  describe('Batch Scheduling', () => {
    it('should use custom batchScheduleFn when provided', async () => {
      const loadFn = jest.fn(async (keys: readonly number[]) => {
        return keys.map((key) => key * 2);
      });

      const customScheduler = jest.fn((callback: () => void) => {
        setImmediate(callback);
      });

      const loader = new BatchLoader(loadFn, {
        batchScheduleFn: customScheduler,
      });

      const promise1 = loader.load(1);
      const promise2 = loader.load(2);

      await Promise.all([promise1, promise2]);

      expect(customScheduler).toHaveBeenCalledTimes(1);
      expect(loadFn).toHaveBeenCalledTimes(1);
    });

    it('should use process.nextTick by default', async () => {
      const loadFn = jest.fn(async (keys: readonly number[]) => {
        return keys.map((key) => key * 2);
      });

      const loader = new BatchLoader(loadFn);

      // Load calls made in current tick
      const promise1 = loader.load(1);
      const promise2 = loader.load(2);

      // loadFn should not be called synchronously
      expect(loadFn).not.toHaveBeenCalled();

      // Wait for next tick
      await Promise.all([promise1, promise2]);

      // Now loadFn should have been called
      expect(loadFn).toHaveBeenCalledTimes(1);
    });

    it('should create separate batches for loads in different ticks', async () => {
      const loadFn = jest.fn(async (keys: readonly number[]) => {
        return keys.map((key) => key * 2);
      });

      const loader = new BatchLoader(loadFn);

      // First batch
      const promise1 = loader.load(1);
      const promise2 = loader.load(2);
      await Promise.all([promise1, promise2]);

      // Second batch (after first batch completes)
      const promise3 = loader.load(3);
      const promise4 = loader.load(4);
      await Promise.all([promise3, promise4]);

      // Should have two separate loadFn invocations
      expect(loadFn).toHaveBeenCalledTimes(2);
      expect(loadFn).toHaveBeenNthCalledWith(1, [1, 2]);
      expect(loadFn).toHaveBeenNthCalledWith(2, [3, 4]);
    });
  });

  describe('Error Handling', () => {
    it('should reject all batched promises when loadFn throws', async () => {
      const errorMessage = 'Database connection failed';
      const loadFn = jest.fn(async () => {
        throw new Error(errorMessage);
      });

      const loader = new BatchLoader(loadFn);

      const promise1 = loader.load(1);
      const promise2 = loader.load(2);
      const promise3 = loader.load(3);

      await expect(promise1).rejects.toThrow(errorMessage);
      await expect(promise2).rejects.toThrow(errorMessage);
      await expect(promise3).rejects.toThrow(errorMessage);

      expect(loadFn).toHaveBeenCalledTimes(1);
    });

    it('should throw error when loadFn returns wrong number of results', async () => {
      const loadFn = jest.fn(async (keys: readonly number[]) => {
        // Return fewer results than keys
        return [keys[0] * 2];
      });

      const loader = new BatchLoader(loadFn);

      const promise1 = loader.load(1);
      const promise2 = loader.load(2);
      const promise3 = loader.load(3);

      await expect(promise1).rejects.toThrow(
        'BatchLoader: loadFn returned 1 results but expected 3'
      );
      await expect(promise2).rejects.toThrow(
        'BatchLoader: loadFn returned 1 results but expected 3'
      );
      await expect(promise3).rejects.toThrow(
        'BatchLoader: loadFn returned 1 results but expected 3'
      );
    });

    it('should continue working after error in previous batch', async () => {
      let callCount = 0;
      const loadFn = jest.fn(async (keys: readonly number[]) => {
        callCount++;
        if (callCount === 1) {
          throw new Error('First batch error');
        }
        return keys.map((key) => key * 2);
      });

      const loader = new BatchLoader(loadFn);

      // First batch - should fail
      const promise1 = loader.load(1);
      await expect(promise1).rejects.toThrow('First batch error');

      // Second batch - should succeed
      const promise2 = loader.load(2);
      const result = await promise2;

      expect(result).toBe(4);
      expect(loadFn).toHaveBeenCalledTimes(2);
    });
  });

  describe('Result Mapping', () => {
    it('should correctly map results to their corresponding keys', async () => {
      const loadFn = jest.fn(async (keys: readonly string[]) => {
        // Return results in same order as keys
        return keys.map((key) => ({ id: key, data: `data-${key}` }));
      });

      const loader = new BatchLoader(loadFn);

      const promise1 = loader.load('key1');
      const promise2 = loader.load('key2');
      const promise3 = loader.load('key3');

      const [result1, result2, result3] = await Promise.all([promise1, promise2, promise3]);

      expect(result1).toEqual({ id: 'key1', data: 'data-key1' });
      expect(result2).toEqual({ id: 'key2', data: 'data-key2' });
      expect(result3).toEqual({ id: 'key3', data: 'data-key3' });
    });

    it('should handle complex object types', async () => {
      interface User {
        id: number;
        name: string;
        email: string;
      }

      const loadFn = jest.fn(async (ids: readonly number[]): Promise<User[]> => {
        return ids.map((id) => ({
          id,
          name: `User ${id}`,
          email: `user${id}@example.com`,
        }));
      });

      const loader = new BatchLoader<number, User>(loadFn);

      const user1 = await loader.load(1);
      const user2 = await loader.load(2);

      expect(user1).toEqual({ id: 1, name: 'User 1', email: 'user1@example.com' });
      expect(user2).toEqual({ id: 2, name: 'User 2', email: 'user2@example.com' });
    });
  });

  describe('Clear Method', () => {
    it('should clear pending queue', async () => {
      const loadFn = jest.fn(async (keys: readonly number[]) => {
        return keys.map((key) => key * 2);
      });

      const loader = new BatchLoader(loadFn);

      // Queue some loads but don't await
      loader.load(1);
      loader.load(2);

      // Clear before execution
      loader.clear();

      // Wait for any pending ticks
      await new Promise((resolve) => setImmediate(resolve));

      // loadFn should not have been called because queue was cleared
      expect(loadFn).not.toHaveBeenCalled();
    });

    it('should reset batchScheduled flag', () => {
      const loadFn = jest.fn(async (keys: readonly number[]) => {
        return keys.map((key) => key * 2);
      });

      const loader = new BatchLoader(loadFn);

      // Queue a load
      loader.load(1);

      // Clear
      loader.clear();

      // Queue another load - should schedule a new batch
      loader.load(2);

      // The loader should be in a clean state
      expect(loadFn).not.toHaveBeenCalled();
    });
  });

  describe('Performance & N+1 Prevention', () => {
    it('should significantly reduce database calls (N+1 problem)', async () => {
      // Simulate fetching users by ID from a "database"
      const databaseCallCount = { count: 0 };

      const loadFn = jest.fn(async (userIds: readonly number[]) => {
        databaseCallCount.count++; // Count actual database calls
        // Simulate database fetch
        return userIds.map((id) => ({ id, name: `User ${id}` }));
      });

      const loader = new BatchLoader(loadFn);

      // Simulate GraphQL resolvers fetching related users
      // Without batching: 5 database calls
      // With batching: 1 database call
      const userPromises = [1, 2, 3, 4, 5].map((id) => loader.load(id));

      await Promise.all(userPromises);

      // Verify batching reduced 5 calls to 1
      expect(databaseCallCount.count).toBe(1);
      expect(loadFn).toHaveBeenCalledTimes(1);
      expect(loadFn).toHaveBeenCalledWith([1, 2, 3, 4, 5]);
    });

    it('should handle high-concurrency scenarios', async () => {
      const loadFn = jest.fn(async (keys: readonly number[]) => {
        return keys.map((key) => key * 2);
      });

      const loader = new BatchLoader(loadFn);

      // Simulate 100 concurrent requests
      const promises = Array.from({ length: 100 }, (_, i) => loader.load(i));

      const results = await Promise.all(promises);

      // All 100 requests batched into 1 call
      expect(loadFn).toHaveBeenCalledTimes(1);
      expect(results.length).toBe(100);
      expect(results[0]).toBe(0);
      expect(results[99]).toBe(198);
    });
  });

  describe('Edge Cases', () => {
    it('should handle null/undefined keys', async () => {
      const loadFn = jest.fn(async (keys: readonly (number | null | undefined)[]) => {
        return keys.map((key) => (key === null || key === undefined ? null : key * 2));
      });

      const loader = new BatchLoader<number | null | undefined, number | null>(loadFn);

      const result1 = await loader.load(null);
      const result2 = await loader.load(undefined);
      const result3 = await loader.load(5);

      expect(result1).toBeNull();
      expect(result2).toBeNull();
      expect(result3).toBe(10);
    });

    it('should handle duplicate keys in same batch', async () => {
      const loadFn = jest.fn(async (keys: readonly number[]) => {
        return keys.map((key) => key * 2);
      });

      const loader = new BatchLoader(loadFn);

      // Load same key multiple times
      const promise1 = loader.load(1);
      const promise2 = loader.load(1);
      const promise3 = loader.load(1);

      const [result1, result2, result3] = await Promise.all([promise1, promise2, promise3]);

      // loadFn receives duplicate keys
      expect(loadFn).toHaveBeenCalledWith([1, 1, 1]);

      // Each promise gets its own result (same value)
      expect(result1).toBe(2);
      expect(result2).toBe(2);
      expect(result3).toBe(2);
    });

    it('should handle async loadFn with delays', async () => {
      const loadFn = jest.fn(async (keys: readonly number[]) => {
        // Simulate async database delay
        await new Promise((resolve) => setTimeout(resolve, 10));
        return keys.map((key) => key * 2);
      });

      const loader = new BatchLoader(loadFn);

      const promise1 = loader.load(1);
      const promise2 = loader.load(2);

      const [result1, result2] = await Promise.all([promise1, promise2]);

      expect(result1).toBe(2);
      expect(result2).toBe(4);
      expect(loadFn).toHaveBeenCalledTimes(1);
    });
  });

  describe('Type Safety', () => {
    it('should maintain type safety with string keys and number values', async () => {
      const loadFn = async (keys: readonly string[]): Promise<number[]> => {
        return keys.map((key) => parseInt(key, 10));
      };

      const loader = new BatchLoader<string, number>(loadFn);

      const result1 = await loader.load('42');
      const result2 = await loader.load('100');

      // TypeScript should infer result types as number
      expect(typeof result1).toBe('number');
      expect(typeof result2).toBe('number');
      expect(result1).toBe(42);
      expect(result2).toBe(100);
    });

    it('should work with complex generic types', async () => {
      interface Query {
        table: string;
        id: number;
      }

      interface Result {
        data: string;
        timestamp: number;
      }

      const loadFn = async (queries: readonly Query[]): Promise<Result[]> => {
        return queries.map((q) => ({
          data: `${q.table}-${q.id}`,
          timestamp: Date.now(),
        }));
      };

      const loader = new BatchLoader<Query, Result>(loadFn);

      const result = await loader.load({ table: 'users', id: 1 });

      expect(result.data).toBe('users-1');
      expect(typeof result.timestamp).toBe('number');
    });
  });
});
