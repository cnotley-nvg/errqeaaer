import { FeatureFlags, isFeatureEnabled, getAllFeatureFlags } from '../../lib/featureFlags';

describe('featureFlags', () => {
  describe('FeatureFlags constant', () => {
    it('should export MosaicTestBanner flag', () => {
      expect(FeatureFlags.MosaicTestBanner).toBe('MosaicTestBanner');
    });
  });

  describe('isFeatureEnabled', () => {
    it('should return false when unleash is not initialized', () => {
      const result = isFeatureEnabled(FeatureFlags.MosaicTestBanner);
      expect(result).toBe(false);
    });
  });

  describe('getAllFeatureFlags', () => {
    it('should return object with all flags set to false when not initialized', () => {
      const flags = getAllFeatureFlags();
      expect(flags).toEqual({
        MosaicTestBanner: false,
      });
    });

    it('should return correct flag keys', () => {
      const flags = getAllFeatureFlags();
      expect(Object.keys(flags)).toContain('MosaicTestBanner');
    });
  });
});
