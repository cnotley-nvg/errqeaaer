import { getRuntimeConfig } from '../../config/runtimeConfig';

const buildMinimalEnv = (overrides: Record<string, string | undefined> = {}) => ({
  PORT: undefined,
  BACKEND_CORS_ORIGINS: undefined,
  ACC_PROXY_BASE_URL: undefined,
  APS_PROJECT_ID: undefined,
  APS_FOLDER_ID: undefined,
  ACC_PROXY_TIMEOUT_MS: undefined,
  DATABASE_URL: 'postgresql://user:pass@localhost:5432/mosaic',
  ...overrides,
});

describe('getRuntimeConfig', () => {
  it('returns sane defaults when environment variables are missing', () => {
    const config = getRuntimeConfig(buildMinimalEnv());

    expect(config.server.port).toBe(4000);
    expect(config.server.corsOrigins).toEqual(['http://localhost:3000', 'http://localhost:3001']);
    expect(config.server.publicBaseUrl).toBe('http://localhost:4000');

    expect(config.proxy).toBeUndefined();
    expect(config.database.url).toBe('postgresql://user:pass@localhost:5432/mosaic');
  });

  it('parses and normalizes provided environment variables', () => {
    const customEnv = buildMinimalEnv({
      PORT: '8080',
      BACKEND_CORS_ORIGINS: 'https://example.com, https://foo.test',
      BACKEND_PUBLIC_BASE_URL: 'https://backend.example/graphql-api',
      ACC_PROXY_BASE_URL: 'https://proxy.test',
      APS_PROJECT_ID: 'project-123',
      APS_FOLDER_ID: 'folder-abc',
      ACC_PROXY_TIMEOUT_MS: '15000',
      DATABASE_URL: 'postgresql://custom:secret@db.example:6543/mosaic-test',
    });

    const config = getRuntimeConfig(customEnv);

    expect(config.server.port).toBe(8080);
    expect(config.server.corsOrigins).toEqual(['https://example.com', 'https://foo.test']);
    expect(config.server.publicBaseUrl).toBe('https://backend.example/graphql-api');
    expect(config.proxy).toEqual({
      baseUrl: 'https://proxy.test',
      projectId: 'project-123',
      folderId: 'folder-abc',
      timeoutMs: 15000,
    });
    expect(config.database.url).toBe('postgresql://custom:secret@db.example:6543/mosaic-test');
  });

  it('throws when proxy configuration is partially specified', () => {
    const env = buildMinimalEnv({
      ACC_PROXY_BASE_URL: 'https://proxy.test',
      APS_PROJECT_ID: 'incomplete',
    });

    expect(() => getRuntimeConfig(env)).toThrow('Backend configuration invalid');
  });

  it('throws when database url is missing', () => {
    const env = buildMinimalEnv({
      DATABASE_URL: undefined,
    });

    expect(() => getRuntimeConfig(env)).toThrow('Backend configuration invalid');
  });

  it('accepts DGE S3 configuration (S3-only) and rejects local DGE directory configuration', () => {
    const withS3 = getRuntimeConfig(
      buildMinimalEnv({
        DATABASE_URL: 'postgresql://user:pass@localhost:5432/mosaic',
        DGE_S3_BUCKET: 'matchmaker-dge',
        DGE_S3_PREFIX: 'pref/',
        DGE_S3_REGION: 'us-east-1',
      })
    );
    expect(withS3.dge?.s3).toEqual({
      bucket: 'matchmaker-dge',
      prefix: 'pref/',
      region: 'us-east-1',
    });

    const envWithLocalDir = buildMinimalEnv({
      DATABASE_URL: 'postgresql://user:pass@localhost:5432/mosaic',
      DGE_LOCAL_DIR: '/some/local/path',
    });
    try {
      const cfg = getRuntimeConfig(envWithLocalDir);
      expect(cfg.dge).toBeUndefined();
    } catch (err) {
      expect(err instanceof Error ? err.message : String(err)).toContain('DGE_LOCAL_DIR');
    }
  });
});
