import { createStandardsModule } from '../../../modules/standards';
import type { Logger } from '../../../shared';
import type { BackendRuntimeConfig } from '../../../config/runtimeConfig';
import { createStandardService } from '../../../modules/standards/domain/standardService';
import { createStandardsResolvers } from '../../../modules/standards/graphql/resolvers';
import { createStandardMetadataService } from '../../../modules/standards/infra/standardMetadataService';

jest.mock('../../../modules/standards/domain/standardService', () => ({
  createStandardService: jest.fn(),
}));

jest.mock('../../../modules/standards/graphql/resolvers', () => ({
  createStandardsResolvers: jest.fn(),
}));

jest.mock('../../../modules/standards/infra/standardMetadataService', () => ({
  createStandardMetadataService: jest.fn(),
}));

const mockedCreateStandardService = createStandardService as jest.MockedFunction<
  typeof createStandardService
>;
const mockedCreateStandardsResolvers = createStandardsResolvers as jest.MockedFunction<
  typeof createStandardsResolvers
>;
const mockedCreateStandardMetadataService = createStandardMetadataService as jest.MockedFunction<
  typeof createStandardMetadataService
>;

const createLogger = (): jest.Mocked<Logger> => {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;

  logger.child.mockReturnValue(logger);
  return logger;
};

describe('createStandardsModule', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('creates the service and resolvers with scoped loggers', () => {
    const service = { search: jest.fn() } as never;
    const metadataService = {
      getStandardDocumentUrls: jest.fn(),
      fetchStandardMetadata: jest.fn(),
    } as never;
    const resolvers = { Query: {}, Mutation: {} } as never;
    mockedCreateStandardService.mockReturnValue(service);
    mockedCreateStandardMetadataService.mockReturnValue(metadataService);
    mockedCreateStandardsResolvers.mockReturnValue(resolvers);

    const moduleLogger = createLogger();
    const resolverLogger = createLogger();
    moduleLogger.child.mockReturnValue(resolverLogger);

    const rootLogger = createLogger();
    rootLogger.child.mockReturnValue(moduleLogger);

    const config: BackendRuntimeConfig = {
      server: { port: 8080, corsOrigins: ['*'], publicBaseUrl: 'http://localhost:8080' },
      proxy: undefined,
      database: { url: 'postgres://local' },
    };

    const module = createStandardsModule({ logger: rootLogger, config });

    expect(rootLogger.child).toHaveBeenCalledWith({ module: 'standards' });
    expect(moduleLogger.child).toHaveBeenCalledWith({ component: 'service' });
    expect(mockedCreateStandardsResolvers).toHaveBeenCalledWith({
      standardService: service,
      standardMetadataService: metadataService,
    });
    expect(module).toEqual({ resolvers, service });
  });
});
