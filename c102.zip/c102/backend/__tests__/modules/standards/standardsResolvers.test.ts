import { createStandardsResolvers } from '../../../modules/standards/graphql/resolvers';
import type { StandardService } from '../../../modules/standards/domain/standardService';

type MockedStandardService = jest.Mocked<StandardService>;

const createService = (): MockedStandardService => ({
  search: jest.fn(),
  getStandard: jest.fn(),
  getStandardByName: jest.fn(),
  getStandardVersion: jest.fn(),
  listStandardVersions: jest.fn(),
  listStandardVersionChanges: jest.fn(),
  listStandardVersionKeyItems: jest.fn(),
  listStandardVersionReferences: jest.fn(),
  listStandardVersionReferencesConnection: jest.fn(),
  isStandardNameAvailable: jest.fn(),
  listStandardsByKitVersion: jest.fn(),
  createStandard: jest.fn(),
  updateStandard: jest.fn(),
  deleteStandard: jest.fn(),
  createStandardVersion: jest.fn(),
  updateStandardVersion: jest.fn(),
  deleteStandardVersion: jest.fn(),
  setLatestStandardVersion: jest.fn(),
});

const createMetadata = () => ({
  getStandardDocumentUrls: jest.fn(),
  fetchStandardMetadata: jest.fn(),
});

describe('createStandardsResolvers', () => {
  describe('Query', () => {
    it.each([
      [
        'searchStandards',
        'search',
        { filter: { pageIdx: 0, limit: 10 } },
        [{ pageIdx: 0, limit: 10 }],
      ],
      ['standard', 'getStandard', { id: 'std-1' }, ['std-1']],
      ['standardByName', 'getStandardByName', { name: 'Standard A' }, ['Standard A']],
      ['standardVersion', 'getStandardVersion', { id: 'ver-1' }, ['ver-1']],
      ['standardVersions', 'listStandardVersions', { standardId: 'std-1' }, ['std-1']],
      [
        'isStandardNameAvailable',
        'isStandardNameAvailable',
        { name: 'Standard A' },
        ['Standard A'],
      ],
      [
        'standardsByKitVersion',
        'listStandardsByKitVersion',
        { kitVersionId: 'kit-ver-1' },
        ['kit-ver-1'],
      ],
      [
        'standardVersionChanges',
        'listStandardVersionChanges',
        { standardVersionId: 'ver-1' },
        ['ver-1'],
      ],
      [
        'standardVersionKeyItems',
        'listStandardVersionKeyItems',
        { standardVersionId: 'ver-1', orderBy: 'category', orderDesc: true },
        ['ver-1', 'category', true],
      ],
      [
        'standardVersionReferences',
        'listStandardVersionReferences',
        { standardVersionId: 'ver-1' },
        ['ver-1'],
      ],
      [
        'standardVersionReferencesConnection',
        'listStandardVersionReferencesConnection',
        {
          standardVersionId: 'ver-1',
          pageIdx: 0,
          limit: 10,
          sort: [{ field: 'name', desc: false }],
          nameContains: 'ign',
        },
        ['ver-1', 0, 10, [{ field: 'name', desc: false }], 'ign'],
      ],
    ] as const)(
      'delegates Query.%s to standardService.%s',
      async (field, method, args, expectedArgs) => {
        const standardService = createService();
        const resolvers = createStandardsResolvers({
          standardService,
          standardMetadataService: createMetadata() as any,
        });
        const expected = Symbol(field);
        (standardService[method] as jest.Mock).mockResolvedValue(expected);

        const result = await (
          resolvers.Query[field] as (parent: unknown, args: any) => Promise<unknown>
        )(null, args);

        expect(standardService[method]).toHaveBeenCalledWith(...expectedArgs);
        expect(result).toBe(expected);
      }
    );
  });

  describe('Mutation', () => {
    it.each([
      [
        'createStandard',
        'createStandard',
        { input: { name: 'Standard A' } },
        [{ name: 'Standard A' }],
      ],
      [
        'updateStandard',
        'updateStandard',
        { id: 'std-1', input: { name: 'Updated' } },
        ['std-1', { name: 'Updated' }],
      ],
      ['deleteStandard', 'deleteStandard', { id: 'std-1' }, ['std-1']],
      [
        'createStandardVersion',
        'createStandardVersion',
        { standardId: 'std-1', input: { version: '1.0.0' } },
        ['std-1', { version: '1.0.0' }],
      ],
      [
        'updateStandardVersion',
        'updateStandardVersion',
        { id: 'ver-1', input: { version: '1.1.0' } },
        ['ver-1', { version: '1.1.0' }],
      ],
      ['deleteStandardVersion', 'deleteStandardVersion', { id: 'ver-1' }, ['ver-1']],
      ['setLatestStandardVersion', 'setLatestStandardVersion', { id: 'ver-1' }, ['ver-1']],
    ] as const)(
      'delegates Mutation.%s to standardService.%s',
      async (field, method, args, expectedArgs) => {
        const standardService = createService();
        const resolvers = createStandardsResolvers({
          standardService,
          standardMetadataService: createMetadata() as any,
        });
        const expected = Symbol(field);
        (standardService[method] as jest.Mock).mockResolvedValue(expected);

        const result = await (
          resolvers.Mutation[field] as (parent: unknown, args: any) => Promise<unknown>
        )(null, args);

        expect(standardService[method]).toHaveBeenCalledWith(...expectedArgs);
        expect(result).toBe(expected);
      }
    );
  });
});
