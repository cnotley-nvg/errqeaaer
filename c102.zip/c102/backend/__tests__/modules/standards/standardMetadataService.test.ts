import { createStandardMetadataService } from '../../../modules/standards/infra/standardMetadataService';
import type { BackendRuntimeConfig } from '../../../config/runtimeConfig';
import { ProxyUnavailableError } from '../../../shared';
import type { Logger } from '../../../shared';

const createMockLogger = (): jest.Mocked<Logger> => ({
  info: jest.fn(),
  warn: jest.fn(),
  error: jest.fn(),
  child: jest.fn().mockReturnThis(),
});

const buildConfig = (): BackendRuntimeConfig => ({
  server: {
    port: 4000,
    corsOrigins: ['http://localhost:3000'],
    publicBaseUrl: 'http://localhost:4000',
  },
  database: {
    url: 'postgresql://test',
  },
  proxy: {
    baseUrl: 'http://localhost:8080',
    timeoutMs: 5000,
  },
});

describe('StandardMetadataService', () => {
  const logger = createMockLogger();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should create service with valid config', () => {
    const service = createStandardMetadataService(buildConfig(), logger);
    expect(service).toBeDefined();
    expect(service.getStandardDocumentUrls).toBeDefined();
  });

  it('should throw ProxyUnavailableError if proxy config is missing', () => {
    const config = buildConfig();
    config.proxy = undefined as any;

    expect(() => createStandardMetadataService(config, logger)).toThrow(ProxyUnavailableError);
    expect(() => createStandardMetadataService(config, logger)).toThrow(
      'ACC proxy configuration missing'
    );
  });

  describe('getStandardDocumentUrls', () => {
    it('should return null if standardId is empty', async () => {
      const service = createStandardMetadataService(buildConfig(), logger);
      const result = await service.getStandardDocumentUrls('project-123', '');
      expect(result).toBeNull();
    });

    // Note: Full integration tests with AccClient are in accClient.test.ts
    // This test only verifies the service interface
  });
});
