import { createStandardService } from '../../../modules/standards/domain/standardService';
import { loadAttributes, storeAttributes } from '../../../modules/shared/attributeStore';
import type { Logger } from '../../../shared';

jest.mock('../../../modules/shared/attributeStore', () => ({
  loadAttributes: jest.fn(),
  storeAttributes: jest.fn(),
}));

jest.mock('../../../lib/prisma', () => ({
  prisma: {
    standard: {
      count: jest.fn(),
      findMany: jest.fn(),
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    standardVersion: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      updateMany: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    standardVersionChange: {
      findMany: jest.fn(),
    },
    standardVersionKeyItem: {
      findMany: jest.fn(),
    },
    standardVersionReference: {
      findMany: jest.fn(),
      count: jest.fn(),
    },
    kitVersionStandardLink: {
      findMany: jest.fn(),
    },
    $transaction: jest.fn(),
  },
}));

const { prisma } = require('../../../lib/prisma') as {
  prisma: {
    standard: {
      count: jest.Mock;
      findMany: jest.Mock;
      findUnique: jest.Mock;
      create: jest.Mock;
      update: jest.Mock;
      delete: jest.Mock;
    };
    standardVersion: {
      findUnique: jest.Mock;
      findMany: jest.Mock;
      create: jest.Mock;
      updateMany: jest.Mock;
      update: jest.Mock;
      delete: jest.Mock;
    };
    standardVersionChange: {
      findMany: jest.Mock;
    };
    standardVersionKeyItem: {
      findMany: jest.Mock;
    };
    standardVersionReference: {
      findMany: jest.Mock;
      count: jest.Mock;
    };
    kitVersionStandardLink: {
      findMany: jest.Mock;
    };
    $transaction: jest.Mock;
  };
};

const mockedLoadAttributes = loadAttributes as jest.MockedFunction<typeof loadAttributes>;
const mockedStoreAttributes = storeAttributes as jest.MockedFunction<typeof storeAttributes>;

const createLogger = (): jest.Mocked<Logger> => {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;

  logger.child.mockReturnValue(logger);
  return logger;
};

const buildStandard = (id: string) => {
  const createdAt = new Date('2024-02-01T00:00:00Z');
  const updatedAt = new Date('2024-02-02T00:00:00Z');

  return {
    id,
    accProjectId: 'proj-1',
    name: `Standard ${id}`,
    description: null,
    createdAt,
    updatedAt,
    versions: [
      {
        id: `${id}-v1`,
        standardId: id,
        accFolderId: 'folder-1',
        accFileId: 'file-1',
        version: '1.0.0',
        isLatest: true,
        createdAt,
        updatedAt,
        kits: [],
      },
    ],
  };
};

const buildVersionRecord = (standardId: string, versionId = `${standardId}-v1`) => {
  const createdAt = new Date('2024-02-01T00:00:00Z');
  const updatedAt = new Date('2024-02-02T00:00:00Z');

  return {
    id: versionId,
    standardId,
    accFolderId: versionId.includes('-v2') ? 'folder-2' : 'folder-1',
    accFileId: versionId.includes('-v2') ? 'file-2' : 'file-1',
    version: versionId.includes('-v2') ? '2.0.0' : '1.0.0',
    isLatest: versionId.endsWith('-v1'),
    createdAt,
    updatedAt,
    standard: {
      id: standardId,
      accProjectId: 'proj-1',
      name: `Standard ${standardId}`,
      description: null,
      createdAt,
      updatedAt,
    },
    kits: [],
  };
};

describe('standardService', () => {
  beforeEach(() => {
    jest.clearAllMocks();

    mockedLoadAttributes.mockResolvedValue({});
    mockedStoreAttributes.mockResolvedValue();
    prisma.$transaction.mockImplementation(async (callback) => callback(prisma));
    prisma.standard.update.mockResolvedValue({ id: 'std-1' });
    prisma.standard.delete.mockResolvedValue(undefined);
    prisma.standardVersion.update.mockResolvedValue({});
    prisma.standardVersion.updateMany.mockResolvedValue(undefined);
    prisma.standardVersion.delete.mockResolvedValue(undefined);
    prisma.standardVersion.findUnique.mockImplementation(async ({ where }) => {
      if (!where?.id) {
        return null;
      }

      const [standardId] = where.id.split('-v');
      return buildVersionRecord(standardId ?? 'std-1', where.id);
    });
  });

  const service = () => createStandardService(createLogger());

  it('searches standards and returns paginated results', async () => {
    const record = buildStandard('std-1');
    prisma.standard.count.mockResolvedValue(1);
    prisma.standard.findMany.mockResolvedValue([record]);

    const result = await service().search({ pageIdx: 0, limit: 10 } as never);

    expect(prisma.standard.count).toHaveBeenCalled();
    expect(result.total).toBe(1);
    expect(result.items[0]?.id).toBe('std-1');
  });

  it('creates a standard with an optional initial version', async () => {
    prisma.standard.create.mockResolvedValue({ id: 'std-1' });
    prisma.standard.findUnique.mockResolvedValue(buildStandard('std-1'));
    prisma.standardVersion.create.mockResolvedValue({ id: 'std-1-v1' });

    const result = await service().createStandard({
      accProjectId: 'proj-1',
      name: 'Standard 1',
      description: 'Fire door spec',
      initialVersion: {
        accFolderId: 'folder-1',
        accFileId: 'file-1',
        version: '1.0.0',
      },
    } as never);

    expect(result.success).toBe(true);
    expect(prisma.standard.create).toHaveBeenCalledWith({
      data: {
        accProjectId: 'proj-1',
        name: 'Standard 1',
        description: 'Fire door spec',
      },
    });
    expect(prisma.standardVersion.create).toHaveBeenCalledWith({
      data: expect.objectContaining({
        standardId: 'std-1',
        accFolderId: 'folder-1',
        accFileId: 'file-1',
        version: '1.0.0',
      }),
    });
    expect(mockedStoreAttributes).toHaveBeenCalled();
  });

  it('loads a standard detail with latest version', async () => {
    const record = buildStandard('std-1');
    prisma.standard.findUnique.mockResolvedValue(record);

    const standard = await service().getStandard('std-1');

    expect(standard?.id).toBe('std-1');
    expect(standard?.latestVersion?.version).toBe('1.0.0');
  });

  it('updates a standard', async () => {
    prisma.standard.findUnique
      .mockResolvedValueOnce({ id: 'std-1', name: 'Standard 1', accProjectId: 'proj-1' })
      .mockResolvedValueOnce(buildStandard('std-1'));
    prisma.standard.update.mockResolvedValue({ id: 'std-1' });

    const result = await service().updateStandard('std-1', {
      name: 'Updated Standard',
      description: 'Updated description',
    } as never);

    expect(result.success).toBe(true);
    expect(prisma.standard.update).toHaveBeenCalledWith({
      where: { id: 'std-1' },
      data: { name: 'Updated Standard', description: 'Updated description' },
    });
  });

  it('creates a standard version and records attributes', async () => {
    prisma.standard.findUnique.mockResolvedValue({ id: 'std-1' });
    prisma.standardVersion.create.mockResolvedValue({ id: 'std-1-v2' });

    const result = await service().createStandardVersion('std-1', {
      accFolderId: 'folder-2',
      accFileId: 'file-2',
      version: '2.0.0',
      attributes: { region: 'EU' },
    } as never);

    expect(result.success).toBe(true);
    expect(prisma.standardVersion.create).toHaveBeenCalledWith({
      data: expect.objectContaining({ standardId: 'std-1', version: '2.0.0' }),
    });
    expect(prisma.standardVersion.updateMany).toHaveBeenCalledWith({
      data: { isLatest: false },
      where: { standardId: 'std-1' },
    });
    expect(mockedStoreAttributes).toHaveBeenCalledWith(
      expect.anything(),
      'STANDARD_VERSION',
      'std-1-v2',
      { region: 'EU' }
    );
  });

  it.skip('updates standard version metadata and sets latest flag', async () => {
    prisma.standardVersion.findUnique
      .mockImplementationOnce(async () => ({ standardId: 'std-1' }))
      .mockImplementationOnce(async () => buildVersionRecord('std-1'));

    const result = await service().updateStandardVersion('std-1-v1', {
      version: '3.0.0',
      isLatest: true,
      attributes: { region: 'APAC' },
    } as never);

    expect(result.success).toBe(true);
    expect(prisma.standardVersion.update).toHaveBeenCalledWith({
      where: { id: 'std-1-v1' },
      data: { version: '3.0.0', isLatest: true },
    });
    expect(prisma.standardVersion.updateMany).toHaveBeenCalledWith({
      data: { isLatest: false },
      where: { standardId: 'std-1' },
    });
    expect(mockedStoreAttributes).toHaveBeenCalledWith(
      expect.anything(),
      'STANDARD_VERSION',
      'std-1-v1',
      { region: 'APAC' }
    );
  });

  it.skip('sets latest standard version explicitly', async () => {
    prisma.standardVersion.findUnique
      .mockImplementationOnce(async () => ({ standardId: 'std-1' }))
      .mockImplementationOnce(async () => buildVersionRecord('std-1'));

    const result = await service().setLatestStandardVersion('std-1-v1');

    expect(result.success).toBe(true);
    expect(prisma.standardVersion.updateMany).toHaveBeenCalledWith({
      data: { isLatest: false },
      where: { standardId: 'std-1' },
    });
    expect(prisma.standardVersion.update).toHaveBeenCalledWith({
      data: { isLatest: true },
      where: { id: 'std-1-v1' },
    });
  });

  it('applies attribute filters when searching standards', async () => {
    const record = buildStandard('std-1');
    prisma.standard.findMany.mockResolvedValue([record]);
    mockedLoadAttributes.mockImplementation(async (_client, entityId) => {
      if (entityId === 'std-1-v1') {
        return { region: 'NA', program: 'GEN5' };
      }
      return {};
    });

    const result = await service().search({
      pageIdx: 0,
      limit: 5,
      query: {
        operation: 'AND',
        tokenGroups: [{ propertyKey: 'region', operator: 'EQUALS', value: 'NA' }],
      },
    } as never);

    expect(prisma.standard.findMany).toHaveBeenCalled();
    expect(prisma.standard.count).not.toHaveBeenCalled();
    expect(result.items).toHaveLength(1);
    expect(result.items[0]?.latestVersion?.attributes).toEqual({ region: 'NA', program: 'GEN5' });
  });

  it('excludes standards when attribute NOT_EQUALS matches the value', async () => {
    const record = buildStandard('std-1');
    prisma.standard.findMany.mockResolvedValue([record]);
    mockedLoadAttributes.mockImplementation(async (_client, entityId) =>
      entityId === 'std-1-v1' ? { region: 'NA' } : {}
    );

    const result = await service().search({
      pageIdx: 0,
      limit: 5,
      query: {
        operation: 'AND',
        tokenGroups: [{ propertyKey: 'region', operator: 'NOT_EQUALS', value: 'NA' }],
      },
    } as never);

    expect(result.items).toHaveLength(0);
  });

  it('returns standards when attribute array contains the searched value using OR logic', async () => {
    const record = buildStandard('std-1');
    prisma.standard.findMany.mockResolvedValue([record]);
    mockedLoadAttributes.mockImplementation(async (_client, entityId) =>
      entityId === 'std-1-v1' ? { tags: ['safety', 'gen5'] } : {}
    );

    const result = await service().search({
      pageIdx: 0,
      limit: 5,
      query: {
        operation: 'OR',
        tokenGroups: [
          { propertyKey: 'tags', operator: 'CONTAINS', value: 'retrofit' },
          { propertyKey: 'tags', operator: 'CONTAINS', values: ['GEN5'] },
        ],
      },
    } as never);

    expect(result.items).toHaveLength(1);
  });

  it('returns standards when attribute does not contain the blocked substring', async () => {
    const record = buildStandard('std-1');
    prisma.standard.findMany.mockResolvedValue([record]);
    mockedLoadAttributes.mockImplementation(async (_client, entityId) =>
      entityId === 'std-1-v1' ? { notes: 'fire rated assembly' } : {}
    );

    const result = await service().search({
      pageIdx: 0,
      limit: 5,
      query: {
        operation: 'AND',
        tokenGroups: [{ propertyKey: 'notes', operator: 'NOT_CONTAINS', value: 'mechanical' }],
      },
    } as never);

    expect(result.items).toHaveLength(1);
  });

  it('falls back to database filtering when only base fields are provided', async () => {
    const record = buildStandard('std-1');
    prisma.standard.count.mockResolvedValueOnce(1);
    prisma.standard.findMany.mockResolvedValueOnce([record]);

    const result = await service().search({
      pageIdx: 0,
      limit: 5,
      query: {
        operation: 'AND',
        tokenGroups: [{ propertyKey: 'name', operator: 'CONTAINS', value: 'Standard' }],
      },
    } as never);

    expect(prisma.standard.count).toHaveBeenCalled();
    expect(result.items).toHaveLength(1);
  });

  it('returns empty list of standard versions when the standard does not exist', async () => {
    prisma.standard.findUnique.mockResolvedValueOnce(null);

    const versions = await service().listStandardVersions('missing-standard');

    expect(versions).toEqual([]);
    expect(prisma.standardVersion.findMany).not.toHaveBeenCalled();
  });

  it('lists standard versions with attributes of each version', async () => {
    const createdAt = new Date('2024-02-01T00:00:00Z');
    const updatedAt = new Date('2024-02-02T00:00:00Z');
    prisma.standard.findUnique.mockResolvedValueOnce({
      id: 'std-1',
      accProjectId: 'proj-1',
      name: 'Standard std-1',
      description: null,
      createdAt,
      updatedAt,
    });
    prisma.standardVersion.findMany.mockResolvedValueOnce([
      {
        ...buildVersionRecord('std-1', 'std-1-v2'),
        isLatest: false,
      },
      buildVersionRecord('std-1', 'std-1-v1'),
    ]);

    mockedLoadAttributes.mockImplementation(async (_client, entityId) => {
      if (entityId === 'std-1-v2') {
        return { region: 'EU' };
      }
      if (entityId === 'std-1-v1') {
        return { region: 'NA' };
      }
      return {};
    });

    const versions = await service().listStandardVersions('std-1');

    expect(versions).toHaveLength(2);
    expect(versions[0]?.attributes).toEqual({ region: 'EU' });
    expect(versions[1]?.attributes).toEqual({ region: 'NA' });
  });

  it('lists standard version changes for a version', async () => {
    prisma.standardVersionChange.findMany.mockResolvedValueOnce([
      {
        id: 'chg-1',
        standardVersionId: 'ver-1',
        details: 'Initial release',
        releasedBy: 'alice',
        approveUrl: 'https://example.com/approve/1',
      },
    ]);

    const result = await service().listStandardVersionChanges('ver-1');

    expect(prisma.standardVersionChange.findMany).toHaveBeenCalledWith({
      where: { standardVersionId: 'ver-1' },
      orderBy: { id: 'asc' },
    });
    expect(result).toEqual([
      {
        id: 'chg-1',
        standardVersionId: 'ver-1',
        details: 'Initial release',
        releasedBy: 'alice',
        approveUrl: 'https://example.com/approve/1',
      },
    ]);
  });

  it('lists standard version key items with server-side sorting', async () => {
    prisma.standardVersionKeyItem.findMany.mockResolvedValueOnce([
      {
        id: 'ki-1',
        standardVersionId: 'ver-1',
        category: 'Access',
        sheet: 'S1',
        cell: 'C1',
      },
    ]);

    const result = await service().listStandardVersionKeyItems('ver-1', 'category', true);

    expect(prisma.standardVersionKeyItem.findMany).toHaveBeenCalledWith({
      where: { standardVersionId: 'ver-1' },
      orderBy: { category: 'desc' },
    });
    expect(result).toEqual([
      {
        id: 'ki-1',
        standardVersionId: 'ver-1',
        category: 'Access',
        sheet: 'S1',
        cell: 'C1',
      },
    ]);
  });

  it('lists standard version references', async () => {
    prisma.standardVersionReference.findMany.mockResolvedValueOnce([
      {
        id: 'ref-1',
        standardVersionId: 'ver-1',
        specification: '101400',
        name: 'Signage',
        createdAt: new Date('2024-01-01T00:00:00Z'),
        ownedBy: 'Ops',
        link: null,
      },
    ]);

    const result = await service().listStandardVersionReferences('ver-1');

    expect(prisma.standardVersionReference.findMany).toHaveBeenCalledWith({
      where: { standardVersionId: 'ver-1' },
      orderBy: { id: 'asc' },
    });
    expect(result).toEqual([
      {
        id: 'ref-1',
        standardVersionId: 'ver-1',
        specification: '101400',
        name: 'Signage',
        createdAt: '2024-01-01',
        ownedBy: 'Ops',
        link: null,
      },
    ]);
  });

  it('lists standard version references with paging, multi-column sort and name filter', async () => {
    prisma.standardVersionReference.count.mockResolvedValueOnce(3);
    prisma.standardVersionReference.findMany.mockResolvedValueOnce([
      {
        id: 'ref-1',
        standardVersionId: 'ver-1',
        specification: '101400',
        name: 'Signage',
        createdAt: new Date('2024-01-01T00:00:00Z'),
        ownedBy: 'Ops',
        link: null,
      },
      {
        id: 'ref-2',
        standardVersionId: 'ver-1',
        specification: '102640',
        name: 'Protection',
        createdAt: new Date('2024-02-01T00:00:00Z'),
        ownedBy: 'BD&E',
        link: null,
      },
    ]);

    const result = await service().listStandardVersionReferencesConnection(
      'ver-1',
      0,
      2,
      [
        { field: 'specification', desc: false },
        { field: 'name', desc: true },
      ],
      'ign'
    );

    expect(prisma.standardVersionReference.count).toHaveBeenCalledWith({
      where: {
        standardVersionId: 'ver-1',
        name: { contains: 'ign', mode: 'insensitive' },
      },
    });
    expect(prisma.standardVersionReference.findMany).toHaveBeenCalledWith({
      where: {
        standardVersionId: 'ver-1',
        name: { contains: 'ign', mode: 'insensitive' },
      },
      orderBy: [{ specification: 'asc' }, { name: 'desc' }],
      skip: 0,
      take: 2,
    });
    expect(result).toMatchObject({
      items: [
        expect.objectContaining({ id: 'ref-1', name: 'Signage' }),
        expect.objectContaining({ id: 'ref-2', name: 'Protection' }),
      ],
      total: 3,
      pageIdx: 0,
      limit: 2,
      hasNext: true,
    });
  });

  it.skip('retrieves a standard version by identifier with kit metadata', async () => {
    const createdAt = new Date('2024-02-01T00:00:00Z');
    const updatedAt = new Date('2024-02-02T00:00:00Z');

    prisma.standardVersion.findUnique.mockResolvedValueOnce({
      ...buildVersionRecord('std-1', 'std-1-v1'),
      kits: [
        {
          kitVersion: {
            id: 'kit-1-v1',
            kitId: 'kit-1',
            version: '1.0.0',
            isLatest: true,
            createdAt,
            updatedAt,
            kit: {
              id: 'kit-1',
              name: 'Kit Alpha',
              description: null,
              createdAt,
              updatedAt,
            },
          },
        },
      ],
    });

    mockedLoadAttributes.mockImplementation(async (_client, entityId) => {
      if (entityId === 'std-1-v1') {
        return { fireRating: '2hr' };
      }
      if (entityId === 'kit-1-v1') {
        return { zone: 'NA' };
      }
      return {};
    });

    const version = await service().getStandardVersion('std-1-v1');

    expect(version?.attributes).toEqual({ fireRating: '2hr' });
    expect(version?.kits[0]?.kit?.name).toBe('Kit Alpha');
  });

  it('lists standards associated with a kit version', async () => {
    prisma.kitVersionStandardLink.findMany.mockResolvedValueOnce([
      {
        standardVersion: {
          ...buildVersionRecord('std-1', 'std-1-v1'),
        },
      },
    ]);

    mockedLoadAttributes.mockImplementation(async (_client, entityId) => {
      if (entityId === 'std-1-v1') {
        return { compliance: 'NFPA' };
      }
      return {};
    });

    const standards = await service().listStandardsByKitVersion('kit-1-v1');

    expect(prisma.kitVersionStandardLink.findMany).toHaveBeenCalledWith({
      where: { kitVersionId: 'kit-1-v1' },
      orderBy: { createdAt: 'asc' },
      include: {
        standardVersion: {
          include: expect.any(Object),
        },
      },
    });
    expect(standards[0]?.attributes).toEqual({ compliance: 'NFPA' });
  });

  it('evaluates standard name availability', async () => {
    prisma.standard.findUnique.mockResolvedValueOnce({ id: 'existing' });

    const unavailable = await service().isStandardNameAvailable('Existing Standard');
    expect(unavailable).toBe(false);

    prisma.standard.findUnique.mockResolvedValueOnce(null);

    const available = await service().isStandardNameAvailable('New Standard');
    expect(available).toBe(true);
  });

  it('fails to create a standard when the initial version is missing accFileId', async () => {
    prisma.standard.create.mockResolvedValue({ id: 'std-2' });
    prisma.standard.findUnique.mockResolvedValueOnce(null);

    const result = await service().createStandard({
      accProjectId: 'proj-1',
      name: 'Standard Missing File',
      initialVersion: {
        accFolderId: 'folder-1',
        accFileId: '   ',
        version: '1.0.0',
      },
    } as never);

    expect(result.success).toBe(false);
    expect(result.message).toContain('accFileId is required');
    expect(prisma.standardVersion.create).not.toHaveBeenCalled();
  });

  it('deletes a standard successfully', async () => {
    prisma.standard.delete.mockResolvedValueOnce({ id: 'std-1' });

    const result = await service().deleteStandard('std-1');

    expect(result.success).toBe(true);
    expect(prisma.standard.delete).toHaveBeenCalledWith({ where: { id: 'std-1' } });
  });

  it('returns null when standard is not found', async () => {
    prisma.standard.findUnique.mockResolvedValueOnce(null);

    const standard = await service().getStandard('missing-standard');

    expect(standard).toBeNull();
  });

  it.skip('returns null when standard version is not found', async () => {
    prisma.standardVersion.findUnique.mockResolvedValueOnce(null);

    const version = await service().getStandardVersion('missing-version');

    expect(version).toBeNull();
  });

  it('fails to create a standard version when the standard does not exist', async () => {
    prisma.standard.findUnique.mockResolvedValueOnce(null);

    const result = await service().createStandardVersion('missing-standard', {
      accFolderId: 'folder-1',
      accFileId: 'file-1',
      version: '1.0.0',
    } as never);

    expect(result.success).toBe(false);
    expect(result.message).toContain('Standard not found');
    expect(prisma.standardVersion.create).not.toHaveBeenCalled();
  });

  it('deletes a standard version and ensures latest flag is recalculated', async () => {
    prisma.standardVersion.findUnique.mockReset();
    prisma.standardVersion.findUnique.mockResolvedValueOnce({
      standardId: 'std-1',
      isLatest: false,
    });
    prisma.standardVersion.delete.mockResolvedValueOnce(undefined);
    prisma.standardVersion.findMany.mockResolvedValueOnce([]);

    const result = await service().deleteStandardVersion('std-1-v2');

    expect(result.success).toBe(true);
    expect(prisma.standardVersion.delete).toHaveBeenCalledWith({ where: { id: 'std-1-v2' } });
    expect(prisma.standardVersion.findMany).toHaveBeenCalled();
  });

  it('fails to delete a standard version when it does not exist', async () => {
    prisma.standardVersion.findUnique.mockReset();
    prisma.standardVersion.findUnique.mockResolvedValueOnce(null);

    const result = await service().deleteStandardVersion('missing-version');

    expect(result.success).toBe(false);
    expect(result.message).toContain('Standard version not found');
    expect(prisma.standardVersion.delete).not.toHaveBeenCalled();
  });

  it('promotes a standard version to latest via updateStandardVersion', async () => {
    prisma.standardVersion.findUnique.mockReset();
    prisma.standardVersion.findUnique
      .mockResolvedValueOnce({ standardId: 'std-1' })
      .mockResolvedValueOnce(buildVersionRecord('std-1'));

    const result = await service().updateStandardVersion('std-1-v1', {
      isLatest: true,
    } as never);

    expect(result.success).toBe(true);
    expect(prisma.standardVersion.update).toHaveBeenCalledWith({
      where: { id: 'std-1-v1' },
      data: { isLatest: true },
    });
    expect(prisma.standardVersion.updateMany).toHaveBeenCalledWith({
      data: { isLatest: false },
      where: { standardId: 'std-1' },
    });
  });

  it('updateStandardVersion returns error when version does not exist', async () => {
    prisma.standardVersion.findUnique.mockReset();
    prisma.standardVersion.findUnique.mockResolvedValueOnce(null);

    const result = await service().updateStandardVersion('missing-version', {
      isLatest: true,
    } as never);

    expect(result.success).toBe(false);
    expect(result.message).toContain('Standard version not found');
  });

  it('updateStandardVersion rejects immutable field edits', async () => {
    prisma.standardVersion.findUnique.mockReset();
    prisma.standardVersion.findUnique.mockResolvedValueOnce({ standardId: 'std-1' });

    const result = await service().updateStandardVersion('std-1-v1', {
      version: '9.9.9',
    } as never);

    expect(result.success).toBe(false);
    expect(result.message).toContain('immutable');
  });

  it('updateStandardVersion rejects when no mutable fields provided', async () => {
    prisma.standardVersion.findUnique.mockReset();
    prisma.standardVersion.findUnique.mockResolvedValueOnce({ standardId: 'std-1' });

    const result = await service().updateStandardVersion('std-1-v1', {} as never);

    expect(result.success).toBe(false);
    expect(result.message).toContain('No mutable fields provided');
  });

  it('updateStandardVersion rejects null isLatest', async () => {
    prisma.standardVersion.findUnique.mockReset();
    prisma.standardVersion.findUnique.mockResolvedValueOnce({ standardId: 'std-1' });

    const result = await service().updateStandardVersion('std-1-v1', {
      isLatest: null,
    } as never);

    expect(result.success).toBe(false);
    expect(result.message).toContain('isLatest cannot be null');
  });

  it('sets latest standard version explicitly', async () => {
    prisma.standardVersion.findUnique.mockReset();
    prisma.standardVersion.findUnique
      .mockResolvedValueOnce({ standardId: 'std-1' })
      .mockResolvedValueOnce(buildVersionRecord('std-1'));

    const result = await service().setLatestStandardVersion('std-1-v1');

    expect(result.success).toBe(true);
    expect(prisma.standardVersion.updateMany).toHaveBeenCalledWith({
      data: { isLatest: false },
      where: { standardId: 'std-1' },
    });
    expect(prisma.standardVersion.update).toHaveBeenCalledWith({
      data: { isLatest: true },
      where: { id: 'std-1-v1' },
    });
  });

  it('fails to set latest standard version when version does not exist', async () => {
    prisma.standardVersion.findUnique.mockReset();
    prisma.standardVersion.findUnique.mockResolvedValueOnce(null);

    const result = await service().setLatestStandardVersion('missing-version');

    expect(result.success).toBe(false);
    expect(result.message).toContain('Standard version not found');
  });

  it('returns null when standard version is not found', async () => {
    prisma.standardVersion.findUnique.mockReset();
    prisma.standardVersion.findUnique.mockResolvedValueOnce(null);

    const version = await service().getStandardVersion('missing-version');

    expect(version).toBeNull();
  });

  it('rejects updateStandard when the standard does not exist', async () => {
    prisma.standard.findUnique.mockResolvedValueOnce(null);

    const result = await service().updateStandard('missing-standard', {
      name: 'Nope',
    } as never);

    expect(result.success).toBe(false);
    expect(typeof result.message).toBe('string');
  });
});
