import {
  createStandardMappers,
  type KitVersionWithKit,
  type StandardRecord,
  type StandardVersionRecord,
} from '../../../modules/standards/domain/standardMappers';

describe('standardMappers', () => {
  const now = new Date('2024-02-01T00:00:00.000Z');

  const kitVersion: KitVersionWithKit = {
    id: 'kit-version-1',
    kitId: 'kit-1',
    version: 'v1',
    isLatest: false,
    createdAt: now,
    updatedAt: now,
    kit: {
      id: 'kit-1',
      name: 'Site Kit',
      description: 'Kit description',
      createdAt: now,
      updatedAt: now,
    } as any,
  } as KitVersionWithKit;

  const standardVersion: StandardVersionRecord = {
    id: 'standard-version-1',
    standardId: 'standard-1',
    accFolderId: 'folder-1',
    accFileId: 'file-1',
    version: 'v1',
    isLatest: true,
    createdAt: now,
    updatedAt: now,
    kits: [
      {
        kitVersion,
      },
    ],
  } as StandardVersionRecord;

  const standardRecord: StandardRecord = {
    id: 'standard-1',
    accProjectId: 'project-1',
    name: 'Core Standard',
    description: 'Standard description',
    createdAt: now,
    updatedAt: now,
    versions: [standardVersion],
  } as StandardRecord;

  const attributeLoader = jest.fn(async (id: string) => ({ attr: `loaded-${id}` }));

  const { toKitVersionGraph, toStandardVersionGraph, toStandardGraph } =
    createStandardMappers(attributeLoader);

  beforeEach(() => {
    attributeLoader.mockClear();
  });

  it('maps kit versions within standards', async () => {
    const kitGraph = await toKitVersionGraph(kitVersion);

    expect(attributeLoader).toHaveBeenCalledWith('kit-version-1');
    expect(kitGraph.kit?.id).toBe('kit-1');
    expect(kitGraph.attributes).toEqual({ attr: 'loaded-kit-version-1' });
  });

  it('maps standard versions and resolves fallback standard', async () => {
    const graph = await toStandardVersionGraph({
      ...standardVersion,
      standard: {
        id: standardRecord.id,
        accProjectId: standardRecord.accProjectId,
        name: standardRecord.name,
        description: standardRecord.description,
        createdAt: now,
        updatedAt: now,
      } as any,
    });

    expect(attributeLoader).toHaveBeenCalledWith('standard-version-1');
    expect(graph.standard?.id).toBe('standard-1');
    expect(graph.kits).toHaveLength(1);
  });

  it('maps standards and picks the latest version', async () => {
    const graph = await toStandardGraph(standardRecord);

    expect(graph.latestVersion?.id).toBe('standard-version-1');
    expect(graph.versions).toHaveLength(1);
  });

  it('throws when standard reference missing', async () => {
    await expect(toStandardVersionGraph(standardVersion)).rejects.toThrow(
      'Standard reference not loaded'
    );
  });
});
