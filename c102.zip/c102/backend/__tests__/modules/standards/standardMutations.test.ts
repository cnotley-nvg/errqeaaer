import {
  ensureLatestStandardVersionExists,
  updateLatestStandardVersionFlags,
  type StandardVersionMutations,
} from '../../../modules/standards/domain/standardMutations';

describe('standardMutations', () => {
  it('updates latest standard version flags', async () => {
    const delegate: StandardVersionMutations = {
      updateMany: jest.fn().mockResolvedValue(undefined),
      update: jest.fn().mockResolvedValue(undefined),
      findMany: jest.fn(),
    };

    await updateLatestStandardVersionFlags(delegate, 'standard-1', 'sv-2');

    expect(delegate.updateMany).toHaveBeenCalledWith({
      data: { isLatest: false },
      where: { standardId: 'standard-1' },
    });
    expect(delegate.update).toHaveBeenCalledWith({
      data: { isLatest: true },
      where: { id: 'sv-2' },
    });
  });

  describe('ensureLatestStandardVersionExists', () => {
    const buildDelegate = (
      records: Array<{ id: string; isLatest: boolean }>
    ): StandardVersionMutations => ({
      updateMany: jest.fn(),
      update: jest.fn().mockResolvedValue(undefined),
      findMany: jest.fn().mockResolvedValue(records),
    });

    it('does nothing when there are no versions', async () => {
      const delegate = buildDelegate([]);

      await ensureLatestStandardVersionExists(delegate, 'standard-1');

      expect(delegate.update).not.toHaveBeenCalled();
    });

    it('does nothing when a latest version already exists', async () => {
      const delegate = buildDelegate([
        { id: 'sv-1', isLatest: true },
        { id: 'sv-2', isLatest: false },
      ]);

      await ensureLatestStandardVersionExists(delegate, 'standard-1');

      expect(delegate.update).not.toHaveBeenCalled();
    });

    it('sets the most recent version as latest when missing', async () => {
      const delegate = buildDelegate([
        { id: 'sv-1', isLatest: false },
        { id: 'sv-2', isLatest: false },
      ]);

      await ensureLatestStandardVersionExists(delegate, 'standard-1');

      expect(delegate.update).toHaveBeenCalledWith({
        where: { id: 'sv-1' },
        data: { isLatest: true },
      });
    });
  });
});
