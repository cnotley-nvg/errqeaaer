import type { FilterInput } from '@amzn/global-realty-mosaic-graphql-schema';

import {
  buildOrderBy,
  buildWhere,
  buildStandardVersionWhere,
  buildStandardVersionOrderBy,
  standardFilterInternals,
} from '../../../modules/standards/domain/standardFilters';

describe('standardFilters', () => {
  const base: FilterInput = {
    pageIdx: 0,
    limit: 25,
    orderBy: 'createdAt',
    orderDesc: false,
    query: null,
  };

  it('builds an AND where clause for name and project filters', () => {
    const where = buildWhere({
      ...base,
      query: {
        operation: 'AND',
        tokenGroups: [
          { propertyKey: 'name', operator: 'EQUALS', values: ['Electrical'] },
          { propertyKey: 'accProjectId', operator: 'NOT_EQUALS', value: 'proj-100' },
        ],
      },
    });

    expect(where).toEqual({
      AND: [
        expect.objectContaining({ name: expect.objectContaining({ equals: 'Electrical' }) }),
        expect.objectContaining({
          AND: [
            expect.objectContaining({
              NOT: expect.objectContaining({ accProjectId: expect.any(Object) }),
            }),
          ],
        }),
      ],
    });
  });

  it('builds string comparison conditions for multiple operators', () => {
    const where = buildWhere({
      ...base,
      query: {
        operation: 'OR',
        tokenGroups: [
          { propertyKey: 'description', operator: 'NOT_CONTAINS', value: 'wip' },
          { propertyKey: 'name', operator: 'STARTS_WITH', values: ['STD', 'REG'] },
          { propertyKey: 'name', operator: 'NOT_STARTS_WITH', values: ['archived'] },
        ],
      },
    });

    const clauses = (where as any).OR;
    expect(Array.isArray(clauses)).toBe(true);
    expect(clauses).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          AND: expect.arrayContaining([
            expect.objectContaining({
              NOT: expect.objectContaining({ description: expect.any(Object) }),
            }),
          ]),
        }),
      ])
    );

    const startsWithGroup = clauses.find((entry: any) => Array.isArray(entry.OR));
    expect(startsWithGroup.OR).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ name: expect.objectContaining({ startsWith: 'STD' }) }),
        expect.objectContaining({ name: expect.objectContaining({ startsWith: 'REG' }) }),
      ])
    );

    const notStartsWithGroup = clauses.find(
      (entry: any) => entry.AND && entry.AND.some((clause: any) => clause.NOT?.name)
    );
    expect(notStartsWithGroup).toBeDefined();
  });

  it('returns empty object when tokens produce no conditions', () => {
    const empty = buildWhere({
      ...base,
      query: {
        operation: 'OR',
        tokenGroups: [{ propertyKey: 'description', operator: 'CONTAINS', value: '   ' }],
      },
    });

    expect(empty).toEqual({});
  });

  it('buildOrderBy maps known columns and defaults', () => {
    expect(buildOrderBy({ ...base, orderBy: 'name', orderDesc: true })).toEqual({ name: 'desc' });
    expect(buildOrderBy({ ...base, orderBy: 'unknown' as any })).toEqual({ createdAt: 'desc' });
  });

  it('parseDateValue returns null for invalid dates', () => {
    const { parseDateValue } = standardFilterInternals;
    expect(parseDateValue('')).toBeNull();
    expect(parseDateValue('2024-04-15T00:00:00.000Z')).toEqual(
      new Date('2024-04-15T00:00:00.000Z')
    );
  });

  it('builds date comparison conditions', () => {
    const where = buildWhere({
      ...base,
      query: {
        operation: 'AND',
        tokenGroups: [
          { propertyKey: 'createdAt', operator: 'GREATER_THAN', value: '2024-01-01T00:00:00.000Z' },
          { propertyKey: 'updatedAt', operator: 'NOT_EQUALS', value: '2024-02-01T00:00:00.000Z' },
        ],
      },
    });

    expect(where).toEqual({
      AND: [
        expect.objectContaining({ createdAt: expect.objectContaining({ gt: expect.any(Date) }) }),
        expect.objectContaining({
          NOT: expect.objectContaining({ updatedAt: expect.any(Object) }),
        }),
      ],
    });
  });

  describe('StandardVersion filtering', () => {
    it('filters by firstPublishedOn date', () => {
      const where = buildStandardVersionWhere({
        ...base,
        query: {
          operation: 'AND',
          tokenGroups: [
            {
              propertyKey: 'firstPublishedOn',
              operator: 'GREATER_OR_EQUAL',
              value: '2024-01-01T00:00:00.000Z',
            },
          ],
        },
      });

      expect(where).toEqual({
        AND: [
          expect.objectContaining({
            firstPublishedOn: expect.objectContaining({
              gte: new Date('2024-01-01T00:00:00.000Z'),
            }),
          }),
        ],
      });
    });

    it('filters by publishedOn date', () => {
      const where = buildStandardVersionWhere({
        ...base,
        query: {
          operation: 'AND',
          tokenGroups: [
            {
              propertyKey: 'publishedOn',
              operator: 'LESS_OR_EQUAL',
              value: '2024-12-31',
            },
          ],
        },
      });

      expect(where).toEqual({
        AND: [
          expect.objectContaining({
            publishedOn: expect.objectContaining({ lte: new Date('2024-12-31T00:00:00.000Z') }),
          }),
        ],
      });
    });

    it('sorts by firstPublishedOn', () => {
      const orderBy = buildStandardVersionOrderBy({
        ...base,
        orderBy: 'firstPublishedOn',
        orderDesc: true,
      });

      expect(orderBy).toEqual({ firstPublishedOn: 'desc' });
    });

    it('sorts by publishedOn', () => {
      const orderBy = buildStandardVersionOrderBy({
        ...base,
        orderBy: 'publishedOn',
        orderDesc: false,
      });

      expect(orderBy).toEqual({ publishedOn: 'asc' });
    });
  });
});
