import { createLightningProtectionService } from '../../../modules/designOptimization/domain/lightningProtectionService';
import type { Logger } from '../../../shared';

const createMockLogger = (): jest.Mocked<Logger> => {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;

  logger.child.mockReturnValue(logger);
  return logger;
};

global.fetch = jest.fn();

describe('lightningProtectionService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('calculates required protection when nd > nc', async () => {
    (global.fetch as jest.Mock).mockResolvedValue({
      ok: true,
      json: async () => ({ density: 50 }),
    });

    const logger = createMockLogger();
    const service = createLightningProtectionService(logger);

    const result = await service.calculate({
      latitude: 40.7128,
      longitude: -74.006,
      length: 100,
      width: 50,
      height: 15,
    });

    expect(result.recommendation).toBe('required');
    expect(result.nsg).toBe(50);
    expect(result.nd).toBeGreaterThan(result.nc);
  });

  it('calculates not-required protection when nd <= nc', async () => {
    (global.fetch as jest.Mock).mockResolvedValue({
      ok: true,
      json: async () => ({ density: 0.1 }),
    });

    const logger = createMockLogger();
    const service = createLightningProtectionService(logger);

    const result = await service.calculate({
      latitude: 40.7128,
      longitude: -74.006,
      length: 20,
      width: 10,
      height: 5,
    });

    expect(result.recommendation).toBe('not-required');
    expect(result.nsg).toBe(0.1);
    expect(result.nd).toBeLessThanOrEqual(result.nc);
  });

  it('uses default values for cd and c2', async () => {
    (global.fetch as jest.Mock).mockResolvedValue({
      ok: true,
      json: async () => ({ density: 10 }),
    });

    const logger = createMockLogger();
    const service = createLightningProtectionService(logger);

    const result = await service.calculate({
      latitude: 40.7128,
      longitude: -74.006,
      length: 100,
      width: 50,
      height: 15,
    });

    expect(result.c).toBe(1.0);
    expect(result.nc).toBe(1.5e-3);
  });

  it('uses custom cd and c2 values', async () => {
    (global.fetch as jest.Mock).mockResolvedValue({
      ok: true,
      json: async () => ({ density: 10 }),
    });

    const logger = createMockLogger();
    const service = createLightningProtectionService(logger);

    const result = await service.calculate({
      latitude: 40.7128,
      longitude: -74.006,
      length: 100,
      width: 50,
      height: 15,
      cd: 0.5,
      c2: 2.0,
    });

    expect(result.c).toBe(2.0);
    expect(result.nc).toBe(1.5e-3 / 2.0);
  });

  it('throws error when lightning service fails', async () => {
    (global.fetch as jest.Mock).mockResolvedValue({
      ok: false,
    });

    const logger = createMockLogger();
    const service = createLightningProtectionService(logger);

    await expect(
      service.calculate({
        latitude: 40.7128,
        longitude: -74.006,
        length: 100,
        width: 50,
        height: 15,
      })
    ).rejects.toThrow('Failed to fetch lightning density');
  });

  it('handles zero density', async () => {
    (global.fetch as jest.Mock).mockResolvedValue({
      ok: true,
      json: async () => ({ density: 0 }),
    });

    const logger = createMockLogger();
    const service = createLightningProtectionService(logger);

    const result = await service.calculate({
      latitude: 40.7128,
      longitude: -74.006,
      length: 100,
      width: 50,
      height: 15,
    });

    expect(result.nsg).toBe(0);
    expect(result.nd).toBe(0);
    expect(result.recommendation).toBe('not-required');
  });

  it('calculates ad correctly per NFPA 780', async () => {
    (global.fetch as jest.Mock).mockResolvedValue({
      ok: true,
      json: async () => ({ density: 10 }),
    });

    const logger = createMockLogger();
    const service = createLightningProtectionService(logger);

    const lengthFt = 100;
    const widthFt = 50;
    const heightFt = 15;

    const result = await service.calculate({
      latitude: 40.7128,
      longitude: -74.006,
      length: lengthFt,
      width: widthFt,
      height: heightFt,
    });

    // Convert feet to meters (service does this internally)
    const FEET_TO_METERS = 0.3048;
    const lengthM = lengthFt * FEET_TO_METERS;
    const widthM = widthFt * FEET_TO_METERS;
    const heightM = heightFt * FEET_TO_METERS;

    // NFPA 780 formula uses meters
    const expectedAd =
      lengthM * widthM + 6 * heightM * (lengthM + widthM) + Math.PI * 9 * heightM * heightM;
    expect(result.ad).toBeCloseTo(expectedAd, 2);
  });
});
