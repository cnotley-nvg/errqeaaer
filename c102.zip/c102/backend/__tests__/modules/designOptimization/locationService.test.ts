import * as locationServiceModule from '../../../modules/designOptimization/domain/locationService';

// eslint-disable-next-line no-var
var mockSend: jest.Mock;

jest.mock('@aws-sdk/client-location', () => {
  mockSend = jest.fn();
  return {
    LocationClient: jest.fn(() => ({
      send: mockSend,
    })),
    SearchPlaceIndexForTextCommand: jest.fn((input) => ({ input })),
    SearchPlaceIndexForPositionCommand: jest.fn((input) => ({ input })),
  };
});

describe('locationService', () => {
  beforeEach(() => {
    if (mockSend) mockSend.mockClear();
  });

  describe('geocodeAddress', () => {
    it('returns geocoded result with coordinates and address details', async () => {
      mockSend.mockResolvedValueOnce({
        Results: [
          {
            Place: {
              Label: '123 Main St, Seattle, WA 98109, USA',
              Geometry: { Point: [-122.3321, 47.6062] },
              Municipality: 'Seattle',
              Region: 'WA',
              PostalCode: '98109',
              Country: 'USA',
            },
          },
        ],
      });

      const result = await locationServiceModule.geocodeAddress('123 Main St, Seattle, WA');

      expect(result).toEqual({
        latitude: 47.6062,
        longitude: -122.3321,
        address: '123 Main St, Seattle, WA 98109, USA',
        city: 'Seattle',
        state: 'WA',
        zipcode: '98109',
        country: 'USA',
      });
    });

    it('returns null when no results found', async () => {
      mockSend.mockResolvedValueOnce({ Results: [] });

      const result = await locationServiceModule.geocodeAddress('nonexistent address');

      expect(result).toBeNull();
    });

    it('returns null when Place is missing', async () => {
      mockSend.mockResolvedValueOnce({
        Results: [{ Place: null }],
      });

      const result = await locationServiceModule.geocodeAddress('some address');

      expect(result).toBeNull();
    });

    it('handles errors gracefully', async () => {
      mockSend.mockRejectedValueOnce(new Error('Network error'));

      const consoleSpy = jest.spyOn(console, 'error').mockImplementation();
      const result = await locationServiceModule.geocodeAddress('some address');

      expect(result).toBeNull();
      consoleSpy.mockRestore();
    });

    it('uses default coordinates when Geometry is missing', async () => {
      mockSend.mockResolvedValueOnce({
        Results: [
          {
            Place: {
              Label: 'Some Place',
              Municipality: 'City',
              Region: 'State',
              PostalCode: '12345',
              Country: 'Country',
            },
          },
        ],
      });

      const result = await locationServiceModule.geocodeAddress('some address');

      expect(result?.latitude).toBe(0);
      expect(result?.longitude).toBe(0);
    });
  });

  describe('reverseGeocodeCoordinates', () => {
    it('returns address details for given coordinates', async () => {
      mockSend.mockResolvedValueOnce({
        Results: [
          {
            Place: {
              Label: '123 Main St, Seattle, WA 98109, USA',
              Municipality: 'Seattle',
              Region: 'WA',
              PostalCode: '98109',
              Country: 'USA',
            },
          },
        ],
      });

      const result = await locationServiceModule.reverseGeocodeCoordinates(47.6062, -122.3321);

      expect(result).toEqual({
        latitude: 47.6062,
        longitude: -122.3321,
        address: '123 Main St, Seattle, WA 98109, USA',
        city: 'Seattle',
        state: 'WA',
        zipcode: '98109',
        country: 'USA',
      });
    });

    it('returns null when no results found', async () => {
      mockSend.mockResolvedValueOnce({ Results: [] });

      const result = await locationServiceModule.reverseGeocodeCoordinates(47.6062, -122.3321);

      expect(result).toBeNull();
    });

    it('returns null when Place is missing', async () => {
      mockSend.mockResolvedValueOnce({
        Results: [{ Place: null }],
      });

      const result = await locationServiceModule.reverseGeocodeCoordinates(47.6062, -122.3321);

      expect(result).toBeNull();
    });

    it('uses empty string for address when Label is missing', async () => {
      mockSend.mockResolvedValueOnce({
        Results: [
          {
            Place: {
              Municipality: 'Seattle',
              Region: 'WA',
              PostalCode: '98109',
              Country: 'USA',
            },
          },
        ],
      });

      const result = await locationServiceModule.reverseGeocodeCoordinates(47.6062, -122.3321);

      expect(result?.address).toBe('');
    });
  });
});
