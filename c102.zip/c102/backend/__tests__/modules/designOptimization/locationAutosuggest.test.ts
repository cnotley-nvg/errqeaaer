import * as locationAutosuggestModule from '../../../modules/designOptimization/domain/locationAutosuggest';

// eslint-disable-next-line no-var
var mockSend: jest.Mock;

jest.mock('@aws-sdk/client-location', () => {
  mockSend = jest.fn();
  return {
    LocationClient: jest.fn(() => ({
      send: mockSend,
    })),
    SearchPlaceIndexForSuggestionsCommand: jest.fn((input) => ({ input })),
    GetPlaceCommand: jest.fn((input) => ({ input })),
  };
});

describe('locationAutosuggest', () => {
  beforeEach(() => {
    if (mockSend) mockSend.mockClear();
  });

  describe('getAddressSuggestions', () => {
    it('returns address suggestions with coordinates', async () => {
      mockSend.mockResolvedValueOnce({
        Results: [
          {
            PlaceId: 'place-1',
            Text: '123 Main St',
          },
          {
            PlaceId: 'place-2',
            Text: '456 Main Ave',
          },
        ],
      });
      mockSend.mockResolvedValueOnce({
        Place: {
          Label: '123 Main St, Seattle, WA 98109, USA',
          Geometry: { Point: [-122.3321, 47.6062] },
          Municipality: 'Seattle',
          Region: 'WA',
          PostalCode: '98109',
          Country: 'USA',
        },
      });
      mockSend.mockResolvedValueOnce({
        Place: {
          Label: '456 Main Ave, Seattle, WA 98101, USA',
          Geometry: { Point: [-122.3297, 47.6101] },
          Municipality: 'Seattle',
          Region: 'WA',
          PostalCode: '98101',
          Country: 'USA',
        },
      });

      const results = await locationAutosuggestModule.getAddressSuggestions('123 Main');

      expect(results).toHaveLength(2);
      expect(results[0]).toEqual({
        label: '123 Main St, Seattle, WA 98109, USA',
        address: '123 Main St, Seattle, WA 98109, USA',
        city: 'Seattle',
        state: 'WA',
        zipcode: '98109',
        country: 'USA',
        latitude: 47.6062,
        longitude: -122.3321,
      });
    });

    it('filters out results with empty labels', async () => {
      mockSend.mockResolvedValueOnce({
        Results: [
          {
            PlaceId: 'place-1',
            Text: '123 Main St',
          },
          {
            Place: {
              Label: '',
            },
          },
          {
            Place: {
              Label: '   ',
            },
          },
        ],
      });
      mockSend.mockResolvedValueOnce({
        Place: {
          Label: '123 Main St, Seattle, WA 98109, USA',
          Geometry: { Point: [-122.3321, 47.6062] },
          Municipality: 'Seattle',
          Region: 'WA',
        },
      });

      const results = await locationAutosuggestModule.getAddressSuggestions('Main St');

      expect(results).toHaveLength(1);
      expect(results[0].address).toBe('123 Main St, Seattle, WA 98109, USA');
    });

    it('returns empty array when text is less than 2 characters', async () => {
      const results = await locationAutosuggestModule.getAddressSuggestions('a');

      expect(results).toEqual([]);
      expect(mockSend).not.toHaveBeenCalled();
    });

    it('returns empty array when text is undefined', async () => {
      const results = await locationAutosuggestModule.getAddressSuggestions(undefined);

      expect(results).toEqual([]);
      expect(mockSend).not.toHaveBeenCalled();
    });

    it('returns empty array when text is empty string', async () => {
      const results = await locationAutosuggestModule.getAddressSuggestions('');

      expect(results).toEqual([]);
      expect(mockSend).not.toHaveBeenCalled();
    });

    it('returns empty array when text is only whitespace', async () => {
      const results = await locationAutosuggestModule.getAddressSuggestions('   ');

      expect(results).toEqual([]);
      expect(mockSend).not.toHaveBeenCalled();
    });

    it('returns empty array when API call fails', async () => {
      mockSend.mockRejectedValueOnce(new Error('API Error'));

      const consoleSpy = jest.spyOn(console, 'error').mockImplementation();
      const results = await locationAutosuggestModule.getAddressSuggestions('Main St');

      expect(results).toEqual([]);
      consoleSpy.mockRestore();
    });

    it('handles missing Place in results', async () => {
      mockSend.mockResolvedValueOnce({
        Results: [
          {
            PlaceId: 'place-1',
            Text: '123 Main St',
          },
          { Place: null },
        ],
      });
      mockSend.mockResolvedValueOnce({
        Place: {
          Label: '123 Main St, Seattle, WA 98109, USA',
          Geometry: { Point: [-122.3321, 47.6062] },
          Municipality: 'Seattle',
          Region: 'WA',
          PostalCode: '98109',
          Country: 'USA',
        },
      });

      const results = await locationAutosuggestModule.getAddressSuggestions('Main St');

      expect(results).toHaveLength(1);
    });

    it('handles missing Geometry in Place', async () => {
      mockSend.mockResolvedValueOnce({
        Results: [
          {
            PlaceId: 'place-1',
            Text: '123 Main St',
          },
        ],
      });
      mockSend.mockResolvedValueOnce({
        Place: {
          Label: '123 Main St, Seattle, WA 98109, USA',
          Municipality: 'Seattle',
          Region: 'WA',
          PostalCode: '98109',
          Country: 'USA',
        },
      });

      const results = await locationAutosuggestModule.getAddressSuggestions('Main St');

      expect(results[0].latitude).toBeUndefined();
      expect(results[0].longitude).toBeUndefined();
    });

    it('handles empty Results array', async () => {
      mockSend.mockResolvedValueOnce({ Results: [] });

      const results = await locationAutosuggestModule.getAddressSuggestions('nonexistent');

      expect(results).toEqual([]);
    });

    it('handles undefined Results', async () => {
      mockSend.mockResolvedValueOnce({});

      const results = await locationAutosuggestModule.getAddressSuggestions('Main St');

      expect(results).toEqual([]);
    });
  });
});
