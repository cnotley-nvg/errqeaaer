import { createHeatIndexService } from '../../../modules/designOptimization/domain/heatIndexService';
import type { Logger } from '../../../shared';
import type { HeatIndexLevel } from '@amzn/global-realty-mosaic-graphql-schema';

const createMockLogger = (): jest.Mocked<Logger> => {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;

  logger.child.mockReturnValue(logger);
  return logger;
};

describe('heatIndexService', () => {
  let mockFetch: jest.Mock;

  beforeEach(() => {
    jest.clearAllMocks();
    mockFetch = jest.fn();
    global.fetch = mockFetch;
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('real-world use cases', () => {
    it('Montana: h2+h3=149 (100-500 range) recommends Option 2', async () => {
      const logger = createMockLogger();
      const service = createHeatIndexService(logger);

      const mockResponse = {
        dataAvailable: true,
        levels: [
          { level: 0, hours: 7965 },
          { level: 1, hours: 646 },
          { level: 2, hours: 147 },
          { level: 3, hours: 2 },
          { level: 4, hours: 0 },
        ] as HeatIndexLevel[],
      };

      mockFetch.mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      } as Response);

      const result = await service.calculate({
        latitude: 47.0,
        longitude: -110.0,
      });

      expect(result.hvacRecommendation).toContain('Option 2 - Partial Mechanical Cooling');
      expect(result.riskWithoutMitigation).toBe('Medium risk');
      expect(result.dataAvailable).toBe(true);
    });

    it('Connecticut: h2=285 (100-500 range) recommends Option 2', async () => {
      const logger = createMockLogger();
      const service = createHeatIndexService(logger);

      const mockResponse = {
        dataAvailable: true,
        levels: [
          { level: 0, hours: 7409 },
          { level: 1, hours: 1034 },
          { level: 2, hours: 285 },
          { level: 3, hours: 32 },
          { level: 4, hours: 0 },
        ] as HeatIndexLevel[],
      };

      mockFetch.mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      } as Response);

      const result = await service.calculate({
        latitude: 41.6500201,
        longitude: -72.7342163,
      });

      expect(result.hvacRecommendation).toContain('Option 2 - Partial Mechanical Cooling');
      expect(result.riskWithoutMitigation).toBe('Medium risk');
      expect(result.dataAvailable).toBe(true);
    });

    it('Chicago: h2=300 (100-500 range) recommends Option 2 for AMZL', async () => {
      const logger = createMockLogger();
      const service = createHeatIndexService(logger);

      const mockResponse = {
        dataAvailable: true,
        levels: [
          { level: 0, hours: 7200 },
          { level: 1, hours: 1200 },
          { level: 2, hours: 300 },
          { level: 3, hours: 60 },
          { level: 4, hours: 0 },
        ] as HeatIndexLevel[],
      };

      mockFetch.mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      } as Response);

      const result = await service.calculate({
        latitude: 41.8781,
        longitude: -87.6298,
        facilityType: 'AMZL',
      });

      expect(result.hvacRecommendation).toContain('Option 2 - Partial Mechanical Cooling');
      expect(result.riskWithoutMitigation).toBe('Medium risk');
      expect(result.dataAvailable).toBe(true);
    });

    it('NYC: h2=342 (>500) recommends Option 3', async () => {
      const logger = createMockLogger();
      const service = createHeatIndexService(logger);

      const mockResponse = {
        dataAvailable: true,
        levels: [
          { level: 0, hours: 7090 },
          { level: 1, hours: 1119 },
          { level: 2, hours: 342 },
          { level: 3, hours: 197 },
          { level: 4, hours: 12 },
        ] as HeatIndexLevel[],
      };

      mockFetch.mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      } as Response);

      const result = await service.calculate({
        latitude: 40.7128,
        longitude: -74.006,
      });

      expect(result.hvacRecommendation).toContain('Option 3 - Permanent HVAC System');
      expect(result.riskWithoutMitigation).toBe('High risk');
      expect(result.dataAvailable).toBe(true);
    });
  });

  describe('HVAC recommendation logic', () => {
    describe('Facility type override', () => {
      it('non-AMZL facility defaults to Option 3', async () => {
        const logger = createMockLogger();
        const service = createHeatIndexService(logger);

        const mockResponse = {
          dataAvailable: true,
          levels: [
            { level: 0, hours: 8200 },
            { level: 1, hours: 500 },
            { level: 2, hours: 50 },
            { level: 3, hours: 10 },
            { level: 4, hours: 0 },
          ] as HeatIndexLevel[],
        };

        mockFetch.mockResolvedValueOnce({
          ok: true,
          json: async () => mockResponse,
        } as Response);

        const result = await service.calculate({
          latitude: 40.7128,
          longitude: -74.006,
          facilityType: 'IXD',
        });

        expect(result.hvacRecommendation).toContain('Option 3 - Permanent HVAC System');
        expect(result.riskWithoutMitigation).toBe('High risk');
      });

      it('AMZL facility uses heat index logic', async () => {
        const logger = createMockLogger();
        const service = createHeatIndexService(logger);

        const mockResponse = {
          dataAvailable: true,
          levels: [
            { level: 0, hours: 8200 },
            { level: 1, hours: 500 },
            { level: 2, hours: 50 },
            { level: 3, hours: 10 },
            { level: 4, hours: 0 },
          ] as HeatIndexLevel[],
        };

        mockFetch.mockResolvedValueOnce({
          ok: true,
          json: async () => mockResponse,
        } as Response);

        const result = await service.calculate({
          latitude: 40.7128,
          longitude: -74.006,
          facilityType: 'AMZL',
        });

        expect(result.hvacRecommendation).toContain('Option 1 - Natural Ventilation');
        expect(result.riskWithoutMitigation).toBe('Low risk');
      });
    });

    describe('Option 3 - Permanent HVAC System', () => {
      it('Scenario A: h2 (90-100°F) > 500 hrs/year', async () => {
        const logger = createMockLogger();
        const service = createHeatIndexService(logger);

        const mockResponse = {
          dataAvailable: true,
          levels: [
            { level: 0, hours: 7000 },
            { level: 1, hours: 1000 },
            { level: 2, hours: 501 },
            { level: 3, hours: 200 },
            { level: 4, hours: 0 },
          ] as HeatIndexLevel[],
        };

        mockFetch.mockResolvedValueOnce({
          ok: true,
          json: async () => mockResponse,
        } as Response);

        const result = await service.calculate({ latitude: 40.7128, longitude: -74.006 });

        expect(result.hvacRecommendation).toContain('Option 3');
        expect(result.riskWithoutMitigation).toBe('High risk');
      });

      it('Scenario B: h3 (101-110°F) > 300 hrs/year', async () => {
        const logger = createMockLogger();
        const service = createHeatIndexService(logger);

        const mockResponse = {
          dataAvailable: true,
          levels: [
            { level: 0, hours: 7000 },
            { level: 1, hours: 1000 },
            { level: 2, hours: 400 },
            { level: 3, hours: 301 },
            { level: 4, hours: 0 },
          ] as HeatIndexLevel[],
        };

        mockFetch.mockResolvedValueOnce({
          ok: true,
          json: async () => mockResponse,
        } as Response);

        const result = await service.calculate({ latitude: 40.7128, longitude: -74.006 });

        expect(result.hvacRecommendation).toContain('Option 3');
        expect(result.riskWithoutMitigation).toBe('High risk');
      });

      it('Scenario C: h4 (≥115°F) ≥ 1 hr/year', async () => {
        const logger = createMockLogger();
        const service = createHeatIndexService(logger);

        const mockResponse = {
          dataAvailable: true,
          levels: [
            { level: 0, hours: 7000 },
            { level: 1, hours: 1000 },
            { level: 2, hours: 400 },
            { level: 3, hours: 200 },
            { level: 4, hours: 1 },
          ] as HeatIndexLevel[],
        };

        mockFetch.mockResolvedValueOnce({
          ok: true,
          json: async () => mockResponse,
        } as Response);

        const result = await service.calculate({ latitude: 40.7128, longitude: -74.006 });

        expect(result.hvacRecommendation).toContain('Option 3');
        expect(result.riskWithoutMitigation).toBe('High risk');
      });
    });

    describe('Option 2 - Partial Mechanical Cooling', () => {
      it('100 hrs/year ≤ h2 (90-100°F) < 500 hrs/year for AMZL', async () => {
        const logger = createMockLogger();
        const service = createHeatIndexService(logger);

        const mockResponse = {
          dataAvailable: true,
          levels: [
            { level: 0, hours: 7000 },
            { level: 1, hours: 1000 },
            { level: 2, hours: 300 },
            { level: 3, hours: 200 },
            { level: 4, hours: 0 },
          ] as HeatIndexLevel[],
        };

        mockFetch.mockResolvedValueOnce({
          ok: true,
          json: async () => mockResponse,
        } as Response);

        const result = await service.calculate({
          latitude: 40.7128,
          longitude: -74.006,
          facilityType: 'AMZL',
        });

        expect(result.hvacRecommendation).toContain('Option 2');
        expect(result.riskWithoutMitigation).toBe('Medium risk');
      });

      it('boundary: h2 = 100 hrs (minimum threshold) for AMZL', async () => {
        const logger = createMockLogger();
        const service = createHeatIndexService(logger);

        const mockResponse = {
          dataAvailable: true,
          levels: [
            { level: 0, hours: 8000 },
            { level: 1, hours: 660 },
            { level: 2, hours: 100 },
            { level: 3, hours: 0 },
            { level: 4, hours: 0 },
          ] as HeatIndexLevel[],
        };

        mockFetch.mockResolvedValueOnce({
          ok: true,
          json: async () => mockResponse,
        } as Response);

        const result = await service.calculate({
          latitude: 40.7128,
          longitude: -74.006,
          facilityType: 'AMZL',
        });

        expect(result.hvacRecommendation).toContain('Option 2');
      });

      it('boundary: h2 = 499 hrs (maximum threshold) for AMZL', async () => {
        const logger = createMockLogger();
        const service = createHeatIndexService(logger);

        const mockResponse = {
          dataAvailable: true,
          levels: [
            { level: 0, hours: 7000 },
            { level: 1, hours: 1261 },
            { level: 2, hours: 499 },
            { level: 3, hours: 0 },
            { level: 4, hours: 0 },
          ] as HeatIndexLevel[],
        };

        mockFetch.mockResolvedValueOnce({
          ok: true,
          json: async () => mockResponse,
        } as Response);

        const result = await service.calculate({
          latitude: 40.7128,
          longitude: -74.006,
          facilityType: 'AMZL',
        });

        expect(result.hvacRecommendation).toContain('Option 2');
      });
    });

    describe('Option 1 - Natural Ventilation', () => {
      it('h0 (<80°F) > 92.5% of year (8103 hrs)', async () => {
        const logger = createMockLogger();
        const service = createHeatIndexService(logger);

        const mockResponse = {
          dataAvailable: true,
          levels: [
            { level: 0, hours: 8104 },
            { level: 1, hours: 600 },
            { level: 2, hours: 50 },
            { level: 3, hours: 6 },
            { level: 4, hours: 0 },
          ] as HeatIndexLevel[],
        };

        mockFetch.mockResolvedValueOnce({
          ok: true,
          json: async () => mockResponse,
        } as Response);

        const result = await service.calculate({ latitude: 40.7128, longitude: -74.006 });

        expect(result.hvacRecommendation).toContain('Option 1');
        expect(result.riskWithoutMitigation).toBe('Low risk');
      });

      it('h0+h1 (<90°F) > 99% of year (8673 hrs)', async () => {
        const logger = createMockLogger();
        const service = createHeatIndexService(logger);

        const mockResponse = {
          dataAvailable: true,
          levels: [
            { level: 0, hours: 7500 },
            { level: 1, hours: 1174 },
            { level: 2, hours: 80 },
            { level: 3, hours: 6 },
            { level: 4, hours: 0 },
          ] as HeatIndexLevel[],
        };

        mockFetch.mockResolvedValueOnce({
          ok: true,
          json: async () => mockResponse,
        } as Response);

        const result = await service.calculate({ latitude: 40.7128, longitude: -74.006 });

        expect(result.hvacRecommendation).toContain('Option 1');
        expect(result.riskWithoutMitigation).toBe('Low risk');
      });

      it('h2 < 100 hrs (below Option 2 threshold)', async () => {
        const logger = createMockLogger();
        const service = createHeatIndexService(logger);

        const mockResponse = {
          dataAvailable: true,
          levels: [
            { level: 0, hours: 8000 },
            { level: 1, hours: 661 },
            { level: 2, hours: 50 },
            { level: 3, hours: 49 },
            { level: 4, hours: 0 },
          ] as HeatIndexLevel[],
        };

        mockFetch.mockResolvedValueOnce({
          ok: true,
          json: async () => mockResponse,
        } as Response);

        const result = await service.calculate({ latitude: 40.7128, longitude: -74.006 });

        expect(result.hvacRecommendation).toContain('Option 1');
      });
    });
  });

  describe('error handling', () => {
    it('returns error response when data is not available', async () => {
      const logger = createMockLogger();
      const service = createHeatIndexService(logger);

      const mockResponse = {
        dataAvailable: false,
      };

      mockFetch.mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      } as Response);

      const result = await service.calculate({
        latitude: 40.7128,
        longitude: -74.006,
      });

      expect(result.dataAvailable).toBe(false);
      expect(result.error).toBe('Weather data not available for this location');
      expect(result.hvacRecommendation).toBe('Data not available for this location');
    });

    it('returns error response when fetch fails', async () => {
      const logger = createMockLogger();
      const service = createHeatIndexService(logger);

      mockFetch.mockRejectedValueOnce(new Error('Network error'));

      const result = await service.calculate({
        latitude: 40.7128,
        longitude: -74.006,
      });

      expect(result.dataAvailable).toBe(false);
      expect(result.error).toBe('Network error');
      expect(result.hvacRecommendation).toBe('Unable to calculate internal heat index');
    });

    it('returns error response when response is not ok', async () => {
      const logger = createMockLogger();
      const service = createHeatIndexService(logger);

      mockFetch.mockResolvedValueOnce({
        ok: false,
      } as Response);

      const result = await service.calculate({
        latitude: 40.7128,
        longitude: -74.006,
      });

      expect(result.dataAvailable).toBe(false);
      expect(result.error).toBe('Failed to fetch weather data');
    });
  });

  describe('real location validation', () => {
    const realLocations = [
      {
        name: 'Seattle, WA',
        facilityType: 'AMZL',
        expected: 'Option 1',
        levels: [8298, 387, 71, 4, 0],
      },
      {
        name: 'Denver, CO',
        facilityType: 'AMZL',
        expected: 'Option 1',
        levels: [8038, 688, 34, 0, 0],
      },
      {
        name: 'Portland, OR',
        facilityType: 'AMZL',
        expected: 'Option 1',
        levels: [8178, 433, 125, 24, 0],
      },
      {
        name: 'Boston, MA',
        facilityType: 'AMZL',
        expected: 'Option 2',
        levels: [7763, 781, 164, 52, 0],
      },
      {
        name: 'Minneapolis, MN',
        facilityType: 'AMZL',
        expected: 'Option 2',
        levels: [7836, 774, 145, 5, 0],
      },
      {
        name: 'Phoenix, AZ',
        facilityType: 'AMZL',
        expected: 'Option 3',
        levels: [4230, 1515, 1540, 1347, 128],
      },
      {
        name: 'Miami, FL',
        facilityType: 'AMZL',
        expected: 'Option 3',
        levels: [1968, 3131, 2141, 1504, 16],
      },
      {
        name: 'Houston, TX',
        facilityType: 'AMZL',
        expected: 'Option 3',
        levels: [3817, 2372, 1223, 1120, 229],
      },
      {
        name: 'San Francisco, CA',
        facilityType: 'FC',
        expected: 'Option 3',
        levels: [8074, 537, 137, 12, 0],
      },
    ];

    realLocations.forEach((location) => {
      it(`${location.name} (${location.facilityType}) should get ${location.expected}`, async () => {
        const logger = createMockLogger();
        const service = createHeatIndexService(logger);

        const mockResponse = {
          dataAvailable: true,
          levels: location.levels.map((hours, level) => ({
            level,
            hours,
            percentage: (hours / 8760) * 100,
          })) as HeatIndexLevel[],
        };

        mockFetch.mockResolvedValueOnce({
          ok: true,
          json: async () => mockResponse,
        } as Response);

        const result = await service.calculate({
          latitude: 0,
          longitude: 0,
          facilityType: location.facilityType,
        });

        expect(result.hvacRecommendation).toContain(location.expected);
      });
    });
  });

  describe('edge cases', () => {
    it('handles missing heat index levels gracefully', async () => {
      const logger = createMockLogger();
      const service = createHeatIndexService(logger);

      const mockResponse = {
        dataAvailable: true,
        levels: [],
      };

      mockFetch.mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      } as Response);

      const result = await service.calculate({ latitude: 40.7128, longitude: -74.006 });

      expect(result.hvacRecommendation).toContain('Option 1');
      expect(result.riskWithoutMitigation).toBe('Low risk');
    });

    it('Option 3 takes precedence: h2=501 even if h2+h3 in Option 2 range', async () => {
      const logger = createMockLogger();
      const service = createHeatIndexService(logger);

      const mockResponse = {
        dataAvailable: true,
        levels: [
          { level: 0, hours: 7000 },
          { level: 1, hours: 1259 },
          { level: 2, hours: 501 },
          { level: 3, hours: 0 },
          { level: 4, hours: 0 },
        ] as HeatIndexLevel[],
      };

      mockFetch.mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      } as Response);

      const result = await service.calculate({ latitude: 40.7128, longitude: -74.006 });

      expect(result.hvacRecommendation).toContain('Option 3');
    });

    it('Option 3 takes precedence: h3=301 even if h2+h3 in Option 2 range', async () => {
      const logger = createMockLogger();
      const service = createHeatIndexService(logger);

      const mockResponse = {
        dataAvailable: true,
        levels: [
          { level: 0, hours: 7000 },
          { level: 1, hours: 1459 },
          { level: 2, hours: 0 },
          { level: 3, hours: 301 },
          { level: 4, hours: 0 },
        ] as HeatIndexLevel[],
      };

      mockFetch.mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      } as Response);

      const result = await service.calculate({ latitude: 40.7128, longitude: -74.006 });

      expect(result.hvacRecommendation).toContain('Option 3');
    });

    it('Option 3 takes precedence: h4=1 overrides all other conditions', async () => {
      const logger = createMockLogger();
      const service = createHeatIndexService(logger);

      const mockResponse = {
        dataAvailable: true,
        levels: [
          { level: 0, hours: 7000 },
          { level: 1, hours: 1600 },
          { level: 2, hours: 150 },
          { level: 3, hours: 9 },
          { level: 4, hours: 1 },
        ] as HeatIndexLevel[],
      };

      mockFetch.mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      } as Response);

      const result = await service.calculate({ latitude: 40.7128, longitude: -74.006 });

      expect(result.hvacRecommendation).toContain('Option 3');
    });
  });
});
