import { createDesignOptimizationModule } from '../../../modules/designOptimization';
import type { Logger } from '../../../shared';

const createMockLogger = (): jest.Mocked<Logger> => {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;

  logger.child.mockReturnValue(logger);
  return logger;
};

describe('createDesignOptimizationModule', () => {
  it('creates resolvers using scoped loggers', () => {
    const resolverLogger = createMockLogger();
    const moduleLogger = createMockLogger();
    moduleLogger.child.mockReturnValue(resolverLogger);

    const rootLogger = createMockLogger();
    rootLogger.child.mockReturnValue(moduleLogger);

    const module = createDesignOptimizationModule({ logger: rootLogger });

    expect(rootLogger.child).toHaveBeenCalledWith({ module: 'design-optimization' });
    expect(moduleLogger.child).toHaveBeenCalledWith({ component: 'resolvers' });
    expect(typeof module.resolvers.Query.optimizeDesign).toBe('function');
  });
});
