import { createDesignOptimizationResolvers } from '../../../modules/designOptimization/graphql/resolvers';
import * as locationService from '../../../modules/designOptimization/domain/locationService';
import * as locationAutosuggest from '../../../modules/designOptimization/domain/locationAutosuggest';
import type { Logger } from '../../../shared';

jest.mock('../../../modules/designOptimization/domain/locationService');
jest.mock('../../../modules/designOptimization/domain/locationAutosuggest');

const createMockLogger = (): jest.Mocked<Logger> => {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;

  logger.child.mockReturnValue(logger);
  return logger;
};

describe('designOptimization resolvers', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('returns deterministic results for explicit latitude/longitude inputs', async () => {
    const logger = createMockLogger();
    const resolvers = createDesignOptimizationResolvers({ logger });

    const result = await resolvers.Query.optimizeDesign(null, {
      input: {
        locationType: 'LAT_LONG',
        latitude: 47.6,
        longitude: -122.3,
        function: 'FULFILLMENT_CENTER',
        program: 'GEN5',
        totalSquareFootage: '500000_750000',
      },
    });

    expect(logger.info).toHaveBeenCalledWith('Design optimization requested', {
      input: expect.objectContaining({ locationType: 'LAT_LONG' }),
    });
    expect(result.location).toEqual({ latitude: 47.6, longitude: -122.3, type: 'LAT_LONG' });
    expect(result.projectParameters).toEqual({
      function: 'FULFILLMENT_CENTER',
      program: 'GEN5',
      totalSquareFootage: '500000_750000',
    });
    expect(result.recommendations).toHaveLength(2);
  });

  it('derives mock coordinates for ZIP code inputs in a stable manner', async () => {
    const logger = createMockLogger();
    const resolvers = createDesignOptimizationResolvers({ logger });

    const first = await resolvers.Query.optimizeDesign(null, {
      input: {
        locationType: 'ZIP_CODE',
        zipCode: '98109',
        function: 'SORT_CENTER',
        program: 'GEN4',
        totalSquareFootage: '250000_400000',
      },
    });

    const second = await resolvers.Query.optimizeDesign(null, {
      input: {
        locationType: 'ZIP_CODE',
        zipCode: '98109',
        function: 'SORT_CENTER',
        program: 'GEN4',
        totalSquareFootage: '250000_400000',
      },
    });

    expect(first.location).toEqual(second.location);
    expect(first.location.type).toBe('ZIP_CODE');
    expect(first.recommendations[0]?.reportId).toBeDefined();
  });

  describe('geocodeAddress resolver', () => {
    it('calls locationService.geocodeAddress with address and zipcode', async () => {
      const logger = createMockLogger();
      const resolvers = createDesignOptimizationResolvers({ logger });

      const mockResult = {
        latitude: 47.6062,
        longitude: -122.3321,
        address: '123 Main St, Seattle, WA 98109, USA',
        city: 'Seattle',
        state: 'WA',
        zipcode: '98109',
        country: 'USA',
      };

      (locationService.geocodeAddress as jest.Mock).mockResolvedValue(mockResult);

      const result = await resolvers.Query.geocodeAddress(null, {
        address: '123 Main St',
        zipcode: '98109',
      });

      expect(locationService.geocodeAddress).toHaveBeenCalledWith('123 Main St', '98109');
      expect(result).toEqual(mockResult);
      expect(logger.info).toHaveBeenCalledWith('Geocoding address', {
        address: '123 Main St',
        zipcode: '98109',
      });
    });

    it('returns null when geocoding fails', async () => {
      const logger = createMockLogger();
      const resolvers = createDesignOptimizationResolvers({ logger });

      (locationService.geocodeAddress as jest.Mock).mockResolvedValue(null);

      const result = await resolvers.Query.geocodeAddress(null, {
        address: 'nonexistent',
      });

      expect(result).toBeNull();
    });
  });

  describe('reverseGeocodeCoordinates resolver', () => {
    it('calls locationService.reverseGeocodeCoordinates with coordinates', async () => {
      const logger = createMockLogger();
      const resolvers = createDesignOptimizationResolvers({ logger });

      const mockResult = {
        latitude: 47.6062,
        longitude: -122.3321,
        address: '123 Main St, Seattle, WA 98109, USA',
        city: 'Seattle',
        state: 'WA',
        zipcode: '98109',
        country: 'USA',
      };

      (locationService.reverseGeocodeCoordinates as jest.Mock).mockResolvedValue(mockResult);

      const result = await resolvers.Query.reverseGeocodeCoordinates(null, {
        latitude: 47.6062,
        longitude: -122.3321,
      });

      expect(locationService.reverseGeocodeCoordinates).toHaveBeenCalledWith(47.6062, -122.3321);
      expect(result).toEqual(mockResult);
      expect(logger.info).toHaveBeenCalledWith('Reverse geocoding coordinates', {
        latitude: 47.6062,
        longitude: -122.3321,
      });
    });

    it('returns null when reverse geocoding fails', async () => {
      const logger = createMockLogger();
      const resolvers = createDesignOptimizationResolvers({ logger });

      (locationService.reverseGeocodeCoordinates as jest.Mock).mockResolvedValue(null);

      const result = await resolvers.Query.reverseGeocodeCoordinates(null, {
        latitude: 0,
        longitude: 0,
      });

      expect(result).toBeNull();
    });
  });

  describe('getAddressSuggestions resolver', () => {
    it('calls locationAutosuggest.getAddressSuggestions with text, country, and city', async () => {
      const logger = createMockLogger();
      const resolvers = createDesignOptimizationResolvers({ logger });

      const mockResults = [
        {
          label: '123 Main St, Seattle, WA 98109, USA',
          address: '123 Main St, Seattle, WA 98109, USA',
          city: 'Seattle',
          state: 'WA',
          zipcode: '98109',
          country: 'USA',
          latitude: 47.6062,
          longitude: -122.3321,
        },
      ];

      (locationAutosuggest.getAddressSuggestions as jest.Mock).mockResolvedValue(mockResults);

      const result = await resolvers.Query.getAddressSuggestions(null, {
        text: '123 Main',
        country: 'USA',
        city: 'Seattle',
      });

      expect(locationAutosuggest.getAddressSuggestions).toHaveBeenCalledWith(
        '123 Main',
        'USA',
        'Seattle'
      );
      expect(result).toEqual(mockResults);
      expect(logger.info).toHaveBeenCalledWith('Getting address suggestions', {
        text: '123 Main',
        country: 'USA',
        city: 'Seattle',
      });
    });

    it('returns empty array when no suggestions found', async () => {
      const logger = createMockLogger();
      const resolvers = createDesignOptimizationResolvers({ logger });

      (locationAutosuggest.getAddressSuggestions as jest.Mock).mockResolvedValue([]);

      const result = await resolvers.Query.getAddressSuggestions(null, {
        text: 'nonexistent',
      });

      expect(result).toEqual([]);
    });

    it('handles missing optional parameters', async () => {
      const logger = createMockLogger();
      const resolvers = createDesignOptimizationResolvers({ logger });

      (locationAutosuggest.getAddressSuggestions as jest.Mock).mockResolvedValue([]);

      await resolvers.Query.getAddressSuggestions(null, {
        text: 'Main St',
      });

      expect(locationAutosuggest.getAddressSuggestions).toHaveBeenCalledWith(
        'Main St',
        undefined,
        undefined
      );
    });
  });
});
