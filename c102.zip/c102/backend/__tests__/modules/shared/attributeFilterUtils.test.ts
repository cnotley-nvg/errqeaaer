import {
  collectAttributeTokens,
  applyAttributeFilters,
} from '../../../modules/shared/attributeFilterUtils';

const buildEntity = (attributes: Record<string, unknown> = {}) => ({
  latestVersion: {
    attributes,
  },
});

describe('attributeFilterUtils', () => {
  it('collectAttributeTokens excludes base field filters', () => {
    const tokens = [
      { propertyKey: 'name', operator: 'CONTAINS', value: 'dock' },
      { propertyKey: 'region', operator: 'EQUALS', value: 'NA' },
    ];

    const baseFields = new Set(['name', 'description', 'accProjectId']);

    const result = collectAttributeTokens({ tokenGroups: tokens } as any, baseFields);

    expect(result).toEqual([{ propertyKey: 'region', operator: 'EQUALS', value: 'NA' }]);
  });

  it('applyAttributeFilters supports AND with EQUALS', () => {
    const entities = [buildEntity({ region: 'NA' }), buildEntity({ region: 'EU' })];

    const tokens = [{ propertyKey: 'region', operator: 'EQUALS', value: 'NA' }];

    const filtered = applyAttributeFilters(entities as any, tokens as any, 'AND');

    expect(filtered).toHaveLength(1);
    expect((filtered[0]?.latestVersion?.attributes as any).region).toBe('NA');
  });

  it('applyAttributeFilters supports NOT_EQUALS including entities with no value', () => {
    const entities = [
      buildEntity({ region: 'NA' }),
      buildEntity({ region: 'EU' }),
      buildEntity({}), // region missing
    ];

    const tokens = [{ propertyKey: 'region', operator: 'NOT_EQUALS', value: 'EU' }];

    const filtered = applyAttributeFilters(entities as any, tokens as any, 'AND');

    expect(filtered).toHaveLength(2);
    const regions = filtered.map((e) => (e.latestVersion as any).attributes.region ?? null);
    expect(regions).toEqual(['NA', null]);
  });

  it('applyAttributeFilters supports OR with CONTAINS across array values', () => {
    const entities = [
      buildEntity({ tags: ['safety', 'gen5'] }),
      buildEntity({ tags: ['retrofit'] }),
      buildEntity({ tags: ['other'] }),
    ];

    const tokens = [{ propertyKey: 'tags', operator: 'CONTAINS', values: ['retrofit', 'gen5'] }];

    const filtered = applyAttributeFilters(entities as any, tokens as any, 'OR');

    expect(filtered).toHaveLength(2);
  });

  it('applyAttributeFilters supports NOT_CONTAINS to exclude matching substrings', () => {
    const entities = [
      buildEntity({ notes: 'fire rated assembly' }),
      buildEntity({ notes: 'mechanical room spec' }),
    ];

    const tokens = [{ propertyKey: 'notes', operator: 'NOT_CONTAINS', value: 'mechanical' }];

    const filtered = applyAttributeFilters(entities as any, tokens as any, 'AND');

    expect(filtered).toHaveLength(1);
    expect((filtered[0]?.latestVersion?.attributes as any).notes).toBe('fire rated assembly');
  });

  it('applyAttributeFilters supports multi-value AND for same property (array intersection)', () => {
    // Test case: Filter for templates that have BOTH ARS AND IXD in their program array
    const entities = [
      buildEntity({ program: ['ARS', 'IXD', 'Prime'] }), // Should match - has both
      buildEntity({ program: ['ARS', 'Prime'] }), // Should NOT match - missing IXD
      buildEntity({ program: ['IXD', 'SSD'] }), // Should NOT match - missing ARS
      buildEntity({ program: ['ARS'] }), // Should NOT match - missing IXD
      buildEntity({ program: [] }), // Should NOT match - empty
      buildEntity({}), // Should NOT match - no program attribute
    ];

    // Two separate tokens for the same property with AND operation
    const tokens = [
      { propertyKey: 'program', operator: 'EQUALS', value: 'ARS' },
      { propertyKey: 'program', operator: 'EQUALS', value: 'IXD' },
    ];

    const filtered = applyAttributeFilters(entities as any, tokens as any, 'AND');

    expect(filtered).toHaveLength(1);
    expect((filtered[0]?.latestVersion?.attributes as any).program).toEqual([
      'ARS',
      'IXD',
      'Prime',
    ]);
  });

  it('applyAttributeFilters supports multi-value OR for same property (array union)', () => {
    // Test case: Filter for templates that have EITHER ARS OR IXD in their program array
    const entities = [
      buildEntity({ program: ['ARS', 'Prime'] }), // Should match - has ARS
      buildEntity({ program: ['IXD', 'SSD'] }), // Should match - has IXD
      buildEntity({ program: ['ARS', 'IXD'] }), // Should match - has both
      buildEntity({ program: ['Prime', 'SSD'] }), // Should NOT match - has neither
      buildEntity({ program: [] }), // Should NOT match - empty
    ];

    // Two separate tokens for the same property with OR operation
    const tokens = [
      { propertyKey: 'program', operator: 'EQUALS', value: 'ARS' },
      { propertyKey: 'program', operator: 'EQUALS', value: 'IXD' },
    ];

    const filtered = applyAttributeFilters(entities as any, tokens as any, 'OR');

    expect(filtered).toHaveLength(3);
    const programs = filtered.map((e) => (e.latestVersion as any).attributes.program);
    expect(programs).toEqual([
      ['ARS', 'Prime'],
      ['IXD', 'SSD'],
      ['ARS', 'IXD'],
    ]);
  });
});
