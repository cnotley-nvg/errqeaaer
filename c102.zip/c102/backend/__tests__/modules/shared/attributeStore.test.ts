import { AttributeDatatype } from '@amzn/global-realty-mosaic-prisma-client';

import { loadAttributes, storeAttributes } from '../../../modules/shared/attributeStore';

const createExecutor = () => {
  const attributeDefinitionCreate = jest.fn().mockImplementation(async ({ data }) => {
    const normalizedDatatype =
      data.datatype ??
      (['throughput', 'mass'].includes(data.name) ? AttributeDatatype.NUM : AttributeDatatype.TEXT);

    return {
      id: `${data.name}-id`,
      ...data,
      datatype: normalizedDatatype,
    };
  });
  const attributeDefinitionFindUnique = jest.fn();
  const unitFindFirst = jest.fn();
  const attributeTextCreate = jest.fn();
  const attributeIntCreate = jest.fn();
  const attributeBoolCreate = jest.fn();
  const attributeNumericCreate = jest.fn();
  const attributeDecimalCreate = jest.fn();
  const textFindMany = jest.fn().mockResolvedValue([]);
  const intFindMany = jest.fn().mockResolvedValue([]);
  const boolFindMany = jest.fn().mockResolvedValue([]);
  const numericFindMany = jest.fn().mockResolvedValue([]);
  const decimalFindMany = jest.fn().mockResolvedValue([]);
  const textDeleteMany = jest.fn();
  const intDeleteMany = jest.fn();
  const boolDeleteMany = jest.fn();
  const numericDeleteMany = jest.fn();
  const decimalDeleteMany = jest.fn();

  const executor = {
    attributeDefinition: {
      findUnique: attributeDefinitionFindUnique,
      create: attributeDefinitionCreate,
    },
    unit: {
      findFirst: unitFindFirst,
    },
    attributeTextValue: {
      deleteMany: textDeleteMany,
      create: attributeTextCreate,
      findMany: textFindMany,
    },
    attributeIntValue: {
      deleteMany: intDeleteMany,
      create: attributeIntCreate,
      findMany: intFindMany,
    },
    attributeBoolValue: {
      deleteMany: boolDeleteMany,
      create: attributeBoolCreate,
      findMany: boolFindMany,
    },
    attributeNumericValue: {
      deleteMany: numericDeleteMany,
      create: attributeNumericCreate,
      findMany: numericFindMany,
    },
    attributeDecimalValue: {
      deleteMany: decimalDeleteMany,
      create: attributeDecimalCreate,
      findMany: decimalFindMany,
    },
  } as unknown as Parameters<typeof storeAttributes>[0];

  return {
    executor,
    attributeDefinitionFindUnique,
    unitFindFirst,
    attributeTextCreate,
    attributeIntCreate,
    attributeBoolCreate,
    attributeNumericCreate,
    attributeDecimalCreate,
  };
};

describe('attributeStore', () => {
  it('stores text, list, integer, and boolean attribute values for an entity', async () => {
    const {
      executor,
      attributeDefinitionFindUnique,
      attributeTextCreate,
      attributeIntCreate,
      attributeBoolCreate,
    } = createExecutor();

    attributeDefinitionFindUnique.mockImplementation(async ({ where: { name } }: any) => {
      switch (name) {
        case 'region':
          return { id: 'region-id', name, datatype: AttributeDatatype.TEXT, isMulti: false };
        case 'tags':
          return { id: 'tags-id', name, datatype: AttributeDatatype.TEXT, isMulti: true };
        case 'priority':
          return { id: 'priority-id', name, datatype: AttributeDatatype.INT, isMulti: false };
        case 'approved':
          return { id: 'approved-id', name, datatype: AttributeDatatype.BOOL, isMulti: false };
        default:
          return null;
      }
    });

    await storeAttributes(executor, 'KIT_VERSION', 'entity-1', {
      region: 'NA',
      tags: ['Dock', 'Safety'],
      priority: 3,
      approved: true,
    });

    expect(attributeTextCreate).toHaveBeenCalledWith({
      data: expect.objectContaining({
        entityType: 'KIT_VERSION',
        entityId: 'entity-1',
        attrDefId: 'region-id',
      }),
    });
    expect(attributeTextCreate).toHaveBeenCalledWith({
      data: expect.objectContaining({ attrDefId: 'tags-id', ord: 2 }),
    });
    expect(attributeIntCreate).toHaveBeenCalledWith({
      data: {
        entityType: 'KIT_VERSION',
        entityId: 'entity-1',
        attrDefId: 'priority-id',
        ord: 1,
        value: BigInt(3),
      },
    });
    expect(attributeBoolCreate).toHaveBeenCalledWith({
      data: {
        entityType: 'KIT_VERSION',
        entityId: 'entity-1',
        attrDefId: 'approved-id',
        ord: 0,
        value: true,
      },
    });
  });

  it('stores numeric attribute values with unit metadata', async () => {
    const attributeNumericCreate = jest.fn().mockResolvedValue(undefined);

    const client = {
      attributeDefinition: {
        findUnique: jest.fn().mockResolvedValue({
          id: 'throughput-id',
          datatype: AttributeDatatype.NUM,
          isMulti: false,
          unitDimensionId: 'dim-1',
        }),
        create: jest.fn(),
      },
      unit: {
        findFirst: jest.fn().mockResolvedValue({
          id: 'unit-1',
          code: 'Mbps',
          unitDimensionId: 'dim-1',
          factorToSi: 1_000_000,
          offsetToSi: 0,
        }),
      },
      attributeTextValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeIntValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeBoolValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeNumericValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: attributeNumericCreate,
        findMany: jest.fn(),
      },
      attributeDecimalValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
    } as unknown as Parameters<typeof storeAttributes>[0];

    await storeAttributes(client, 'KIT_VERSION', 'entity-1', {
      throughput: { value: 12.5, unit: 'Mbps' },
    });

    expect(client.attributeDefinition.findUnique).toHaveBeenCalledWith({
      where: { name: 'throughput' },
    });
    expect(attributeNumericCreate).toHaveBeenCalledWith({
      data: {
        entityType: 'KIT_VERSION',
        entityId: 'entity-1',
        attrDefId: 'throughput-id',
        ord: 1,
        value: 12.5,
        valueSi: 12.5 * 1_000_000,
        unitId: 'unit-1',
      },
    });
  });

  it('throws when numeric attribute is missing unit information', async () => {
    const client = {
      attributeDefinition: {
        findUnique: jest.fn().mockResolvedValue({
          id: 'mass-id',
          datatype: AttributeDatatype.NUM,
          isMulti: false,
          unitDimensionId: 'dim-1',
        }),
        create: jest.fn(),
      },
      unit: {
        findFirst: jest.fn().mockResolvedValue(null),
      },
      attributeTextValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeIntValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeBoolValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeNumericValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeDecimalValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
    } as unknown as Parameters<typeof storeAttributes>[0];

    await expect(
      storeAttributes(client, 'STANDARD_VERSION', 'entity-2', {
        mass: { value: 12.5, unit: undefined },
      })
    ).rejects.toThrow("Attribute 'mass' requires a unit within dimension 'dim-1'.");
  });

  it('loads attribute values back into a record', async () => {
    const { executor } = createExecutor();

    (executor.attributeTextValue.findMany as jest.Mock).mockResolvedValue([
      {
        attrDef: { name: 'region', isMulti: false },
        value: 'NA',
      },
      {
        attrDef: { name: 'tags', isMulti: true },
        value: 'Dock',
      },
      {
        attrDef: { name: 'tags', isMulti: true },
        value: 'Safety',
      },
    ]);

    (executor.attributeIntValue.findMany as jest.Mock).mockResolvedValue([
      {
        attrDef: { name: 'priority', isMulti: false },
        value: BigInt(7),
      },
    ]);

    (executor.attributeBoolValue.findMany as jest.Mock).mockResolvedValue([
      {
        attrDef: { name: 'approved', isMulti: false },
        value: true,
      },
    ]);

    (executor.attributeNumericValue.findMany as jest.Mock).mockResolvedValue([
      {
        attrDef: { name: 'throughput', isMulti: false },
        value: '12.5',
        unit: { code: 'Mbps' },
      },
    ]);

    const attributes = await loadAttributes(executor, 'entity-3');

    expect(attributes).toEqual({
      region: 'NA',
      tags: ['Dock', 'Safety'],
      priority: 7,
      approved: true,
      throughput: { value: 12.5, unit: 'Mbps' },
    });
  });

  it('throws when a single-value attribute receives multiple values', async () => {
    const client = {
      attributeDefinition: {
        findUnique: jest.fn().mockResolvedValue({
          id: 'region-id',
          datatype: AttributeDatatype.TEXT,
          isMulti: false,
          unitDimensionId: null,
        }),
        create: jest.fn(),
      },
      unit: {
        findFirst: jest.fn(),
      },
      attributeTextValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeIntValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeBoolValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeNumericValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeDecimalValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
    } as unknown as Parameters<typeof storeAttributes>[0];

    await expect(
      storeAttributes(client, 'KIT_VERSION', 'entity-x', {
        region: ['NA', 'EU'],
      })
    ).rejects.toThrow("Attribute 'region' does not accept multiple values.");
  });

  it('throws when boolean attribute provides multiple values', async () => {
    const client = {
      attributeDefinition: {
        findUnique: jest.fn().mockResolvedValue({
          id: 'approved-id',
          datatype: AttributeDatatype.BOOL,
          isMulti: true,
          unitDimensionId: null,
        }),
        create: jest.fn(),
      },
      unit: {
        findFirst: jest.fn(),
      },
      attributeTextValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeIntValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeBoolValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeNumericValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeDecimalValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
    } as unknown as Parameters<typeof storeAttributes>[0];

    await expect(
      storeAttributes(client, 'KIT_VERSION', 'entity-y', {
        approved: [true, false],
      })
    ).rejects.toThrow("Attribute 'approved' does not support multiple boolean values.");
  });

  it('throws when numeric attribute is missing a unit and no dimension is required', async () => {
    const client = {
      attributeDefinition: {
        findUnique: jest.fn().mockResolvedValue({
          id: 'throughput-id',
          datatype: AttributeDatatype.NUM,
          isMulti: false,
          unitDimensionId: null,
        }),
        create: jest.fn(),
      },
      unit: {
        findFirst: jest.fn().mockResolvedValue(null),
      },
      attributeTextValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeIntValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeBoolValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeNumericValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeDecimalValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
    } as unknown as Parameters<typeof storeAttributes>[0];

    await expect(
      storeAttributes(client, 'KIT_VERSION', 'entity-z', {
        throughput: { value: 250, unit: undefined },
      })
    ).rejects.toThrow("Attribute 'throughput' requires a unit.");
  });

  it('stores and loads multi-value TEXT attributes correctly', async () => {
    const attributeTextCreate = jest.fn().mockResolvedValue(undefined);
    const textFindMany = jest.fn().mockResolvedValue([
      {
        attrDefId: 'projectType-id',
        entityType: 'STANDARD_VERSION',
        entityId: 'standard-1',
        ord: 1,
        value: 'Build-to-suit',
        attrDef: {
          id: 'projectType-id',
          name: 'projectType',
          datatype: AttributeDatatype.TEXT,
          isMulti: true,
        },
      },
      {
        attrDefId: 'projectType-id',
        entityType: 'STANDARD_VERSION',
        entityId: 'standard-1',
        ord: 2,
        value: 'Retrofit',
        attrDef: {
          id: 'projectType-id',
          name: 'projectType',
          datatype: AttributeDatatype.TEXT,
          isMulti: true,
        },
      },
    ]);

    const client = {
      attributeDefinition: {
        findUnique: jest.fn().mockResolvedValue({
          id: 'projectType-id',
          name: 'projectType',
          datatype: AttributeDatatype.TEXT,
          isMulti: true,
          unitDimensionId: null,
        }),
        create: jest.fn(),
      },
      unit: {
        findFirst: jest.fn(),
      },
      attributeTextValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: attributeTextCreate,
        findMany: textFindMany,
      },
      attributeIntValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn().mockResolvedValue([]),
      },
      attributeBoolValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn().mockResolvedValue([]),
      },
      attributeNumericValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn().mockResolvedValue([]),
      },
      attributeDecimalValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn().mockResolvedValue([]),
      },
    } as unknown as Parameters<typeof storeAttributes>[0];

    // Store multi-value projectType
    await storeAttributes(client, 'STANDARD_VERSION', 'standard-1', {
      projectType: ['Build-to-suit', 'Retrofit'],
    });

    // Verify multiple TEXT values were stored with correct ord values
    expect(attributeTextCreate).toHaveBeenCalledTimes(2);
    expect(attributeTextCreate).toHaveBeenNthCalledWith(1, {
      data: {
        entityType: 'STANDARD_VERSION',
        entityId: 'standard-1',
        attrDefId: 'projectType-id',
        ord: 1,
        value: 'Build-to-suit',
      },
    });
    expect(attributeTextCreate).toHaveBeenNthCalledWith(2, {
      data: {
        entityType: 'STANDARD_VERSION',
        entityId: 'standard-1',
        attrDefId: 'projectType-id',
        ord: 2,
        value: 'Retrofit',
      },
    });

    // Load and verify attributes are returned as an array
    const loaded = await loadAttributes(client, 'standard-1');
    expect(loaded).toEqual({
      projectType: ['Build-to-suit', 'Retrofit'],
    });
    expect(Array.isArray(loaded.projectType)).toBe(true);
    expect(loaded.projectType).toHaveLength(2);
  });

  it('rejects multi-value input for single-value attributes', async () => {
    const client = {
      attributeDefinition: {
        findUnique: jest.fn().mockResolvedValue({
          id: 'region-id',
          name: 'region',
          datatype: AttributeDatatype.TEXT,
          isMulti: false, // Single value only
          unitDimensionId: null,
        }),
        create: jest.fn(),
      },
      unit: {
        findFirst: jest.fn(),
      },
      attributeTextValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeIntValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeBoolValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeNumericValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
      attributeDecimalValue: {
        deleteMany: jest.fn().mockResolvedValue(undefined),
        create: jest.fn(),
        findMany: jest.fn(),
      },
    } as unknown as Parameters<typeof storeAttributes>[0];

    // Attempt to store multiple values for a single-value attribute
    await expect(
      storeAttributes(client, 'STANDARD_VERSION', 'standard-2', {
        region: ['NA', 'EU'], // Multiple values for single-value attribute
      })
    ).rejects.toThrow("Attribute 'region' does not accept multiple values.");
  });
});
