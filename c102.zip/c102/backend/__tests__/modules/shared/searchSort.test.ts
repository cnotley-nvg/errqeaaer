import { sortEntities } from '../../../modules/shared/searchSort';

interface TestEntity {
  name?: string | null;
  desc?: string | null;
  description?: string | null;
  accProjectId?: string | null;
  createdAt: string;
  updatedAt: string;
  latestVersion?: { attributes?: Record<string, unknown> | null } | null;
}

const buildEntity = (overrides: Partial<TestEntity> = {}): TestEntity => ({
  name: overrides.name ?? null,
  desc: overrides.desc ?? null,
  description: overrides.description ?? null,
  accProjectId: overrides.accProjectId ?? null,
  createdAt: overrides.createdAt ?? '2024-01-01T00:00:00Z',
  updatedAt: overrides.updatedAt ?? '2024-01-02T00:00:00Z',
  latestVersion: overrides.latestVersion ?? {
    attributes: {},
  },
});

describe('sortEntities', () => {
  it('sorts by name ascending', () => {
    const alpha = buildEntity({ name: 'Alpha' });
    const beta = buildEntity({ name: 'Beta' });

    const result = sortEntities([beta, alpha], {
      orderBy: 'name',
      orderDesc: false,
    } as never);

    expect(result[0]?.name).toBe('Alpha');
    expect(result[1]?.name).toBe('Beta');
  });

  it('sorts by updatedAt ascending for base fields', () => {
    const older = buildEntity({
      updatedAt: '2024-01-01T00:00:00Z',
    });
    const newer = buildEntity({
      updatedAt: '2024-02-01T00:00:00Z',
    });

    const result = sortEntities([older, newer], {
      orderBy: 'updatedAt',
      orderDesc: false,
    } as never);

    expect(result[0]?.updatedAt).toBe('2024-01-01T00:00:00Z');
    expect(result[1]?.updatedAt).toBe('2024-02-01T00:00:00Z');
  });

  it('sorts numerically by attribute throughput when provided as numeric object', () => {
    const slow = buildEntity({
      latestVersion: {
        attributes: { throughput: { value: 100, unit: 'cph' } },
      },
    });
    const fast = buildEntity({
      latestVersion: {
        attributes: { throughput: { value: 250, unit: 'cph' } },
      },
    });

    const result = sortEntities([slow, fast], {
      orderBy: 'throughput',
      orderDesc: true,
    } as never);

    const topThroughput = (
      result[0]?.latestVersion?.attributes as { throughput?: { value: number } }
    )?.throughput?.value;

    expect(topThroughput).toBe(250);
  });

  it('sorts alphabetically by attribute region', () => {
    const west = buildEntity({
      latestVersion: {
        attributes: { region: 'west' },
      },
    });
    const east = buildEntity({
      latestVersion: {
        attributes: { region: 'east' },
      },
    });

    const result = sortEntities([west, east], {
      orderBy: 'region',
      orderDesc: false,
    } as never);

    const firstRegion = (result[0]?.latestVersion?.attributes as { region?: string })?.region;
    expect(firstRegion).toBe('east');
  });

  it('sorts by project id for base field accProjectId', () => {
    const a = buildEntity({ accProjectId: 'proj-a' });
    const b = buildEntity({ accProjectId: 'proj-b' });

    const result = sortEntities([b, a], {
      orderBy: 'accProjectId',
      orderDesc: false,
    } as never);

    expect(result[0]?.accProjectId).toBe('proj-a');
    expect(result[1]?.accProjectId).toBe('proj-b');
  });

  it('sorts region attribute in descending order (orderDesc=true)', () => {
    const west = buildEntity({
      latestVersion: {
        attributes: { region: 'west' },
      },
    });
    const east = buildEntity({
      latestVersion: {
        attributes: { region: 'east' },
      },
    });

    const result = sortEntities([east, west], {
      orderBy: 'region',
      orderDesc: true,
    } as never);

    const firstRegionDesc = (result[0]?.latestVersion?.attributes as { region?: string })?.region;
    expect(firstRegionDesc).toBe('west');
  });

  it('sorts by createdAt with orderDesc=true (includes both timestamps)', () => {
    const older = buildEntity({
      createdAt: '2024-01-01T00:00:00Z',
    });
    const newer = buildEntity({
      createdAt: '2024-02-01T00:00:00Z',
    });

    const result = sortEntities([older, newer], {
      orderBy: 'createdAt',
      orderDesc: true,
    } as never);

    const timestamps = result.map((e) => e.createdAt).sort();
    expect(timestamps).toEqual(['2024-01-01T00:00:00Z', '2024-02-01T00:00:00Z']);
  });
});
