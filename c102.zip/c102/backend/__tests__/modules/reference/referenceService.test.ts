import { createReferenceService } from '../../../modules/reference/domain/referenceService';
import type { Logger } from '../../../shared';

jest.mock('../../../lib/prisma', () => ({
  prisma: {
    attributeDefinition: {
      findMany: jest.fn(),
    },
    unit: {
      findMany: jest.fn(),
    },
  },
}));

const { prisma } = require('../../../lib/prisma') as {
  prisma: {
    attributeDefinition: { findMany: jest.Mock };
    unit: { findMany: jest.Mock };
  };
};

const attrDefFindMany = prisma.attributeDefinition.findMany;
const unitFindMany = prisma.unit.findMany;

const createMockLogger = (): jest.Mocked<Logger> => {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;

  logger.child.mockReturnValue(logger);
  return logger;
};

describe('referenceService metadata exposure', () => {
  const service = createReferenceService(createMockLogger());

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('maps attribute definitions with unit dimensions and datatype', async () => {
    attrDefFindMany.mockResolvedValue([
      {
        id: 'attr-1',
        name: 'throughput',
        description: 'Nominal throughput',
        datatype: 'NUM',
        unitDimensionId: 'dim-1',
        isRequired: false,
        isMulti: false,
        unitDimension: {
          id: 'dim-1',
          code: 'THROUGHPUT',
        },
      },
    ]);

    const attrDefs = await service.listAttrDefs();

    expect(attrDefFindMany).toHaveBeenCalledWith({
      orderBy: { name: 'asc' },
      include: { unitDimension: true },
    });
    expect(attrDefs).toEqual([
      {
        id: 'attr-1',
        name: 'throughput',
        description: 'Nominal throughput',
        datatype: 'NUMERIC',
        unitDimensionId: 'dim-1',
        unitDimension: { id: 'dim-1', code: 'THROUGHPUT' },
        isRequired: false,
        isMulti: false,
      },
    ]);
  });

  it('maps units with conversion metadata', async () => {
    unitFindMany.mockResolvedValue([
      {
        id: 'unit-1',
        unitDimensionId: 'dim-1',
        code: 'Mbps',
        symbol: 'Mbps',
        factorToSi: '1000000',
        offsetToSi: '0',
        unitDimension: {
          id: 'dim-1',
          code: 'THROUGHPUT',
        },
      },
    ]);

    const units = await service.listUnits();

    expect(unitFindMany).toHaveBeenCalledWith({
      orderBy: { code: 'asc' },
      include: { unitDimension: true },
    });
    expect(units).toEqual([
      {
        id: 'unit-1',
        code: 'Mbps',
        symbol: 'Mbps',
        factorToSi: 1000000,
        offsetToSi: 0,
        unitDimension: { id: 'dim-1', code: 'THROUGHPUT' },
      },
    ]);
  });
});
