import { createReferenceModule } from '../../../modules/reference';
import type { Logger } from '../../../shared';
import { createReferenceService } from '../../../modules/reference/domain/referenceService';
import { createReferenceResolvers } from '../../../modules/reference/graphql/resolvers';

jest.mock('../../../modules/reference/domain/referenceService', () => ({
  createReferenceService: jest.fn(),
}));

jest.mock('../../../modules/reference/graphql/resolvers', () => ({
  createReferenceResolvers: jest.fn(),
}));

const mockedCreateReferenceService = createReferenceService as jest.MockedFunction<
  typeof createReferenceService
>;
const mockedCreateReferenceResolvers = createReferenceResolvers as jest.MockedFunction<
  typeof createReferenceResolvers
>;

const createMockLogger = (): jest.Mocked<Logger> => {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;

  logger.child.mockReturnValue(logger);
  return logger;
};

describe('createReferenceModule', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('creates reference module services and resolvers', () => {
    const service = { listReferences: jest.fn() } as any;
    const resolvers = { Query: {} } as any;
    mockedCreateReferenceService.mockReturnValue(service);
    mockedCreateReferenceResolvers.mockReturnValue(resolvers);

    const moduleLogger = createMockLogger();
    const rootLogger = createMockLogger();
    rootLogger.child.mockReturnValue(moduleLogger);

    const module = createReferenceModule({ logger: rootLogger });

    expect(rootLogger.child).toHaveBeenCalledWith({ module: 'reference-data' });
    expect(moduleLogger.child).toHaveBeenCalledWith({ component: 'service' });
    expect(mockedCreateReferenceResolvers).toHaveBeenCalledWith({ referenceService: service });
    expect(module).toEqual({ resolvers, service });
  });
});
