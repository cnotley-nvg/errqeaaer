import { createReferenceResolvers } from '../../../modules/reference/graphql/resolvers';

describe('createReferenceResolvers', () => {
  const referenceService = {
    listAttrDefs: jest.fn().mockResolvedValue(['attr-a', 'attr-b']),
    listUnits: jest.fn().mockResolvedValue(['unit-a']),
  } as const;

  const resolvers = createReferenceResolvers({ referenceService: referenceService as any });

  it('attrDefs delegates to referenceService.listAttrDefs', async () => {
    await expect(resolvers.Query.attrDefs()).resolves.toEqual(['attr-a', 'attr-b']);
    expect(referenceService.listAttrDefs).toHaveBeenCalled();
  });

  it('units delegates to referenceService.listUnits', async () => {
    await expect(resolvers.Query.units()).resolves.toEqual(['unit-a']);
    expect(referenceService.listUnits).toHaveBeenCalled();
  });
});
