import { createEventsResolvers } from '../../../modules/events/graphql/resolvers';
import { EventsService } from '../../../modules/events/domain/eventsService';
import { createSystemEvent } from '../../../modules/events/domain/eventsMutations';
import type { Logger } from '../../../shared';
import type { PrismaClient, SystemEvent } from '@amzn/global-realty-mosaic-prisma-client';
import type { CreateSystemEventInput } from '@amzn/global-realty-mosaic-graphql-schema';

jest.mock('../../../modules/events/domain/eventsService');
jest.mock('../../../modules/events/domain/eventsMutations');

const mockPrisma = {} as PrismaClient;
const mockLogger = {
  error: jest.fn(),
  child: jest.fn(() => mockLogger),
} as unknown as Logger;

describe('Events Resolvers', () => {
  let resolvers: ReturnType<typeof createEventsResolvers>;
  let mockService: jest.Mocked<EventsService>;

  beforeEach(() => {
    mockService = {
      searchSystemEvents: jest.fn(),
      getSystemEvent: jest.fn(),
    } as any;

    (EventsService as jest.Mock).mockImplementation(() => mockService);
    resolvers = createEventsResolvers(mockPrisma, mockLogger);
    jest.clearAllMocks();
  });

  describe('Query.searchSystemEvents', () => {
    it('should return paginated system events', async () => {
      const mockEvents: SystemEvent[] = [
        {
          id: '1',
          type: 'SYSTEM',
          message: 'Test event',
          details: {},
          status: 'NEW',
          createdBy: 'testuser',
          createdAt: new Date(),
        },
      ];

      mockService.searchSystemEvents.mockResolvedValue({
        items: mockEvents,
        total: 1,
      });

      const result = await resolvers.Query.searchSystemEvents(null, {});

      expect(result).toEqual({
        items: [
          expect.objectContaining({
            id: '1',
            type: 'SYSTEM',
            message: 'Test event',
            details: {},
            status: 'NEW',
            createdBy: 'testuser',
            createdAt: expect.any(String),
          }),
        ],
        total: 1,
        pageIdx: 0,
        limit: 10,
        hasNext: false,
      });
    });

    it('should handle pagination correctly', async () => {
      const filter = { pageIdx: 1, limit: 5 };

      mockService.searchSystemEvents.mockResolvedValue({
        items: [],
        total: 15,
      });

      const result = await resolvers.Query.searchSystemEvents(null, { filter });

      expect(result.hasNext).toBe(true);
      expect(result.pageIdx).toBe(1);
      expect(result.limit).toBe(5);
    });
  });

  describe('Query.systemEvent', () => {
    it('should return system event by id', async () => {
      const mockEvent: SystemEvent = {
        id: '1',
        type: 'SYSTEM',
        message: 'Test event',
        details: {},
        status: 'NEW',
        createdBy: 'admin',
        createdAt: new Date(),
      };

      mockService.getSystemEvent.mockResolvedValue(mockEvent);

      const result = await resolvers.Query.systemEvent(null, { id: '1' });

      expect(result).toEqual(
        expect.objectContaining({
          id: '1',
          type: 'SYSTEM',
          message: 'Test event',
          details: {},
          status: 'NEW',
          createdBy: 'admin',
          createdAt: expect.any(String),
        })
      );
      expect(mockService.getSystemEvent).toHaveBeenCalledWith('1');
    });

    it('should return null if event not found', async () => {
      mockService.getSystemEvent.mockResolvedValue(null);

      const result = await resolvers.Query.systemEvent(null, { id: 'nonexistent' });

      expect(result).toBeNull();
    });
  });

  describe('Mutation.createSystemEvent', () => {
    it('should create system event successfully', async () => {
      const input: CreateSystemEventInput = {
        type: 'SYSTEM',
        message: 'New event',
        details: { source: 'test' },
      };

      const mockCreatedEvent: SystemEvent = {
        id: '1',
        type: 'SYSTEM',
        message: 'New event',
        details: { source: 'test' },
        status: 'NEW',
        createdBy: null,
        createdAt: new Date(),
      };

      (createSystemEvent as jest.Mock).mockResolvedValue(mockCreatedEvent);

      const result = await resolvers.Mutation.createSystemEvent(null, { input });

      expect(result).toEqual({
        success: true,
        message: 'System event created successfully',
        systemEvent: expect.objectContaining({
          id: '1',
          type: 'SYSTEM',
          message: 'New event',
          details: { source: 'test' },
          status: 'NEW',
          createdBy: null,
          createdAt: expect.any(String),
        }),
      });
      expect(createSystemEvent).toHaveBeenCalledWith(mockPrisma, input, mockLogger);
    });

    it('should handle creation errors', async () => {
      const input: CreateSystemEventInput = {
        type: 'SYSTEM',
        message: 'New event',
      };

      const error = new Error('Database error');
      (createSystemEvent as jest.Mock).mockRejectedValue(error);

      const result = await resolvers.Mutation.createSystemEvent(null, { input });

      expect(result).toEqual({
        success: false,
        message: 'Database error',
        systemEvent: null,
      });
      expect(mockLogger.error).toHaveBeenCalledWith('Failed to create system event', {
        error,
        input,
      });
    });
  });
});
