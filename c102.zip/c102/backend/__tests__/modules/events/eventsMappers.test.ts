import { mapSystemEventToGraphQL } from '../../../modules/events/domain/eventsMappers';
import type { SystemEvent as PrismaSystemEvent } from '@amzn/global-realty-mosaic-prisma-client';

describe('eventsMappers', () => {
  describe('mapSystemEventToGraphQL', () => {
    it('should map Prisma SystemEvent to GraphQL SystemEvent', () => {
      const prismaEvent: PrismaSystemEvent = {
        id: '1',
        type: 'SYSTEM',
        message: 'Test system event',
        details: { source: 'test', priority: 'high' },
        status: 'NEW',
        createdBy: 'testuser',
        createdAt: new Date('2023-12-10T10:00:00Z'),
      };

      const result = mapSystemEventToGraphQL(prismaEvent);

      expect(result).toEqual({
        id: '1',
        type: 'SYSTEM',
        message: 'Test system event',
        details: { source: 'test', priority: 'high' },
        status: 'NEW',
        createdBy: 'testuser',
        createdAt: '2023-12-10T10:00:00.000Z',
      });
    });

    it('should handle empty details object', () => {
      const prismaEvent: PrismaSystemEvent = {
        id: '2',
        type: 'KIT',
        message: 'Kit event',
        details: {},
        status: 'PUBLISHED',
        createdBy: null,
        createdAt: new Date('2023-12-10T15:30:00Z'),
      };

      const result = mapSystemEventToGraphQL(prismaEvent);

      expect(result).toEqual({
        id: '2',
        type: 'KIT',
        message: 'Kit event',
        details: {},
        status: 'PUBLISHED',
        createdBy: null,
        createdAt: '2023-12-10T15:30:00.000Z',
      });
    });

    it('should handle different event types and statuses', () => {
      const testCases = [
        { type: 'TEMPLATE', status: 'UPDATED' },
        { type: 'STANDARD', status: 'CHANGE' },
      ];

      testCases.forEach(({ type, status }) => {
        const prismaEvent: PrismaSystemEvent = {
          id: `test-${type}`,
          type: type as any,
          message: `${type} event`,
          details: { type },
          status: status as any,
          createdBy: 'admin',
          createdAt: new Date('2023-12-10T12:00:00Z'),
        };

        const result = mapSystemEventToGraphQL(prismaEvent);

        expect(result.type).toBe(type);
        expect(result.status).toBe(status);
        expect(result.createdBy).toBe('admin');
      });
    });
  });
});
