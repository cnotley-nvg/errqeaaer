import { createEventsModule } from '../../../modules/events';
import type { Logger } from '../../../shared';

const mockLogger = {
  info: jest.fn(),
  warn: jest.fn(),
  error: jest.fn(),
  debug: jest.fn(),
  child: jest.fn(() => mockLogger),
} as unknown as Logger;

describe('Events Module', () => {
  it('should create events module with resolvers', () => {
    const module = createEventsModule({ logger: mockLogger });

    expect(module).toHaveProperty('resolvers');
    expect(module.resolvers).toHaveProperty('Query');
    expect(module.resolvers).toHaveProperty('Mutation');
    expect(module.resolvers.Query).toHaveProperty('searchSystemEvents');
    expect(module.resolvers.Query).toHaveProperty('systemEvent');
    expect(module.resolvers.Mutation).toHaveProperty('createSystemEvent');
  });

  it('should create child loggers correctly', () => {
    createEventsModule({ logger: mockLogger });

    expect(mockLogger.child).toHaveBeenCalledWith({ module: 'events' });
  });
});
