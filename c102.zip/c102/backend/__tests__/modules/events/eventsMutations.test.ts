import { createSystemEvent } from '../../../modules/events/domain/eventsMutations';
import type { Logger } from '../../../shared';
import type { PrismaClient, SystemEvent } from '@amzn/global-realty-mosaic-prisma-client';
import type { CreateSystemEventInput } from '@amzn/global-realty-mosaic-graphql-schema';

const mockPrisma = {
  systemEvent: {
    create: jest.fn(),
  },
} as unknown as PrismaClient;

const mockLogger = {
  info: jest.fn(),
  error: jest.fn(),
  warn: jest.fn(),
  debug: jest.fn(),
  child: jest.fn(() => mockLogger),
} as unknown as Logger;

describe('eventsMutations', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('createSystemEvent', () => {
    it('should create a system event successfully', async () => {
      const input: CreateSystemEventInput = {
        type: 'SYSTEM',
        message: 'Test event created',
        details: { source: 'test' },
        status: 'NEW',
      };

      const mockCreatedEvent: SystemEvent = {
        id: '1',
        type: 'SYSTEM',
        message: 'Test event created',
        details: { source: 'test' },
        status: 'NEW',
        createdBy: null,
        createdAt: new Date(),
      };

      (mockPrisma.systemEvent.create as jest.Mock).mockResolvedValue(mockCreatedEvent);

      const result = await createSystemEvent(mockPrisma, input, mockLogger);

      expect(result).toEqual(mockCreatedEvent);
      expect(mockPrisma.systemEvent.create).toHaveBeenCalledWith({
        data: {
          type: input.type,
          message: input.message,
          details: input.details,
        },
      });
      expect(mockLogger.info).toHaveBeenCalledWith('Creating system event', {
        type: input.type,
        message: input.message,
      });
    });

    it('should use default status if not provided', async () => {
      const input: CreateSystemEventInput = {
        type: 'KIT',
        message: 'Kit event',
      };

      const mockCreatedEvent: SystemEvent = {
        id: '2',
        type: 'KIT',
        message: 'Kit event',
        details: {},
        status: 'NEW',
        createdBy: null,
        createdAt: new Date(),
      };

      (mockPrisma.systemEvent.create as jest.Mock).mockResolvedValue(mockCreatedEvent);

      await createSystemEvent(mockPrisma, input, mockLogger);

      expect(mockPrisma.systemEvent.create).toHaveBeenCalledWith({
        data: {
          type: input.type,
          message: input.message,
          details: {},
        },
      });
    });

    it('should handle database errors', async () => {
      const input: CreateSystemEventInput = {
        type: 'SYSTEM',
        message: 'Test event',
      };

      const dbError = new Error('Database connection failed');
      (mockPrisma.systemEvent.create as jest.Mock).mockRejectedValue(dbError);

      await expect(createSystemEvent(mockPrisma, input, mockLogger)).rejects.toThrow(dbError);
    });
  });
});
