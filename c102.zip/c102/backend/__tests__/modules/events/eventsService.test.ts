import { EventsService } from '../../../modules/events/domain/eventsService';
import type { Logger } from '../../../shared';
import type { PrismaClient, SystemEvent } from '@amzn/global-realty-mosaic-prisma-client';

const mockPrisma = {
  systemEvent: {
    count: jest.fn(),
    findMany: jest.fn(),
    findUnique: jest.fn(),
    create: jest.fn(),
  },
  $queryRaw: jest.fn(),
  $queryRawUnsafe: jest.fn(),
} as unknown as PrismaClient;

const mockLogger = {
  info: jest.fn(),
  error: jest.fn(),
  warn: jest.fn(),
  debug: jest.fn(),
  child: jest.fn(() => mockLogger),
} as unknown as Logger;

describe('EventsService', () => {
  let service: EventsService;

  beforeEach(() => {
    service = new EventsService(mockPrisma, mockLogger);
    jest.clearAllMocks();
  });

  describe('searchSystemEvents', () => {
    it('should return paginated system events', async () => {
      const mockEvents: SystemEvent[] = [
        {
          id: '1',
          type: 'SYSTEM',
          message: 'Test event',
          details: {},
          status: 'NEW',
          createdBy: 'testuser',
          createdAt: new Date(),
        },
      ];

      (mockPrisma.systemEvent.findMany as jest.Mock).mockResolvedValue(mockEvents);
      (mockPrisma.systemEvent.count as jest.Mock).mockResolvedValue(1);

      const result = await service.searchSystemEvents({});

      expect(result.items).toEqual(mockEvents);
      expect(result.total).toBe(1);
      expect(mockPrisma.systemEvent.findMany).toHaveBeenCalled();
      expect(mockPrisma.systemEvent.count).toHaveBeenCalled();
    });

    it('should apply filters correctly', async () => {
      const filter = {
        searchTerm: 'test',
        limit: 5,
        pageIdx: 1,
      };

      const mockItems = [
        {
          id: '1',
          type: 'SYSTEM',
          message: 'Test event',
          details: {},
          status: 'NEW',
          createdBy: 'admin',
          createdAt: new Date(),
        },
      ];

      (mockPrisma.$queryRawUnsafe as jest.Mock).mockResolvedValue(mockItems);
      (mockPrisma.$queryRaw as jest.Mock).mockResolvedValue([{ count: BigInt(1) }]);

      const result = await service.searchSystemEvents({ filter });

      expect(result.items).toEqual(mockItems);
      expect(result.total).toBe(1);
      expect(mockPrisma.$queryRawUnsafe).toHaveBeenCalledTimes(1);
      expect(mockPrisma.$queryRaw).toHaveBeenCalledTimes(1);
    });
  });

  describe('getSystemEvent', () => {
    it('should return system event by id', async () => {
      const mockEvent: SystemEvent = {
        id: '1',
        type: 'SYSTEM',
        message: 'Test event',
        details: {},
        status: 'NEW',
        createdBy: 'user123',
        createdAt: new Date(),
      };

      (mockPrisma.systemEvent.findUnique as jest.Mock).mockResolvedValue(mockEvent);

      const result = await service.getSystemEvent('1');

      expect(result).toEqual(mockEvent);
      expect(mockPrisma.systemEvent.findUnique).toHaveBeenCalledWith({
        where: { id: '1' },
      });
    });

    it('should return null if event not found', async () => {
      (mockPrisma.systemEvent.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await service.getSystemEvent('nonexistent');

      expect(result).toBeNull();
    });
  });
});
