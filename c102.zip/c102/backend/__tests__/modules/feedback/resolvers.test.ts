import { createFeedbackResolvers } from '../../../modules/feedback/graphql/resolvers';
import type { Logger } from '../../../shared';
import type { AuthenticatedUser } from '../../../lib/auth';
import type { SubmitFeedbackInput } from '@amzn/global-realty-mosaic-graphql-schema';
import * as feedbackService from '../../../modules/feedback/domain/feedbackService';

jest.mock('../../../modules/feedback/domain/feedbackService');

const mockLogger = {
  info: jest.fn(),
  error: jest.fn(),
  warn: jest.fn(),
  debug: jest.fn(),
} as unknown as Logger;

const mockUser: AuthenticatedUser = {
  username: 'testuser',
  email: 'test@example.com',
  name: 'Test User',
  givenName: 'Test',
  familyName: 'User',
  groups: ['test-group'],
  expiresAt: new Date(),
  issuedAt: new Date(),
  warning: null,
};

const mockInput: SubmitFeedbackInput = {
  feedbackType: 'Bug Report',
  issueType: 'UI Issue',
  description: 'Test description',
};

describe('Feedback Resolvers', () => {
  const resolvers = createFeedbackResolvers(mockLogger);
  const mockSubmitFeedback = jest.mocked(feedbackService.submitFeedback);

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('submitFeedback mutation', () => {
    it('should call feedbackService with correct parameters', async () => {
      const expectedResponse = {
        success: true,
        message: 'Feedback submitted successfully. Ticket ID: TICKET-123',
      };
      mockSubmitFeedback.mockResolvedValue(expectedResponse);

      const context = { user: mockUser, logger: mockLogger };
      const result = await resolvers.Mutation.submitFeedback({}, { input: mockInput }, context);

      expect(mockSubmitFeedback).toHaveBeenCalledWith(mockInput, mockUser, mockLogger);
      expect(result).toEqual(expectedResponse);
    });

    it('should handle null user context', async () => {
      const expectedResponse = {
        success: false,
        message: 'Authentication required to submit feedback.',
      };
      mockSubmitFeedback.mockResolvedValue(expectedResponse);

      const context = { user: null, logger: mockLogger };
      const result = await resolvers.Mutation.submitFeedback({}, { input: mockInput }, context);

      expect(mockSubmitFeedback).toHaveBeenCalledWith(mockInput, null, mockLogger);
      expect(result).toEqual(expectedResponse);
    });

    it('should propagate service errors', async () => {
      const error = new Error('Service error');
      mockSubmitFeedback.mockRejectedValue(error);

      const context = { user: mockUser, logger: mockLogger };

      await expect(
        resolvers.Mutation.submitFeedback({}, { input: mockInput }, context)
      ).rejects.toThrow('Service error');
    });
  });
});
