import { createFeedbackModule } from '../../../modules/feedback';
import type { Logger } from '../../../shared';

const mockLogger = {
  info: jest.fn(),
  error: jest.fn(),
  warn: jest.fn(),
  child: jest.fn(() => mockLogger),
} as unknown as Logger;

describe('Feedback Module', () => {
  it('should create feedback module with resolvers', () => {
    const module = createFeedbackModule({ logger: mockLogger });

    expect(module).toHaveProperty('resolvers');
    expect(module.resolvers).toHaveProperty('Mutation');
    expect(module.resolvers.Mutation).toHaveProperty('submitFeedback');
    expect(typeof module.resolvers.Mutation.submitFeedback).toBe('function');
  });
});
