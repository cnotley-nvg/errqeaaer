import { submitFeedback } from '../../../modules/feedback/domain/feedbackService';
import type { Logger } from '../../../shared';
import type { AuthenticatedUser } from '../../../lib/auth';
import type { SubmitFeedbackInput } from '@amzn/global-realty-mosaic-graphql-schema';
import { Tickety } from '@amzn/tickety-typescript-sdk';

// Mock the Tickety SDK
jest.mock('@amzn/tickety-typescript-sdk');
jest.mock('@aws-sdk/credential-providers');
jest.mock('@aws-sdk/signature-v4-crt');

const mockCreateTicket = jest.fn();
const mockTickety = {
  createTicket: mockCreateTicket,
} as unknown as Tickety;

const mockLogger = {
  info: jest.fn(),
  error: jest.fn(),
  warn: jest.fn(),
  debug: jest.fn(),
} as unknown as Logger;

const mockUser: AuthenticatedUser = {
  username: 'testuser',
  email: 'test@example.com',
  name: 'Test User',
  givenName: 'Test',
  familyName: 'User',
  groups: ['test-group'],
  expiresAt: new Date(),
  issuedAt: new Date(),
  warning: null,
};

const mockInput: SubmitFeedbackInput = {
  feedbackType: 'Bug Report',
  issueType: 'UI Issue',
  description: 'Test description',
};

describe('submitFeedback', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (Tickety as jest.MockedClass<typeof Tickety>).mockImplementation(() => mockTickety);
    process.env.TICKETY_ENDPOINT = 'https://test-endpoint.com';
    process.env.TICKETY_RESOLVER_GROUP = 'test-group';
    process.env.TICKETY_APP_BASEURL = 'https://issues.amazon.com';
  });

  it('should return error when user is not authenticated', async () => {
    const result = await submitFeedback(mockInput, null, mockLogger);

    expect(result).toEqual({
      success: false,
      message: 'Authentication required to submit feedback.',
    });
    expect(mockLogger.warn).toHaveBeenCalledWith(
      'Feedback submission attempted without authenticated user'
    );
    expect(mockCreateTicket).not.toHaveBeenCalled();
  });

  it('should return error when user has no username', async () => {
    const userWithoutUsername = { ...mockUser, username: '' };
    const result = await submitFeedback(mockInput, userWithoutUsername, mockLogger);

    expect(result).toEqual({
      success: false,
      message: 'Authentication required to submit feedback.',
    });
    expect(mockLogger.warn).toHaveBeenCalledWith(
      'Feedback submission attempted without authenticated user'
    );
  });

  it('should successfully create ticket when user is authenticated', async () => {
    mockCreateTicket.mockResolvedValue({ id: 'TICKET-123' });

    const result = await submitFeedback(mockInput, mockUser, mockLogger);

    expect(result).toEqual({
      success: true,
      message: 'Feedback submitted!',
      ticketUrl: 'https://issues.amazon.com/TICKET-123',
    });
    expect(mockCreateTicket).toHaveBeenCalledWith({
      awsAccountId: 'Default',
      ticketingSystemName: 'Default',
      ticket: {
        title: 'User Feedback: Bug Report - UI Issue',
        description: 'Test description',
        severity: 'SEV_5',
        requester: { namespace: 'MIDWAY', value: 'testuser' },
        assignedGroup: { namespace: 'RESOLVER_GROUP', value: 'test-group' },
      },
    });
    expect(mockLogger.info).toHaveBeenCalledWith('Tickety ticket created successfully', {
      ticketId: 'TICKET-123',
    });
  });

  it('should handle Tickety API errors gracefully', async () => {
    const error = new Error('Tickety API error');
    mockCreateTicket.mockRejectedValue(error);

    const result = await submitFeedback(mockInput, mockUser, mockLogger);

    expect(result).toEqual({
      success: false,
      message: 'Failed to submit feedback. Please try again.',
    });
    expect(mockLogger.error).toHaveBeenCalledWith('Failed to create Tickety ticket', {
      error: 'Tickety API error',
      stack: error.stack,
      feedbackInput: mockInput,
      requester: 'testuser',
    });
  });

  it('should log feedback submission details', async () => {
    mockCreateTicket.mockResolvedValue({ id: 'TICKET-123' });

    await submitFeedback(mockInput, mockUser, mockLogger);

    expect(mockLogger.info).toHaveBeenCalledWith('Feedback submitted:', {
      feedbackType: 'Bug Report',
      issueType: 'UI Issue',
      description: 'Test description',
      requester: 'testuser',
      timestamp: expect.any(String),
    });
  });
});
