import { createTemplatesResolvers } from '../../../modules/templates/graphql/resolvers';
import type { TemplateService } from '../../../modules/templates/domain/templateService';
import { BatchLoader } from '../../../lib/batchLoader';
import type { GraphqlContext } from '../../../createGraphqlServer';
import type {
  TemplateVersionChange,
  TemplateFile,
} from '@amzn/global-realty-mosaic-graphql-schema';

type MockedTemplateService = jest.Mocked<TemplateService>;

const createMockService = (): MockedTemplateService => ({
  search: jest.fn(),
  searchTemplateVersions: jest.fn(),
  searchLatestTemplateVersions: jest.fn(),
  getTemplate: jest.fn(),
  getTemplateByName: jest.fn(),
  getTemplateVersion: jest.fn(),
  listTemplateVersions: jest.fn(),
  listTemplateVersionChanges: jest.fn(),
  batchLoadTemplateVersionChanges: jest.fn(),
  batchLoadElectricalLoadData: jest.fn(),
  batchLoadTemplateFiles: jest.fn(),
  getTemplateFiles: jest.fn(),
  getTemplateFile: jest.fn(),
  isTemplateNameAvailable: jest.fn(),
  getFilterOptions: jest.fn(),
  createTemplate: jest.fn(),
  updateTemplate: jest.fn(),
  deleteTemplate: jest.fn(),
  createTemplateVersion: jest.fn(),
  updateTemplateVersion: jest.fn(),
  deleteTemplateVersion: jest.fn(),
  setLatestTemplateVersion: jest.fn(),
  addTemplateFile: jest.fn(),
  removeTemplateFile: jest.fn(),
});

const createMockAssetService = () => ({
  generateSignedUrl: jest.fn(),
});

const createMockContext = (templateService: MockedTemplateService): Partial<GraphqlContext> => ({
  logger: {} as any,
  request: {} as any,
  user: null,
  loaders: {
    templateVersionChanges: new BatchLoader<string, TemplateVersionChange[]>(
      async (templateVersionIds) =>
        templateService.batchLoadTemplateVersionChanges(templateVersionIds)
    ),
    electricalLoadData: new BatchLoader<string, any[]>(async (templateVersionIds) =>
      templateService.batchLoadElectricalLoadData(templateVersionIds)
    ),
    templateFiles: new BatchLoader<string, TemplateFile[]>(async (templateVersionIds) =>
      templateService.batchLoadTemplateFiles(templateVersionIds)
    ),
  },
});

const resolversWith = (
  templateService: MockedTemplateService,
  assetService = createMockAssetService()
) => createTemplatesResolvers({ templateService, templateAssetService: assetService as any });

describe('createTemplatesResolvers', () => {
  describe('Query', () => {
    it.each([
      [
        'searchTemplates',
        'search',
        { filter: { pageIdx: 0, limit: 10 } },
        [{ pageIdx: 0, limit: 10 }],
      ],
      [
        'searchTemplateVersions',
        'searchTemplateVersions',
        { templateId: 'tpl-1', filter: { pageIdx: 0, limit: 10 } },
        ['tpl-1', { pageIdx: 0, limit: 10 }],
      ],
      ['template', 'getTemplate', { id: 'tpl-1' }, ['tpl-1']],
      ['templateByName', 'getTemplateByName', { name: 'Template A' }, ['Template A']],
      ['templateVersion', 'getTemplateVersion', { id: 'ver-1' }, ['ver-1']],
      ['templateVersions', 'listTemplateVersions', { templateId: 'tpl-1' }, ['tpl-1']],
      ['templateFiles', 'getTemplateFiles', { templateVersionId: 'ver-1' }, ['ver-1']],
      [
        'templateVersionChanges',
        'listTemplateVersionChanges',
        { templateVersionId: 'ver-1' },
        ['ver-1'],
      ],
      [
        'isTemplateNameAvailable',
        'isTemplateNameAvailable',
        { name: 'Template A' },
        ['Template A'],
      ],
    ] as const)(
      'delegates Query.%s to templateService.%s',
      async (field, method, args, expectedArgs) => {
        const templateService = createMockService();
        const resolvers = resolversWith(templateService);
        const expected = Symbol(field);
        (templateService[method] as jest.Mock).mockResolvedValue(expected);

        const result = await (
          resolvers.Query[field] as (parent: unknown, args: any) => Promise<unknown>
        )(null, args);

        expect(templateService[method]).toHaveBeenCalledWith(...expectedArgs);
        expect(result).toBe(expected);
      }
    );

    describe('templateFileSignedUrl', () => {
      it('returns null when file is not found', async () => {
        const templateService = createMockService();
        const assetService = createMockAssetService();
        templateService.getTemplateFile.mockResolvedValueOnce(null);

        const resolvers = resolversWith(templateService, assetService);

        const result = await resolvers.Query.templateFileSignedUrl(null, {
          templateFileId: 'file-missing',
          disposition: 'ATTACHMENT',
        });

        expect(templateService.getTemplateFile).toHaveBeenCalledWith('file-missing');
        expect(assetService.generateSignedUrl).not.toHaveBeenCalled();
        expect(result).toBeNull();
      });

      it('delegates to assetService.generateSignedUrl with normalized disposition', async () => {
        const templateService = createMockService();
        const assetService = createMockAssetService();

        templateService.getTemplateFile.mockResolvedValueOnce({
          id: 'file-1',
          accFileId: 'acc://123',
          templateVersionId: 'ver-1',
        } as any);
        templateService.getTemplateVersion.mockResolvedValueOnce({
          id: 'ver-1',
          templateId: 'tpl-1',
          accFolderId: 'folder-456',
        } as any);
        templateService.getTemplate.mockResolvedValueOnce({
          id: 'tpl-1',
          accProjectId: 'project-123',
        } as any);
        (assetService.generateSignedUrl as jest.Mock).mockResolvedValueOnce('SIGNED_URL');

        const resolvers = resolversWith(templateService, assetService);

        const resultInline = await resolvers.Query.templateFileSignedUrl(null, {
          templateFileId: 'file-1',
          disposition: 'INLINE',
        });

        expect(assetService.generateSignedUrl).toHaveBeenCalledWith('project-123', 'acc://123', {
          disposition: 'inline',
          filename: 'template-file-file-1.pdf',
        });
        expect(resultInline).toBe('SIGNED_URL');

        (assetService.generateSignedUrl as jest.Mock).mockClear();
        (assetService.generateSignedUrl as jest.Mock).mockResolvedValueOnce('SIGNED_URL_ATTACH');
        // ensure the resolver still sees a valid file on the second call
        templateService.getTemplateFile.mockResolvedValueOnce({
          id: 'file-1',
          accFileId: 'acc://123',
          templateVersionId: 'ver-1',
        } as any);
        templateService.getTemplateVersion.mockResolvedValueOnce({
          id: 'ver-1',
          templateId: 'tpl-1',
          accFolderId: 'folder-456',
        } as any);
        templateService.getTemplate.mockResolvedValueOnce({
          id: 'tpl-1',
          accProjectId: 'project-123',
        } as any);

        const resultAttachment = await resolvers.Query.templateFileSignedUrl(null, {
          templateFileId: 'file-1',
          disposition: 'ATTACHMENT',
        });

        expect(assetService.generateSignedUrl).toHaveBeenCalledWith('project-123', 'acc://123', {
          disposition: 'attachment',
          filename: 'template-file-file-1.pdf',
        });
        expect(resultAttachment).toBe('SIGNED_URL_ATTACH');
      });
    });
  });

  describe('Mutation', () => {
    it.each([
      [
        'createTemplate',
        'createTemplate',
        { input: { name: 'Template A' } },
        [{ name: 'Template A' }],
      ],
      [
        'updateTemplate',
        'updateTemplate',
        { id: 'tpl-1', input: { name: 'New Name' } },
        ['tpl-1', { name: 'New Name' }],
      ],
      ['deleteTemplate', 'deleteTemplate', { id: 'tpl-1' }, ['tpl-1']],
      [
        'createTemplateVersion',
        'createTemplateVersion',
        { templateId: 'tpl-1', input: { version: '1.0.0' } },
        ['tpl-1', { version: '1.0.0' }],
      ],
      [
        'updateTemplateVersion',
        'updateTemplateVersion',
        { id: 'ver-1', input: { version: '2.0.0' } },
        ['ver-1', { version: '2.0.0' }],
      ],
      ['deleteTemplateVersion', 'deleteTemplateVersion', { id: 'ver-1' }, ['ver-1']],
      ['setLatestTemplateVersion', 'setLatestTemplateVersion', { id: 'ver-1' }, ['ver-1']],
      [
        'addTemplateFile',
        'addTemplateFile',
        { templateVersionId: 'ver-1', accFileId: 'file-1' },
        ['ver-1', 'file-1'],
      ],
      ['removeTemplateFile', 'removeTemplateFile', { id: 'file-1' }, ['file-1']],
    ] as const)(
      'delegates Mutation.%s to templateService.%s',
      async (field, method, args, expectedArgs) => {
        const templateService = createMockService();
        const resolvers = resolversWith(templateService);
        const expected = Symbol(field);
        (templateService[method] as jest.Mock).mockResolvedValue(expected);

        const result = await (
          resolvers.Mutation[field] as (parent: unknown, args: any) => Promise<unknown>
        )(null, args);

        expect(templateService[method]).toHaveBeenCalledWith(...expectedArgs);
        expect(result).toBe(expected);
      }
    );
  });

  describe('TemplateVersion field resolvers', () => {
    describe('changes', () => {
      it('returns already loaded changes if present', async () => {
        const templateService = createMockService();
        const resolvers = resolversWith(templateService);
        const context = createMockContext(templateService);

        const existingChanges = [
          {
            id: 'change-1',
            templateVersionId: 'ver-1',
            category: 'Update',
            title: 'Updated feature',
            description: 'Description',
            dci: null,
            dcr: null,
            sheet: null,
            changeInCost: null,
          },
        ];

        const parent = {
          id: 'ver-1',
          templateId: 'tpl-1',
          changes: existingChanges,
        } as any;

        const result = await resolvers.TemplateVersion.changes(
          parent,
          {},
          context as GraphqlContext
        );

        expect(result).toBe(existingChanges);
        expect(templateService.batchLoadTemplateVersionChanges).not.toHaveBeenCalled();
      });

      it('lazy-loads changes using batch loader when not present', async () => {
        const templateService = createMockService();
        const resolvers = resolversWith(templateService);
        const context = createMockContext(templateService);

        const expectedChanges = [
          {
            id: 'change-1',
            templateVersionId: 'ver-1',
            category: 'New Feature',
            title: 'Added functionality',
            description: 'Description',
            dci: null,
            dcr: null,
            sheet: null,
            changeInCost: null,
          },
        ];

        templateService.batchLoadTemplateVersionChanges.mockResolvedValue([expectedChanges]);

        const parent = {
          id: 'ver-1',
          templateId: 'tpl-1',
        } as any;

        const result = await resolvers.TemplateVersion.changes(
          parent,
          {},
          context as GraphqlContext
        );

        expect(result).toEqual(expectedChanges);
      });

      it('returns empty array when no changes exist', async () => {
        const templateService = createMockService();
        const resolvers = resolversWith(templateService);
        const context = createMockContext(templateService);

        templateService.batchLoadTemplateVersionChanges.mockResolvedValue([[]]);

        const parent = {
          id: 'ver-1',
          templateId: 'tpl-1',
        } as any;

        const result = await resolvers.TemplateVersion.changes(
          parent,
          {},
          context as GraphqlContext
        );

        expect(result).toEqual([]);
      });

      it('batches multiple concurrent requests', async () => {
        const templateService = createMockService();
        const resolvers = resolversWith(templateService);
        const context = createMockContext(templateService);

        const changes1 = [
          {
            id: 'change-1',
            templateVersionId: 'ver-1',
            category: 'Update',
            title: 'Title 1',
            description: 'Desc 1',
            dci: null,
            dcr: null,
            sheet: null,
            changeInCost: null,
          },
        ];

        const changes2 = [
          {
            id: 'change-2',
            templateVersionId: 'ver-2',
            category: 'Fix',
            title: 'Title 2',
            description: 'Desc 2',
            dci: null,
            dcr: null,
            sheet: null,
            changeInCost: null,
          },
        ];

        templateService.batchLoadTemplateVersionChanges.mockResolvedValue([changes1, changes2]);

        const parent1 = { id: 'ver-1', templateId: 'tpl-1' } as any;
        const parent2 = { id: 'ver-2', templateId: 'tpl-2' } as any;

        // Make concurrent requests
        const [result1, result2] = await Promise.all([
          resolvers.TemplateVersion.changes(parent1, {}, context as GraphqlContext),
          resolvers.TemplateVersion.changes(parent2, {}, context as GraphqlContext),
        ]);

        expect(result1).toEqual(changes1);
        expect(result2).toEqual(changes2);
        // Should be called once for both requests (batched)
        expect(templateService.batchLoadTemplateVersionChanges).toHaveBeenCalledTimes(1);
        expect(templateService.batchLoadTemplateVersionChanges).toHaveBeenCalledWith([
          'ver-1',
          'ver-2',
        ]);
      });

      it('handles duplicate IDs in batch correctly', async () => {
        const templateService = createMockService();
        const resolvers = resolversWith(templateService);
        const context = createMockContext(templateService);

        const changes = [
          {
            id: 'change-1',
            templateVersionId: 'ver-1',
            category: 'Update',
            title: 'Title',
            description: 'Desc',
            dci: null,
            dcr: null,
            sheet: null,
            changeInCost: null,
          },
        ];

        // Return same changes for both duplicate requests
        templateService.batchLoadTemplateVersionChanges.mockResolvedValue([changes, changes]);

        const parent = { id: 'ver-1', templateId: 'tpl-1' } as any;

        // Make concurrent requests with same ID
        const [result1, result2] = await Promise.all([
          resolvers.TemplateVersion.changes(parent, {}, context as GraphqlContext),
          resolvers.TemplateVersion.changes(parent, {}, context as GraphqlContext),
        ]);

        expect(result1).toEqual(changes);
        expect(result2).toEqual(changes);
        // Should be called once with duplicate IDs
        expect(templateService.batchLoadTemplateVersionChanges).toHaveBeenCalledTimes(1);
        expect(templateService.batchLoadTemplateVersionChanges).toHaveBeenCalledWith([
          'ver-1',
          'ver-1',
        ]);
      });
    });
  });
});
