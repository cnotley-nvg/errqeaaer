import type { FilterInput } from '@amzn/global-realty-mosaic-graphql-schema';

import {
  buildOrderBy,
  buildWhere,
  templateFilterInternals,
} from '../../../modules/templates/domain/templateFilters';

describe('templateFilters', () => {
  const baseFilter: FilterInput = {
    pageIdx: 0,
    limit: 10,
    orderBy: 'createdAt',
    orderDesc: false,
    query: null,
  };

  describe('buildWhere', () => {
    it('combines string and date tokens with AND semantics', () => {
      const filter: FilterInput = {
        ...baseFilter,
        query: {
          operation: 'AND',
          tokenGroups: [
            { propertyKey: 'name', operator: 'CONTAINS', value: 'Template' },
            { propertyKey: 'accProjectId', operator: 'EQUALS', values: ['proj-123', 'proj-456'] },
            {
              propertyKey: 'createdAt',
              operator: 'GREATER_OR_EQUAL',
              value: '2024-05-01T00:00:00.000Z',
            },
          ],
        },
      };

      const where = buildWhere(filter);

      expect(where).toEqual({
        AND: [
          expect.objectContaining({ name: expect.objectContaining({ contains: 'Template' }) }),
          {
            OR: [
              expect.objectContaining({
                accProjectId: expect.objectContaining({ equals: 'proj-123' }),
              }),
              expect.objectContaining({
                accProjectId: expect.objectContaining({ equals: 'proj-456' }),
              }),
            ],
          },
          expect.objectContaining({
            createdAt: expect.objectContaining({ gte: new Date('2024-05-01T00:00:00.000Z') }),
          }),
        ],
      });
    });

    it('returns empty filter when tokens resolve to no conditions', () => {
      const empty = buildWhere({
        ...baseFilter,
        query: {
          operation: 'OR',
          tokenGroups: [
            { propertyKey: 'unknown', operator: 'EQUALS', value: '' },
            { propertyKey: 'name', operator: 'CONTAINS', value: '   ' },
          ],
        },
      });

      expect(empty).toEqual({});
    });
  });

  describe('buildOrderBy', () => {
    it('maps known sortable fields', () => {
      expect(buildOrderBy({ ...baseFilter, orderBy: 'name' })).toEqual({ name: 'asc' });
      expect(buildOrderBy({ ...baseFilter, orderBy: 'updatedAt', orderDesc: true })).toEqual({
        updatedAt: 'desc',
      });
    });

    it('defaults to createdAt desc when orderBy is unknown', () => {
      expect(buildOrderBy({ ...baseFilter, orderBy: 'unknown' as any })).toEqual({
        createdAt: 'desc',
      });
    });
  });

  describe('internals', () => {
    it('parseDateValue rejects invalid input', () => {
      const { parseDateValue } = templateFilterInternals;

      expect(parseDateValue('not-a-date')).toBeNull();
      expect(parseDateValue('2024-05-12T00:00:00.000Z')).toEqual(
        new Date('2024-05-12T00:00:00.000Z')
      );
    });
  });
});
