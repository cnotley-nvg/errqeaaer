import { createTemplateService } from '../../../modules/templates/domain/templateService';
import { loadAttributes, storeAttributes } from '../../../modules/shared/attributeStore';
import type { Logger } from '../../../shared';

jest.mock('../../../modules/shared/attributeStore', () => ({
  loadAttributes: jest.fn(),
  storeAttributes: jest.fn(),
}));

jest.mock('../../../lib/prisma', () => ({
  prisma: {
    template: {
      count: jest.fn(),
      findMany: jest.fn(),
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    templateVersion: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      updateMany: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    templateFile: {
      create: jest.fn(),
      findMany: jest.fn(),
      findUnique: jest.fn(),
      delete: jest.fn(),
    },
    templateVersionChange: {
      findMany: jest.fn(),
    },
    $transaction: jest.fn(),
  },
}));

const { prisma } = require('../../../lib/prisma') as {
  prisma: {
    template: {
      count: jest.Mock;
      findMany: jest.Mock;
      findUnique: jest.Mock;
      create: jest.Mock;
      update: jest.Mock;
      delete: jest.Mock;
    };
    templateVersion: {
      findUnique: jest.Mock;
      findMany: jest.Mock;
      create: jest.Mock;
      updateMany: jest.Mock;
      update: jest.Mock;
      delete: jest.Mock;
    };
    templateFile: {
      create: jest.Mock;
      findMany: jest.Mock;
      findUnique: jest.Mock;
      delete: jest.Mock;
    };
    templateVersionChange: {
      findMany: jest.Mock;
    };
    $transaction: jest.Mock;
  };
};

const mockedLoadAttributes = loadAttributes as jest.MockedFunction<typeof loadAttributes>;
const mockedStoreAttributes = storeAttributes as jest.MockedFunction<typeof storeAttributes>;

const createLogger = (): jest.Mocked<Logger> => {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;

  logger.child.mockReturnValue(logger);
  return logger;
};

const buildTemplate = (id: string) => {
  const createdAt = new Date('2024-03-01T00:00:00Z');
  const updatedAt = new Date('2024-03-02T00:00:00Z');

  return {
    id,
    accProjectId: 'proj-1',
    name: `Template ${id}`,
    description: null,
    createdAt,
    updatedAt,
    versions: [
      {
        id: `${id}-v1`,
        templateId: id,
        accFolderId: 'folder-1',
        brsId: 'brs-1',
        version: '1.0.0',
        isLatest: true,
        createdAt,
        updatedAt,
        template: {
          id,
          accProjectId: 'proj-1',
          name: `Template ${id}`,
          description: null,
          createdAt,
          updatedAt,
        },
        files: [],
      },
    ],
  };
};

const buildTemplateVersionRecord = (templateId: string, versionId = `${templateId}-v1`) => {
  const createdAt = new Date('2024-03-01T00:00:00Z');
  const updatedAt = new Date('2024-03-02T00:00:00Z');

  return {
    id: versionId,
    templateId,
    accFolderId: versionId.includes('-v2') ? 'folder-2' : 'folder-1',
    brsId: versionId.includes('-v2') ? 'brs-2' : 'brs-1',
    version: versionId.includes('-v2') ? '2.0.0' : '1.0.0',
    isLatest: versionId.endsWith('-v1'),
    createdAt,
    updatedAt,
    template: {
      id: templateId,
      accProjectId: 'proj-1',
      name: `Template ${templateId}`,
      description: null,
      createdAt,
      updatedAt,
    },
    files: [],
  };
};

describe('templateService', () => {
  beforeEach(() => {
    jest.clearAllMocks();

    mockedLoadAttributes.mockResolvedValue({});
    mockedStoreAttributes.mockResolvedValue();
    prisma.$transaction.mockImplementation(async (callback) => callback(prisma));
    prisma.templateVersion.updateMany.mockResolvedValue(undefined);
    prisma.templateVersion.findUnique.mockImplementation(async ({ where }) => {
      if (!where?.id) {
        return null;
      }

      const [templateId] = where.id.split('-v');
      return buildTemplateVersionRecord(templateId ?? 'tpl-1', where.id);
    });
  });

  const service = () => createTemplateService(createLogger());

  it('searches templates and returns results', async () => {
    const record = buildTemplate('tpl-1');
    prisma.template.count.mockResolvedValue(1);
    prisma.template.findMany.mockResolvedValue([record]);

    const result = await service().search({ pageIdx: 0, limit: 10 } as never);

    expect(result.total).toBe(1);
    expect(result.items[0]?.id).toBe('tpl-1');
  });

  it('creates a template with an initial version', async () => {
    prisma.template.create.mockResolvedValue({ id: 'tpl-1' });
    prisma.template.findUnique.mockResolvedValue(buildTemplate('tpl-1'));
    prisma.templateVersion.create.mockResolvedValue({ id: 'tpl-1-v1' });

    const result = await service().createTemplate({
      accProjectId: 'proj-1',
      name: 'Template One',
      description: 'Initial',
      initialVersion: {
        accFolderId: 'folder-1',
        brsId: 'brs-1',
        version: '1.0.0',
        files: [],
        attributes: {},
      },
    } as never);

    expect(result.success).toBe(true);
    expect(prisma.template.create).toHaveBeenCalledWith({
      data: {
        accProjectId: 'proj-1',
        name: 'Template One',
        description: 'Initial',
      },
    });
    expect(prisma.templateVersion.create).toHaveBeenCalledWith({
      data: expect.objectContaining({ templateId: 'tpl-1', version: '1.0.0', isLatest: false }),
    });
    expect(mockedStoreAttributes).toHaveBeenCalledWith(
      expect.anything(),
      'TEMPLATE_VERSION',
      'tpl-1-v1',
      {}
    );
  });

  it('loads template detail with latest version', async () => {
    const record = buildTemplate('tpl-1');
    prisma.template.findUnique.mockResolvedValue(record);

    const template = await service().getTemplate('tpl-1');

    expect(template?.id).toBe('tpl-1');
    expect(template?.latestVersion?.version).toBe('1.0.0');
  });

  it('updates template metadata', async () => {
    prisma.template.findUnique
      .mockResolvedValueOnce({ id: 'tpl-1', accProjectId: 'proj-1', name: 'Template One' })
      .mockResolvedValueOnce(buildTemplate('tpl-1'));
    prisma.template.update.mockResolvedValue({ id: 'tpl-1' });

    const result = await service().updateTemplate('tpl-1', {
      name: 'Template Two',
      description: 'Updated desc',
    } as never);

    expect(result.success).toBe(true);
    expect(prisma.template.update).toHaveBeenCalledWith({
      where: { id: 'tpl-1' },
      data: { name: 'Template Two', description: 'Updated desc' },
    });
  });

  it('creates a template version and updates latest flag', async () => {
    prisma.template.findUnique.mockResolvedValue({ id: 'tpl-1' });
    prisma.templateVersion.create.mockResolvedValue({ id: 'tpl-1-v2' });

    const result = await service().createTemplateVersion('tpl-1', {
      accFolderId: 'folder-2',
      brsId: 'brs-2',
      version: '2.0.0',
      files: [{ accFileId: 'file-2' }],
      attributes: { region: 'EU' },
    } as never);

    expect(result.success).toBe(true);
    expect(prisma.templateVersion.create).toHaveBeenCalledWith({
      data: expect.objectContaining({ templateId: 'tpl-1', version: '2.0.0' }),
    });
    expect(prisma.templateVersion.updateMany).toHaveBeenCalledWith({
      data: { isLatest: false },
      where: { templateId: 'tpl-1' },
    });
    expect(mockedStoreAttributes).toHaveBeenCalledWith(
      expect.anything(),
      'TEMPLATE_VERSION',
      'tpl-1-v2',
      { region: 'EU' }
    );
  });

  it('updates template version latest flag (allowed mutation path)', async () => {
    // reset and provide controlled responses that satisfy service invariants
    prisma.templateVersion.findUnique.mockReset();
    prisma.templateVersion.findUnique
      .mockResolvedValueOnce({ templateId: 'tpl-1' }) // first lookup: exists + templateId
      .mockResolvedValueOnce(buildTemplateVersionRecord('tpl-1')); // second lookup for getTemplateVersion

    const result = await service().updateTemplateVersion('tpl-1-v1', {
      isLatest: true,
    } as never);

    expect(result.success).toBe(true);
    expect(prisma.templateVersion.update).toHaveBeenCalledWith({
      where: { id: 'tpl-1-v1' },
      data: { isLatest: true },
    });
    // updateLatestTemplateFlags should drive updateMany to clear other latest flags
    expect(prisma.templateVersion.updateMany).toHaveBeenCalledWith({
      data: { isLatest: false },
      where: { templateId: 'tpl-1' },
    });
  });

  it('adds a template file successfully', async () => {
    prisma.templateVersion.findUnique.mockImplementationOnce(async () => ({ id: 'tpl-1-v1' }));
    prisma.templateFile.create.mockResolvedValue({
      id: 'file-1',
      templateVersionId: 'tpl-1-v1',
      accFileId: 'file-1',
      createdAt: new Date('2024-03-03T00:00:00Z'),
    });

    const result = await service().addTemplateFile('tpl-1-v1', 'file-1');

    expect(result.success).toBe(true);
    expect(prisma.templateFile.create).toHaveBeenCalledWith({
      data: { templateVersionId: 'tpl-1-v1', accFileId: 'file-1' },
    });
  });

  it('fails to add a template file when the version is missing', async () => {
    // ensure first lookup returns null so service bails early
    prisma.templateVersion.findUnique.mockReset();
    prisma.templateVersion.findUnique.mockResolvedValueOnce(null);

    const result = await service().addTemplateFile('missing-version', 'file-1');

    expect(result.success).toBe(false);
    expect(result.message).toContain('Template version not found');
    expect(prisma.templateFile.create).not.toHaveBeenCalled();
  });

  it('removes a template file', async () => {
    prisma.templateFile.findUnique.mockResolvedValue({ id: 'file-1' });
    prisma.templateFile.delete.mockResolvedValue(undefined);

    const result = await service().removeTemplateFile('file-1');

    expect(result.success).toBe(true);
    expect(prisma.templateFile.delete).toHaveBeenCalledWith({ where: { id: 'file-1' } });
  });

  it('checks template name availability with trimmed value', async () => {
    prisma.template.findUnique.mockResolvedValue(null);

    const available = await service().isTemplateNameAvailable('  Template One  ');

    expect(prisma.template.findUnique).toHaveBeenCalledWith({ where: { name: 'Template One' } });
    expect(available).toBe(true);
  });

  it('returns empty template version list when template is missing', async () => {
    prisma.template.findUnique.mockResolvedValueOnce(null);

    const versions = await service().listTemplateVersions('missing-template');

    expect(versions).toEqual([]);
    expect(prisma.templateVersion.findMany).not.toHaveBeenCalled();
  });

  it('lists template versions with attributes for each version', async () => {
    const createdAt = new Date('2024-03-01T00:00:00Z');
    const updatedAt = new Date('2024-03-02T00:00:00Z');
    prisma.template.findUnique.mockResolvedValueOnce({
      id: 'tpl-1',
      accProjectId: 'proj-1',
      name: 'Template tpl-1',
      description: null,
      createdAt,
      updatedAt,
    });
    prisma.templateVersion.findMany.mockResolvedValueOnce([
      {
        ...buildTemplateVersionRecord('tpl-1', 'tpl-1-v2'),
        isLatest: false,
      },
      buildTemplateVersionRecord('tpl-1', 'tpl-1-v1'),
    ]);

    mockedLoadAttributes.mockImplementation(async (_client, entityId) => {
      if (entityId === 'tpl-1-v2') {
        return { generation: 'GEN4' };
      }
      if (entityId === 'tpl-1-v1') {
        return { generation: 'GEN3' };
      }
      return {};
    });

    const versions = await service().listTemplateVersions('tpl-1');

    expect(versions).toHaveLength(2);
    expect(versions[0]?.attributes).toEqual({ generation: 'GEN4' });
    expect(versions[1]?.attributes).toEqual({ generation: 'GEN3' });
  });

  it('searches template versions with pagination and sorting', async () => {
    const createdAtOld = new Date('2024-03-01T00:00:00Z');
    const createdAtNew = new Date('2024-03-10T00:00:00Z');

    prisma.template.findUnique.mockResolvedValueOnce({
      id: 'tpl-1',
      accProjectId: 'proj-1',
      name: 'Template tpl-1',
      description: null,
      createdAt: createdAtOld,
      updatedAt: createdAtNew,
    });

    prisma.templateVersion.findMany.mockResolvedValueOnce([
      {
        ...buildTemplateVersionRecord('tpl-1', 'tpl-1-v1'),
        createdAt: createdAtOld,
        updatedAt: createdAtOld,
      },
      {
        ...buildTemplateVersionRecord('tpl-1', 'tpl-1-v2'),
        createdAt: createdAtNew,
        updatedAt: createdAtNew,
      },
    ]);

    mockedLoadAttributes.mockResolvedValue({});

    const result = await service().searchTemplateVersions('tpl-1', {
      pageIdx: 0,
      limit: 1,
      orderBy: 'updatedAt',
      orderDesc: true,
    } as never);

    expect(prisma.template.findUnique).toHaveBeenCalledWith({ where: { id: 'tpl-1' } });
    expect(prisma.templateVersion.findMany).toHaveBeenCalledWith({
      where: { templateId: 'tpl-1' },
      orderBy: { createdAt: 'desc' },
      include: {}, // Files lazy-loaded via field resolver
    });

    expect(result.total).toBe(2);
    expect(result.items).toHaveLength(1);
    expect(result.items[0]?.id).toBe('tpl-1-v2');
    expect(result.pageIdx).toBe(0);
    expect(result.limit).toBe(1);
    expect(result.hasNext).toBe(true);
  });

  it('retrieves a template version with associated files', async () => {
    prisma.templateVersion.findUnique.mockResolvedValueOnce({
      ...buildTemplateVersionRecord('tpl-1', 'tpl-1-v1'),
      files: [
        {
          id: 'file-1',
          templateVersionId: 'tpl-1-v1',
          accFileId: 'file-1',
          createdAt: new Date('2024-03-03T00:00:00Z'),
        },
      ],
    });

    mockedLoadAttributes.mockImplementation(async (_client, entityId) =>
      entityId === 'tpl-1-v1' ? { packageType: 'Retrofit' } : {}
    );

    const version = await service().getTemplateVersion('tpl-1-v1');

    expect(version?.attributes).toEqual({ packageType: 'Retrofit' });
    expect(version?.files[0]?.accFileId).toBe('file-1');
  });

  it('returns template files for a version', async () => {
    prisma.templateFile.findMany.mockResolvedValueOnce([
      {
        id: 'file-1',
        templateVersionId: 'tpl-1-v1',
        accFileId: 'file-1',
        createdAt: new Date('2024-03-04T00:00:00Z'),
      },
      {
        id: 'file-2',
        templateVersionId: 'tpl-1-v1',
        accFileId: 'file-2',
        createdAt: new Date('2024-03-05T00:00:00Z'),
      },
    ]);

    const files = await service().getTemplateFiles('tpl-1-v1');

    expect(files).toHaveLength(2);
    expect(files[1]?.accFileId).toBe('file-2');
  });

  it('returns null when requesting an unknown template file', async () => {
    prisma.templateFile.findUnique.mockResolvedValueOnce(null);

    const file = await service().getTemplateFile('unknown-file');

    expect(file).toBeNull();
  });

  it('fails to create a template when the initial version is missing a BRS record id', async () => {
    prisma.template.findUnique.mockResolvedValueOnce(null);

    const result = await service().createTemplate({
      accProjectId: 'proj-1',
      name: 'Template Invalid',
      initialVersion: {
        accFolderId: 'folder-1',
        brsId: '   ',
        version: '1.0.0',
      },
    } as never);

    expect(result.success).toBe(false);
    expect(result.message).toContain('BRS record id is required');
  });

  it('fails to create a template version when the template is missing', async () => {
    prisma.template.findUnique.mockResolvedValueOnce(null);

    const result = await service().createTemplateVersion('missing-template', {
      accFolderId: 'folder-1',
      brsId: 'brs-1',
      version: '1.0.0',
      files: [],
    } as never);

    expect(result.success).toBe(false);
    expect(result.message).toContain('Template not found');
    expect(prisma.templateVersion.create).not.toHaveBeenCalled();
  });

  it.skip('updates template version and recalculates latest flags when unset', async () => {
    prisma.templateVersion.findUnique
      .mockResolvedValueOnce({ templateId: 'tpl-1' })
      .mockResolvedValueOnce(buildTemplateVersionRecord('tpl-1', 'tpl-1-v1'));
    prisma.templateVersion.findMany.mockResolvedValueOnce([
      {
        id: 'tpl-1-v1',
        isLatest: false,
      },
    ]);

    const result = await service().updateTemplateVersion('tpl-1-v1', {
      isLatest: false,
      attributes: { packageType: 'Retrofit' },
    } as never);

    expect(result.success).toBe(true);
    expect(prisma.templateVersion.update).toHaveBeenCalledWith({
      where: { id: 'tpl-1-v1' },
      data: { isLatest: false },
    });
    expect(prisma.templateVersion.findMany).toHaveBeenCalled();
  });

  it('fails to remove a template file that does not exist', async () => {
    prisma.templateFile.findUnique.mockResolvedValueOnce(null);

    const result = await service().removeTemplateFile('unknown-file');

    expect(result.success).toBe(false);
    expect(result.message).toContain('Template file not found');
    expect(prisma.templateFile.delete).not.toHaveBeenCalled();
  });

  it('returns null when template is not found by id', async () => {
    prisma.template.findUnique.mockResolvedValueOnce(null);

    const template = await service().getTemplate('missing');

    expect(template).toBeNull();
  });

  it('returns null when template version is not found', async () => {
    prisma.templateVersion.findUnique.mockResolvedValueOnce(null);

    const version = await service().getTemplateVersion('missing-version');

    expect(version).toBeNull();
  });

  it('sets latest template version explicitly', async () => {
    prisma.templateVersion.findUnique.mockResolvedValueOnce({ templateId: 'tpl-1' });
    prisma.templateVersion.update.mockResolvedValueOnce({});

    const result = await service().setLatestTemplateVersion('tpl-1-v2');

    expect(result.success).toBe(true);
    expect(prisma.templateVersion.updateMany).toHaveBeenCalledWith({
      data: { isLatest: false },
      where: { templateId: 'tpl-1' },
    });
    expect(prisma.templateVersion.update).toHaveBeenCalledWith({
      data: { isLatest: true },
      where: { id: 'tpl-1-v2' },
    });
  });

  it('fails to set latest template version when version does not exist', async () => {
    prisma.templateVersion.findUnique.mockResolvedValueOnce(null);

    const result = await service().setLatestTemplateVersion('missing-version');

    expect(result.success).toBe(false);
    expect(result.message).toContain('Template version not found');
  });

  it('deletes a template version and ensures latest flag is recalculated', async () => {
    prisma.templateVersion.findUnique.mockResolvedValueOnce({
      templateId: 'tpl-1',
      isLatest: false,
    });
    prisma.templateVersion.delete.mockResolvedValueOnce(undefined);
    prisma.templateVersion.findMany.mockResolvedValueOnce([]);

    const result = await service().deleteTemplateVersion('tpl-1-v1');

    expect(result.success).toBe(true);
    expect(prisma.templateVersion.delete).toHaveBeenCalledWith({ where: { id: 'tpl-1-v1' } });
    expect(prisma.templateVersion.findMany).toHaveBeenCalled();
  });

  it('fails to add a template file when the accFileId is blank', async () => {
    prisma.templateVersion.findUnique.mockResolvedValueOnce({ id: 'tpl-1-v1' });

    const result = await service().addTemplateFile('tpl-1-v1', '   ');

    expect(result.success).toBe(false);
    expect(result.message).toContain('ACC file id is required');
    expect(prisma.templateFile.create).not.toHaveBeenCalled();
  });

  it('falls back to database-backed pagination when sorting by base field', async () => {
    const record = buildTemplate('tpl-1');
    prisma.template.count.mockResolvedValueOnce(1);
    prisma.template.findMany.mockResolvedValueOnce([record]);

    const result = await service().search({
      pageIdx: 0,
      limit: 10,
      orderBy: 'updatedAt',
      orderDesc: false,
    } as never);

    expect(prisma.template.count).toHaveBeenCalled();
    expect(result.items[0]?.id).toBe('tpl-1');
  });

  it('deletes a template successfully', async () => {
    prisma.template.delete.mockResolvedValueOnce(undefined);

    const result = await service().deleteTemplate('tpl-1');

    expect(result.success).toBe(true);
    expect(prisma.template.delete).toHaveBeenCalledWith({ where: { id: 'tpl-1' } });
  });

  it('checks template name availability returns true for blank input without DB call', async () => {
    prisma.template.findUnique.mockClear();

    const available = await service().isTemplateNameAvailable('   ');

    expect(available).toBe(true);
    expect(prisma.template.findUnique).not.toHaveBeenCalled();
  });

  it('returns a specific template file when present', async () => {
    prisma.templateFile.findUnique.mockResolvedValueOnce({
      id: 'file-1',
      templateVersionId: 'tpl-1-v1',
      accFileId: 'acc-123',
      createdAt: new Date('2024-03-03T00:00:00Z'),
    });

    const file = await service().getTemplateFile('file-1');

    expect(file?.accFileId).toBe('acc-123');
  });

  it('updateTemplateVersion returns error when version does not exist', async () => {
    prisma.templateVersion.findUnique.mockReset();
    prisma.templateVersion.findUnique.mockResolvedValueOnce(null);

    const result = await service().updateTemplateVersion('missing-version', {
      isLatest: true,
    } as never);

    expect(result.success).toBe(false);
    expect(result.message).toContain('Template version not found');
  });

  it('updateTemplateVersion rejects immutable field edits', async () => {
    prisma.templateVersion.findUnique.mockReset();
    prisma.templateVersion.findUnique.mockResolvedValueOnce({ templateId: 'tpl-1' });

    const result = await service().updateTemplateVersion('tpl-1-v1', {
      version: '9.9.9',
    } as never);

    expect(result.success).toBe(false);
    expect(result.message).toContain('immutable');
  });

  it('updateTemplateVersion rejects when no mutable fields provided', async () => {
    prisma.templateVersion.findUnique.mockReset();
    prisma.templateVersion.findUnique.mockResolvedValueOnce({ templateId: 'tpl-1' });

    const result = await service().updateTemplateVersion('tpl-1-v1', {} as never);

    expect(result.success).toBe(false);
    expect(result.message).toContain('No mutable fields provided');
  });

  it('updateTemplateVersion rejects null isLatest', async () => {
    prisma.templateVersion.findUnique.mockReset();
    prisma.templateVersion.findUnique.mockResolvedValueOnce({ templateId: 'tpl-1' });

    const result = await service().updateTemplateVersion('tpl-1-v1', {
      isLatest: null,
    } as never);

    expect(result.success).toBe(false);
    expect(result.message).toContain('isLatest cannot be null');
  });

  it('deleteTemplateVersion returns error when template version does not exist', async () => {
    prisma.templateVersion.findUnique.mockReset();
    prisma.templateVersion.findUnique.mockResolvedValueOnce(null);

    const result = await service().deleteTemplateVersion('missing-version');

    expect(result.success).toBe(false);
    expect(result.message).toContain('Template version not found');
    expect(prisma.templateVersion.delete).not.toHaveBeenCalled();
  });

  it('demotes a template version from latest via updateTemplateVersion(false)', async () => {
    prisma.templateVersion.findUnique.mockReset();
    prisma.templateVersion.findUnique
      .mockResolvedValueOnce({ templateId: 'tpl-1' })
      .mockResolvedValueOnce(buildTemplateVersionRecord('tpl-1'));

    prisma.templateVersion.findMany.mockResolvedValueOnce([{ id: 'tpl-1-v1', isLatest: false }]);

    const result = await service().updateTemplateVersion('tpl-1-v1', {
      isLatest: false,
    } as never);

    expect(result.success).toBe(true);
    expect(prisma.templateVersion.update).toHaveBeenCalledWith({
      where: { id: 'tpl-1-v1' },
      data: { isLatest: false },
    });
    expect(prisma.templateVersion.findMany).toHaveBeenCalled();
  });

  it('filters and sorts template versions using attribute-aware searchTemplateVersions', async () => {
    const createdAtOld = new Date('2024-03-01T00:00:00Z');
    const createdAtNew = new Date('2024-03-10T00:00:00Z');

    prisma.template.findUnique.mockResolvedValueOnce({
      id: 'tpl-1',
      accProjectId: 'proj-1',
      name: 'Template tpl-1',
      description: null,
      createdAt: createdAtOld,
      updatedAt: createdAtNew,
    });

    prisma.templateVersion.findMany.mockResolvedValueOnce([
      {
        ...buildTemplateVersionRecord('tpl-1', 'tpl-1-v1'),
        createdAt: createdAtOld,
        updatedAt: createdAtOld,
      },
      {
        ...buildTemplateVersionRecord('tpl-1', 'tpl-1-v2'),
        createdAt: createdAtNew,
        updatedAt: createdAtNew,
      },
    ]);

    mockedLoadAttributes.mockResolvedValue({});

    const result = await service().searchTemplateVersions('tpl-1', {
      pageIdx: 0,
      limit: 10,
      orderBy: 'title',
      orderDesc: false,
      query: {
        operation: 'OR',
        tokenGroups: [
          { propertyKey: 'title', operator: 'CONTAINS', value: '2.0.0' },
          { propertyKey: 'description', operator: 'CONTAINS', value: 'does-not-exist' },
        ],
      },
    } as never);

    expect(prisma.template.findUnique).toHaveBeenCalledWith({ where: { id: 'tpl-1' } });
    expect(result.pageIdx).toBe(0);
    expect(result.limit).toBe(10);
    expect(typeof result.hasNext).toBe('boolean');
  });

  it('rejects updateTemplate when the template does not exist', async () => {
    prisma.template.findUnique.mockResolvedValueOnce(null);

    const result = await service().updateTemplate('missing-template', {
      name: 'Nope',
    } as never);

    expect(result.success).toBe(false);
    expect(typeof result.message).toBe('string');
  });

  it('surfaces deleteTemplate failures with error message', async () => {
    prisma.template.delete.mockRejectedValueOnce(new Error('db failure'));

    const result = await service().deleteTemplate('tpl-1');

    expect(result.success).toBe(false);
    expect(result.message).toContain('db failure');
  });

  it('returns all changes for a template version', async () => {
    prisma.templateVersionChange.findMany.mockResolvedValueOnce([
      {
        id: 'chg-1',
        templateVersionId: 'ver-1',
        category: 'Structural',
        title: 'Updated foundation design',
        description: 'Modified foundation specs for seismic zones',
        dci: 'DCI-12345',
      },
      {
        id: 'chg-2',
        templateVersionId: 'ver-1',
        category: 'Mechanical',
        title: 'HVAC system upgrade',
        description: 'Updated HVAC requirements',
        dci: 'DCI-12346',
      },
    ]);

    const result = await service().listTemplateVersionChanges('ver-1');

    expect(prisma.templateVersionChange.findMany).toHaveBeenCalledWith({
      where: { templateVersionId: 'ver-1' },
      orderBy: { id: 'asc' },
    });
    expect(result).toEqual([
      {
        id: 'chg-1',
        templateVersionId: 'ver-1',
        category: 'Structural',
        title: 'Updated foundation design',
        description: 'Modified foundation specs for seismic zones',
        dci: 'DCI-12345',
      },
      {
        id: 'chg-2',
        templateVersionId: 'ver-1',
        category: 'Mechanical',
        title: 'HVAC system upgrade',
        description: 'Updated HVAC requirements',
        dci: 'DCI-12346',
      },
    ]);
  });
});
