import { createTemplateAssetService } from '../../../modules/templates/infra/templateAssetService';
import { ProxyUnavailableError } from '../../../shared';
import type { Logger } from '../../../shared';

const createMockLogger = (): jest.Mocked<Logger> => ({
  info: jest.fn(),
  warn: jest.fn(),
  error: jest.fn(),
  child: jest.fn().mockReturnThis(),
});

const buildConfig = (
  overrides?: Partial<import('../../../config/runtimeConfig').BackendRuntimeConfig>
): import('../../../config/runtimeConfig').BackendRuntimeConfig => {
  return {
    server: {
      port: 4000,
      corsOrigins: ['http://localhost:3000'],
      publicBaseUrl: 'http://localhost:4000',
    },
    proxy: overrides?.proxy ?? {
      baseUrl: 'http://proxy.local',
      timeoutMs: 5000,
    },
    database: {
      url: 'postgres://example',
    },
    ...overrides,
  };
};

describe('createTemplateAssetService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('generateSignedUrl', () => {
    it('returns null immediately when accFileId is blank', async () => {
      const mockLogger = createMockLogger();
      const service = createTemplateAssetService(buildConfig(), mockLogger);

      const result = await service.generateSignedUrl('proj-123', '   ');

      expect(result).toBeNull();
    });

    it('throws ProxyUnavailableError when proxy config is missing', () => {
      const mockLogger = createMockLogger();
      const configWithoutProxy = buildConfig({ proxy: undefined });

      expect(() => createTemplateAssetService(configWithoutProxy, mockLogger)).toThrow(
        ProxyUnavailableError
      );
    });

    // Note: Full integration tests with AccClient are in accClient.test.ts
    // This test only verifies the service interface
  });
});
