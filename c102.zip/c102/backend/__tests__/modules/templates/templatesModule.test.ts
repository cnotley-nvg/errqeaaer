import { createTemplateModule } from '../../../modules/templates';
import type { Logger } from '../../../shared';
import type { BackendRuntimeConfig } from '../../../config/runtimeConfig';
import { createTemplateService } from '../../../modules/templates/domain/templateService';
import { createTemplatesResolvers } from '../../../modules/templates/graphql/resolvers';
import { createTemplateAssetService } from '../../../modules/templates/infra/templateAssetService';

jest.mock('../../../modules/templates/domain/templateService', () => ({
  createTemplateService: jest.fn(),
}));

jest.mock('../../../modules/templates/graphql/resolvers', () => ({
  createTemplatesResolvers: jest.fn(),
}));

jest.mock('../../../modules/templates/infra/templateAssetService', () => ({
  createTemplateAssetService: jest.fn(),
}));

const mockedCreateTemplateService = createTemplateService as jest.MockedFunction<
  typeof createTemplateService
>;
const mockedCreateTemplatesResolvers = createTemplatesResolvers as jest.MockedFunction<
  typeof createTemplatesResolvers
>;
const mockedCreateTemplateAssetService = createTemplateAssetService as jest.MockedFunction<
  typeof createTemplateAssetService
>;

const createLogger = (): jest.Mocked<Logger> => {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;

  logger.child.mockReturnValue(logger);
  return logger;
};

describe('createTemplateModule', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('creates the module with scoped loggers', () => {
    const service = { search: jest.fn() } as never;
    const assetService = { getRevisionLog: jest.fn(), generateSignedUrl: jest.fn() } as never;
    const resolvers = { Query: {}, Mutation: {} } as never;
    mockedCreateTemplateService.mockReturnValue(service);
    mockedCreateTemplateAssetService.mockReturnValue(assetService);
    mockedCreateTemplatesResolvers.mockReturnValue(resolvers);

    const moduleLogger = createLogger();
    const resolverLogger = createLogger();
    moduleLogger.child.mockReturnValue(resolverLogger);

    const rootLogger = createLogger();
    rootLogger.child.mockReturnValue(moduleLogger);

    const config: BackendRuntimeConfig = {
      server: { port: 8080, corsOrigins: ['*'], publicBaseUrl: 'http://localhost:8080' },
      proxy: undefined,
      database: { url: 'postgres://local' },
    };

    const module = createTemplateModule({ logger: rootLogger, config });

    expect(rootLogger.child).toHaveBeenCalledWith({ module: 'templates' });
    expect(moduleLogger.child).toHaveBeenCalledWith({ component: 'service' });
    expect(mockedCreateTemplatesResolvers).toHaveBeenCalledWith({
      templateService: service,
      templateAssetService: assetService,
    });
    expect(module).toEqual({ resolvers, service });
  });
});
