import type { Prisma } from '@amzn/global-realty-mosaic-prisma-client';
import type { CreateTemplateFileInput } from '@amzn/global-realty-mosaic-graphql-schema';

import {
  ensureLatestTemplateVersionExists,
  insertTemplateFiles,
  updateLatestTemplateFlags,
  type TemplateFileMutations,
  type TemplateVersionMutations,
} from '../../../modules/templates/domain/templateMutations';

describe('templateMutations', () => {
  const createArgs = (accFileId: string): Prisma.TemplateFileCreateArgs => ({
    data: {
      templateVersionId: 'template-version-1',
      accFileId,
    },
  });

  it('skips file insertion when list is empty', async () => {
    const templateFile = {
      create: jest.fn().mockResolvedValue(undefined),
    } as unknown as TemplateFileMutations;

    await insertTemplateFiles(templateFile, 'template-version-1', []);

    expect(templateFile.create).not.toHaveBeenCalled();
  });

  it('inserts each file when provided', async () => {
    const templateFile = {
      create: jest.fn().mockResolvedValue(undefined),
    } as unknown as TemplateFileMutations;

    const files: ReadonlyArray<CreateTemplateFileInput> = [
      { accFileId: 'file-1' },
      { accFileId: 'file-2' },
    ];

    await insertTemplateFiles(templateFile, 'template-version-1', files);

    expect(templateFile.create).toHaveBeenCalledTimes(2);
    expect(templateFile.create).toHaveBeenNthCalledWith(1, createArgs('file-1'));
    expect(templateFile.create).toHaveBeenNthCalledWith(2, createArgs('file-2'));
  });

  it('updates latest flags for a template', async () => {
    const templateVersion = {
      updateMany: jest.fn().mockResolvedValue(undefined),
      update: jest.fn().mockResolvedValue(undefined),
      findMany: jest.fn(),
    } as unknown as TemplateVersionMutations;

    await updateLatestTemplateFlags(templateVersion, 'template-1', 'version-2');

    expect(templateVersion.updateMany).toHaveBeenCalledWith({
      data: { isLatest: false },
      where: { templateId: 'template-1' },
    });
    expect(templateVersion.update).toHaveBeenCalledWith({
      data: { isLatest: true },
      where: { id: 'version-2' },
    });
  });

  describe('ensureLatestTemplateVersionExists', () => {
    const buildDelegate = (records: Array<{ id: string; isLatest: boolean }>) =>
      ({
        updateMany: jest.fn(),
        update: jest.fn().mockResolvedValue(undefined),
        findMany: jest.fn().mockResolvedValue(records),
      }) as unknown as TemplateVersionMutations;

    it('does nothing when no versions found', async () => {
      const delegate = buildDelegate([]);

      await ensureLatestTemplateVersionExists(delegate, 'template-1');

      expect(delegate.update).not.toHaveBeenCalled();
    });

    it('does nothing when a latest version already exists', async () => {
      const delegate = buildDelegate([
        { id: 'version-1', isLatest: true },
        { id: 'version-2', isLatest: false },
      ]);

      await ensureLatestTemplateVersionExists(delegate, 'template-1');

      expect(delegate.update).not.toHaveBeenCalled();
    });

    it('marks the most recent version as latest when missing', async () => {
      const delegate = buildDelegate([
        { id: 'version-1', isLatest: false },
        { id: 'version-2', isLatest: false },
      ]);

      await ensureLatestTemplateVersionExists(delegate, 'template-1');

      expect(delegate.update).toHaveBeenCalledWith({
        where: { id: 'version-1' },
        data: { isLatest: true },
      });
    });
  });
});
