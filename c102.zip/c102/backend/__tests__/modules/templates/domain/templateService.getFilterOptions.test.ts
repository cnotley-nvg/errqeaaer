import { createTemplateService } from '../../../../modules/templates/domain/templateService';
import type { Logger } from '../../../../shared';
import { Decimal } from 'decimal.js';

jest.mock('../../../../lib/prisma', () => ({
  prisma: {
    templateVersion: {
      findMany: jest.fn(),
    },
    attributeDefinition: {
      findUnique: jest.fn(),
    },
    attributeTextValue: {
      findMany: jest.fn(),
    },
    attributeIntValue: {
      findMany: jest.fn(),
    },
    attributeBoolValue: {
      findMany: jest.fn(),
    },
    attributeNumericValue: {
      findMany: jest.fn(),
    },
  },
}));

const { prisma } = require('../../../../lib/prisma') as {
  prisma: {
    templateVersion: {
      findMany: jest.Mock;
    };
    attributeDefinition: {
      findUnique: jest.Mock;
    };
    attributeTextValue: {
      findMany: jest.Mock;
    };
    attributeIntValue: {
      findMany: jest.Mock;
    };
    attributeBoolValue: {
      findMany: jest.Mock;
    };
    attributeNumericValue: {
      findMany: jest.Mock;
    };
  };
};

const createLogger = (): jest.Mocked<Logger> => {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;

  logger.child.mockReturnValue(logger);
  return logger;
};

describe('TemplateService.getFilterOptions', () => {
  let templateService: ReturnType<typeof createTemplateService>;
  let logger: jest.Mocked<Logger>;

  beforeEach(() => {
    jest.clearAllMocks();
    logger = createLogger();
    templateService = createTemplateService(logger);
  });

  describe('field validation', () => {
    it('should throw error for invalid field name', async () => {
      await expect(templateService.getFilterOptions('invalidField')).rejects.toThrow(
        'Invalid filter field: "invalidField"'
      );
    });

    it('should accept valid direct field (version)', async () => {
      prisma.templateVersion.findMany.mockResolvedValue([{ version: '1.0' }, { version: '2.0' }]);

      const result = await templateService.getFilterOptions('version');
      expect(result).toEqual(['1.0', '2.0']);
    });

    it('should accept valid parent field (name)', async () => {
      prisma.templateVersion.findMany.mockResolvedValue([
        { templateId: 't1', template: { name: 'Template A' } },
        { templateId: 't2', template: { name: 'Template B' } },
      ]);

      const result = await templateService.getFilterOptions('name');
      expect(result).toEqual(['Template A', 'Template B']);
    });

    it('should accept valid attribute field (program)', async () => {
      prisma.templateVersion.findMany
        .mockResolvedValueOnce([{ id: 'v1' }, { id: 'v2' }])
        .mockResolvedValueOnce([]);
      prisma.attributeDefinition.findUnique.mockResolvedValue({
        id: 'attr1',
        name: 'program',
        datatype: 'TEXT',
      });
      prisma.attributeTextValue.findMany.mockResolvedValue([{ value: 'ARS' }, { value: 'Prime' }]);

      const result = await templateService.getFilterOptions('program');
      expect(result).toEqual(['ARS', 'Prime']);
    });
  });

  describe('direct field options (version)', () => {
    it('should return distinct version values from latest template versions', async () => {
      // Mock needs to return result from Prisma.findMany with proper structure
      prisma.templateVersion.findMany.mockReset();
      prisma.templateVersion.findMany.mockResolvedValueOnce([
        { version: '2.0' },
        { version: '1.0' },
        { version: '1.5' },
      ]);

      const result = await templateService.getFilterOptions('version');

      expect(prisma.templateVersion.findMany).toHaveBeenCalledWith({
        where: { isLatest: true },
        select: { version: true },
        distinct: ['version'],
      });
      expect(result).toEqual(['1.0', '1.5', '2.0']); // Sorted alphabetically
    });

    it('should filter out empty values', async () => {
      prisma.templateVersion.findMany.mockReset();
      prisma.templateVersion.findMany.mockResolvedValueOnce([
        { version: '1.0' },
        { version: '' },
        { version: '2.0' },
        { version: '   ' },
      ]);

      const result = await templateService.getFilterOptions('version');
      expect(result).toEqual(['1.0', '2.0']);
    });

    it('should return empty array when no latest versions exist', async () => {
      prisma.templateVersion.findMany.mockResolvedValue([]);

      const result = await templateService.getFilterOptions('version');
      expect(result).toEqual([]);
    });
  });

  describe('parent field options (name, accProjectId)', () => {
    it('should return distinct template names from latest versions', async () => {
      prisma.templateVersion.findMany.mockResolvedValue([
        { templateId: 't1', template: { name: 'Building Template' } },
        { templateId: 't2', template: { name: 'Site Template' } },
        { templateId: 't3', template: { name: 'Building Template' } }, // Duplicate
      ]);

      const result = await templateService.getFilterOptions('name');

      expect(prisma.templateVersion.findMany).toHaveBeenCalledWith({
        where: { isLatest: true },
        include: { template: true },
        distinct: ['templateId'],
      });
      expect(result).toEqual(['Building Template', 'Site Template']);
    });

    it('should return distinct ACC project IDs', async () => {
      prisma.templateVersion.findMany.mockResolvedValue([
        { templateId: 't1', template: { accProjectId: 'proj-123' } },
        { templateId: 't2', template: { accProjectId: 'proj-456' } },
      ]);

      const result = await templateService.getFilterOptions('accProjectId');
      expect(result).toEqual(['proj-123', 'proj-456']);
    });

    it('should filter out null and empty values', async () => {
      prisma.templateVersion.findMany.mockResolvedValue([
        { templateId: 't1', template: { name: 'Valid' } },
        { templateId: 't2', template: { name: null } },
        { templateId: 't3', template: { name: '' } },
        { templateId: 't4', template: { name: '   ' } },
      ]);

      const result = await templateService.getFilterOptions('name');
      expect(result).toEqual(['Valid']);
    });
  });

  describe('attribute field options (EAV)', () => {
    it('should return empty array when attribute definition not found', async () => {
      prisma.templateVersion.findMany.mockResolvedValue([{ id: 'v1' }]);
      prisma.attributeDefinition.findUnique.mockResolvedValue(null);

      const result = await templateService.getFilterOptions('program');

      expect(prisma.attributeDefinition.findUnique).toHaveBeenCalledWith({
        where: { name: 'program' },
      });
      expect(result).toEqual([]);
    });

    it('should return empty array when no latest versions exist', async () => {
      prisma.templateVersion.findMany.mockResolvedValue([]);
      prisma.attributeDefinition.findUnique.mockResolvedValue({
        id: 'attr1',
        name: 'program',
        datatype: 'TEXT',
      });

      const result = await templateService.getFilterOptions('program');
      expect(result).toEqual([]);
      expect(prisma.attributeTextValue.findMany).not.toHaveBeenCalled();
    });

    it('should fetch TEXT attribute values from latest versions', async () => {
      prisma.templateVersion.findMany
        .mockResolvedValueOnce([{ id: 'v1' }, { id: 'v2' }])
        .mockResolvedValueOnce([]); // For distinct check
      prisma.attributeDefinition.findUnique.mockResolvedValue({
        id: 'attr1',
        name: 'program',
        datatype: 'TEXT',
      });
      prisma.attributeTextValue.findMany.mockResolvedValue([
        { value: 'Prime' },
        { value: 'ARS' },
        { value: 'IXD' },
      ]);

      const result = await templateService.getFilterOptions('program');

      expect(prisma.attributeTextValue.findMany).toHaveBeenCalledWith({
        where: {
          attrDefId: 'attr1',
          entityType: 'TEMPLATE_VERSION',
          entityId: { in: ['v1', 'v2'] },
        },
        select: { value: true },
        distinct: ['value'],
        orderBy: { value: 'asc' },
      });
      expect(result).toEqual(['ARS', 'IXD', 'Prime']); // Sorted
    });

    it('should fetch INT attribute values (businessUnit)', async () => {
      prisma.templateVersion.findMany.mockReset();
      prisma.attributeDefinition.findUnique.mockReset();
      prisma.attributeIntValue.findMany.mockReset();

      prisma.templateVersion.findMany.mockResolvedValueOnce([{ id: 'v1' }]);
      prisma.attributeDefinition.findUnique.mockResolvedValueOnce({
        id: 'attr2',
        name: 'businessUnit',
        datatype: 'INT',
      });
      prisma.attributeIntValue.findMany.mockResolvedValueOnce([
        { value: 3 },
        { value: 5 },
        { value: 1 },
      ]);

      const result = await templateService.getFilterOptions('businessUnit');

      expect(prisma.attributeIntValue.findMany).toHaveBeenCalled();
      expect(result).toEqual(['1', '3', '5']); // Converted to strings and sorted
    });

    it('should fetch BOOL attribute values (generation)', async () => {
      prisma.templateVersion.findMany.mockResolvedValue([{ id: 'v1' }]);
      prisma.attributeDefinition.findUnique.mockResolvedValue({
        id: 'attr3',
        name: 'generation',
        datatype: 'BOOL',
      });
      prisma.attributeBoolValue.findMany.mockResolvedValue([{ value: true }, { value: false }]);

      const result = await templateService.getFilterOptions('generation');

      expect(prisma.attributeBoolValue.findMany).toHaveBeenCalled();
      expect(result).toEqual(['false', 'true']); // Converted to strings and sorted
    });

    it('should fetch NUM (Decimal) attribute values (createdBy)', async () => {
      prisma.templateVersion.findMany.mockResolvedValue([{ id: 'v1' }]);
      prisma.attributeDefinition.findUnique.mockResolvedValue({
        id: 'attr4',
        name: 'createdBy',
        datatype: 'NUM',
      });
      prisma.attributeNumericValue.findMany.mockResolvedValue([
        { value: new Decimal('1000.50') },
        { value: new Decimal('500.25') },
      ]);

      const result = await templateService.getFilterOptions('createdBy');

      expect(prisma.attributeNumericValue.findMany).toHaveBeenCalled();
      expect(result).toEqual(['1000.5', '500.25']); // Converted to strings and sorted
    });

    it('should automatically flatten multi-value attributes using distinct', async () => {
      // Template with program = ['ARS', 'Prime'] is stored as 2 rows:
      // - { entityId: 'v1', ord: 0, value: 'ARS' }
      // - { entityId: 'v1', ord: 1, value: 'Prime' }
      // Using distinct: ['value'] returns both unique values
      prisma.templateVersion.findMany.mockResolvedValueOnce([{ id: 'v1' }]);
      prisma.attributeDefinition.findUnique.mockResolvedValue({
        id: 'attr1',
        name: 'program',
        datatype: 'TEXT',
      });
      prisma.attributeTextValue.findMany.mockResolvedValue([
        { value: 'ARS' },
        { value: 'Prime' },
        { value: 'IXD' },
      ]);

      const result = await templateService.getFilterOptions('program');

      // Distinct on 'value' automatically flattens multi-value arrays
      expect(result).toEqual(['ARS', 'IXD', 'Prime']);
    });

    it('should filter out empty attribute values', async () => {
      prisma.templateVersion.findMany.mockResolvedValueOnce([{ id: 'v1' }]);
      prisma.attributeDefinition.findUnique.mockResolvedValue({
        id: 'attr1',
        name: 'program',
        datatype: 'TEXT',
      });
      prisma.attributeTextValue.findMany.mockResolvedValue([
        { value: 'ARS' },
        { value: '' },
        { value: '   ' },
      ]);

      const result = await templateService.getFilterOptions('program');
      expect(result).toEqual(['ARS']);
    });
  });

  describe('all valid field names', () => {
    const validFields = [
      'version',
      'name',
      'accProjectId',
      'program',
      'region',
      'facilityType',
      'businessUnit',
      'generation',
      'createdBy',
    ];

    validFields.forEach((fieldName) => {
      it(`should accept ${fieldName} as valid field`, async () => {
        // Mock basic responses
        if (fieldName === 'version') {
          prisma.templateVersion.findMany.mockResolvedValueOnce([]);
        } else if (fieldName === 'name' || fieldName === 'accProjectId') {
          prisma.templateVersion.findMany.mockResolvedValueOnce([]);
        } else {
          prisma.templateVersion.findMany.mockResolvedValueOnce([]);
          prisma.attributeDefinition.findUnique.mockResolvedValue(null);
        }

        await templateService.getFilterOptions(fieldName);

        // Should not throw error
        expect(true).toBe(true);
      });
    });
  });
});
