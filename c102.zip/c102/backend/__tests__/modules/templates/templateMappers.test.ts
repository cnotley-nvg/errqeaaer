import type { TemplateVersion } from '@amzn/global-realty-mosaic-graphql-schema';

import {
  createTemplateMappers,
  type TemplateRecord,
  type TemplateVersionRecord,
} from '../../../modules/templates/domain/templateMappers';

describe('templateMappers', () => {
  const now = new Date('2024-06-01T00:00:00.000Z');

  const versionRecord: TemplateVersionRecord = {
    id: 'template-version-1',
    templateId: 'template-1',
    accFolderId: 'folder-1',
    brsId: 'brs-1',
    version: 'v1',
    isLatest: true,
    createdAt: now,
    updatedAt: now,
    files: [
      {
        id: 'file-1',
        templateVersionId: 'template-version-1',
        accFileId: 'acc-file-1',
        createdAt: now,
        updatedAt: now,
      } as unknown as TemplateVersionRecord['files'][number],
    ],
  } as TemplateVersionRecord;

  const templateRecord: TemplateRecord = {
    id: 'template-1',
    accProjectId: 'project-1',
    name: 'Template',
    description: 'Example template',
    createdAt: now,
    updatedAt: now,
    versions: [versionRecord],
  } as TemplateRecord;

  const attributeLoader = jest.fn<Promise<TemplateVersion['attributes']>, [string]>(async (id) => ({
    region: `attr-${id}`,
  }));

  const { toTemplateFileGraph, toTemplateVersionGraph, toTemplateGraph } =
    createTemplateMappers(attributeLoader);

  beforeEach(() => {
    attributeLoader.mockClear();
  });

  it('maps template files with ISO timestamps', () => {
    const fileGraph = toTemplateFileGraph(versionRecord.files[0]!);

    expect(fileGraph).toEqual({
      id: 'file-1',
      templateVersionId: 'template-version-1',
      accFileId: 'acc-file-1',
      displayName: null,
      createdAt: now.toISOString(),
    });
  });

  it('maps template versions with loaded attributes', async () => {
    const graph = await toTemplateVersionGraph({ ...versionRecord, template: templateRecord });

    expect(attributeLoader).toHaveBeenCalledWith('template-version-1');
    expect(graph.attributes).toEqual({ region: 'attr-template-version-1' });
    expect(graph.template?.id).toBe('template-1');
  });

  it('throws when template reference is missing', async () => {
    await expect(toTemplateVersionGraph(versionRecord)).rejects.toThrow(
      'Template reference not loaded'
    );
  });

  it('maps templates and selects the latest version', async () => {
    const graph = await toTemplateGraph(templateRecord);

    expect(graph.latestVersion?.id).toBe(versionRecord.id);
    expect(graph.versions).toHaveLength(1);
  });
});
