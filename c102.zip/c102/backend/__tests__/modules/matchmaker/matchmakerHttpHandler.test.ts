import type { BackendRuntimeConfig } from '../../../config/runtimeConfig';
import type { Logger } from '../../../shared';
import { createMatchmakerHttpHandler } from '../../../modules/matchmaker/http/handler';

const createMockLogger = (): jest.Mocked<Logger> => {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;
  logger.child.mockReturnValue(logger);
  return logger;
};

const buildConfig = (overrides: Partial<BackendRuntimeConfig> = {}): BackendRuntimeConfig =>
  ({
    server: {
      port: 4000,
      corsOrigins: ['http://localhost:3000'],
      publicBaseUrl: 'http://localhost:4000',
      ...overrides.server,
    },
    dge: overrides.dge,
    proxy: overrides.proxy,
    database: { url: 'postgres://example', ...overrides.database },
  }) as unknown as BackendRuntimeConfig;

const makeRes = () => {
  const headers: Record<string, string> = {};
  const res: any = {
    statusCode: 0,
    setHeader: jest.fn((k: string, v: string) => {
      headers[k] = v;
    }),
    end: jest.fn(),
  };
  return { res, headers };
};

describe('createMatchmakerHttpHandler', () => {
  const logger = createMockLogger();

  it('returns false for non-GET requests', async () => {
    const service = { getReportHtml: jest.fn(), getAsset: jest.fn() } as any;
    const handler = createMatchmakerHttpHandler(buildConfig(), logger, service);

    const req: any = { url: '/matchmaker/report?templateId=abc', method: 'POST' };
    const { res } = makeRes();

    const handled = await handler(req, res);

    expect(handled).toBe(false);
  });

  it('responds 404 when report route missing templateId', async () => {
    const service = { getReportHtml: jest.fn(), getAsset: jest.fn() } as any;
    const handler = createMatchmakerHttpHandler(buildConfig(), logger, service);
    const req: any = { url: '/matchmaker/report', method: 'GET' };
    const { res } = makeRes();

    const handled = await handler(req, res);

    expect(handled).toBe(true);
    expect(res.statusCode).toBe(404);
    expect(res.end).toHaveBeenCalledWith('Report not found');
  });

  it('responds 404 when report not found (service returns null)', async () => {
    const service = {
      getReportHtml: jest.fn().mockResolvedValue(null),
      getAsset: jest.fn(),
    } as any;
    const handler = createMatchmakerHttpHandler(buildConfig(), logger, service);
    const req: any = { url: '/matchmaker/report?templateId=tpl-1', method: 'GET' };
    const { res } = makeRes();

    const handled = await handler(req, res);

    expect(handled).toBe(true);
    expect(service.getReportHtml).toHaveBeenCalledWith('tpl-1');
    expect(res.statusCode).toBe(404);
    expect(res.end).toHaveBeenCalledWith('Report not found');
  });

  it('serves report HTML with correct headers when found', async () => {
    const service = {
      getReportHtml: jest.fn().mockResolvedValue('<html>ok</html>'),
      getAsset: jest.fn(),
    } as any;
    const handler = createMatchmakerHttpHandler(buildConfig(), logger, service);
    const req: any = { url: '/matchmaker/report?templateId=tpl-2', method: 'GET' };
    const { res, headers } = makeRes();

    const handled = await handler(req, res);

    expect(handled).toBe(true);
    expect(service.getReportHtml).toHaveBeenCalledWith('tpl-2');
    expect(res.statusCode).toBe(200);
    expect(headers['Content-Type']).toBe('text/html; charset=utf-8');
    expect(headers['Content-Disposition']).toBe('inline; filename="tpl-2.html"');
    expect(headers['Cache-Control']).toBe('no-store');
    expect(res.end).toHaveBeenCalledWith('<html>ok</html>');
  });

  it('accepts a valid S3-style key with path segments (encoded in the query) and serves the asset', async () => {
    const buffer = Buffer.from('png-bytes');
    const service = {
      getReportHtml: jest.fn(),
      getAsset: jest.fn().mockResolvedValue({ body: buffer, contentType: 'image/png' }),
    } as any;

    const handler = createMatchmakerHttpHandler(buildConfig(), logger, service);
    const encodedKey = 'ixd%2Fvisualizations%2Fdesign%2Fixd_design_gen_5_18M_weekly.png';
    const req: any = { url: `/matchmaker/asset?key=${encodedKey}`, method: 'GET' };
    const { res, headers } = makeRes();

    const handled = await handler(req, res);

    expect(handled).toBe(true);
    expect(service.getAsset).toHaveBeenCalledWith(
      'ixd/visualizations/design/ixd_design_gen_5_18M_weekly.png'
    );
    expect(res.statusCode).toBe(200);
    expect(headers['Content-Type']).toBe('image/png');
    expect(headers['Content-Disposition']).toBe(
      'inline; filename="ixd_design_gen_5_18M_weekly.png"'
    );
    expect(headers['Cache-Control']).toBe('no-store');
    expect(res.end).toHaveBeenCalledWith(buffer);
  });

  it('rejects unsafe asset keys (path traversal or blank)', async () => {
    const service = { getReportHtml: jest.fn(), getAsset: jest.fn() } as any;
    const handler = createMatchmakerHttpHandler(buildConfig(), logger, service);
    const { res } = makeRes();

    const req: any = { url: '/matchmaker/asset?key=../secret', method: 'GET' };
    const handled = await handler(req, res);

    expect(handled).toBe(true);
    expect(service.getAsset).not.toHaveBeenCalled();
    expect(res.statusCode).toBe(404);
    expect(res.end).toHaveBeenCalledWith('Not found');
  });

  it('serves binary asset with correct headers when found', async () => {
    const buffer = Buffer.from('asset-bytes');
    const service = {
      getReportHtml: jest.fn(),
      getAsset: jest.fn().mockResolvedValue({ body: buffer, contentType: 'image/png' }),
    } as any;
    const handler = createMatchmakerHttpHandler(buildConfig(), logger, service);
    const req: any = { url: '/matchmaker/asset?key=img.png', method: 'GET' };
    const { res, headers } = makeRes();

    const handled = await handler(req, res);

    expect(handled).toBe(true);
    expect(service.getAsset).toHaveBeenCalledWith('img.png');
    expect(res.statusCode).toBe(200);
    expect(headers['Content-Type']).toBe('image/png');
    expect(headers['Content-Disposition']).toBe('inline; filename="img.png"');
    expect(headers['Cache-Control']).toBe('no-store');
    expect(res.end).toHaveBeenCalledWith(buffer);
  });

  it('responds 404 when asset not found', async () => {
    const service = {
      getReportHtml: jest.fn(),
      getAsset: jest.fn().mockResolvedValue(null),
    } as any;
    const handler = createMatchmakerHttpHandler(buildConfig(), logger, service);
    const req: any = { url: '/matchmaker/asset?key=missing.png', method: 'GET' };
    const { res } = makeRes();

    const handled = await handler(req, res);

    expect(handled).toBe(true);
    expect(service.getAsset).toHaveBeenCalledWith('missing.png');
    expect(res.statusCode).toBe(404);
    expect(res.end).toHaveBeenCalledWith('Not found');
  });
});
