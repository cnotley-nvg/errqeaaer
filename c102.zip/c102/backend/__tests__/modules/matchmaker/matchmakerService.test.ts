import type {
  DesignGeneratorInput,
  DesignGeneratorProgram,
  DesignGeneratorAlternative,
} from '@amzn/global-realty-mosaic-graphql-schema';
import type { BackendRuntimeConfig } from '../../../config/runtimeConfig';
import type { Logger } from '../../../shared';

const yamlLoadMock = jest.fn();
jest.mock('js-yaml', () => ({
  load: (...args: any[]) => yamlLoadMock(...args),
}));

const s3SendMock = jest.fn();

const S3ClientMock = jest.fn().mockImplementation(function S3Client(this: any, _opts: any) {
  return { send: s3SendMock };
});
const GetObjectCommandMock = jest.fn((args: any) => args);
jest.mock('@aws-sdk/client-s3', () => ({
  S3Client: S3ClientMock,
  GetObjectCommand: GetObjectCommandMock,
}));

type CreateMatchmakerService =
  typeof import('../../../modules/matchmaker/infra/matchmakerService').createMatchmakerService;

const loadCreateMatchmakerService = (): CreateMatchmakerService => {
  let fn!: CreateMatchmakerService;
  jest.isolateModules(() => {
    ({
      createMatchmakerService: fn,
    } = require('../../../modules/matchmaker/infra/matchmakerService'));
  });
  return fn;
};

const createMockLogger = (): jest.Mocked<Logger> => {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;
  logger.child.mockReturnValue(logger);
  return logger;
};

const buildConfig = (overrides: Partial<BackendRuntimeConfig> = {}): BackendRuntimeConfig => ({
  server: {
    port: 4000,
    corsOrigins: ['http://localhost:3000'],
    publicBaseUrl: 'http://localhost:4000',
    ...overrides.server,
  },
  dge: overrides.dge,
  proxy: overrides.proxy,
  database: {
    url: 'postgres://example',
    ...overrides.database,
  },
});

const makeCatalog = (templates: any) => ({ templates });

const makeInput = (partial: Partial<DesignGeneratorInput>): DesignGeneratorInput => ({
  region: 'NA',
  program: 'IXD',
  projectedWeeklyThroughput: 100,
  throughputRange: null,
  numberOfAlternatives: 4,
  ...partial,
});

describe('createMatchmakerService', () => {
  beforeEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
  });

  describe('catalog loading', () => {
    it('returns empty results and warns when DGE S3 is not configured (S3-only mode)', async () => {
      const createMatchmakerService = loadCreateMatchmakerService();
      const logger = createMockLogger();
      const service = createMatchmakerService(buildConfig({ dge: undefined }), logger);

      const out = await service.listAlternatives(makeInput({ numberOfAlternatives: 2 }));

      expect(out).toEqual([]);
      expect(logger.warn).toHaveBeenCalledWith(
        'DGE S3 bucket not configured; set DGE_S3_BUCKET (and optional DGE_S3_PREFIX / DGE_S3_REGION).'
      );
    });

    it('loads catalog from S3 when bucket configured', async () => {
      const createMatchmakerService = loadCreateMatchmakerService();
      const catalog = makeCatalog({
        ixd: { design: { a: { template_id: 'ixd_gen_1_100', throughput: 100, region: 'NA' } } },
      });
      s3SendMock.mockResolvedValueOnce({
        Body: Buffer.from(JSON.stringify(catalog)),
        ContentType: 'application/json',
      });

      const logger = createMockLogger();
      const service = createMatchmakerService(
        buildConfig({ dge: { s3: { bucket: 'dge-bucket', prefix: 'pref/' } } }),
        logger
      );

      const out = await service.listAlternatives(makeInput({ numberOfAlternatives: 1 }));

      expect(out).toHaveLength(1);
      expect(s3SendMock).toHaveBeenCalledTimes(1);
    });

    it('handles S3 get failure gracefully (warn + empty)', async () => {
      const createMatchmakerService = loadCreateMatchmakerService();
      s3SendMock.mockRejectedValueOnce(new Error('boom'));
      const logger = createMockLogger();
      const service = createMatchmakerService(
        buildConfig({ dge: { s3: { bucket: 'dge-bucket' } } }),
        logger
      );

      const out = await service.listAlternatives(makeInput({ numberOfAlternatives: 1 }));

      expect(out).toEqual([]);
      expect(logger.warn).toHaveBeenCalledWith(
        'Failed to read DGE object from S3',
        expect.objectContaining({
          bucket: 'dge-bucket',
          key: expect.stringContaining('all_designs.json'),
        })
      );
    });
  });

  describe('baseline normalization / getBaselineThroughput', () => {
    const truthyCases: Array<[unknown, boolean]> = [
      ['YES', true],
      [' true ', true],
      ['1', true],
      [true, true],
      [1, true],
      ['NO', false],
      [' false ', false],
      ['0', false],
      [false, false],
      [0, false],
      ['   ', false],
      [{}, false],
      [null, false],
      [undefined, false],
    ];

    it.each(truthyCases)('normalizes baseline value %p', async (baselineVal, expectedTruthy) => {
      const createMatchmakerService = loadCreateMatchmakerService();
      const catalog = makeCatalog({
        ixd: {
          design: {
            a: {
              template_id: 'ixd_gen_1_100',
              throughput: 123,
              baseline: baselineVal,
              throughput_units: 'DAILY',
              region: 'NA',
            },
            b: { template_id: 'ixd_gen_2_90', throughput: 90, baseline: false, region: 'NA' },
          },
        },
      });
      s3SendMock.mockResolvedValueOnce({
        Body: Buffer.from(JSON.stringify(catalog)),
      });

      const service = createMatchmakerService(
        buildConfig({ dge: { s3: { bucket: 'dge-bucket' } } }),
        createMockLogger()
      );
      const res = await service.getBaselineThroughput('IXD');

      if (expectedTruthy) {
        expect(res).toEqual({ throughput: 123, throughputUnits: 'DAILY' });
      } else {
        expect(res).toBeNull();
      }
    });

    it('returns baseline for each program facility map and defaults units to WEEKLY', async () => {
      const createMatchmakerService = loadCreateMatchmakerService();
      const catalog = makeCatalog({
        ixd: {
          design: { a: { template_id: 'ixd_t_100', throughput: 10, baseline: true, region: 'NA' } },
        },
        ars: {
          design: {
            a: {
              template_id: 'ars_t_100',
              throughput: 20,
              baseline: 'YES',
              throughput_units: 'bad',
              region: 'NA',
            },
          },
        },
        ssd: {
          design: {
            a: {
              template_id: 'ssd_t_100',
              throughput: 30,
              baseline: 1,
              throughput_units: undefined,
              region: 'NA',
            },
          },
        },
        tns: {
          design: {
            a: {
              template_id: 'tns_t_100',
              throughput: 40,
              baseline: true,
              throughput_units: 'WEEKLY',
              region: 'NA',
            },
          },
        },
        ds: {
          design: {
            a: {
              template_id: 'ds_t_100',
              throughput: 50,
              baseline: true,
              throughput_units: 'daily',
              region: 'NA',
            },
          },
        },
      });
      s3SendMock.mockResolvedValue({
        Body: Buffer.from(JSON.stringify(catalog)),
      });

      const service = createMatchmakerService(
        buildConfig({ dge: { s3: { bucket: 'dge-bucket' } } }),
        createMockLogger()
      );

      await expect(service.getBaselineThroughput('IXD')).resolves.toEqual({
        throughput: 10,
        throughputUnits: 'WEEKLY',
      });
      await expect(service.getBaselineThroughput('ARS')).resolves.toEqual({
        throughput: 20,
        throughputUnits: 'WEEKLY',
      });
      await expect(service.getBaselineThroughput('SSD')).resolves.toEqual({
        throughput: 30,
        throughputUnits: 'WEEKLY',
      });
      await expect(service.getBaselineThroughput('TNS')).resolves.toEqual({
        throughput: 40,
        throughputUnits: 'WEEKLY',
      });
      await expect(service.getBaselineThroughput('DS')).resolves.toEqual({
        throughput: 50,
        throughputUnits: 'DAILY',
      });
    });

    it('returns null when baseline entry has missing/non-numeric throughput', async () => {
      const createMatchmakerService = loadCreateMatchmakerService();
      const catalog = makeCatalog({
        ixd: {
          design: {
            a: { template_id: 'ixd_t_100', baseline: true, throughput: 'oops', region: 'NA' },
          },
        },
      });
      s3SendMock.mockResolvedValueOnce({
        Body: Buffer.from(JSON.stringify(catalog)),
      });

      const service = createMatchmakerService(
        buildConfig({ dge: { s3: { bucket: 'dge-bucket' } } }),
        createMockLogger()
      );
      await expect(service.getBaselineThroughput('IXD')).resolves.toBeNull();
    });
  });

  describe('listAlternatives filtering and sampling', () => {
    const baseCatalog = makeCatalog({
      ixd: {
        design: {
          a: { template_id: 'ixd_a_80', throughput: 80, region: 'NA', template_area: 1 },
          b: { template_id: 'ixd_b_90', throughput: 90, region: 'na', template_area: 1 },
          c: { template_id: 'ixd_c_100', throughput: 100, region: 'EU', template_area: 1 },
          d: { template_id: 'ixd_d_110', throughput: 110, region: 'NA', template_area: 1 },
          e: { template_id: 'ixd_e_120', throughput: 120, region: 'NA', template_area: 1 },
          f: { template_id: 'ixd_f_bad', throughput: 'abc', region: 'NA', template_area: 1 },
        },
      },
      ars: {
        design: {
          z: { template_id: 'ars_z_999', throughput: 999, region: 'NA', template_area: 1 },
        },
      },
    });

    beforeEach(() => {
      s3SendMock.mockResolvedValue({
        Body: Buffer.from(JSON.stringify(baseCatalog)),
      });
    });

    it('filters by program/facility bucket and region NA only', async () => {
      const createMatchmakerService = loadCreateMatchmakerService();
      const service = createMatchmakerService(
        buildConfig({ dge: { s3: { bucket: 'dge-bucket' } } }),
        createMockLogger()
      );

      const out = await service.listAlternatives(
        makeInput({ program: 'IXD', region: 'NA', throughputRange: null, numberOfAlternatives: 10 })
      );

      expect(out.map((o) => o.templateId)).toEqual(expect.not.arrayContaining(['ars_z_999']));

      expect(out.map((o) => o.templateId)).toEqual(
        expect.arrayContaining(['ixd_a_80', 'ixd_b_90', 'ixd_d_110', 'ixd_e_120'])
      );
      expect(out.map((o) => o.templateId)).not.toContain('ixd_c_100');
    });

    it.each([
      ['PLUS_MINUS_10', [90, 110]],
      ['PLUS_MINUS_25', [80, 120]],
      ['PLUS_MINUS_50', [80, 120]],
      [null, [80, 120]],
    ] as Array<[DesignGeneratorInput['throughputRange'], [number, number]]>)(
      'filters by throughput range %p',
      async (range, expectedMinMax) => {
        const createMatchmakerService = loadCreateMatchmakerService();
        const service = createMatchmakerService(
          buildConfig({ dge: { s3: { bucket: 'dge-bucket' } } }),
          createMockLogger()
        );
        const out = await service.listAlternatives(
          makeInput({
            program: 'IXD',
            projectedWeeklyThroughput: 100,
            throughputRange: range,
            numberOfAlternatives: 10,
          })
        );

        const tps = out.map((o) => o.throughput).filter((tp) => typeof tp === 'number') as number[];
        expect(Math.min(...tps)).toBeGreaterThanOrEqual(expectedMinMax[0]);
        expect(Math.max(...tps)).toBeLessThanOrEqual(expectedMinMax[1]);

        if (range) {
          expect(out.map((o) => o.templateId)).not.toContain('ixd_f_bad');
        }
      }
    );

    it('sorts by throughput ascending and evenly samples, clamping numberOfAlternatives >= 1', async () => {
      const createMatchmakerService = loadCreateMatchmakerService();
      const service = createMatchmakerService(
        buildConfig({ dge: { s3: { bucket: 'dge-bucket' } } }),
        createMockLogger()
      );

      const sampled3 = await service.listAlternatives(
        makeInput({ program: 'IXD', throughputRange: null, numberOfAlternatives: 3 })
      );

      expect(sampled3.map((o) => o.throughput)).toEqual([80, 110, 'abc']);

      const sampledInvalid0 = await service.listAlternatives(
        makeInput({ program: 'IXD', throughputRange: null, numberOfAlternatives: 0 })
      );
      expect(sampledInvalid0).toHaveLength(1);
      expect(sampledInvalid0[0]?.throughput).toBe(80);
    });

    it('returns empty array when no entries after filtering', async () => {
      const createMatchmakerService = loadCreateMatchmakerService();
      const service = createMatchmakerService(
        buildConfig({ dge: { s3: { bucket: 'dge-bucket' } } }),
        createMockLogger()
      );

      const out = await service.listAlternatives(
        makeInput({
          program: 'IXD',
          projectedWeeklyThroughput: 1000,
          throughputRange: 'PLUS_MINUS_10',
          numberOfAlternatives: 2,
        })
      );

      expect(out).toEqual([]);
    });
  });

  describe('YAML metric extraction (S3)', () => {
    it('extracts YAML metrics when YAML exists (S3)', async () => {
      const createMatchmakerService = loadCreateMatchmakerService();
      const catalog = makeCatalog({
        ixd: {
          design: {
            a: {
              template_id: 'ixd_gen_1_100',
              throughput: 100,
              region: 'NA',
              template_area: 5,
              template_path: 'ixd_design.yaml',
            },
          },
        },
      });

      s3SendMock
        .mockResolvedValueOnce({ Body: Buffer.from(JSON.stringify(catalog)) })
        .mockResolvedValueOnce({ Body: Buffer.from('yaml: here') });

      yamlLoadMock.mockReturnValue({
        WAREHOUSE_METRICS: { Total_Warehouse_Area_SqFt: 1234 },
        COST_METRICS: { 'Total Cost': 99, VCPU: 0.22 },
        UTILITY_METRICS: { 'Total Utility Demand (Amps)': 50 },
        CARBON_METRICS: { 'Total Carbon (tCO2)': 10 },
        TRAFFIC_METRICS: {
          key_metrics: {
            seasonal_peak_day: {
              ite_compliance_peaks: { morning: { vehicles: 7 } },
              operational_peaks: { evening: { vehicles: 9 } },
            },
          },
        },
      });

      const service = createMatchmakerService(
        buildConfig({ dge: { s3: { bucket: 'dge-bucket' } } }),
        createMockLogger()
      );
      const out = await service.listAlternatives(makeInput({ numberOfAlternatives: 1 }));

      const alt = out[0]!;
      expect(alt.warehouseAreaSqft).toBe(1234);
      expect(alt.realEstateCostUsd).toBe(99);
      expect(alt.vcpuUsdPerUnit).toBeCloseTo(0.22);
      expect(alt.utilityDemandAmps).toBe(50);
      expect(alt.carbonFootprintTco2).toBe(10);
      expect(alt.seasonalPeakMorningVehPerHr).toBe(7);
      expect(alt.seasonalPeakEveningVehPerHr).toBe(9);
    });

    it('logs warning and returns alternative with null YAML fields on invalid YAML (S3)', async () => {
      const createMatchmakerService = loadCreateMatchmakerService();
      const catalog = makeCatalog({
        ixd: {
          design: {
            a: {
              template_id: 'ixd_gen_1_100',
              throughput: 100,
              region: 'NA',
              template_area: 5,
              template_path: 'ixd_design.yaml',
            },
          },
        },
      });

      s3SendMock
        .mockResolvedValueOnce({ Body: Buffer.from(JSON.stringify(catalog)) })
        .mockResolvedValueOnce({ Body: Buffer.from('bad yaml') });
      yamlLoadMock.mockImplementation(() => {
        throw new Error('parse error');
      });

      const logger = createMockLogger();
      const service = createMatchmakerService(
        buildConfig({ dge: { s3: { bucket: 'dge-bucket' } } }),
        logger
      );
      const out = await service.listAlternatives(makeInput({ numberOfAlternatives: 1 }));

      expect(out).toHaveLength(1);
      expect(out[0]?.warehouseAreaSqft).toBeNull();
      expect(logger.warn).toHaveBeenCalledWith(
        'Failed to parse DGE YAML from S3; continuing with partial data',
        expect.objectContaining({ templateId: 'ixd_gen_1_100', error: 'parse error' })
      );
    });
  });

  describe('artifact links and assets (S3)', () => {
    it('resolveReportPath is always null (no local filesystem paths)', async () => {
      const createMatchmakerService = loadCreateMatchmakerService();
      const service = createMatchmakerService(
        buildConfig({ dge: { s3: { bucket: 'dge-bucket' } } }),
        createMockLogger()
      );
      expect(await service.resolveReportPath('ixd_gen_1_100')).toBeNull();
    });

    it('getReportHtml reads from S3 in S3 mode', async () => {
      const createMatchmakerService = loadCreateMatchmakerService();
      const catalog = makeCatalog({
        ixd: {
          design: {
            a: {
              template_id: 'ixd_gen_1_100',
              throughput: 100,
              region: 'NA',
              report_path: 'reports/r1.html',
            },
          },
        },
      });
      s3SendMock
        .mockResolvedValueOnce({ Body: Buffer.from(JSON.stringify(catalog)) })
        .mockResolvedValueOnce({ Body: Buffer.from('<html>s3report</html>') });

      const service = createMatchmakerService(
        buildConfig({ dge: { s3: { bucket: 'dge-bucket' } } }),
        createMockLogger()
      );

      const html = await service.getReportHtml('ixd_gen_1_100');
      expect(html).toBe('<html>s3report</html>');
      expect(s3SendMock).toHaveBeenCalledTimes(2);
    });

    it('getAsset returns buffer + contentType from S3 and null on missing', async () => {
      const createMatchmakerService = loadCreateMatchmakerService();
      s3SendMock.mockResolvedValueOnce({ Body: Buffer.from('asset'), ContentType: 'image/png' });

      const logger = createMockLogger();
      const service = createMatchmakerService(
        buildConfig({ dge: { s3: { bucket: 'dge-bucket' } } }),
        logger
      );
      const asset = await service.getAsset('img.png');

      expect(asset?.body.toString('utf-8')).toBe('asset');
      expect(asset?.contentType).toBe('image/png');

      s3SendMock.mockRejectedValueOnce(new Error('not found'));
      const missing = await service.getAsset('missing.png');
      expect(missing).toBeNull();
      expect(logger.warn).toHaveBeenCalledWith(
        'Failed to read DGE object from S3',
        expect.objectContaining({ key: expect.stringContaining('missing.png') })
      );
    });
  });
});
