import type { AttributeMap } from '@amzn/global-realty-mosaic-graphql-schema';

import {
  createKitMappers,
  type KitRecord,
  type KitVersionWithRelations,
  type StandardVersionWithStandard,
} from '../../../modules/kits/domain/kitMappers';

describe('kitMappers', () => {
  const now = new Date('2024-04-01T00:00:00.000Z');

  const standardVersion: StandardVersionWithStandard = {
    id: 'standard-version-1',
    standardId: 'standard-1',
    accFolderId: 'folder-1',
    accFileId: 'file-1',
    version: 'v1',
    isLatest: true,
    createdAt: now,
    updatedAt: now,
    standard: {
      id: 'standard-1',
      accProjectId: 'project-1',
      name: 'Safety Standard',
      description: 'Desc',
      createdAt: now,
      updatedAt: now,
    } as any,
  } as StandardVersionWithStandard;

  const kitVersion: KitVersionWithRelations = {
    id: 'kit-version-1',
    kitId: 'kit-1',
    version: 'v1',
    isLatest: true,
    createdAt: now,
    updatedAt: now,
    kit: {
      id: 'kit-1',
      name: 'Mechanical Kit',
      description: 'Kit description',
      createdAt: now,
      updatedAt: now,
    } as any,
    standards: [
      {
        standardVersion,
      },
    ],
  } as KitVersionWithRelations;

  const kitRecord: KitRecord = {
    id: 'kit-1',
    name: 'Mechanical Kit',
    description: 'Kit description',
    createdAt: now,
    updatedAt: now,
    versions: [kitVersion],
  } as KitRecord;

  const attributeLoader = jest.fn<Promise<AttributeMap>, [string]>(async (id) => ({
    marker: `loaded-${id}`,
  }));

  const { toStandardVersionGraph, toKitVersionGraph, toKitGraph } =
    createKitMappers(attributeLoader);

  beforeEach(() => {
    attributeLoader.mockClear();
  });

  it('maps standard versions with attribute loader', async () => {
    const graph = await toStandardVersionGraph(standardVersion);

    expect(attributeLoader).toHaveBeenCalledWith('standard-version-1');
    expect(graph.attributes).toEqual({ marker: 'loaded-standard-version-1' });
    expect(graph.standard?.id).toBe('standard-1');
  });

  it('maps kit versions including nested standards', async () => {
    const graph = await toKitVersionGraph(kitVersion);

    expect(attributeLoader).toHaveBeenCalledWith('kit-version-1');
    expect(graph.standards).toHaveLength(1);
    expect(graph.attributes).toEqual({ marker: 'loaded-kit-version-1' });
  });

  it('maps kits and selects latest version', async () => {
    const graph = await toKitGraph(kitRecord);

    expect(graph.latestVersion?.id).toBe('kit-version-1');
    expect(graph.versions).toHaveLength(1);
  });
});
