import { createKitModule } from '../../../modules/kits';
import type { StandardService } from '../../../modules/standards/domain/standardService';
import type { Logger } from '../../../shared';
import { createKitService } from '../../../modules/kits/domain/kitService';
import { createKitResolvers } from '../../../modules/kits/graphql/resolvers';

jest.mock('../../../modules/kits/domain/kitService', () => ({
  createKitService: jest.fn(),
}));

jest.mock('../../../modules/kits/graphql/resolvers', () => ({
  createKitResolvers: jest.fn(),
}));

const mockedCreateKitService = createKitService as jest.MockedFunction<typeof createKitService>;
const mockedCreateKitResolvers = createKitResolvers as jest.MockedFunction<
  typeof createKitResolvers
>;

const createMockLogger = (): jest.Mocked<Logger> => {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;

  logger.child.mockReturnValue(logger);
  return logger;
};

describe('createKitModule', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('creates kit module with scoped logger, service, and resolvers', () => {
    const service = { search: jest.fn() } as any;
    const resolvers = { Query: {}, Mutation: {} } as any;
    mockedCreateKitService.mockReturnValue(service);
    mockedCreateKitResolvers.mockReturnValue(resolvers);

    const moduleLogger = createMockLogger();
    const rootLogger = createMockLogger();
    rootLogger.child.mockReturnValue(moduleLogger);

    const module = createKitModule({
      logger: rootLogger,
      standardService: { search: jest.fn() } as unknown as StandardService,
    });

    expect(rootLogger.child).toHaveBeenCalledWith({ module: 'kits' });
    expect(moduleLogger.child).toHaveBeenCalledWith({ component: 'service' });
    expect(mockedCreateKitResolvers).toHaveBeenCalledWith({ kitService: service });
    expect(module).toEqual({ resolvers, service });
  });
});
