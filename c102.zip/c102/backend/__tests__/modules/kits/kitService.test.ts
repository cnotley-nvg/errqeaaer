import { createKitService } from '../../../modules/kits/domain/kitService';
import type { StandardService } from '../../../modules/standards/domain/standardService';
import { loadAttributes, storeAttributes } from '../../../modules/shared/attributeStore';
import type { Logger } from '../../../shared';
import type { KitVersionWithRelations } from '../../../modules/kits/domain/kitMappers';

jest.mock('../../../modules/shared/attributeStore', () => ({
  loadAttributes: jest.fn(),
  storeAttributes: jest.fn(),
}));

jest.mock('../../../lib/prisma', () => ({
  prisma: {
    kit: {
      count: jest.fn(),
      findMany: jest.fn(),
      findUnique: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    kitVersion: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      updateMany: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    standardVersion: {
      findMany: jest.fn(),
    },
    kitVersionStandardLink: {
      deleteMany: jest.fn(),
      create: jest.fn(),
      delete: jest.fn(),
    },
    $transaction: jest.fn(),
  },
}));

const { prisma } = require('../../../lib/prisma') as {
  prisma: {
    kit: {
      count: jest.Mock;
      findMany: jest.Mock;
      findUnique: jest.Mock;
      create: jest.Mock;
      update: jest.Mock;
      delete: jest.Mock;
    };
    kitVersion: {
      findUnique: jest.Mock;
      findMany: jest.Mock;
      create: jest.Mock;
      updateMany: jest.Mock;
      update: jest.Mock;
      delete: jest.Mock;
    };
    standardVersion: {
      findMany: jest.Mock;
    };
    kitVersionStandardLink: {
      deleteMany: jest.Mock;
      create: jest.Mock;
      delete: jest.Mock;
    };
    $transaction: jest.Mock;
  };
};

const mockedLoadAttributes = loadAttributes as jest.MockedFunction<typeof loadAttributes>;
const mockedStoreAttributes = storeAttributes as jest.MockedFunction<typeof storeAttributes>;

const createLogger = (): jest.Mocked<Logger> => {
  const logger = {
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
    child: jest.fn(),
  } as unknown as jest.Mocked<Logger>;

  logger.child.mockReturnValue(logger);
  return logger;
};

const buildKitRecord = (id: string) => {
  const createdAt = new Date('2024-01-01T00:00:00Z');
  const updatedAt = new Date('2024-01-02T00:00:00Z');

  return {
    id,
    name: `Kit ${id}`,
    description: null,
    createdAt,
    updatedAt,
    versions: [
      {
        id: `${id}-v1`,
        kitId: id,
        version: '1.0.0',
        isLatest: true,
        createdAt,
        updatedAt,
        kit: {
          id,
          name: `Kit ${id}`,
          description: null,
          createdAt,
          updatedAt,
        },
        standards: [],
      },
    ],
  };
};

const buildKitVersionRecord = (
  kitId: string,
  versionId = `${kitId}-v1`,
  overrides: Partial<KitVersionWithRelations> = {}
): KitVersionWithRelations => {
  const createdAt = new Date('2024-01-01T00:00:00Z');
  const updatedAt = new Date('2024-01-02T00:00:00Z');

  const base: KitVersionWithRelations = {
    id: versionId,
    kitId,
    version: versionId.includes('-v2') ? '2.0.0' : '1.0.0',
    isLatest: versionId.endsWith('-v1'),
    createdAt,
    updatedAt,
    kit: {
      id: kitId,
      name: `Kit ${kitId}`,
      description: null,
      createdAt,
      updatedAt,
    },
    standards: [] as KitVersionWithRelations['standards'],
  };

  return {
    ...base,
    ...overrides,
    kit: overrides.kit ?? base.kit,
    standards: overrides.standards ?? base.standards,
  };
};

describe('kitService', () => {
  beforeEach(() => {
    jest.clearAllMocks();

    mockedLoadAttributes.mockResolvedValue({});
    mockedStoreAttributes.mockResolvedValue();

    prisma.$transaction.mockImplementation(async (callback) => callback(prisma));
    prisma.kitVersionStandardLink.deleteMany.mockResolvedValue(undefined);
    prisma.kitVersionStandardLink.create.mockResolvedValue(undefined);
    prisma.standardVersion.findMany.mockImplementation(async ({ where }) => {
      const ids: readonly string[] = where?.id?.in ?? [];
      const catalog = [{ id: 'sv-1' }, { id: 'sv-2' }];
      if (!ids.length) {
        return catalog;
      }
      return catalog.filter((entry) => ids.includes(entry.id));
    });
    prisma.kitVersion.findUnique.mockImplementation(async ({ where }) => {
      if (!where?.id) {
        return null;
      }

      const [kitId] = where.id.split('-v');
      return buildKitVersionRecord(kitId ?? 'kit-1', where.id);
    });
    prisma.kitVersion.findMany.mockResolvedValue([{ id: 'kit-1-v1', isLatest: true }]);
  });

  const createStandardServiceMock = (): jest.Mocked<StandardService> =>
    ({
      search: jest
        .fn()
        .mockResolvedValue({ items: [], total: 0, pageIdx: 0, limit: 500, hasNext: false }),
      searchLatestStandardVersions: jest
        .fn()
        .mockResolvedValue({ items: [], total: 0, pageIdx: 0, limit: 500, hasNext: false }),
    }) as unknown as jest.Mocked<StandardService>;

  const service = (standardService: jest.Mocked<StandardService> = createStandardServiceMock()) =>
    createKitService(createLogger(), standardService);

  it('searches kits and returns paged results', async () => {
    const record = buildKitRecord('kit-1');
    prisma.kit.count.mockResolvedValue(1);
    prisma.kit.findMany.mockResolvedValue([record]);

    const result = await service().search({ pageIdx: 0, limit: 10 } as never);

    expect(prisma.kit.count).toHaveBeenCalledWith(expect.any(Object));
    expect(prisma.kit.findMany).toHaveBeenCalled();
    expect(result.total).toBe(1);
    expect(result.items[0]?.id).toBe('kit-1');
  });

  it('searchPublishedKits applies a published constraint (has latest version)', async () => {
    const record = buildKitRecord('kit-1');
    prisma.kit.count.mockResolvedValue(1);
    prisma.kit.findMany.mockResolvedValue([record]);

    const result = await service().searchPublishedKits({ pageIdx: 0, limit: 10 } as never);

    expect(prisma.kit.count).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          versions: { some: { isLatest: true } },
        }),
      })
    );
    expect(prisma.kit.findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          versions: { some: { isLatest: true } },
        }),
      })
    );
    expect(result.total).toBe(1);
  });

  it('creates a kit with an initial version and standard links', async () => {
    prisma.kit.findUnique
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(buildKitRecord('kit-1'));
    prisma.kit.create.mockResolvedValue({ id: 'kit-1' });
    prisma.kitVersion.create.mockResolvedValue({ id: 'kit-1-v1' });

    const result = await service().createKit({
      name: 'Kit 1',
      desc: 'Test kit',
      initialVersion: {
        version: '1.0.0',
        standardVersionIds: ['sv-1', 'sv-2'],
        attributes: {},
      },
    } as never);

    expect(result.success).toBe(true);
    expect(prisma.kit.create).toHaveBeenCalledWith({
      data: {
        name: 'Kit 1',
        description: 'Test kit',
      },
    });
    expect(prisma.kitVersion.create).toHaveBeenCalledWith({
      data: expect.objectContaining({ kitId: 'kit-1', version: '1.0.0', isLatest: true }),
    });
    expect(prisma.kitVersionStandardLink.deleteMany).toHaveBeenCalledWith({
      where: { kitVersionId: 'kit-1-v1' },
    });
    expect(prisma.kitVersionStandardLink.create).toHaveBeenCalledTimes(2);
    expect(mockedStoreAttributes).toHaveBeenCalledWith(prisma, 'KIT_VERSION', 'kit-1-v1', {
      createdBy: 'system',
    });
  });

  it('persists KIT_VERSION.attributes.createdBy from authenticated username (overrides client value)', async () => {
    prisma.kit.findUnique
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(buildKitRecord('kit-1'));
    prisma.kit.create.mockResolvedValue({ id: 'kit-1' });
    prisma.kitVersion.create.mockResolvedValue({ id: 'kit-1-v1' });

    const result = await service().createKit(
      {
        name: 'Kit 1',
        initialVersion: {
          version: '1.0.0',
          standardVersionIds: ['sv-1'],
          attributes: {
            region: 'NA',
            createdBy: 'spoofed-user',
            program: 'AMZL',
          },
        },
      } as never,
      { username: 'real-user', groups: [] } as any
    );

    expect(result.success).toBe(true);
    expect(mockedStoreAttributes).toHaveBeenCalledWith(prisma, 'KIT_VERSION', 'kit-1-v1', {
      region: 'NA',
      program: 'AMZL',
      createdBy: 'real-user',
    });
  });

  it('defaults KIT_VERSION.attributes.createdBy to system when unauthenticated (and overrides client value)', async () => {
    prisma.kit.findUnique
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(buildKitRecord('kit-1'));
    prisma.kit.create.mockResolvedValue({ id: 'kit-1' });
    prisma.kitVersion.create.mockResolvedValue({ id: 'kit-1-v1' });

    const result = await service().createKit(
      {
        name: 'Kit 1',
        initialVersion: {
          version: '1.0.0',
          standardVersionIds: ['sv-1'],
          attributes: {
            region: 'EU',
            createdBy: 'spoofed-user',
          },
        },
      } as never,
      null
    );

    expect(result.success).toBe(true);
    expect(mockedStoreAttributes).toHaveBeenCalledWith(prisma, 'KIT_VERSION', 'kit-1-v1', {
      region: 'EU',
      createdBy: 'system',
    });
  });

  it('loads an individual kit with mapped relations', async () => {
    const record = buildKitRecord('kit-1');
    prisma.kit.findUnique.mockResolvedValue(record);

    const kit = await service().getKit('kit-1');

    expect(kit?.id).toBe('kit-1');
    expect(kit?.latestVersion?.version).toBe('1.0.0');
  });

  it('updates kit metadata', async () => {
    prisma.kit.findUnique
      .mockResolvedValueOnce({ id: 'kit-1', name: 'Kit 1' })
      .mockResolvedValueOnce(buildKitRecord('kit-1'));
    prisma.kit.update.mockResolvedValue({ id: 'kit-1' });

    const result = await service().updateKit('kit-1', {
      name: 'New Kit',
      desc: 'Updated',
    } as never);

    expect(result.success).toBe(true);
    expect(prisma.kit.update).toHaveBeenCalledWith({
      where: { id: 'kit-1' },
      data: { name: 'New Kit', description: 'Updated' },
    });
  });

  it('fails to create a kit when name already exists', async () => {
    prisma.kit.findUnique.mockResolvedValue({ id: 'existing-kit' });

    const result = await service().createKit({ name: 'Duplicate' } as never);

    expect(result.success).toBe(false);
    expect(prisma.kit.create).not.toHaveBeenCalled();
  });

  it('rejects direct kit version mutation (immutable versions)', async () => {
    prisma.kitVersion.findUnique.mockReset();
    prisma.kitVersion.findUnique.mockResolvedValueOnce({ id: 'kit-1-v1', kitId: 'kit-1' });

    const result = await service().updateKitVersion('kit-1-v1', {
      version: '2.0.0',
      attributes: { region: 'EU' },
    } as never);

    expect(result.success).toBe(false);

    expect(prisma.kitVersion.update).not.toHaveBeenCalled();
  });

  it('updates kit version latest flag only', async () => {
    prisma.kitVersion.findUnique.mockResolvedValueOnce({ id: 'kit-1-v1', kitId: 'kit-1' });
    prisma.kitVersion.update.mockResolvedValueOnce(undefined as never);
    prisma.kitVersion.updateMany.mockResolvedValueOnce(undefined as never);
    prisma.kitVersion.findMany.mockResolvedValueOnce([{ id: 'kit-1-v1', isLatest: false }]);

    const result = await service().updateKitVersion('kit-1-v1', { isLatest: true } as never);

    expect(result.success).toBe(true);
    expect(prisma.kitVersion.update).toHaveBeenCalled();
  });

  it('deletes a kit version and ensures latest flag is recalculated', async () => {
    prisma.kitVersion.findUnique.mockImplementationOnce(async () => ({
      kitId: 'kit-1',
      isLatest: false,
    }));
    prisma.kitVersion.delete.mockResolvedValue(undefined);

    const result = await service().deleteKitVersion('kit-1-v1');

    expect(result.success).toBe(true);
    expect(prisma.kitVersion.delete).toHaveBeenCalledWith({ where: { id: 'kit-1-v1' } });
  });

  it('marks a kit version as latest', async () => {
    prisma.kitVersion.findUnique.mockReset();
    prisma.kitVersion.findUnique
      .mockResolvedValueOnce({ kitId: 'kit-1' })
      .mockResolvedValueOnce(buildKitVersionRecord('kit-1', 'kit-1-v2'));

    const result = await service().setLatestKitVersion('kit-1-v2');

    expect(result.success).toBe(true);
    expect(prisma.kitVersion.updateMany).toHaveBeenCalledWith({
      data: { isLatest: false },
      where: { kitId: 'kit-1' },
    });
    expect(prisma.kitVersion.update).toHaveBeenCalledWith({
      data: { isLatest: true },
      where: { id: 'kit-1-v2' },
    });
  });

  it('lists kit versions with loaded attributes', async () => {
    const kitRecord = buildKitRecord('kit-1');
    prisma.kit.findUnique.mockResolvedValue({
      ...kitRecord,
      versions: [
        buildKitVersionRecord('kit-1', 'kit-1-v2', { isLatest: false }),
        buildKitVersionRecord('kit-1', 'kit-1-v1'),
      ],
    });

    mockedLoadAttributes
      .mockImplementationOnce(async () => ({ capacity: 200 }))
      .mockImplementationOnce(async () => ({ capacity: 100 }));

    const versions = await service().listKitVersions('kit-1');

    expect(prisma.kit.findUnique).toHaveBeenCalledWith({
      where: { id: 'kit-1' },
      include: expect.any(Object),
    });
    expect(versions).toHaveLength(2);
    expect(mockedLoadAttributes).toHaveBeenNthCalledWith(1, expect.anything(), 'kit-1-v2');
    expect(versions[0]?.attributes).toEqual({ capacity: 200 });
  });

  it('retrieves a kit version with linked standards', async () => {
    const createdAt = new Date('2024-01-01T00:00:00Z');
    const updatedAt = new Date('2024-01-02T00:00:00Z');

    prisma.kitVersion.findUnique.mockResolvedValueOnce(
      buildKitVersionRecord('kit-1', 'kit-1-v1', {
        standards: [
          {
            standardVersion: {
              id: 'std-1-v1',
              standardId: 'std-1',
              accFolderId: 'folder-std',
              accFileId: 'file-std',
              version: '1.0.0',
              isLatest: true,
              createdAt,
              updatedAt,
              standard: {
                id: 'std-1',
                accProjectId: 'proj-std',
                name: 'Fire Safety',
                description: null,
                createdAt,
                updatedAt,
              },
            },
          },
        ],
      })
    );

    mockedLoadAttributes
      .mockImplementationOnce(async () => ({ rating: 'A' }))
      .mockImplementationOnce(async () => ({ zone: 'NA' }));

    const version = await service().getKitVersion('kit-1-v1');

    expect(version?.standards[0]?.standard?.name).toBe('Fire Safety');
    expect(mockedLoadAttributes).toHaveBeenNthCalledWith(1, expect.anything(), 'kit-1-v1');
    expect(mockedLoadAttributes).toHaveBeenNthCalledWith(2, expect.anything(), 'std-1-v1');
  });

  it('creates a kit version and updates latest flags', async () => {
    prisma.kit.findUnique.mockResolvedValueOnce({ id: 'kit-1' });
    prisma.kitVersion.create.mockResolvedValue({ id: 'kit-1-v2' });

    const result = await service().createKitVersion('kit-1', {
      version: '2.0.0',
      standardVersionIds: ['sv-1'],
      attributes: { zone: 'NA' },
    } as never);

    expect(result.success).toBe(true);
    expect(prisma.kitVersion.create).toHaveBeenCalledWith({
      data: expect.objectContaining({ kitId: 'kit-1', version: '2.0.0', isLatest: false }),
    });
    expect(prisma.kitVersion.updateMany).toHaveBeenCalledWith({
      data: { isLatest: false },
      where: { kitId: 'kit-1' },
    });
    expect(mockedStoreAttributes).toHaveBeenCalledWith(
      expect.anything(),
      'KIT_VERSION',
      'kit-1-v2',
      { zone: 'NA' }
    );
  });

  it('fails to create a kit version when the kit is missing', async () => {
    prisma.kit.findUnique.mockResolvedValueOnce(null);

    const result = await service().createKitVersion('unknown-kit', {
      version: '1.0.0',
      standardVersionIds: ['sv-1'],
    } as never);

    expect(result.success).toBe(false);
    expect(result.message).toContain('Kit not found');
  });

  it('validates standard version presence when creating a kit version', async () => {
    prisma.kit.findUnique.mockResolvedValueOnce({ id: 'kit-1' });
    prisma.standardVersion.findMany.mockResolvedValueOnce([]);

    const result = await service().createKitVersion('kit-1', {
      version: '1.0.1',
      standardVersionIds: ['missing'],
    } as never);

    expect(result.success).toBe(false);
    expect(result.message).toContain('standard versions could not be found');
    expect(prisma.kitVersion.create).not.toHaveBeenCalled();
  });

  it('returns false when a kit name already exists', async () => {
    prisma.kit.findUnique.mockResolvedValueOnce({ id: 'kit-existing' });

    const exists = await service().isKitNameAvailable('Existing Kit');
    expect(exists).toBe(false);
    expect(prisma.kit.findUnique).toHaveBeenCalledWith({ where: { name: 'Existing Kit' } });
  });

  it('links and unlinks standards from kit versions', async () => {
    prisma.standardVersion.findMany
      .mockResolvedValueOnce([{ id: 'sv-1' }])
      .mockResolvedValueOnce([]);

    const resultLink = await service().linkStandardVersion('kit-1-v1', 'sv-1');

    expect(resultLink).toBe(true);
    expect(prisma.kitVersionStandardLink.create).toHaveBeenCalledWith({
      data: { kitVersionId: 'kit-1-v1', standardVersionId: 'sv-1' },
    });

    const resultLinkFailure = await service().linkStandardVersion('kit-1-v1', 'sv-missing');
    expect(resultLinkFailure).toBe(false);

    prisma.kitVersionStandardLink.delete.mockResolvedValue(undefined);
    const resultUnlink = await service().unlinkStandardVersion('kit-1-v1', 'sv-1');
    expect(resultUnlink).toBe(true);
    expect(prisma.kitVersionStandardLink.delete).toHaveBeenCalledWith({
      where: {
        kitVersionId_standardVersionId: { kitVersionId: 'kit-1-v1', standardVersionId: 'sv-1' },
      },
    });
  });

  it('deletes a kit successfully', async () => {
    prisma.kit.delete.mockResolvedValueOnce(undefined);

    const result = await service().deleteKit('kit-1');

    expect(result.success).toBe(true);
    expect(prisma.kit.delete).toHaveBeenCalledWith({ where: { id: 'kit-1' } });
  });

  it('fails to set latest kit version when version does not exist', async () => {
    prisma.kitVersion.findUnique.mockReset();
    prisma.kitVersion.findUnique.mockResolvedValueOnce(null);

    const result = await service().setLatestKitVersion('missing-version');

    expect(result.success).toBe(false);
    expect(result.message).toContain('Kit version not found');
  });

  it('builds kitOptions from latest standard versions and attributes', async () => {
    prisma.standardVersion.findMany.mockResolvedValueOnce([
      {
        id: 'sv-1',
        standardId: 'std-1',
        isLatest: true,
        standard: { id: 'std-1', name: 'Std One' },
      },
      {
        id: 'sv-2',
        standardId: 'std-2',
        isLatest: true,
        standard: { id: 'std-2', name: 'Std Two' },
      },
    ]);

    mockedLoadAttributes
      .mockImplementationOnce(async () => ({
        region: ['NA', '  EU '],
        program: 'GEN5',
        useCase: ['Retrofit', 'retrofit'],
        roomFeatureZone: 'Zone A',
        dataType: ['Telemetry', 'telemetry'],
      }))
      .mockImplementationOnce(async () => ({
        region: 'APAC',
        program: 'GEN4',
        useCase: 'New Build',
        roomFeatureZone: ['Zone B', 'Zone A'],
        dataType: 'BIM',
      }));

    const result = await service().kitOptions();

    expect(result.regions).toEqual(['APAC', 'EU', 'NA']);
    expect(result.programs).toEqual(['GEN4', 'GEN5']);
    expect([...result.useCases].sort()).toEqual(['New Build', 'Retrofit', 'retrofit'].sort());
    expect(result.roomFeatureZones).toEqual(['Zone A', 'Zone B']);
    expect([...result.dataTypes].sort()).toEqual(['BIM', 'Telemetry', 'telemetry'].sort());
  });

  it('returns compatible standards filtered by provided attributes', async () => {
    const standardService = createStandardServiceMock();
    standardService.searchLatestStandardVersions.mockResolvedValueOnce({
      items: [
        {
          id: 'std-1-v1',
          standardId: 'std-1',
          standard: {
            id: 'std-1',
            name: 'Fire Safety',
            description: null,
            accProjectId: 'proj-1',
            createdAt: '2024-01-01T00:00:00.000Z',
            updatedAt: '2024-01-02T00:00:00.000Z',
          },
          accFolderId: 'folder',
          accFileId: 'file',
          version: '1.0.0',
          isLatest: true,
          attributes: {
            region: 'NA',
            program: 'GEN5',
            useCase: 'Retrofit',
            roomFeatureZone: 'Zone A',
            dataType: 'Telemetry',
          },
          createdAt: '2024-01-01T00:00:00.000Z',
          updatedAt: '2024-01-02T00:00:00.000Z',
        },
      ],
      total: 1,
      pageIdx: 0,
      limit: 500,
      hasNext: false,
    } as never);

    const result = await service(standardService).kitCompatibleStandards({
      regions: ['NA'],
      programs: ['GEN5'],
      useCases: ['Retrofit'],
      roomFeatureZones: ['Zone A'],
      dataTypes: ['Telemetry'],
    } as never);

    expect(standardService.searchLatestStandardVersions).toHaveBeenCalledWith(
      expect.objectContaining({ limit: 500, orderBy: 'name', orderDesc: false })
    );
    expect(result).toEqual([
      {
        id: 'std-1-v1',
        standardId: 'std-1',
        standardName: 'Fire Safety',
        version: '1.0.0',
        region: 'NA',
        program: ['GEN5'],
        useCase: 'Retrofit',
        roomFeatureZone: ['Zone A'],
        dataType: 'Telemetry',
        projectType: null,
      },
    ]);
  });

  it('searches kits with attribute-based filters and in-memory pagination', async () => {
    const kit1 = buildKitRecord('kit-1');
    const kit2 = buildKitRecord('kit-2');

    prisma.kit.findMany.mockResolvedValueOnce([kit1, kit2]);

    mockedLoadAttributes
      .mockImplementationOnce(async () => ({ region: 'NA' }))
      .mockImplementationOnce(async () => ({ region: 'EU' }));

    const result = await service().search({
      pageIdx: 0,
      limit: 10,
      query: {
        operation: 'AND',
        tokenGroups: [{ propertyKey: 'region', operator: 'EQUALS', value: 'NA' }],
      },
    } as never);

    expect(prisma.kit.findMany).toHaveBeenCalled();
    expect(prisma.kit.count).not.toHaveBeenCalled();
    expect(result.total).toBe(1);
    expect(result.items).toHaveLength(1);
    expect(result.items[0]?.id).toBe('kit-1');
    expect(result.hasNext).toBe(false);
  });

  it('returns null for unknown kit version', async () => {
    prisma.kitVersion.findUnique.mockReset();
    prisma.kitVersion.findUnique.mockResolvedValueOnce(null);

    const version = await service().getKitVersion('missing-version');
    expect(version).toBeNull();
  });

  it('fails to delete kit version that does not exist', async () => {
    prisma.kitVersion.findUnique.mockReset();
    prisma.kitVersion.findUnique.mockResolvedValueOnce(null);

    const result = await service().deleteKitVersion('missing-version');

    expect(result.success).toBe(false);
    expect(result.message).toContain('Kit version not found');
    expect(prisma.kitVersion.delete).not.toHaveBeenCalled();
  });

  it('rejects updateKit when the kit does not exist', async () => {
    prisma.kit.findUnique.mockResolvedValueOnce(null);

    const result = await service().updateKit('missing-kit', { name: 'Nope' } as never);

    expect(result.success).toBe(false);
    expect(typeof result.message).toBe('string');
  });

  it('returns true from isKitNameAvailable when name is unused', async () => {
    prisma.kit.findUnique.mockResolvedValueOnce(null);

    const available = await service().isKitNameAvailable('Available Kit');

    expect(available).toBe(true);
  });

  it('fails to create a kit when initialVersion has no standardVersionIds', async () => {
    prisma.kit.findUnique
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(buildKitRecord('kit-1'));

    prisma.kit.create.mockResolvedValue({ id: 'kit-1' });

    const result = await service().createKit({
      name: 'Kit 1',
      initialVersion: {
        version: '1.0.0',
        standardVersionIds: [],
        attributes: {},
      },
    } as never);

    expect(result.success).toBe(false);
    expect(prisma.kitVersion.create).not.toHaveBeenCalled();
  });

  it('surfaces deleteKit failures with error message', async () => {
    prisma.kit.delete.mockRejectedValueOnce(new Error('db failure'));

    const result = await service().deleteKit('kit-1');

    expect(result.success).toBe(false);
    expect(result.message).toContain('db failure');
  });
});
