import { createKitResolvers } from '../../../modules/kits/graphql/resolvers';

describe('createKitResolvers', () => {
  const kitService = {
    search: jest.fn().mockResolvedValue('search-result'),
    searchPublishedKits: jest.fn().mockResolvedValue('published-search-result'),
    getKit: jest.fn().mockResolvedValue('kit-by-id'),
    getKitByName: jest.fn().mockResolvedValue('kit-by-name'),
    getKitVersion: jest.fn().mockResolvedValue('kit-version'),
    listKitVersions: jest.fn().mockResolvedValue(['v1', 'v2']),
    isKitNameAvailable: jest.fn().mockResolvedValue(true),
    kitOptions: jest.fn().mockResolvedValue({ regions: ['NA'] }),
    kitCompatibleStandards: jest.fn().mockResolvedValue(['std-1']),

    createKit: jest.fn().mockResolvedValue('created-kit'),
    updateKit: jest.fn().mockResolvedValue('updated-kit'),
    deleteKit: jest.fn().mockResolvedValue('deleted-kit'),
    createKitVersion: jest.fn().mockResolvedValue('created-version'),
    updateKitVersion: jest.fn().mockResolvedValue('updated-version'),
    deleteKitVersion: jest.fn().mockResolvedValue('deleted-version'),
    setLatestKitVersion: jest.fn().mockResolvedValue('latest-set'),
    linkStandardVersion: jest.fn().mockResolvedValue('linked'),
    unlinkStandardVersion: jest.fn().mockResolvedValue('unlinked'),
  } as const;

  const resolvers = createKitResolvers({ kitService: kitService as any });

  describe('Query resolvers', () => {
    it('searchKits delegates to kitService.search', async () => {
      const filter = { pageIdx: 0 } as any;
      await expect(resolvers.Query.searchKits({}, { filter })).resolves.toBe('search-result');
      expect(kitService.search).toHaveBeenCalledWith(filter);
    });

    it('searchPublishedKits delegates to kitService.searchPublishedKits', async () => {
      const filter = { pageIdx: 0, limit: 20 } as any;
      await expect(resolvers.Query.searchPublishedKits({}, { filter })).resolves.toBe(
        'published-search-result'
      );
      expect(kitService.searchPublishedKits).toHaveBeenCalledWith(filter);
    });

    it('kit delegates to kitService.getKit', async () => {
      await expect(resolvers.Query.kit({}, { id: 'kid' })).resolves.toBe('kit-by-id');
      expect(kitService.getKit).toHaveBeenCalledWith('kid');
    });

    it('kitByName delegates to kitService.getKitByName', async () => {
      await expect(resolvers.Query.kitByName({}, { name: 'K' })).resolves.toBe('kit-by-name');
      expect(kitService.getKitByName).toHaveBeenCalledWith('K');
    });

    it('kitVersion delegates to kitService.getKitVersion', async () => {
      await expect(resolvers.Query.kitVersion({}, { id: 'ver' })).resolves.toBe('kit-version');
      expect(kitService.getKitVersion).toHaveBeenCalledWith('ver');
    });

    it('kitVersions delegates to kitService.listKitVersions', async () => {
      await expect(resolvers.Query.kitVersions({}, { kitId: 'kid' })).resolves.toEqual([
        'v1',
        'v2',
      ]);
      expect(kitService.listKitVersions).toHaveBeenCalledWith('kid');
    });

    it('isKitNameAvailable delegates to kitService.isKitNameAvailable', async () => {
      await expect(resolvers.Query.isKitNameAvailable({}, { name: 'Name' })).resolves.toBe(true);
      expect(kitService.isKitNameAvailable).toHaveBeenCalledWith('Name');
    });

    it('kitOptions delegates to kitService.kitOptions', async () => {
      await expect(resolvers.Query.kitOptions({}, {} as any)).resolves.toEqual({ regions: ['NA'] });
      expect(kitService.kitOptions).toHaveBeenCalled();
    });

    it('kitCompatibleStandards delegates correctly', async () => {
      const input = { regions: ['NA'] } as any;
      await expect(resolvers.Query.kitCompatibleStandards({}, { input })).resolves.toEqual([
        'std-1',
      ]);
      expect(kitService.kitCompatibleStandards).toHaveBeenCalledWith(input);
    });
  });

  describe('Mutation resolvers', () => {
    it('createKit', async () => {
      const input = { name: 'NewKit' } as any;
      await expect(
        resolvers.Mutation.createKit({}, { input }, { user: null } as any)
      ).resolves.toBe('created-kit');
      expect(kitService.createKit).toHaveBeenCalledWith(input, null);
    });

    it('createKit passes authenticated user through to kitService', async () => {
      const input = { name: 'NewKit' } as any;
      const user = { username: 'real-user', groups: [] } as any;

      await expect(resolvers.Mutation.createKit({}, { input }, { user } as any)).resolves.toBe(
        'created-kit'
      );

      expect(kitService.createKit).toHaveBeenCalledWith(input, user);
    });

    it('updateKit', async () => {
      const input = { desc: 'Updated' } as any;
      await expect(resolvers.Mutation.updateKit({}, { id: 'kid', input })).resolves.toBe(
        'updated-kit'
      );
      expect(kitService.updateKit).toHaveBeenCalledWith('kid', input);
    });

    it('deleteKit', async () => {
      await expect(resolvers.Mutation.deleteKit({}, { id: 'kid' })).resolves.toBe('deleted-kit');
      expect(kitService.deleteKit).toHaveBeenCalledWith('kid');
    });

    it('createKitVersion', async () => {
      const input = { version: 'v1' } as any;
      await expect(resolvers.Mutation.createKitVersion({}, { kitId: 'kid', input })).resolves.toBe(
        'created-version'
      );
      expect(kitService.createKitVersion).toHaveBeenCalledWith('kid', input);
    });

    it('updateKitVersion', async () => {
      const input = { isLatest: true } as any;
      await expect(resolvers.Mutation.updateKitVersion({}, { id: 'kv', input })).resolves.toBe(
        'updated-version'
      );
      expect(kitService.updateKitVersion).toHaveBeenCalledWith('kv', input);
    });

    it('deleteKitVersion', async () => {
      await expect(resolvers.Mutation.deleteKitVersion({}, { id: 'kv' })).resolves.toBe(
        'deleted-version'
      );
      expect(kitService.deleteKitVersion).toHaveBeenCalledWith('kv');
    });

    it('setLatestKitVersion', async () => {
      await expect(resolvers.Mutation.setLatestKitVersion({}, { id: 'kv' })).resolves.toBe(
        'latest-set'
      );
      expect(kitService.setLatestKitVersion).toHaveBeenCalledWith('kv');
    });

    it('linkStandardToKit', async () => {
      await expect(
        resolvers.Mutation.linkStandardToKit({}, { kitVersionId: 'kv', standardVersionId: 'sv' })
      ).resolves.toBe('linked');
      expect(kitService.linkStandardVersion).toHaveBeenCalledWith('kv', 'sv');
    });

    it('unlinkStandardFromKit', async () => {
      await expect(
        resolvers.Mutation.unlinkStandardFromKit(
          {},
          { kitVersionId: 'kv', standardVersionId: 'sv' }
        )
      ).resolves.toBe('unlinked');
      expect(kitService.unlinkStandardVersion).toHaveBeenCalledWith('kv', 'sv');
    });
  });
});
