import type { FilterInput } from '@amzn/global-realty-mosaic-graphql-schema';

import {
  buildOrderBy,
  buildWhere,
  kitFilterInternals,
} from '../../../modules/kits/domain/kitFilters';

describe('kitFilters', () => {
  const baseFilter: FilterInput = {
    pageIdx: 0,
    limit: 20,
    orderBy: 'createdAt',
    orderDesc: false,
    query: null,
  };

  describe('buildWhere', () => {
    it('builds OR clauses for multiple values', () => {
      const where = buildWhere({
        ...baseFilter,
        query: {
          operation: 'OR',
          tokenGroups: [
            { propertyKey: 'name', operator: 'STARTS_WITH', value: 'HVAC' },
            { propertyKey: 'desc', operator: 'CONTAINS', values: ['cooling', 'heating'] },
            {
              propertyKey: 'createdAt',
              operator: 'LESS_OR_EQUAL',
              value: '2024-05-02T00:00:00.000Z',
            },
          ],
        },
      });

      expect(where).toEqual({
        OR: [
          expect.objectContaining({ name: expect.objectContaining({ startsWith: 'HVAC' }) }),
          expect.objectContaining({
            OR: [
              expect.objectContaining({
                description: expect.objectContaining({ contains: 'cooling' }),
              }),
              expect.objectContaining({
                description: expect.objectContaining({ contains: 'heating' }),
              }),
            ],
          }),
          expect.objectContaining({
            createdAt: expect.objectContaining({ lte: new Date('2024-05-02T00:00:00.000Z') }),
          }),
        ],
      });
    });

    it('builds AND clauses for negative string filters and date comparisons', () => {
      const where = buildWhere({
        ...baseFilter,
        query: {
          operation: 'AND',
          tokenGroups: [
            { propertyKey: 'desc', operator: 'NOT_CONTAINS', value: 'deprecated' },
            { propertyKey: 'name', operator: 'NOT_STARTS_WITH', values: ['archived', 'legacy'] },
            {
              propertyKey: 'updatedAt',
              operator: 'GREATER_THAN',
              value: '2024-04-01T00:00:00.000Z',
            },
          ],
        },
      });

      const clauses = (where as any).AND;
      expect(Array.isArray(clauses)).toBe(true);
      expect(clauses).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            AND: expect.arrayContaining([
              expect.objectContaining({
                NOT: expect.objectContaining({ description: expect.any(Object) }),
              }),
            ]),
          }),
          expect.objectContaining({
            updatedAt: expect.objectContaining({ gt: new Date('2024-04-01T00:00:00.000Z') }),
          }),
        ])
      );

      const notStartsGroup = clauses.find(
        (entry: any) =>
          Array.isArray(entry.AND) && entry.AND.some((nested: any) => nested.NOT?.name)
      );
      expect(notStartsGroup).toBeDefined();
      expect(notStartsGroup.AND).toHaveLength(2);
      expect(notStartsGroup.AND).toEqual(
        expect.arrayContaining([
          expect.objectContaining({ NOT: expect.objectContaining({ name: expect.any(Object) }) }),
        ])
      );
    });

    it('returns empty query when no conditions produced', () => {
      const empty = buildWhere({
        ...baseFilter,
        query: {
          operation: 'AND',
          tokenGroups: [{ propertyKey: 'unknown', operator: 'EQUALS', value: '   ' }],
        },
      });

      expect(empty).toEqual({});
    });
  });

  describe('buildOrderBy', () => {
    it('respects known aliases', () => {
      expect(buildOrderBy({ ...baseFilter, orderBy: 'name', orderDesc: true })).toEqual({
        name: 'desc',
      });
      expect(buildOrderBy({ ...baseFilter, orderBy: 'description' })).toEqual({
        description: 'asc',
      });
    });

    it('defaults to createdAt desc', () => {
      expect(buildOrderBy({ ...baseFilter, orderBy: 'other' as any })).toEqual({
        createdAt: 'desc',
      });
    });
  });

  describe('internals', () => {
    it('collectTokenValues trims whitespace and skips empties', () => {
      const { collectTokenValues } = kitFilterInternals;

      expect(
        collectTokenValues({
          propertyKey: 'name',
          operator: 'EQUALS',
          values: ['  foo  ', '', 'bar'],
        } as any)
      ).toEqual(['  foo  ', 'bar']);
    });

    it('collectTokenValues handles single value property', () => {
      const { collectTokenValues } = kitFilterInternals;
      expect(
        collectTokenValues({
          propertyKey: 'desc',
          operator: 'CONTAINS',
          value: '  summary ',
        } as any)
      ).toEqual(['  summary ']);
    });

    it('parseDateValue returns null for invalid input', () => {
      const { parseDateValue } = kitFilterInternals;
      expect(parseDateValue('not-a-date')).toBeNull();
      expect(parseDateValue('2024-05-10T00:00:00.000Z')).toEqual(
        new Date('2024-05-10T00:00:00.000Z')
      );
    });
  });
});
