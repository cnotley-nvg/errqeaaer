import {
  ensureLatestKitVersionExists,
  linkStandardVersions,
  updateLatestKitVersionFlags,
  validateStandardVersions,
  type KitVersionStandardLinkMutations,
  type KitVersionMutations,
  type StandardVersionQueries,
} from '../../../modules/kits/domain/kitMutations';

describe('kitMutations', () => {
  it('validates that standard versions exist', async () => {
    const delegate: StandardVersionQueries = {
      findMany: jest.fn().mockResolvedValue([{ id: 'sv-1' }]),
    };

    await validateStandardVersions(delegate, ['sv-1']);

    expect(delegate.findMany).toHaveBeenCalledWith({ where: { id: { in: ['sv-1'] } } });
  });

  it('throws when standard versions are missing', async () => {
    const delegate: StandardVersionQueries = {
      findMany: jest.fn().mockResolvedValue([]),
    };

    await expect(validateStandardVersions(delegate, ['missing'])).rejects.toThrow(
      'One or more standard versions could not be found.'
    );
  });

  it('links standard versions by replacing existing links', async () => {
    const kitStandardLink: KitVersionStandardLinkMutations = {
      deleteMany: jest.fn().mockResolvedValue(undefined),
      create: jest.fn().mockResolvedValue(undefined),
    };

    await linkStandardVersions(kitStandardLink, 'kit-version-1', ['sv-1', 'sv-2']);

    expect(kitStandardLink.deleteMany).toHaveBeenCalledWith({
      where: { kitVersionId: 'kit-version-1' },
    });
    expect(kitStandardLink.create).toHaveBeenNthCalledWith(1, {
      data: { kitVersionId: 'kit-version-1', standardVersionId: 'sv-1' },
    });
    expect(kitStandardLink.create).toHaveBeenNthCalledWith(2, {
      data: { kitVersionId: 'kit-version-1', standardVersionId: 'sv-2' },
    });
  });

  it('updates latest kit version flags', async () => {
    const kitVersion: KitVersionMutations = {
      updateMany: jest.fn().mockResolvedValue(undefined),
      update: jest.fn().mockResolvedValue(undefined),
      findMany: jest.fn(),
    };

    await updateLatestKitVersionFlags(kitVersion, 'kit-1', 'kv-2');

    expect(kitVersion.updateMany).toHaveBeenCalledWith({
      data: { isLatest: false },
      where: { kitId: 'kit-1' },
    });
    expect(kitVersion.update).toHaveBeenCalledWith({
      data: { isLatest: true },
      where: { id: 'kv-2' },
    });
  });

  describe('ensureLatestKitVersionExists', () => {
    const buildDelegate = (
      records: Array<{ id: string; isLatest: boolean }>
    ): KitVersionMutations => ({
      updateMany: jest.fn(),
      update: jest.fn().mockResolvedValue(undefined),
      findMany: jest.fn().mockResolvedValue(records),
    });

    it('does nothing when versions are absent', async () => {
      const delegate = buildDelegate([]);
      await ensureLatestKitVersionExists(delegate, 'kit-1');
      expect(delegate.update).not.toHaveBeenCalled();
    });

    it('does nothing when a latest version already exists', async () => {
      const delegate = buildDelegate([
        { id: 'kv-1', isLatest: true },
        { id: 'kv-2', isLatest: false },
      ]);

      await ensureLatestKitVersionExists(delegate, 'kit-1');

      expect(delegate.update).not.toHaveBeenCalled();
    });

    it('marks the most recent version as latest when missing', async () => {
      const delegate = buildDelegate([
        { id: 'kv-1', isLatest: false },
        { id: 'kv-2', isLatest: false },
      ]);

      await ensureLatestKitVersionExists(delegate, 'kit-1');

      expect(delegate.update).toHaveBeenCalledWith({
        where: { id: 'kv-1' },
        data: { isLatest: true },
      });
    });
  });
});
