import { readFileSync } from 'node:fs';
import path from 'node:path';
import { ModuleKind, transpileModule } from 'typescript';

describe('backend entry point', () => {
  const entryPath = path.resolve(__dirname, '../index.ts');

  it('re-exports helpers without starting the server when imported', () => {
    const startServer = jest.fn();
    const getRuntimeConfig = jest.fn();

    jest.isolateModules(() => {
      jest.doMock('../server', () => ({ startServer }));
      jest.doMock('../config/runtimeConfig', () => ({ getRuntimeConfig }));

      const moduleExports = require('../index');

      expect(moduleExports.startServer).toBe(startServer);
      expect(moduleExports.getRuntimeConfig).toBe(getRuntimeConfig);
      expect(startServer).not.toHaveBeenCalled();
    });
  });

  it('starts the server when executed as the main module', () => {
    const source = readFileSync(entryPath, 'utf8');
    const startServer = jest.fn();
    const getRuntimeConfig = jest.fn();

    const fakeModule = {
      id: entryPath,
      filename: entryPath,
      exports: {},
      parent: module,
      loaded: false,
      children: [] as NodeModule[],
      paths: [],
      path: path.dirname(entryPath),
      isPreloading: false,
      require: undefined as unknown,
    } as unknown as NodeModule;

    const fakeRequire = ((requested: string) => {
      if (requested === 'dotenv/config') {
        return {};
      }

      if (requested === './server') {
        return { startServer };
      }

      if (requested === './createGraphqlServer') {
        return { createGraphqlServer: jest.fn() };
      }

      if (requested === './config/runtimeConfig') {
        return { getRuntimeConfig };
      }

      return require(requested);
    }) as NodeRequire;

    fakeRequire.main = fakeModule;
    (fakeModule as unknown as { require?: NodeRequire }).require = fakeRequire;

    const transpiled = transpileModule(source, {
      compilerOptions: { module: ModuleKind.CommonJS },
    }).outputText;

    const evaluate = new Function(
      'require',
      'module',
      'exports',
      '__dirname',
      '__filename',
      'process',
      'global',
      transpiled
    );

    evaluate(
      fakeRequire,
      fakeModule,
      fakeModule.exports,
      path.dirname(entryPath),
      entryPath,
      process,
      global
    );

    expect(startServer).toHaveBeenCalledTimes(1);
    expect(fakeModule.exports.startServer).toBe(startServer);
    expect(fakeModule.exports.getRuntimeConfig).toBe(getRuntimeConfig);
  });
});
