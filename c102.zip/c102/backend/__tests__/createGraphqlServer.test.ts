import crypto from 'node:crypto';

import { createSchema, createYoga } from 'graphql-yoga';

import { createGraphqlServer } from '../createGraphqlServer';
import type { BackendRuntimeConfig } from '../config/runtimeConfig';
import { createStandardsModule } from '../modules/standards';
import { createTemplateModule } from '../modules/templates';
import { createKitModule } from '../modules/kits';
import { createReferenceModule } from '../modules/reference';
import { createDesignOptimizationModule } from '../modules/designOptimization';
import { createPerformanceTimingPlugin } from '../plugins/performanceTiming';
import type { Logger } from '../shared';

jest.mock('graphql-yoga', () => ({
  createSchema: jest.fn(),
  createYoga: jest.fn(),
}));

jest.mock('../modules/standards', () => ({
  createStandardsModule: jest.fn(),
}));

jest.mock('../modules/templates', () => ({
  createTemplateModule: jest.fn(),
}));

jest.mock('../modules/kits', () => ({
  createKitModule: jest.fn(),
}));

jest.mock('../modules/reference', () => ({
  createReferenceModule: jest.fn(),
}));

jest.mock('../modules/designOptimization', () => ({
  createDesignOptimizationModule: jest.fn(),
}));

jest.mock('@amzn/global-realty-mosaic-graphql-schema', () => ({
  typeDefs: 'type Query { ping: String }',
}));

jest.mock('../plugins/performanceTiming', () => ({
  createPerformanceTimingPlugin: jest.fn(() => ({ name: 'performanceTiming' })),
}));

describe('createGraphqlServer', () => {
  const mockSchema = { kind: 'schema' } as const;
  const mockYoga = { server: 'handler' } as const;

  const mockedCreateSchema = jest.mocked(createSchema);
  const mockedCreateYoga = jest.mocked(createYoga);
  const mockedCreateStandardsModule = jest.mocked(createStandardsModule);
  const mockedCreateTemplateModule = jest.mocked(createTemplateModule);
  const mockedCreateKitModule = jest.mocked(createKitModule);
  const mockedCreateReferenceModule = jest.mocked(createReferenceModule);
  const mockedCreateDesignOptimizationModule = jest.mocked(createDesignOptimizationModule);
  const mockedCreatePerformanceTimingPlugin = jest.mocked(createPerformanceTimingPlugin);

  const config: BackendRuntimeConfig = {
    server: {
      port: 8080,
      corsOrigins: ['https://example.com'],
      publicBaseUrl: 'http://localhost:8080',
    },
    proxy: undefined,
    database: { url: 'postgresql://user:pass@localhost:5432/mosaic' },
  };

  const createMockLogger = (): jest.Mocked<Logger> => {
    const logger = {
      info: jest.fn(),
      warn: jest.fn(),
      error: jest.fn(),
      child: jest.fn(),
    } as unknown as jest.Mocked<Logger>;

    logger.child.mockReturnValue(logger);
    return logger;
  };

  const createLogger = () => {
    const requestLogger = createMockLogger();
    const graphqlLogger = createMockLogger();
    graphqlLogger.child.mockReturnValue(requestLogger);

    const rootLogger = createMockLogger();
    rootLogger.child.mockReturnValue(graphqlLogger);

    return { rootLogger, graphqlLogger, requestLogger };
  };

  beforeEach(() => {
    jest.clearAllMocks();

    mockedCreateSchema.mockReturnValue(mockSchema as never);
    mockedCreateYoga.mockReturnValue(mockYoga as never);

    mockedCreateStandardsModule.mockReturnValue({
      resolvers: { Query: { searchStandards: jest.fn() }, Mutation: { createStandard: jest.fn() } },
      service: {} as never,
    } as never);

    mockedCreateTemplateModule.mockReturnValue({
      resolvers: { Query: { searchTemplates: jest.fn() }, Mutation: { createTemplate: jest.fn() } },
      service: {} as never,
    } as never);

    mockedCreateKitModule.mockReturnValue({
      resolvers: { Query: { searchKits: jest.fn() }, Mutation: { createKit: jest.fn() } },
      service: {} as never,
    } as never);

    mockedCreateReferenceModule.mockReturnValue({
      resolvers: { Query: { attrDefs: jest.fn(), units: jest.fn() } },
      service: {} as never,
    } as never);

    mockedCreateDesignOptimizationModule.mockReturnValue({
      resolvers: { Query: { optimizeDesign: jest.fn() } },
    } as never);
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('wires schema, modules, and yoga server with provided configuration', () => {
    const { rootLogger, graphqlLogger } = createLogger();

    const result = createGraphqlServer(config, { logger: rootLogger });

    expect(rootLogger.child).toHaveBeenCalledWith({ component: 'graphql' });
    expect(mockedCreateStandardsModule).toHaveBeenCalledWith({ logger: graphqlLogger, config });
    expect(mockedCreateTemplateModule).toHaveBeenCalledWith({ logger: graphqlLogger, config });
    expect(mockedCreateKitModule).toHaveBeenCalledWith({
      logger: graphqlLogger,
      standardService: expect.any(Object),
    });
    expect(mockedCreateReferenceModule).toHaveBeenCalledWith({ logger: graphqlLogger });
    expect(mockedCreateDesignOptimizationModule).toHaveBeenCalledWith({ logger: graphqlLogger });

    expect(mockedCreateSchema).toHaveBeenCalledWith(
      expect.objectContaining({
        resolvers: expect.objectContaining({
          Query: expect.any(Object),
          Mutation: expect.any(Object),
        }),
      })
    );

    expect(mockedCreateYoga).toHaveBeenCalledWith(
      expect.objectContaining({
        schema: mockSchema,
        plugins: expect.arrayContaining([{ name: 'performanceTiming' }]),
        cors: { origin: ['https://example.com'], credentials: true },
      })
    );

    expect(result).toEqual({ schema: mockSchema, yoga: mockYoga });
  });

  it('configures performance timing plugin with correct options', () => {
    const { rootLogger, graphqlLogger } = createLogger();

    createGraphqlServer(config, { logger: rootLogger });

    expect(mockedCreatePerformanceTimingPlugin).toHaveBeenCalledWith({
      logger: graphqlLogger,
      logSlowQueries: false,
      slowQueryThreshold: 500,
    });
  });

  it('creates request scoped loggers with either supplied or generated request ids', () => {
    const { rootLogger, graphqlLogger, requestLogger } = createLogger();

    jest.spyOn(crypto, 'randomUUID').mockReturnValue('00000000-0000-0000-0000-000000000000');

    createGraphqlServer(config, { logger: rootLogger });

    const yogaCall = mockedCreateYoga.mock.calls[0];
    expect(yogaCall).toBeDefined();

    const yogaOptions = yogaCall?.[0] as Parameters<typeof createYoga>[0];
    expect(typeof yogaOptions?.context).toBe('function');

    const contextFactory = yogaOptions?.context as
      | ((args: { request: { headers: { get: (key: string) => string | null } } }) => unknown)
      | undefined;
    expect(contextFactory).toBeDefined();

    if (!contextFactory) {
      throw new Error('createGraphqlServer must configure a Yoga context factory');
    }

    const headerRequest = {
      headers: {
        get: jest.fn().mockReturnValue('trace-id'),
      },
    };

    contextFactory({ request: headerRequest });
    expect(graphqlLogger.child).toHaveBeenCalledWith({ requestId: 'trace-id' });

    headerRequest.headers.get.mockReturnValueOnce(null);
    contextFactory({ request: headerRequest });
    expect(graphqlLogger.child).toHaveBeenCalledWith({
      requestId: '00000000-0000-0000-0000-000000000000',
    });
  });
});
